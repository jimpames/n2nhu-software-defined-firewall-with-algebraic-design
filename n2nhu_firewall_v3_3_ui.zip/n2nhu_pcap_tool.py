#!/usr/bin/env python3
"""
n2nhu_pcap_tool — read N2NHU PcapNG captures offline.

Pure-Python pcapng reader; understands the comment annotations N2NHU
emits (capture_point, decision, rule_id, nat_rule_id, pbr_rule_id,
cap_rule). No third-party dependencies.

Usage:
    n2nhu_pcap_tool stats <file>
    n2nhu_pcap_tool list <file> [--limit N] [--match KEY=VAL ...]

Examples:
    n2nhu_pcap_tool stats /var/log/n2nhu/lan_egress.pcapng
    n2nhu_pcap_tool list capture.pcapng --limit 10
    n2nhu_pcap_tool list capture.pcapng --match decision=deny
    n2nhu_pcap_tool list capture.pcapng --match rule_id=p_block_blocked
"""

from __future__ import annotations

import argparse
import struct
import sys
from collections import Counter
from pathlib import Path
from typing import Iterator


# ---------------------------------------------------------------------------
# Native byte order (per the PcapNG byte-order magic — both readers and
# writers consult this in real implementations; we always emit native, so
# round-tripping our own files doesn't require detection. For files from
# foreign systems this would need to be inferred from the SHB.)
# ---------------------------------------------------------------------------

_NATIVE = "<" if sys.byteorder == "little" else ">"

BLOCK_TYPE_SHB = 0x0A0D0D0A
BLOCK_TYPE_IDB = 0x00000001
BLOCK_TYPE_EPB = 0x00000006
OPT_END = 0
OPT_COMMENT = 1


# ---------------------------------------------------------------------------
# Reader
# ---------------------------------------------------------------------------


def _parse_options(buf: bytes) -> dict[int, list[bytes]]:
    out: dict[int, list[bytes]] = {}
    i = 0
    while i + 4 <= len(buf):
        code, length = struct.unpack(_NATIVE + "HH", buf[i : i + 4])
        i += 4
        if code == OPT_END and length == 0:
            break
        out.setdefault(code, []).append(buf[i : i + length])
        i += (length + 3) & ~3
    return out


def iter_blocks(data: bytes) -> Iterator[tuple[int, bytes]]:
    i = 0
    while i + 8 <= len(data):
        block_type, total_len = struct.unpack(_NATIVE + "II", data[i : i + 8])
        if total_len < 12 or i + total_len > len(data):
            raise ValueError(f"corrupt pcapng at offset {i}")
        body = data[i + 8 : i + total_len - 4]
        yield block_type, body
        i += total_len


def parse_epb(body: bytes) -> dict:
    iface_id, ts_high, ts_low, captured_len, original_len = struct.unpack(
        _NATIVE + "IIIII", body[:20]
    )
    timestamp_us = (ts_high << 32) | ts_low
    captured = body[20 : 20 + captured_len]
    options = _parse_options(body[20 + ((captured_len + 3) & ~3):])
    comment = b""
    if OPT_COMMENT in options:
        comment = options[OPT_COMMENT][0]
    return {
        "interface_id": iface_id,
        "timestamp_us": timestamp_us,
        "captured_len": captured_len,
        "original_len": original_len,
        "captured": captured,
        "comment": comment.decode("utf-8", errors="replace"),
    }


def parse_comment_kv(comment: str) -> dict[str, str]:
    """N2NHU comments are space-separated 'key=value' pairs."""
    out: dict[str, str] = {}
    for token in comment.split():
        if "=" in token:
            k, v = token.split("=", 1)
            out[k] = v
    return out


def iter_records(path: Path) -> Iterator[dict]:
    """Yield one dict per EPB. Each dict has timestamp_us, captured,
    captured_len, original_len, comment, plus parsed kv fields."""
    data = path.read_bytes()
    for bt, body in iter_blocks(data):
        if bt != BLOCK_TYPE_EPB:
            continue
        rec = parse_epb(body)
        rec.update(parse_comment_kv(rec["comment"]))
        yield rec


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_stats(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.exists():
        print(f"file not found: {path}", file=sys.stderr)
        return 2
    records = list(iter_records(path))
    n = len(records)
    if n == 0:
        print(f"{path}: 0 frames")
        return 0

    total_orig = sum(r["original_len"] for r in records)
    total_cap = sum(r["captured_len"] for r in records)
    first_ts = min(r["timestamp_us"] for r in records)
    last_ts = max(r["timestamp_us"] for r in records)
    duration_s = (last_ts - first_ts) / 1_000_000

    by_decision: Counter = Counter(r.get("decision", "n/a") for r in records)
    by_point: Counter = Counter(r.get("capture_point", "n/a") for r in records)
    by_rule: Counter = Counter(r.get("rule_id", "n/a") for r in records)
    by_nat: Counter = Counter(r.get("nat_rule_id", "n/a") for r in records)

    print(f"file:            {path}")
    print(f"frames:          {n}")
    print(f"original bytes:  {total_orig}")
    print(f"captured bytes:  {total_cap}")
    print(f"duration:        {duration_s:.3f}s")
    print()
    print("By capture_point:")
    for k, v in by_point.most_common():
        print(f"  {k:20s} {v}")
    print("By decision:")
    for k, v in by_decision.most_common():
        print(f"  {k:20s} {v}")
    print("By policy rule_id:")
    for k, v in by_rule.most_common():
        if k:
            print(f"  {k:20s} {v}")
    print("By NAT rule_id:")
    for k, v in by_nat.most_common():
        if k:
            print(f"  {k:20s} {v}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.exists():
        print(f"file not found: {path}", file=sys.stderr)
        return 2

    # Parse --match KEY=VAL filters
    filters: list[tuple[str, str]] = []
    for m in args.match or ():
        if "=" not in m:
            print(f"bad --match {m!r}, expected KEY=VAL", file=sys.stderr)
            return 2
        k, v = m.split("=", 1)
        filters.append((k.strip(), v.strip()))

    n_shown = 0
    for i, rec in enumerate(iter_records(path), start=1):
        if filters:
            if not all(rec.get(k) == v for k, v in filters):
                continue
        ts_s = rec["timestamp_us"] / 1_000_000
        print(
            f"#{i:5d} t={ts_s:.6f}  "
            f"point={rec.get('capture_point', '-'):11s} "
            f"dec={rec.get('decision', '-'):5s} "
            f"rule={rec.get('rule_id', '-'):20s} "
            f"nat={rec.get('nat_rule_id', '-'):15s} "
            f"len={rec['original_len']}"
        )
        n_shown += 1
        if args.limit and n_shown >= args.limit:
            break

    if n_shown == 0:
        print("(no matching frames)")
    return 0


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="n2nhu_pcap_tool",
        description="Inspect N2NHU PcapNG captures offline.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_stats = sub.add_parser("stats", help="Summary stats for a file")
    p_stats.add_argument("file", help="pcapng path")
    p_stats.set_defaults(func=cmd_stats)

    p_list = sub.add_parser("list", help="List frames with optional filter")
    p_list.add_argument("file", help="pcapng path")
    p_list.add_argument("--limit", type=int, default=0,
                        help="Max frames to show (0 = no limit)")
    p_list.add_argument("--match", action="append", default=[],
                        help="Filter KEY=VAL (e.g. decision=deny)")
    p_list.set_defaults(func=cmd_list)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

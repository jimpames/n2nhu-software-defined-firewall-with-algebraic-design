#!/usr/bin/env python3
"""
router_v3.py — drop-in replacement for multi_interface_firewall_v2.py's
frame-processing core, built on n2nhu_policy.RouterShim.

The Windows-side TAP read/write plumbing is NOT here — that lives in the
existing multi_interface_firewall_v2.py and works. What this module
provides is the `process_frame(iface, bytes) -> (out_iface, out_bytes)`
logic that replaces ~200 lines of procedural NAT + firewall code.

INTEGRATION GUIDE for multi_interface_firewall_v2.py
====================================================

1. At startup, replace the firewall + NAT construction:

       # OLD:
       # self.firewall = FirewallEngine(config_path=self.config.firewall_config_path)
       # self.nat_sessions = {}
       # self.nat_reverse_lookup = {}

       # NEW:
       from n2nhu_policy import RouterShim
       self.shim = RouterShim(
           config_root="etc/n2nhu",              # directory containing zones.ini, etc.
           interface_ips={name: iface.ip for name, iface in self.taps.items()},
           interface_networks={name: iface.network for name, iface in self.taps.items()},
       )

2. Replace `process_frame()` with a thin wrapper:

       async def process_frame(self, src_interface, frame):
           decision = self.shim.process_frame(src_interface, frame)
           if decision.action == ForwardAction.FORWARD:
               await self.forward_frame(decision.egress_iface, decision.frame)
           # else drop — RouterShim already logged the reason

3. On SIGHUP (config reload):

       def reload_config(self):
           try:
               new_shim = self.shim.reload()
           except Exception as e:
               logger.error(f"reload failed, keeping old config: {e}")
               return
           self.shim = new_shim   # atomic pointer swap

The existing TAP read loop, debug PCAP capture, stats loop, signal handlers,
and Windows-specific TAP adapter code all stay exactly as they are.
What gets replaced is the ~200 lines between frame-in and frame-out.
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
import time
from ipaddress import IPv4Address, IPv4Network
from pathlib import Path

from n2nhu_policy import (
    ForwardAction,
    RouterShim,
    build_tcp_frame,
    parse_frame,
)


logger = logging.getLogger("router_v3")


def parse_interface_spec(spec: str) -> tuple[str, IPv4Address, IPv4Network]:
    """
    Parse a CLI interface spec like 'lan:192.168.1.1/24'.
    Returns (name, ip, network).
    """
    if ":" not in spec:
        raise ValueError(f"interface spec must be 'name:ip/mask', got {spec!r}")
    name, addr = spec.split(":", 1)
    net = IPv4Network(addr.strip(), strict=False)
    # For /32 specs, the IP is the network address
    ip = IPv4Address(addr.split("/")[0]) if "/" in addr else net.network_address
    return name.strip(), ip, net


def demo_loop(shim: RouterShim) -> None:
    """
    Simulates a TAP loop feeding a few synthetic frames through the shim.
    On the real Windows router, this is replaced by the existing async
    read_loop() in multi_interface_firewall_v2.py calling shim.process_frame().
    """
    print("=" * 80)
    print("Router v3 — simulated frame processing")
    print("=" * 80)
    print()

    scenarios = [
        (
            "lan",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("8.8.8.8"),
                src_port=54321, dst_port=443,
                payload=b"TLS ClientHello",
            ),
            "LAN -> internet HTTPS",
        ),
        (
            "lan",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("203.0.113.66"),  # blocklist
                src_port=54321, dst_port=80,
                payload=b"GET /",
            ),
            "LAN -> blocklisted IP (expect DROP)",
        ),
        (
            "wifi_guest",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.99.10"),
                dst_ip=IPv4Address("192.168.1.50"),
                src_port=33333, dst_port=445,
                payload=b"SMB",
            ),
            "Guest -> internal LAN (expect DROP)",
        ),
    ]

    for ingress, frame, label in scenarios:
        parsed_in = parse_frame(frame)
        decision = shim.process_frame(ingress, frame)
        print(f"  {label}")
        print(
            f"    IN:  {ingress:<10s} "
            f"{str(parsed_in.src_ip):<15s}:{parsed_in.src_port:<5d} -> "
            f"{str(parsed_in.dst_ip):<15s}:{parsed_in.dst_port}"
        )
        if decision.action == ForwardAction.FORWARD:
            parsed_out = parse_frame(decision.frame)
            print(
                f"    OUT: {decision.egress_iface:<10s} "
                f"{str(parsed_out.src_ip):<15s}:{parsed_out.src_port:<5d} -> "
                f"{str(parsed_out.dst_ip):<15s}:{parsed_out.dst_port}"
            )
            print(
                f"    -> FORWARD via policy={decision.policy_rule_id} "
                f"nat={decision.nat_rule_id or '(none)'}"
            )
        else:
            print(
                f"    -> {decision.action.value.upper()}: {decision.drop_reason}"
            )
            if decision.policy_rule_id:
                print(f"       policy rule: {decision.policy_rule_id}")
        print()

    stats = shim.get_stats()
    print("Stats:")
    print(f"  frames in       : {stats.frames_in}")
    print(f"  forwarded       : {stats.frames_forwarded}")
    print(f"  dropped         : {stats.frames_dropped}")
    print(f"  parse errors    : {stats.parse_errors}")
    print(f"  policy denies   : {stats.policy_denies}")
    print(f"  NAT translations: {stats.nat_translations}")
    print(f"  active sessions : {shim.session_count()}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="N2NHU Router v3 — INI-driven firewall with NAT",
    )
    parser.add_argument(
        "--config-root", type=Path, default=Path("fixtures"),
        help="Root of the INI config tree",
    )
    parser.add_argument(
        "--interface", "-i", action="append", default=[], metavar="NAME:IP/MASK",
        help="Interface definition, e.g. --interface lan:192.168.1.1/24. "
             "Repeat for each interface.",
    )
    parser.add_argument(
        "--demo", action="store_true",
        help="Run the built-in demo loop with synthetic frames",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Enable debug logging",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )

    # Default interfaces if none given (matches fixtures)
    if not args.interface:
        defaults = [
            "lan:192.168.1.1/24",
            "wifi_corp:192.168.2.1/24",
            "dmz:172.16.0.1/24",
            "wifi_guest:192.168.99.1/24",
            "mgt:10.255.0.1/24",
            "wan2:203.0.113.2/24",
            "wan1:203.0.113.1/0",  # /0 = default route
        ]
        args.interface = defaults

    interface_ips: dict[str, IPv4Address] = {}
    interface_networks: dict[str, IPv4Network] = {}
    for spec in args.interface:
        name, ip, network = parse_interface_spec(spec)
        interface_ips[name] = ip
        interface_networks[name] = network

    logger.info(
        "Starting router v3 with %d interfaces: %s",
        len(interface_ips), ", ".join(interface_ips.keys()),
    )

    try:
        shim = RouterShim(args.config_root, interface_ips, interface_networks)
    except Exception as e:
        logger.error("failed to load config: %s", e)
        return 1

    logger.info(
        "Loaded %d policy rules, %d NAT rules",
        len(shim.policy_config.policies),
        len(shim.nat_config.rules),
    )

    # Install SIGHUP handler for reload (Linux/Mac; Windows will just skip)
    if hasattr(signal, "SIGHUP"):
        def handle_sighup(signum, frame):
            nonlocal shim
            logger.info("SIGHUP received — reloading config")
            try:
                shim = shim.reload()
                logger.info("reload complete")
            except Exception as e:
                logger.error("reload failed: %s (keeping old config)", e)
        signal.signal(signal.SIGHUP, handle_sighup)

    if args.demo:
        demo_loop(shim)
        return 0

    print()
    print("Router v3 ready. Integrate with multi_interface_firewall_v2.py:")
    print("  - replace process_frame() body with:")
    print("      decision = self.shim.process_frame(src_iface, frame)")
    print("      if decision.action == ForwardAction.FORWARD:")
    print("          await self.forward_frame(decision.egress_iface, decision.frame)")
    print()
    print("Or run this script with --demo to see the shim in action.")
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Router v2 → v3 Cutover Guide

How to migrate `multi_interface_firewall_v2.py` to use the `RouterShim` from `n2nhu_policy`.

**Net change: replace ~300 lines of procedural NAT/firewall code with ~15 lines that call the shim.**

The existing TAP adapter code, Windows-specific `CreateFile` handles, debug PCAP capture, async read loop, and stats reporter all stay untouched. What gets replaced is the packet-processing brain between "frame came in from a TAP" and "frame goes out to another TAP".

---

## Prerequisites

1. Unzip `n2nhu_firewall_router_v3.zip` somewhere the router can import it. Simplest: drop the `n2nhu_policy/` directory and the `fixtures/` directory next to `multi_interface_firewall_v2.py`.
2. Create a config directory (or use the supplied `fixtures/` directly) containing:
   ```
   etc/n2nhu/
     zones.ini
     objects/
       addresses.ini
       services.ini
       schedules.ini
     policies/
       security.ini
       nat.ini
   ```
3. Edit `zones.ini` so its `[zones]` section lists your actual interface names (`lan`, `wan1`, `dmz`, etc.) matching what you pass to the TAP adapter setup.

---

## Step 1 — Imports (top of `multi_interface_firewall_v2.py`)

**ADD:**

```python
from n2nhu_policy import (
    ForwardAction,
    RouterShim,
    parse_frame,
    FrameParseError,
)
```

**REMOVE** (or leave dead — they're no longer called):

```python
# The module-level checksum functions — now live in n2nhu_policy.checksum
# def calculate_ip_checksum(header: bytes) -> int: ...
# def calculate_tcp_checksum(src_ip, dst_ip, tcp_segment) -> int: ...
# def calculate_udp_checksum(src_ip, dst_ip, udp_datagram) -> int: ...

# The NATSession dataclass — n2nhu_policy has its own
# @dataclass class NATSession: ...
```

These can stay for now; the shim doesn't use them and deleting can come later.

---

## Step 2 — Replace `__init__` body (roughly lines 238–292)

**OLD:**

```python
class MultiInterfaceFirewallV2:
    def __init__(self, config_file: str):
        # ... load firewall_router_v2.ini ...
        self.config = self._load_config(config_file)
        self.firewall = FirewallEngine(config_path=self.config.firewall_config_path)
        # NAT state
        self.nat_sessions: Dict[str, NATSession] = {}
        self.nat_reverse_lookup: Dict[Tuple[str, int], str] = {}
        self.nat_lock = threading.Lock()
        # ... TAP setup ...
```

**NEW:**

```python
class MultiInterfaceFirewallV2:
    def __init__(self, config_file: str, policy_root: str = "etc/n2nhu"):
        # Existing code: load firewall_router_v2.ini for TAP/interface info
        self.config = self._load_config(config_file)

        # NEW: build the shim from our interface definitions
        interface_ips = {
            name: IPv4Address(iface.ip_address)
            for name, iface in self.config.interfaces.items()
        }
        interface_networks = {
            name: IPv4Network(f"{iface.ip_address}/{iface.netmask_prefix}", strict=False)
            for name, iface in self.config.interfaces.items()
        }
        # Make wan1 (or your default-route iface) actually the default
        if "wan1" in interface_networks:
            interface_networks["wan1"] = IPv4Network("0.0.0.0/0")

        self.shim = RouterShim(
            config_root=policy_root,
            interface_ips=interface_ips,
            interface_networks=interface_networks,
        )

        # REMOVED: self.firewall, self.nat_sessions, self.nat_reverse_lookup, self.nat_lock
        # All of that is now inside self.shim.

        # Existing code: TAP init, stats, etc. stays
        self._init_tap_devices()
        self.stats = RouterStats()
        self.running = False
```

---

## Step 3 — Replace `process_frame` (lines ~679–725)

This is the big one. The old `process_frame` is ~50 lines of "if SNAT call apply_nat; else if DNAT call apply_nat; else forward". The new version is 10 lines.

**OLD:**

```python
async def process_frame(self, src_interface: str, frame: bytes):
    try:
        self.stats.frames_rx[src_interface] += 1
        self.stats.bytes_rx[src_interface] += len(frame)
        if self.debug:
            self.debug.on_frame(f"{src_interface}_RX", frame)

        packet = self.frame_to_packet(frame, src_interface)
        if not packet:
            self.stats.drops['non_ip'] += 1
            return

        action, policy_id = self.firewall.process_packet(packet)
        self.stats.actions[action.value] += 1

        if action == Action.ALLOW:
            needs_nat, nat_type = self.needs_nat(src_interface, packet.dst_interface)
            if needs_nat and nat_type == 'SNAT':
                dst_config = self.config.interfaces[packet.dst_interface]
                modified = self.apply_nat_to_frame(frame, packet, 'SNAT', dst_config)
                await self.forward_frame(packet.dst_interface, modified)
            elif needs_nat and nat_type == 'DNAT':
                dst_config = self.config.interfaces[packet.dst_interface]
                modified = self.apply_nat_to_frame(frame, packet, 'DNAT', dst_config)
                await self.forward_frame(packet.dst_interface, modified)
            else:
                await self.forward_frame(packet.dst_interface, frame)
        else:
            self.stats.drops[action.value] += 1
            if self.debug:
                self.debug.drop(f"{action.value}_{policy_id}")
    except Exception as e:
        logger.error(f"Error processing frame from {src_interface}: {e}")
        self.stats.drops['error'] += 1
```

**NEW:**

```python
async def process_frame(self, src_interface: str, frame: bytes):
    try:
        self.stats.frames_rx[src_interface] += 1
        self.stats.bytes_rx[src_interface] += len(frame)
        if self.debug:
            self.debug.on_frame(f"{src_interface}_RX", frame)

        decision = self.shim.process_frame(src_interface, frame)

        if decision.action == ForwardAction.FORWARD:
            await self.forward_frame(decision.egress_iface, decision.frame)
        else:
            self.stats.drops[decision.action.value] += 1
            if self.debug:
                reason = decision.policy_rule_id or decision.nat_rule_id or decision.drop_reason
                self.debug.drop(f"{decision.action.value}_{reason}")
    except Exception as e:
        logger.error(f"Error processing frame from {src_interface}: {e}")
        self.stats.drops['error'] += 1
```

That's the whole brain. The shim parses the frame, does route lookup, NAT-translates, policy-evaluates, rewrites checksums, and hands back either `FORWARD + rewritten_bytes + egress_iface` or a drop with a reason.

---

## Step 4 — DELETE these methods entirely (lines ~452–677)

None of this is used anymore:

- `needs_nat()` — the NAT engine decides what to NAT based on the rule matrix, not interface type comparisons.
- `create_nat_session()` — session table lives in `shim.nat_engine.session_table`.
- `lookup_nat_session()` — same.
- `apply_nat_to_frame()` — replaced by `n2nhu_policy.frame_codec` (and it's now byte-exact-tested against real frames).
- `_allocate_nat_port()` — the old `random.randint` version that can produce collisions. Replaced by `PortPool` with thread-safe FIFO allocation and guaranteed no-collision.
- `frame_to_packet()` — replaced by `parse_frame()` which produces a fully-typed `ParsedFrame`.

You can either delete these or comment them out. I recommend deleting — if anything still imports them, the error surfaces immediately rather than lurking.

---

## Step 5 — Add SIGHUP reload (optional but useful on Linux)

Somewhere in `run()` or `__init__`, after the shim is built:

```python
if hasattr(signal, 'SIGHUP'):
    def _reload_handler(signum, frame):
        logger.info("SIGHUP received — reloading config")
        try:
            self.shim = self.shim.reload()
            logger.info("Config reload OK")
        except Exception as e:
            logger.error(f"Config reload failed (keeping old): {e}")
    signal.signal(signal.SIGHUP, _reload_handler)
```

On Windows, use a file-watcher or a small REST endpoint instead — SIGHUP doesn't exist there.

---

## Step 6 — Update `get_statistics`

**ADD** shim stats to the output:

```python
def get_statistics(self) -> Dict:
    stats = {
        # existing TAP-level counters
        'elapsed_seconds': time.time() - self.stats.start_time,
        'frames_rx': dict(self.stats.frames_rx),
        'frames_tx': dict(self.stats.frames_tx),
        'drops': dict(self.stats.drops),
    }
    # NEW: add shim stats
    shim_stats = self.shim.get_stats()
    stats.update({
        'shim_frames_in': shim_stats.frames_in,
        'shim_frames_forwarded': shim_stats.frames_forwarded,
        'shim_frames_dropped': shim_stats.frames_dropped,
        'shim_parse_errors': shim_stats.parse_errors,
        'shim_policy_denies': shim_stats.policy_denies,
        'shim_nat_translations': shim_stats.nat_translations,
        'shim_nat_denies': shim_stats.nat_denies,
        'shim_active_sessions': self.shim.session_count(),
        'shim_policy_hits': self.shim.policy_stats.as_dict(),
    })
    return stats
```

---

## Step 7 — Start the session reaper

Right before the async `run()` event loop starts:

```python
self.shim.nat_engine.session_table.start_reaper()
```

And in `stop()`:

```python
self.shim.nat_engine.session_table.stop_reaper()
```

This gives you automatic session-cleanup every 10 seconds — expired flows get evicted, their ports go back to the pool.

---

## What to test after cutover

On the Windows box, before flipping to production traffic:

1. **Config loads.** `python multi_interface_firewall_v2.py --config firewall_router_v2.ini` should print "Loaded N policy rules, M NAT rules" and not crash.
2. **SNAT round-trip.** Ping 8.8.8.8 from a LAN client. Capture WAN side with Wireshark. Verify src IP was rewritten to the WAN IP and the ICMP reply came back to the LAN client.
3. **DNAT.** From an external host (or a simulated one on your WAN network), curl `http://<public_ip>:80`. Verify the request hit the DMZ webserver and the response came back.
4. **Policy block.** Try to reach `203.0.113.66` (the blocklisted IP in the fixture) from a LAN host. Wireshark should show no packet on WAN. Router log should show "policy DROP via p010_block_malware".
5. **Session reuse.** Hit the same external host 10 times from the same LAN client with the same source port. `shim.session_count()` should show 1, not 10.
6. **Reaper working.** Leave it running 5 minutes, grep logs for any long-idle sessions. Half-open TCP should evict at 30s, UDP at 180s, established TCP at 3600s.

---

## Rollback plan

If anything goes sideways, the cutover is one `git revert` away. Keep `multi_interface_firewall_v2.py` unchanged until the new version is verified working, then rename it `multi_interface_firewall_v2_legacy.py` and only then remove the old NAT methods.

---

## What you gain

- **Byte-exact tested NAT.** 36 frame-codec tests verify that rewrites produce valid IP and TCP/UDP checksums on real Ethernet frames. The old `_allocate_nat_port` used `random.randint` which can collide and cause session corruption — this is fixed.
- **Correct session reuse.** Old code created a new session on every packet (the reverse lookup only stored last one). New code reuses the session for every packet of the same 5-tuple.
- **Port pool with overflow chain.** When the primary pool fills up, the engine tries configured backup pools. Old code just rolled more random numbers.
- **Schedule-aware rules.** Policies can now gate on time of day (business hours, maintenance windows).
- **Hot reload.** SIGHUP reloads the full config without dropping traffic in progress, atomic pointer swap.
- **209+36 test suite** that runs in 3 seconds and proves the engine's correctness before you ship changes.

— J P Ames & Claude, April 2026

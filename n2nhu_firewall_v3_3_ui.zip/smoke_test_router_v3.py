#!/usr/bin/env python3
"""
smoke_test_router_v3.py — Exercise multi_interface_firewall_v3 without real TAPs.

We stub out TapDevice, DebugCapture, and DebugSettings, then run the v3 router's
process_frame() directly on synthetic Ethernet frames. This catches any wiring
bugs in the v3 script before it touches the Windows box.

Run:
    python3 smoke_test_router_v3.py

On the Windows box, this is NOT needed — just run
`python multi_interface_firewall_v3.py --config firewall_router_v2.ini`
and traffic flows. This script is only to verify the v3 glue file is correct.
"""

from __future__ import annotations

import asyncio
import logging
import sys
import tempfile
from ipaddress import IPv4Address
from pathlib import Path

# Silence noisy logging for the test
logging.basicConfig(level=logging.WARNING)


# ---------------------------------------------------------------------------
# Stub out Windows-only dependencies before importing v3 router
# ---------------------------------------------------------------------------


class _StubTapDevice:
    """In-memory TAP device — read_frame/write_frame work against a deque."""

    def __init__(self, name: str):
        self.name = name
        self.tx_frames: list[bytes] = []
        self.rx_queue: list[bytes] = []
        self._opened = False

    def open(self):
        self._opened = True

    def read_frame(self, timeout_ms: int = 100):
        if self.rx_queue:
            return self.rx_queue.pop(0)
        return None

    def write_frame(self, frame: bytes, timeout_ms: int = 100):
        self.tx_frames.append(frame)

    def close(self):
        self._opened = False


class _StubDebugCapture:
    def __init__(self, settings):
        pass
    def on_frame(self, label, frame): pass
    def drop(self, reason): pass
    def close(self): pass


class _StubDebugSettings:
    def __init__(self, **kwargs):
        pass


# Install stubs into sys.modules BEFORE importing the v3 router
class _StubVPNModule:
    TapDevice = _StubTapDevice

class _StubDebugModule:
    DebugCapture = _StubDebugCapture
    DebugSettings = _StubDebugSettings


sys.modules["vpn_server_v3_debug"] = _StubVPNModule()
sys.modules["vpn_debug"] = _StubDebugModule()


# ---------------------------------------------------------------------------
# Now import v3 router and n2nhu_policy
# ---------------------------------------------------------------------------


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from n2nhu_policy import build_tcp_frame, parse_frame, verify_frame_checksums
import multi_interface_firewall_v3 as router_module


# ---------------------------------------------------------------------------
# Build a working v2-style INI for the interface/TAP layer
# ---------------------------------------------------------------------------


V2_INI = """
[interfaces]
lan = TAP-LAN
wan1 = TAP-WAN1
dmz = TAP-DMZ
wifi_guest = TAP-GUEST
wifi_corp = TAP-CORP
mgt = TAP-MGT
wan2 = TAP-WAN2

[interface_lan]
type = LAN
network = 192.168.1.0/24
ip_address = 192.168.1.1
enabled = true

[interface_wan1]
type = WAN
network = 203.0.113.0/24
ip_address = 203.0.113.1
enabled = true

[interface_wan2]
type = WAN
network = 198.51.100.0/24
ip_address = 198.51.100.1
enabled = true

[interface_dmz]
type = DMZ
network = 172.16.0.0/24
ip_address = 172.16.0.1
enabled = true

[interface_wifi_guest]
type = LAN
network = 192.168.99.0/24
ip_address = 192.168.99.1
enabled = true

[interface_wifi_corp]
type = LAN
network = 192.168.2.0/24
ip_address = 192.168.2.1
enabled = true

[interface_mgt]
type = MGT
network = 10.255.0.0/24
ip_address = 10.255.0.1
enabled = true

[routing]
default_interface = wan1

[firewall]
policy_config_root = fixtures

[debug]
enabled = false
pcap_enable = false
pcap_file = /tmp/smoke.pcap
frame_trace = false
stats_interval_sec = 0
"""


def _write_ini(tmp_dir: Path) -> Path:
    path = tmp_dir / "firewall_router_v2.ini"
    path.write_text(V2_INI)
    return path


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------


def run_scenario(router, ingress: str, frame: bytes, label: str):
    """Drive one frame through process_frame() and report what happened."""
    # Clear tx buffers
    for t in router.taps.values():
        t.tx_frames.clear()

    # Run the async method synchronously
    asyncio.run(router.process_frame(ingress, frame))

    # Inspect outcomes across all egress TAPs
    emitted: list[tuple[str, bytes]] = []
    for name, tap in router.taps.items():
        for f in tap.tx_frames:
            emitted.append((name, f))

    in_parsed = parse_frame(frame)
    print(f"  {label}")
    print(
        f"    IN : {ingress:<11s} "
        f"{str(in_parsed.src_ip):<15s}:{in_parsed.src_port:<5d} -> "
        f"{str(in_parsed.dst_ip):<15s}:{in_parsed.dst_port}"
    )
    if emitted:
        for egress, out_frame in emitted:
            out_parsed = parse_frame(out_frame)
            ip_ok, l4_ok = verify_frame_checksums(out_frame)
            print(
                f"    OUT: {egress:<11s} "
                f"{str(out_parsed.src_ip):<15s}:{out_parsed.src_port:<5d} -> "
                f"{str(out_parsed.dst_ip):<15s}:{out_parsed.dst_port}  "
                f"[IP cs={'OK' if ip_ok else 'BAD'}, L4 cs={'OK' if l4_ok else 'BAD'}]"
            )
    else:
        print(f"    -> DROPPED (no frame emitted on any TAP)")
    print()


def main():
    print("=" * 80)
    print("Smoke test: multi_interface_firewall_v3.py with mock TAPs")
    print("=" * 80)
    print()

    with tempfile.TemporaryDirectory() as tmp:
        ini_path = _write_ini(Path(tmp))
        print(f"Using stub INI: {ini_path}")
        print(f"Using policy fixtures at: {ROOT / 'fixtures'}")
        print()

        # Build the router. This runs the full v3 __init__ including RouterShim
        # construction from the fixtures, TAP (stub) opens, and reaper thread.
        # The only reason it runs is because our stubs are installed above.
        router = router_module.MultiInterfaceFirewallV3(str(ini_path))

        try:
            # Tell the v3 code's policy_root to look at our bundled fixtures
            # (Override after construction if needed — but _load_config already
            # read it from the INI.)

            print("-" * 80)
            print("Scenarios")
            print("-" * 80)
            print()

            # Scenario 1: LAN client → internet (expect SNAT forward on wan1)
            f1 = build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("8.8.8.8"),
                src_port=54321, dst_port=443,
                payload=b"TLS ClientHello",
            )
            run_scenario(router, "lan", f1, "LAN -> internet HTTPS (expect SNAT)")

            # Scenario 2: LAN client → blocklisted IP (expect DROP)
            f2 = build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("203.0.113.66"),
                src_port=54321, dst_port=80,
                payload=b"GET /",
            )
            run_scenario(router, "lan", f2, "LAN -> blocklisted IP (expect DROP)")

            # Scenario 3: Guest → internal LAN (expect DROP)
            f3 = build_tcp_frame(
                src_ip=IPv4Address("192.168.99.10"),
                dst_ip=IPv4Address("192.168.1.50"),
                src_port=33333, dst_port=445,
                payload=b"SMB",
            )
            run_scenario(router, "wifi_guest", f3, "Guest -> internal LAN (expect DROP)")

            # Scenario 4: Session reuse
            print("Session reuse check (5 packets same flow)")
            for _ in range(5):
                asyncio.run(router.process_frame("lan", f1))
            print(f"  session count after 6 total forward packets: {router.shim.session_count()}")
            print(f"  (should be 1 — one flow)")
            print()

            # Stats
            print("-" * 80)
            print("Final stats")
            print("-" * 80)
            s = router.get_statistics()
            print(f"  TAP drops     : {s['tap']['drops']}")
            print(f"  Shim in       : {s['shim']['frames_in']}")
            print(f"  Shim forwarded: {s['shim']['frames_forwarded']}")
            print(f"  Shim dropped  : {s['shim']['frames_dropped']}")
            print(f"  NAT xlations  : {s['shim']['nat_translations']}")
            print(f"  Policy hits   : {s['policy_hits']['by_rule']}")
            print()

            # Reload test
            print("-" * 80)
            print("Reload test (invokes SIGHUP path synchronously)")
            print("-" * 80)
            router._sighup_handler(None, None)
            print("  -> reload completed without error")
            print()

        finally:
            router.stop()

    print("=" * 80)
    print("SMOKE TEST PASSED — v3 wiring is correct")
    print("=" * 80)
    return 0


if __name__ == "__main__":
    sys.exit(main())

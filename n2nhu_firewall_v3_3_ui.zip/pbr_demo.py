#!/usr/bin/env python3
"""
pbr_demo.py — Walk packets through the PBR engine with readable output.

Shows how PBR matches override the default destination-IP routing, using
the same object vocabulary (zones, addresses, services, schedules) as
policy and NAT, plus the new DSCP criterion.
"""

from __future__ import annotations

import sys
from datetime import datetime
from ipaddress import IPv4Address
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from n2nhu_policy import (
    ConfigLoader,
    DSCPMatchMode,
    Packet,
    PBRConfigLoader,
    PBREngine,
    PBRMatch,
    PBRPassThrough,
    Protocol,
)


NY = ZoneInfo("America/New_York")
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)
WEEKEND = datetime(2026, 2, 22, 10, 0, tzinfo=NY)


def _supports_color() -> bool:
    return sys.stdout.isatty()


def _c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _supports_color() else text


def _pkt(**kw):
    return Packet(
        ingress_iface=kw["ingress"],
        egress_iface=kw.get("egress", "wan1"),  # default route
        src_ip=IPv4Address(kw["src"]),
        dst_ip=IPv4Address(kw["dst"]),
        protocol=kw.get("proto", Protocol.TCP),
        src_port=kw.get("sport", 54321),
        dst_port=kw.get("dport", 443),
        icmp_type=kw.get("icmp"),
        dscp=kw.get("dscp", 0),
    )


def _describe(p: Packet) -> str:
    proto = p.protocol.value.upper()
    return (
        f"{p.ingress_iface:>10s} (route={p.egress_iface:<5s}) "
        f"{str(p.src_ip):<15s}:{p.src_port:<5d} -> "
        f"{str(p.dst_ip):<15s}:{p.dst_port} {proto} DSCP={p.dscp}"
    )


def _describe_result(r) -> str:
    if isinstance(r, PBRMatch):
        return _c("OVERRIDE", "32") + f" -> egress={r.egress_iface:<5s}  via {r.rule_id}"
    return _c("PASS    ", "33") + " (use default route)"


SCENARIOS = [
    (
        "VoIP call from LAN (DSCP EF=46)",
        _pkt(ingress="lan", src="192.168.1.20", dst="8.8.8.8",
             proto=Protocol.UDP, sport=5060, dport=5060, dscp=46),
        BIZ,
    ),
    (
        "Regular LAN HTTPS (no DSCP)",
        _pkt(ingress="lan", src="192.168.1.10", dst="8.8.8.8", dport=443),
        BIZ,
    ),
    (
        "Guest WiFi to internet",
        _pkt(ingress="wifi_guest", src="192.168.99.5", dst="1.1.1.1", dport=443),
        BIZ,
    ),
    (
        "Admin workstation (business hours)",
        _pkt(ingress="lan", src="192.168.1.50", dst="8.8.8.8", dport=443),
        BIZ,
    ),
    (
        "Admin workstation (weekend — schedule miss)",
        _pkt(ingress="lan", src="192.168.1.50", dst="8.8.8.8", dport=443),
        WEEKEND,
    ),
    (
        "Lab host with AF31 DSCP (28) — in range",
        _pkt(ingress="lan", src="192.168.1.150", dst="8.8.8.8",
             dport=443, dscp=28),
        BIZ,
    ),
    (
        "Lab host with DSCP 10 — out of range",
        _pkt(ingress="lan", src="192.168.1.150", dst="8.8.8.8",
             dport=443, dscp=10),
        BIZ,
    ),
]


def main() -> int:
    print("=" * 96)
    print("N2NHU PBR Engine — demo walkthrough")
    print("=" * 96)
    print()

    pcfg = ConfigLoader(ROOT / "fixtures").load()
    pbr_cfg = PBRConfigLoader(ROOT / "fixtures", pcfg).load()
    engine = PBREngine(pcfg, pbr_cfg)

    print(f"Loaded PBR config: {len(pbr_cfg.rules)} rules")
    for r in pbr_cfg.rules:
        dscp_desc = ""
        if r.dscp_mode == DSCPMatchMode.EQUAL:
            dscp_desc = f" DSCP={r.dscp_value}"
        elif r.dscp_mode == DSCPMatchMode.RANGE:
            dscp_desc = f" DSCP={r.dscp_min}-{r.dscp_max}"
        print(f"  {r.id:<34s} -> {r.egress_iface:<5s}  src_addr={r.src_addr:<25s} {dscp_desc}")
    print()
    print("-" * 96)

    for i, (label, pkt, now) in enumerate(SCENARIOS, 1):
        r = engine.route_override(pkt, now)
        print()
        print(f"[{i}] {label}")
        print(f"    IN : {_describe(pkt)}")
        print(f"    OUT: {_describe_result(r)}")

    print()
    print("-" * 96)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Tests for PortPool — allocation, release, exhaustion, concurrency."""

from __future__ import annotations

import threading

import pytest

from n2nhu_policy import PortPool, PortPoolExhausted, PortPoolSpec


class TestBasicAllocation:
    def test_allocate_returns_port_in_range(self):
        pool = PortPool(PortPoolSpec(10000, 10010))
        port = pool.allocate()
        assert 10000 <= port <= 10010

    def test_sequential_allocations_are_distinct(self):
        pool = PortPool(PortPoolSpec(10000, 10003))
        ports = {pool.allocate() for _ in range(4)}
        assert ports == {10000, 10001, 10002, 10003}

    def test_exhaustion_raises(self):
        pool = PortPool(PortPoolSpec(10000, 10001))
        pool.allocate()
        pool.allocate()
        with pytest.raises(PortPoolExhausted):
            pool.allocate()

    def test_release_allows_reallocation(self):
        pool = PortPool(PortPoolSpec(10000, 10001))
        p1 = pool.allocate()
        p2 = pool.allocate()
        pool.release(p1)
        p3 = pool.allocate()
        assert p3 == p1

    def test_fifo_reuse(self):
        """Released ports go to the back of the queue (avoids TIME_WAIT collision)."""
        pool = PortPool(PortPoolSpec(10000, 10002))
        p1 = pool.allocate()
        p2 = pool.allocate()
        p3 = pool.allocate()
        # Release in order
        pool.release(p1)
        pool.release(p2)
        pool.release(p3)
        # Should come back in FIFO order
        assert pool.allocate() == p1
        assert pool.allocate() == p2
        assert pool.allocate() == p3

    def test_release_unknown_port_is_noop(self):
        pool = PortPool(PortPoolSpec(10000, 10001))
        pool.release(99999)  # never allocated, never released
        # Pool should still be full
        assert pool.available() == 2


class TestMetrics:
    def test_available_tracks_free_count(self):
        pool = PortPool(PortPoolSpec(10000, 10004))
        assert pool.available() == 5
        pool.allocate()
        assert pool.available() == 4
        pool.allocate()
        assert pool.available() == 3

    def test_in_use_tracks_allocated(self):
        pool = PortPool(PortPoolSpec(10000, 10004))
        assert pool.in_use() == 0
        pool.allocate()
        pool.allocate()
        assert pool.in_use() == 2

    def test_utilization(self):
        pool = PortPool(PortPoolSpec(10000, 10003))  # 4 ports
        assert pool.utilization() == 0.0
        pool.allocate()
        assert pool.utilization() == 0.25
        pool.allocate()
        pool.allocate()
        pool.allocate()
        assert pool.utilization() == 1.0

    def test_is_exhausted(self):
        pool = PortPool(PortPoolSpec(10000, 10001))
        assert not pool.is_exhausted()
        pool.allocate()
        pool.allocate()
        assert pool.is_exhausted()


class TestConcurrency:
    def test_no_duplicate_allocations_under_threads(self):
        pool = PortPool(PortPoolSpec(10000, 11999))  # 2000 ports
        results: list[int] = []
        results_lock = threading.Lock()

        def worker():
            for _ in range(200):
                try:
                    p = pool.allocate()
                    with results_lock:
                        results.append(p)
                except PortPoolExhausted:
                    return

        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All 2000 ports allocated, zero duplicates
        assert len(results) == 2000
        assert len(set(results)) == 2000
        assert pool.is_exhausted()


class TestValidation:
    def test_invalid_pool_range_rejected(self):
        with pytest.raises(ValueError, match="out of range"):
            PortPoolSpec(100, 50)  # end < start

    def test_port_zero_rejected(self):
        with pytest.raises(ValueError):
            PortPoolSpec(0, 100)

    def test_port_above_65535_rejected(self):
        with pytest.raises(ValueError):
            PortPoolSpec(60000, 70000)

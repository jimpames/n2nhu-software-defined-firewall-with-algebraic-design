"""Tests for PBREngine — route_override() pure function."""

from __future__ import annotations

from datetime import datetime
from ipaddress import IPv4Address
from zoneinfo import ZoneInfo

import pytest

from n2nhu_policy import (
    ConfigLoader,
    Packet,
    PBRConfigLoader,
    PBREngine,
    PBRMatch,
    PBRPassThrough,
    Protocol,
)

NY = ZoneInfo("America/New_York")
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)      # business hours
WEEKEND = datetime(2026, 2, 22, 10, 0, tzinfo=NY)  # Sunday


@pytest.fixture
def policy_config(fixture_root):
    return ConfigLoader(fixture_root).load()


@pytest.fixture
def pbr_engine(fixture_root, policy_config):
    pbr_cfg = PBRConfigLoader(fixture_root, policy_config).load()
    return PBREngine(policy_config, pbr_cfg)


def _pkt(**kw):
    return Packet(
        ingress_iface=kw.get("ingress", "lan"),
        egress_iface=kw.get("egress", "wan1"),
        src_ip=IPv4Address(kw.get("src", "192.168.1.10")),
        dst_ip=IPv4Address(kw.get("dst", "8.8.8.8")),
        protocol=kw.get("proto", Protocol.TCP),
        src_port=kw.get("sport", 54321),
        dst_port=kw.get("dport", 443),
        icmp_type=kw.get("icmp"),
        dscp=kw.get("dscp", 0),
    )


class TestDSCPEqualMatch:
    def test_voip_ef_redirects_to_wan2(self, pbr_engine):
        # VoIP with DSCP 46 (EF) from anywhere should hit pbr010
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.20", dst="1.1.1.1", dscp=46), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr010_voip_to_wan2"
        assert r.egress_iface == "wan2"

    def test_non_ef_dscp_skips_voip_rule(self, pbr_engine):
        # DSCP 0 should NOT match pbr010 (which requires dscp=46)
        r = pbr_engine.route_override(_pkt(dscp=0), BIZ)
        # But other rules might match. For 192.168.1.10 (random LAN), none do.
        assert isinstance(r, PBRPassThrough)

    def test_ef_from_guest_still_hits_voip_rule(self, pbr_engine):
        # Guest VoIP: pbr010 has src_zone=any, so it matches before pbr020
        r = pbr_engine.route_override(
            _pkt(ingress="wifi_guest", src="192.168.99.5", dscp=46), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr010_voip_to_wan2"


class TestZoneAndAddressMatch:
    def test_guest_no_dscp_routes_via_wan2(self, pbr_engine):
        r = pbr_engine.route_override(
            _pkt(ingress="wifi_guest", src="192.168.99.5", dst="1.1.1.1"),
            BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr020_guest_out_wan2"
        assert r.egress_iface == "wan2"

    def test_admin_workstation_routes_via_wan1(self, pbr_engine):
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.50", dst="8.8.8.8"), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr030_admin_via_wan1"
        assert r.egress_iface == "wan1"

    def test_admin_outside_business_hours_no_match(self, pbr_engine):
        # pbr030 only fires during business hours
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.50", dst="8.8.8.8"), WEEKEND,
        )
        assert isinstance(r, PBRPassThrough)


class TestDSCPRangeMatch:
    def test_lab_range_with_af31_matches(self, pbr_engine):
        # Lab host (192.168.1.150) with DSCP 26 (AF31) → pbr040
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.150", dscp=26), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr040_lab_range_high_dscp"

    def test_lab_range_af33_still_in_range(self, pbr_engine):
        # DSCP 30 (AF33) is the upper bound of the range
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.150", dscp=30), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr040_lab_range_high_dscp"

    def test_lab_range_dscp_below_range(self, pbr_engine):
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.150", dscp=24), BIZ,
        )
        # Lab host, DSCP 24 — below range 26-30, no match
        assert isinstance(r, PBRPassThrough)

    def test_lab_range_dscp_above_range(self, pbr_engine):
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.150", dscp=32), BIZ,
        )
        assert isinstance(r, PBRPassThrough)

    def test_non_lab_host_with_af31_no_match(self, pbr_engine):
        # Host OUTSIDE the lab range with matching DSCP — pbr040 shouldn't fire
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.99", dscp=28), BIZ,
        )
        # But wait — 192.168.1.99 with DSCP 28 still might hit admin rule if it's the admin
        # 192.168.1.99 is NOT the admin workstation (that's .50), NOT in lab range (.100-.200)
        # No DSCP match — passthrough
        assert isinstance(r, PBRPassThrough)


class TestFirstMatchWins:
    def test_voip_beats_guest(self, pbr_engine):
        """
        Guest with DSCP EF — both pbr010 (EF) and pbr020 (guest) could match.
        pbr010 is listed first, so it wins.
        """
        r = pbr_engine.route_override(
            _pkt(ingress="wifi_guest", src="192.168.99.5", dscp=46), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr010_voip_to_wan2"

    def test_admin_beats_lab_range(self, pbr_engine):
        """
        Admin workstation IS NOT in the lab range (.50 vs .100-.200),
        so this is a different scenario. Test pbr030 fires for the admin.
        """
        # Admin WS with DSCP 28 — only pbr030 should match (src_addr = admin)
        # pbr040 wouldn't match because admin WS isn't in the lab range
        r = pbr_engine.route_override(
            _pkt(src="192.168.1.50", dscp=28), BIZ,
        )
        assert isinstance(r, PBRMatch)
        assert r.rule_id == "pbr030_admin_via_wan1"


class TestNoMatch:
    def test_random_host_no_dscp_no_match(self, pbr_engine):
        r = pbr_engine.route_override(_pkt(src="192.168.1.99"), BIZ)
        assert isinstance(r, PBRPassThrough)

    def test_stateless_no_session_side_effects(self, pbr_engine):
        """PBR should never mutate state. Two identical calls produce identical results."""
        r1 = pbr_engine.route_override(_pkt(src="192.168.1.20", dscp=46), BIZ)
        r2 = pbr_engine.route_override(_pkt(src="192.168.1.20", dscp=46), BIZ)
        assert r1 == r2
        assert isinstance(r1, PBRMatch)


class TestEmptyConfig:
    def test_empty_pbr_always_passthrough(self, policy_config):
        """With no rules, every packet passes through."""
        from n2nhu_policy import PBRConfig
        engine = PBREngine(policy_config, PBRConfig(rules=()))
        r = engine.route_override(
            _pkt(src="192.168.1.20", dscp=46), BIZ,
        )
        assert isinstance(r, PBRPassThrough)

"""
Tests for checksum.py — byte-exact against RFC reference values.

These pin correctness so that future performance optimizations don't silently
break NAT (packets would still be transmitted but receivers would discard them
as malformed).
"""

from __future__ import annotations

import struct
from ipaddress import IPv4Address

import pytest

from n2nhu_policy.checksum import (
    calculate_ip_checksum,
    calculate_tcp_checksum,
    calculate_udp_checksum,
    incremental_update,
    internet_checksum,
    ones_complement_sum,
    update_ip_checksum_for_dst_change,
    update_ip_checksum_for_src_change,
    update_l4_checksum_for_dnat,
    update_l4_checksum_for_snat,
)


class TestInternetChecksumCore:
    def test_rfc1071_example(self):
        """RFC 1071 section 1 canonical example."""
        data = bytes([0x00, 0x01, 0xf2, 0x03, 0xf4, 0xf5, 0xf6, 0xf7])
        assert ones_complement_sum(data) == 0xDDF2
        assert internet_checksum(data) == 0x220D

    def test_empty_data(self):
        assert internet_checksum(b"") == 0xFFFF

    def test_single_zero_word(self):
        assert internet_checksum(b"\x00\x00") == 0xFFFF

    def test_odd_length_padded(self):
        # Odd-length should pad with zero byte
        even = internet_checksum(b"\xAB\xCD\x12\x00")
        odd = internet_checksum(b"\xAB\xCD\x12")
        assert even == odd


class TestIPChecksum:
    def test_known_header(self):
        """Hand-computed IP header — round-trip verification."""
        header = struct.pack(
            "!BBHHHBBH4s4s",
            0x45, 0x00, 0x0073, 0x0000, 0x4000, 0x40, 0x06, 0x0000,
            b"\x0a\x0c\x0e\x05", b"\x0c\x06\x07\x09",
        )
        cs = calculate_ip_checksum(header)
        # Insert and verify round-trip: summing with the checksum in place yields 0xFFFF
        header_with_cs = header[:10] + struct.pack("!H", cs) + header[12:]
        assert ones_complement_sum(header_with_cs) == 0xFFFF

    def test_too_short_raises(self):
        with pytest.raises(ValueError, match="too short"):
            calculate_ip_checksum(b"\x00" * 10)

    def test_checksum_field_zeroed_automatically(self):
        """If the input already has a checksum, it should be zeroed before compute."""
        header_zero = struct.pack(
            "!BBHHHBBH4s4s",
            0x45, 0x00, 0x0073, 0x0000, 0x4000, 0x40, 0x06, 0x0000,
            b"\x0a\x0c\x0e\x05", b"\x0c\x06\x07\x09",
        )
        cs = calculate_ip_checksum(header_zero)
        # Now put garbage in the checksum field and recompute
        header_garbage = header_zero[:10] + b"\xFF\xFF" + header_zero[12:]
        assert calculate_ip_checksum(header_garbage) == cs


class TestIncrementalUpdate:
    def test_snat_src_change_matches_fresh_compute(self):
        """
        The core NAT correctness property: incremental update of the IP
        checksum after changing source IP equals a fresh compute.
        """
        old_src = IPv4Address("192.168.1.10")
        new_src = IPv4Address("203.0.113.1")
        dst = IPv4Address("8.8.8.8")

        header_old = struct.pack(
            "!BBHHHBBH4s4s",
            0x45, 0x00, 0x0028, 0x1234, 0x4000, 0x40, 0x06, 0x0000,
            old_src.packed, dst.packed,
        )
        old_cs = calculate_ip_checksum(header_old)

        # Incremental update
        new_cs_incremental = update_ip_checksum_for_src_change(
            old_cs, old_src, new_src,
        )

        # Fresh compute with new src
        header_new = struct.pack(
            "!BBHHHBBH4s4s",
            0x45, 0x00, 0x0028, 0x1234, 0x4000, 0x40, 0x06, 0x0000,
            new_src.packed, dst.packed,
        )
        new_cs_fresh = calculate_ip_checksum(header_new)

        assert new_cs_incremental == new_cs_fresh

    def test_dnat_dst_change_matches_fresh_compute(self):
        src = IPv4Address("198.51.100.77")
        old_dst = IPv4Address("203.0.113.1")
        new_dst = IPv4Address("172.16.0.10")

        header_old = struct.pack(
            "!BBHHHBBH4s4s",
            0x45, 0x00, 0x0028, 0x1234, 0x4000, 0x40, 0x06, 0x0000,
            src.packed, old_dst.packed,
        )
        old_cs = calculate_ip_checksum(header_old)
        new_cs_incremental = update_ip_checksum_for_dst_change(
            old_cs, old_dst, new_dst,
        )

        header_new = struct.pack(
            "!BBHHHBBH4s4s",
            0x45, 0x00, 0x0028, 0x1234, 0x4000, 0x40, 0x06, 0x0000,
            src.packed, new_dst.packed,
        )
        new_cs_fresh = calculate_ip_checksum(header_new)

        assert new_cs_incremental == new_cs_fresh

    def test_l4_snat_update_matches_fresh(self):
        """TCP checksum incremental update when both src IP and src port change."""
        old_src_ip = IPv4Address("192.168.1.10")
        new_src_ip = IPv4Address("203.0.113.1")
        dst_ip = IPv4Address("8.8.8.8")
        old_src_port, new_src_port = 54321, 10000

        # TCP header (20 bytes, no options)
        # fields: src_port, dst_port, seq, ack, off+flags, win, cksum=0, urg
        def tcp_seg(sp):
            return struct.pack(
                "!HHIIBBHHH",
                sp, 443, 0x12345678, 0, (5 << 4), 0x18, 8192, 0, 0,
            )
        old_seg = tcp_seg(old_src_port)
        old_cs = calculate_tcp_checksum(old_src_ip, dst_ip, old_seg)

        new_cs_incremental = update_l4_checksum_for_snat(
            old_cs,
            old_src_ip, new_src_ip,
            old_src_port, new_src_port,
        )

        # Fresh compute with both changes
        new_seg = tcp_seg(new_src_port)
        new_cs_fresh = calculate_tcp_checksum(new_src_ip, dst_ip, new_seg)

        assert new_cs_incremental == new_cs_fresh

    def test_l4_dnat_update_matches_fresh(self):
        src_ip = IPv4Address("198.51.100.77")
        old_dst_ip = IPv4Address("203.0.113.1")
        new_dst_ip = IPv4Address("172.16.0.10")
        old_dst_port, new_dst_port = 443, 8443

        def tcp_seg(dp):
            return struct.pack(
                "!HHIIBBHHH",
                55555, dp, 0xABCDEF01, 0, (5 << 4), 0x02, 8192, 0, 0,
            )
        old_seg = tcp_seg(old_dst_port)
        old_cs = calculate_tcp_checksum(src_ip, old_dst_ip, old_seg)

        new_cs_incremental = update_l4_checksum_for_dnat(
            old_cs,
            old_dst_ip, new_dst_ip,
            old_dst_port, new_dst_port,
        )

        new_seg = tcp_seg(new_dst_port)
        new_cs_fresh = calculate_tcp_checksum(src_ip, new_dst_ip, new_seg)
        assert new_cs_incremental == new_cs_fresh

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError):
            incremental_update(0, [1, 2], [3])


class TestUDPChecksum:
    def test_udp_round_trip(self):
        src = IPv4Address("192.168.1.10")
        dst = IPv4Address("10.0.0.1")
        # UDP header: src_port=33333, dst_port=53, length=8, cksum=0 + payload
        segment = struct.pack("!HHHH", 33333, 53, 8, 0)
        cs = calculate_udp_checksum(src, dst, segment)
        assert cs != 0  # 0 has special meaning

    def test_udp_too_short_raises(self):
        with pytest.raises(ValueError, match="too short"):
            calculate_udp_checksum(
                IPv4Address("1.1.1.1"), IPv4Address("2.2.2.2"), b"\x00" * 4,
            )

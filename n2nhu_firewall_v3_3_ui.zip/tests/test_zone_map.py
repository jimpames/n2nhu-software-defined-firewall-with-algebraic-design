"""Tests for ZoneMap — interface lookup and defaults matrix."""

from __future__ import annotations

import pytest

from n2nhu_policy import Action
from n2nhu_policy.errors import ResolverError


class TestInterfaceLookup:
    def test_lookup_trusted(self, zone_map):
        assert zone_map.zone_for_interface("lan") == "trusted"
        assert zone_map.zone_for_interface("wifi_corp") == "trusted"

    def test_lookup_untrusted(self, zone_map):
        assert zone_map.zone_for_interface("wan1") == "untrusted"
        assert zone_map.zone_for_interface("wan2") == "untrusted"

    def test_lookup_dmz(self, zone_map):
        assert zone_map.zone_for_interface("dmz") == "dmz"

    def test_lookup_guest(self, zone_map):
        assert zone_map.zone_for_interface("wifi_guest") == "guest"

    def test_lookup_mgt(self, zone_map):
        assert zone_map.zone_for_interface("mgt") == "mgt"

    def test_unknown_interface_raises(self, zone_map):
        with pytest.raises(ResolverError, match="not mapped"):
            zone_map.zone_for_interface("eth99")


class TestDefaultsMatrix:
    def test_explicit_match(self, zone_map):
        assert zone_map.default_action("trusted", "untrusted") == Action.ALLOW
        assert zone_map.default_action("untrusted", "trusted") == Action.DENY
        assert zone_map.default_action("guest", "trusted") == Action.DENY

    def test_any_to_mgt_denied(self, zone_map):
        # No explicit trusted_to_mgt rule, but any_to_mgt = DENY
        assert zone_map.default_action("trusted", "mgt") == Action.DENY
        assert zone_map.default_action("untrusted", "mgt") == Action.DENY
        assert zone_map.default_action("dmz", "mgt") == Action.DENY

    def test_mgt_to_any_allowed(self, zone_map):
        # mgt_to_any = ALLOW wildcard
        assert zone_map.default_action("mgt", "trusted") == Action.ALLOW
        assert zone_map.default_action("mgt", "untrusted") == Action.ALLOW

    def test_fallthrough_to_any_any(self, zone_map):
        # Something with no explicit mapping falls to any_any = DENY
        assert zone_map.default_action("dmz", "guest") == Action.DENY


class TestZoneAccess:
    def test_zone_metadata(self, zone_map):
        z = zone_map.zone("trusted")
        assert z.security_level == 100

    def test_mgt_plane_flag(self, zone_map):
        assert zone_map.zone("mgt").mgt_plane is True
        assert zone_map.zone("trusted").mgt_plane is False

    def test_unknown_zone(self, zone_map):
        with pytest.raises(ResolverError, match="unknown zone"):
            zone_map.zone("nonexistent")

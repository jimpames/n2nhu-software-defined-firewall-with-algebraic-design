"""
Phase D tests — NAT64 config and RFC 6052 address mapping.
"""

from __future__ import annotations

import tempfile
from ipaddress import IPv4Address, IPv6Address, IPv6Network
from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.errors import ConfigError
from n2nhu_policy.nat64_addr import (
    NAT64AddressError, WELL_KNOWN_PREFIX,
    embed_v4_in_v6, extract_v4_from_v6, is_nat64_address, parse_nat64_prefix,
)
from n2nhu_policy.nat_config_loader import NATConfigLoader
from n2nhu_policy.nat_models import NATType


class TestRFC6052Embedding:
    def test_embed_well_known(self):
        """203.0.113.5 → 64:ff9b::cb00:7105 per RFC 6052 example."""
        result = embed_v4_in_v6(IPv4Address("203.0.113.5"), WELL_KNOWN_PREFIX)
        assert result == IPv6Address("64:ff9b::cb00:7105")

    def test_embed_rfc_example_8_8_8_8(self):
        """Google DNS 8.8.8.8 embedded in 64:ff9b::/96."""
        result = embed_v4_in_v6(IPv4Address("8.8.8.8"), WELL_KNOWN_PREFIX)
        assert result == IPv6Address("64:ff9b::808:808")

    def test_embed_zero(self):
        result = embed_v4_in_v6(IPv4Address("0.0.0.0"), WELL_KNOWN_PREFIX)
        assert result == IPv6Address("64:ff9b::")

    def test_embed_max(self):
        result = embed_v4_in_v6(IPv4Address("255.255.255.255"), WELL_KNOWN_PREFIX)
        assert result == IPv6Address("64:ff9b::ffff:ffff")

    def test_extract_roundtrip(self):
        v4 = IPv4Address("192.168.1.1")
        v6 = embed_v4_in_v6(v4, WELL_KNOWN_PREFIX)
        back = extract_v4_from_v6(v6, WELL_KNOWN_PREFIX)
        assert back == v4

    def test_extract_out_of_prefix_rejected(self):
        """An address outside the prefix is not extractable."""
        with pytest.raises(NAT64AddressError):
            extract_v4_from_v6(IPv6Address("2001:db8::1"), WELL_KNOWN_PREFIX)

    def test_is_nat64_address(self):
        assert is_nat64_address(IPv6Address("64:ff9b::cb00:7105"), WELL_KNOWN_PREFIX)
        assert not is_nat64_address(IPv6Address("2001:db8::1"), WELL_KNOWN_PREFIX)

    def test_custom_prefix_96(self):
        """Operator's own /96 prefix works the same way."""
        custom = IPv6Network("2001:db8:abcd:ef00::/96")
        v4 = IPv4Address("10.0.0.1")
        v6 = embed_v4_in_v6(v4, custom)
        assert extract_v4_from_v6(v6, custom) == v4
        assert is_nat64_address(v6, custom)
        # Not in the well-known prefix
        assert not is_nat64_address(v6, WELL_KNOWN_PREFIX)

    def test_non_96_prefix_rejected(self):
        """v1 supports /96 only; other RFC 6052 lengths deferred to v1.1."""
        with pytest.raises(NAT64AddressError):
            embed_v4_in_v6(
                IPv4Address("1.2.3.4"), IPv6Network("64:ff9b::/64"),
            )


class TestParseNAT64Prefix:
    def test_parse_with_slash(self):
        p = parse_nat64_prefix("64:ff9b::/96")
        assert p == WELL_KNOWN_PREFIX

    def test_parse_without_slash_defaults_to_96(self):
        p = parse_nat64_prefix("64:ff9b::")
        assert p.prefixlen == 96

    def test_parse_custom(self):
        p = parse_nat64_prefix("2001:db8:abcd:ef00::/96")
        assert p == IPv6Network("2001:db8:abcd:ef00::/96")

    def test_parse_rejects_non_96(self):
        with pytest.raises(NAT64AddressError):
            parse_nat64_prefix("64:ff9b::/64")

    def test_parse_rejects_garbage(self):
        with pytest.raises(ValueError):  # IPv6Network raises ValueError, covered
            parse_nat64_prefix("not-an-address")


class TestNAT64ConfigLoading:
    """The NAT loader recognizes and validates nat64 rule type."""

    def _build_tree(self, nat_body: str) -> Path:
        """Build a minimal config tree with the given nat.ini body and
        return its root. Caller is responsible for context management of
        the tempdir (the fixture below handles that)."""
        root = self._tmp
        (root / "objects").mkdir(exist_ok=True)
        (root / "policies").mkdir(exist_ok=True)
        (root / "zones.ini").write_text(
            "[zones]\ntrusted = lan\nuntrusted = wan1\n"
            "\n[defaults]\ndefault_any_to_any = DENY\n"
        )
        (root / "objects" / "addresses.ini").write_text(
            "[addr_any]\ntype = network\nvalue = ::/0\n"
            "\n[addr_v6_clients]\ntype = network\nvalue = 2001:db8::/32\n"
            "\n[addr_v4_pool]\ntype = host\nvalue = 203.0.113.10\n"
            "\n[addr_any_v4]\ntype = network\nvalue = 0.0.0.0/0\n"
        )
        (root / "objects" / "services.ini").write_text(
            "[svc_any]\nprotocol = any\n"
        )
        (root / "objects" / "schedules.ini").write_text(
            "[sched_always]\ntype = always\n"
        )
        (root / "policies" / "security.ini").write_text(
            "[policy_order]\nrules = p_deny\n"
            "\n[p_deny]\n"
            "src_zone = any\ndst_zone = any\n"
            "src_addr = addr_any\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "action = DENY\n"
        )
        (root / "policies" / "nat.ini").write_text(nat_body)
        return root

    @pytest.fixture
    def tmp_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._tmp = Path(tmp)
            yield self._tmp

    def test_minimal_nat64_rule_loads(self, tmp_root):
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\n"
            "dst_zone = untrusted\n"
            "src_addr = addr_v6_clients\n"
            "dst_addr = addr_any\n"
            "service = svc_any\n"
            "schedule = sched_always\n"
            "translate_src_to_v4 = addr_v4_pool\n"
        )
        pcfg = ConfigLoader(root).load()
        ncfg = NATConfigLoader(root, pcfg).load()
        rules = [r for r in ncfg.rules if r.type == NATType.NAT64]
        assert len(rules) == 1
        r = rules[0]
        assert r.translate_src_to_v4 == "addr_v4_pool"
        # Default prefix
        assert r.nat64_prefix == "64:ff9b::/96"

    def test_custom_prefix(self, tmp_root):
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\n"
            "dst_zone = untrusted\n"
            "src_addr = addr_v6_clients\n"
            "dst_addr = addr_any\n"
            "service = svc_any\n"
            "schedule = sched_always\n"
            "translate_src_to_v4 = addr_v4_pool\n"
            "nat64_prefix = 2001:db8:abcd:ef00::/96\n"
        )
        pcfg = ConfigLoader(root).load()
        ncfg = NATConfigLoader(root, pcfg).load()
        r = [r for r in ncfg.rules if r.type == NATType.NAT64][0]
        assert r.nat64_prefix == "2001:db8:abcd:ef00::/96"

    def test_missing_v4_pool_rejected(self, tmp_root):
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\n"
            "dst_zone = untrusted\n"
            "src_addr = addr_v6_clients\n"
            "dst_addr = addr_any\n"
            "service = svc_any\n"
            "schedule = sched_always\n"
        )
        pcfg = ConfigLoader(root).load()
        with pytest.raises(ConfigError) as ei:
            NATConfigLoader(root, pcfg).load()
        assert "translate_src_to_v4" in str(ei.value)

    def test_undefined_v4_pool_rejected(self, tmp_root):
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\ndst_zone = untrusted\n"
            "src_addr = addr_v6_clients\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "translate_src_to_v4 = addr_does_not_exist\n"
        )
        pcfg = ConfigLoader(root).load()
        with pytest.raises(ConfigError) as ei:
            NATConfigLoader(root, pcfg).load()
        assert "not defined" in str(ei.value)

    def test_bad_prefix_rejected(self, tmp_root):
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\ndst_zone = untrusted\n"
            "src_addr = addr_v6_clients\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "translate_src_to_v4 = addr_v4_pool\n"
            "nat64_prefix = 64:ff9b::/64\n"  # /64 not allowed in v1
        )
        pcfg = ConfigLoader(root).load()
        with pytest.raises(ConfigError) as ei:
            NATConfigLoader(root, pcfg).load()
        assert "/96" in str(ei.value) or "nat64" in str(ei.value).lower()

    def test_port_pool_accepted(self, tmp_root):
        """NAT64 reuses SNAT port pool semantics for source NAT onto the
        v4 address."""
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\ndst_zone = untrusted\n"
            "src_addr = addr_v6_clients\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "translate_src_to_v4 = addr_v4_pool\n"
            "port_pool = 10000-60000\n"
        )
        pcfg = ConfigLoader(root).load()
        ncfg = NATConfigLoader(root, pcfg).load()
        r = [r for r in ncfg.rules if r.type == NATType.NAT64][0]
        assert r.port_pool is not None
        assert r.port_pool.start == 10000
        assert r.port_pool.end == 60000

    def test_unknown_key_rejected(self, tmp_root):
        """Keys from other NAT types shouldn't be accepted on nat64."""
        root = self._build_tree(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\ndst_zone = untrusted\n"
            "src_addr = addr_v6_clients\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "translate_src_to_v4 = addr_v4_pool\n"
            "translate_dst_to = addr_any\n"  # DNAT key — invalid on NAT64
        )
        pcfg = ConfigLoader(root).load()
        with pytest.raises(ConfigError):
            NATConfigLoader(root, pcfg).load()

"""
Phase H tests — NAT64 registered in the UI schema.
"""

from __future__ import annotations

from pathlib import Path

from n2nhu_ui.schema_loader import SchemaLoader
from n2nhu_ui.schema_models import FieldType


def _load_nat():
    loader = SchemaLoader(Path("n2nhu_ui/schemas"))
    s = loader.load_schema("n2nhu_ui/schemas/nat.schema.ini")
    # The template section (pattern n*) is the per-rule section
    return next(sect for sect in s.sections if sect.name == "n*")


class TestNAT64Schema:
    def test_nat64_in_type_choices(self):
        sect = _load_nat()
        type_field = sect.field_by_name("type")
        assert "nat64" in type_field.choices

    def test_nat64_prefix_field_registered(self):
        sect = _load_nat()
        f = sect.field_by_name("nat64_prefix")
        assert f is not None
        assert f.type == FieldType.STRING
        assert f.default == "64:ff9b::/96"

    def test_translate_src_to_v4_registered(self):
        sect = _load_nat()
        f = sect.field_by_name("translate_src_to_v4")
        assert f is not None
        assert f.type == FieldType.REF
        assert f.ref_to == "addresses"

    def test_all_nat_types_in_choices(self):
        """All five NAT types (snat, dnat, static, none, nat64) are
        selectable in the UI."""
        sect = _load_nat()
        choices = sect.field_by_name("type").choices
        assert set(choices) >= {"snat", "dnat", "static", "none", "nat64"}

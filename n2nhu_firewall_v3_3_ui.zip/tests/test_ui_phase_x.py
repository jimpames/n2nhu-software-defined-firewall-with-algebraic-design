"""
Phase X tests — Flask routes for template instance add/delete/reorder.

Covers:
  - POST add_instance with valid data succeeds and redirects
  - The added section appears in the on-disk file after commit
  - The added section appears in the order field
  - POST add_instance with invalid pattern returns redirect with flash
  - POST add_instance with empty fields returns redirect with flash
  - POST delete_instance removes the section from disk
  - POST delete_instance removes from order list too
  - POST reorder_instances updates the order CSV
  - All three routes 404 for unknown schema names
  - All three routes 403 when ALLOW_EDIT is False
  - Routes are POST-only (GET returns 405)
"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from n2nhu_ui.app import create_app


SCHEMA_DIR = Path(__file__).resolve().parent.parent / "n2nhu_ui" / "schemas"
DEFAULTS = SCHEMA_DIR / "defaults"


@pytest.fixture
def writable_tree(tmp_path):
    """Materialize a writable config tree from schema defaults."""
    root = tmp_path / "config"
    root.mkdir()
    (root / "objects").mkdir()
    (root / "policies").mkdir()
    for default in DEFAULTS.glob("*.ini"):
        if default.name in ("zones.ini",):
            shutil.copy(default, root / "zones.ini")
        elif default.name in ("addresses.ini", "services.ini", "schedules.ini"):
            shutil.copy(default, root / "objects" / default.name)
        else:
            shutil.copy(default, root / "policies" / default.name)
    return root


@pytest.fixture
def client(writable_tree):
    app = create_app(
        config_root=str(writable_tree),
        schema_dir=str(SCHEMA_DIR),
        allow_edit=True,
    )
    app.config["TESTING"] = True
    return app.test_client(), writable_tree


@pytest.fixture
def readonly_client(writable_tree):
    app = create_app(
        config_root=str(writable_tree),
        schema_dir=str(SCHEMA_DIR),
        allow_edit=False,
    )
    app.config["TESTING"] = True
    return app.test_client(), writable_tree


# ---------------------------------------------------------------------------
# add_instance route
# ---------------------------------------------------------------------------


class TestAddInstanceRoute:

    def test_add_capture_rule(self, client):
        c, root = client
        r = c.post("/ini/capture/instance/add", data={
            "pattern": "cap*",
            "instance_id": "cap_lan_egress",
        }, follow_redirects=False)
        assert r.status_code == 302
        # File should now contain the new section
        text = (root / "policies" / "capture.ini").read_text()
        assert "[cap_lan_egress]" in text

    def test_added_rule_in_order(self, client):
        c, root = client
        c.post("/ini/capture/instance/add", data={
            "pattern": "cap*",
            "instance_id": "cap_test",
        })
        text = (root / "policies" / "capture.ini").read_text()
        # rules = line should now mention cap_test
        for line in text.splitlines():
            if line.strip().startswith("rules"):
                assert "cap_test" in line
                break
        else:
            pytest.fail("no rules = line in capture.ini")

    def test_add_ipsec_proposal(self, client):
        c, root = client
        r = c.post("/ini/ipsec/instance/add", data={
            "pattern": "ipsec_proposal_*",
            "instance_id": "ipsec_proposal_default",
        })
        assert r.status_code == 302
        text = (root / "policies" / "ipsec.ini").read_text()
        assert "[ipsec_proposal_default]" in text

    def test_add_ipsec_tunnel_appears_in_tunnels(self, client):
        c, root = client
        # Need the ike_policy and proposal first to satisfy validate later, but
        # for the add route we just check sections appear.
        c.post("/ini/ipsec/instance/add", data={
            "pattern": "ipsec_tunnel_*",
            "instance_id": "ipsec_tunnel_branch1",
        })
        text = (root / "policies" / "ipsec.ini").read_text()
        for line in text.splitlines():
            if line.strip().startswith("tunnels"):
                assert "ipsec_tunnel_branch1" in line
                break

    def test_add_with_invalid_pattern_redirects(self, client):
        c, root = client
        r = c.post("/ini/capture/instance/add", data={
            "pattern": "bogus_*",
            "instance_id": "x",
        })
        assert r.status_code == 302
        # File unchanged — no [bogus*] section
        text = (root / "policies" / "capture.ini").read_text()
        assert "bogus" not in text

    def test_add_with_empty_id_redirects(self, client):
        c, root = client
        r = c.post("/ini/capture/instance/add", data={
            "pattern": "cap*",
            "instance_id": "",
        })
        assert r.status_code == 302

    def test_add_to_unknown_schema_404(self, client):
        c, _ = client
        r = c.post("/ini/imaginary/instance/add", data={
            "pattern": "x*", "instance_id": "y",
        })
        assert r.status_code == 404

    def test_add_when_readonly_returns_403(self, readonly_client):
        c, _ = readonly_client
        r = c.post("/ini/capture/instance/add", data={
            "pattern": "cap*", "instance_id": "x",
        })
        assert r.status_code == 403

    def test_add_get_method_not_allowed(self, client):
        c, _ = client
        r = c.get("/ini/capture/instance/add")
        assert r.status_code == 405


# ---------------------------------------------------------------------------
# delete_instance route
# ---------------------------------------------------------------------------


class TestDeleteInstanceRoute:

    def test_delete_existing_instance(self, client):
        c, root = client
        # First add
        c.post("/ini/capture/instance/add", data={
            "pattern": "cap*", "instance_id": "cap_to_kill",
        })
        text = (root / "policies" / "capture.ini").read_text()
        assert "[cap_to_kill]" in text
        # Then delete
        r = c.post("/ini/capture/instance/delete", data={
            "instance": "cap_to_kill",
        })
        assert r.status_code == 302
        text = (root / "policies" / "capture.ini").read_text()
        assert "[cap_to_kill]" not in text
        # And not in order
        for line in text.splitlines():
            if line.strip().startswith("rules"):
                assert "cap_to_kill" not in line

    def test_delete_nonexistent_redirects_with_flash(self, client):
        c, _ = client
        r = c.post("/ini/capture/instance/delete", data={
            "instance": "cap_imaginary",
        })
        assert r.status_code == 302

    def test_delete_empty_instance_field_redirects(self, client):
        c, _ = client
        r = c.post("/ini/capture/instance/delete", data={
            "instance": "",
        })
        assert r.status_code == 302

    def test_delete_404_for_unknown_schema(self, client):
        c, _ = client
        r = c.post("/ini/imaginary/instance/delete", data={
            "instance": "x",
        })
        assert r.status_code == 404

    def test_delete_403_when_readonly(self, readonly_client):
        c, _ = readonly_client
        r = c.post("/ini/capture/instance/delete", data={
            "instance": "x",
        })
        assert r.status_code == 403


# ---------------------------------------------------------------------------
# reorder_instances route
# ---------------------------------------------------------------------------


class TestReorderInstancesRoute:

    def test_reorder_two_capture_rules(self, client):
        c, root = client
        c.post("/ini/capture/instance/add", data={
            "pattern": "cap*", "instance_id": "cap_alpha",
        })
        c.post("/ini/capture/instance/add", data={
            "pattern": "cap*", "instance_id": "cap_beta",
        })
        # Reorder beta before alpha
        r = c.post("/ini/capture/instance/reorder", data={
            "pattern": "cap*",
            "order": "cap_beta, cap_alpha",
        })
        assert r.status_code == 302
        text = (root / "policies" / "capture.ini").read_text()
        for line in text.splitlines():
            if line.strip().startswith("rules"):
                a = line.find("cap_alpha")
                b = line.find("cap_beta")
                assert b < a, f"order wrong: {line}"
                break

    def test_reorder_with_empty_order_redirects(self, client):
        c, _ = client
        r = c.post("/ini/capture/instance/reorder", data={
            "pattern": "cap*",
            "order": "",
        })
        assert r.status_code == 302

    def test_reorder_with_unknown_id_redirects(self, client):
        c, _ = client
        r = c.post("/ini/capture/instance/reorder", data={
            "pattern": "cap*",
            "order": "cap_does_not_exist",
        })
        # Redirects with flash error
        assert r.status_code == 302

    def test_reorder_404_unknown_schema(self, client):
        c, _ = client
        r = c.post("/ini/imaginary/instance/reorder", data={
            "pattern": "x*", "order": "y",
        })
        assert r.status_code == 404

    def test_reorder_403_when_readonly(self, readonly_client):
        c, _ = readonly_client
        r = c.post("/ini/capture/instance/reorder", data={
            "pattern": "cap*", "order": "x",
        })
        assert r.status_code == 403

"""
Phase S tests — IPSecShim with mocked subprocess.

Covers:
  - Files written atomically (no .new file remains after apply)
  - ipsec.conf has 0644, ipsec.secrets has 0600
  - Reload command is invoked with the configured argv
  - Successful reload returns wrote_files=True, reloaded_daemon=True
  - Reload returncode != 0 raises IPSecShimError after files are written
  - Subprocess timeout / FileNotFoundError raises IPSecShimError
  - dry_run=True writes nothing and invokes nothing
  - apply() with empty config still writes (a removal of all conns)
  - Permissions persist after concurrent apply() calls (no race window
    where secrets file briefly has 0644)
  - Stats counters track applies / writes / reloads / failures
"""

from __future__ import annotations

import os
import stat
import subprocess
from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.ipsec_config_loader import IPSecConfigLoader
from n2nhu_policy.ipsec_models import IPSecConfig
from n2nhu_policy.ipsec_shim import (
    IPSecShim, IPSecShimError, IPSecShimResult,
)
from n2nhu_policy.object_resolver import ObjectResolver


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def policy_tree(tmp_path):
    root = tmp_path / "config"
    root.mkdir()
    (root / "objects").mkdir()
    (root / "policies").mkdir()
    (root / "zones.ini").write_text(
        "[zones]\ntrusted = lan\nuntrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan_net]\ntype = network\nvalue = 192.168.1.0/24\n"
        "\n[addr_branch_net]\ntype = network\nvalue = 10.20.0.0/16\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\nsrc_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\nservice = svc_any\n"
        "schedule = sched_always\naction = ALLOW\n"
    )
    return root


def _populated_ipsec(policy_tree: Path, tmp_path: Path) -> tuple[IPSecConfig, ObjectResolver]:
    psk = tmp_path / "psk.key"
    psk.write_text("super-secret-psk")
    (policy_tree / "policies" / "ipsec.ini").write_text(
        "[ipsec_proposal_p1]\n"
        "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
        f"\n[ike_policy_x]\n"
        f"local_id = a\nremote_id = b\nremote_addr = 1.2.3.4\n"
        f"auth_method = psk\npsk_file = {psk}\n"
        f"proposals = ipsec_proposal_p1\n"
        f"\n[ipsec_tunnel_x]\n"
        f"ike_policy = ike_policy_x\n"
        f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
        f"proposals = ipsec_proposal_p1\n"
    )
    pcfg = ConfigLoader(policy_tree).load()
    cfg = IPSecConfigLoader(policy_tree, pcfg).load()
    resolver = ObjectResolver(pcfg.addresses, pcfg.services)
    return cfg, resolver


def _empty_ipsec(policy_tree: Path) -> tuple[IPSecConfig, ObjectResolver]:
    pcfg = ConfigLoader(policy_tree).load()
    cfg = IPSecConfig(proposals={}, ike_policies={}, tunnels=())
    resolver = ObjectResolver(pcfg.addresses, pcfg.services)
    return cfg, resolver


def _fake_runner(*, returncode: int = 0, stderr: str = ""):
    """Build a callable that returns a subprocess.CompletedProcess."""
    invocations: list[list[str]] = []

    def run(cmd: list[str]) -> subprocess.CompletedProcess:
        invocations.append(list(cmd))
        return subprocess.CompletedProcess(
            args=cmd, returncode=returncode, stdout="", stderr=stderr,
        )
    run.invocations = invocations  # type: ignore[attr-defined]
    return run


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestApplyFiles:

    def test_writes_both_files(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        conf = tmp_path / "ipsec.conf"
        secrets = tmp_path / "ipsec.secrets"
        runner = _fake_runner(returncode=0)
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=secrets,
            runner=runner,
        )
        result = shim.apply(cfg, resolver)
        assert result.wrote_files is True
        assert conf.exists()
        assert secrets.exists()
        # Content sanity
        assert "conn ipsec_tunnel_x" in conf.read_text()
        assert "PSK" in secrets.read_text()
        assert "super-secret-psk" in secrets.read_text()

    def test_secrets_chmod_0600(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        secrets = tmp_path / "ipsec.secrets"
        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=secrets,
            runner=_fake_runner(),
        )
        shim.apply(cfg, resolver)
        mode = stat.S_IMODE(secrets.stat().st_mode)
        assert mode == 0o600, f"expected 0600, got {oct(mode)}"

    def test_conf_chmod_0644(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        conf = tmp_path / "ipsec.conf"
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=_fake_runner(),
        )
        shim.apply(cfg, resolver)
        mode = stat.S_IMODE(conf.stat().st_mode)
        assert mode == 0o644, f"expected 0644, got {oct(mode)}"

    def test_atomic_write_no_temp_left_behind(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        conf = tmp_path / "ipsec.conf"
        secrets = tmp_path / "ipsec.secrets"
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=secrets,
            runner=_fake_runner(),
        )
        shim.apply(cfg, resolver)
        # No .new files survive
        leftovers = list(tmp_path.glob("*.new"))
        assert leftovers == [], f"left-over temp files: {leftovers}"

    def test_apply_creates_parent_dir(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        conf = tmp_path / "deep" / "nested" / "etc" / "ipsec.conf"
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=_fake_runner(),
        )
        shim.apply(cfg, resolver)
        assert conf.exists()


class TestApplyReload:

    def test_reload_invokes_default_command(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        runner = _fake_runner()
        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=runner,
        )
        shim.apply(cfg, resolver)
        assert runner.invocations == [["ipsec", "reload"]]

    def test_reload_invokes_custom_command(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        runner = _fake_runner()
        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            reload_command=("/usr/sbin/swanctl", "--load-all"),
            runner=runner,
        )
        shim.apply(cfg, resolver)
        assert runner.invocations == [["/usr/sbin/swanctl", "--load-all"]]

    def test_successful_reload_result(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=_fake_runner(returncode=0, stderr=""),
        )
        result = shim.apply(cfg, resolver)
        assert result.reloaded_daemon is True
        assert result.reload_returncode == 0

    def test_reload_failure_raises_after_files_written(
        self, policy_tree, tmp_path,
    ):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        conf = tmp_path / "ipsec.conf"
        secrets = tmp_path / "ipsec.secrets"
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=secrets,
            runner=_fake_runner(returncode=1, stderr="syntax error"),
        )
        with pytest.raises(IPSecShimError, match="syntax error"):
            shim.apply(cfg, resolver)
        # Files were written before the failed reload
        assert conf.exists()
        assert secrets.exists()
        assert shim.reload_failures == 1

    def test_reload_filenotfound_raises(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)

        def boom(cmd):
            raise FileNotFoundError(f"ipsec not found")

        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=boom,
        )
        with pytest.raises(IPSecShimError, match="ipsec not found"):
            shim.apply(cfg, resolver)
        assert shim.reload_failures == 1

    def test_reload_timeout_raises(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)

        def slow(cmd):
            raise subprocess.TimeoutExpired(cmd, timeout=15)

        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=slow,
        )
        with pytest.raises(IPSecShimError):
            shim.apply(cfg, resolver)


class TestDryRun:

    def test_dry_run_writes_nothing(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        conf = tmp_path / "ipsec.conf"
        secrets = tmp_path / "ipsec.secrets"
        runner = _fake_runner()
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=secrets,
            runner=runner,
            dry_run=True,
        )
        result = shim.apply(cfg, resolver)
        assert result.wrote_files is False
        assert result.reloaded_daemon is False
        assert result.skipped_reason == "dry-run"
        assert not conf.exists()
        assert not secrets.exists()
        assert runner.invocations == []


class TestEmptyConfig:

    def test_empty_apply_still_writes(self, policy_tree, tmp_path):
        """Going from a non-empty to empty config must remove the conn
        blocks — meaning we must write the new (empty) ipsec.conf and
        reload."""
        cfg, resolver = _empty_ipsec(policy_tree)
        conf = tmp_path / "ipsec.conf"
        runner = _fake_runner()
        shim = IPSecShim(
            ipsec_conf_path=conf,
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=runner,
        )
        result = shim.apply(cfg, resolver)
        assert result.wrote_files is True
        assert "No tunnels configured" in conf.read_text()
        assert len(runner.invocations) == 1


class TestStats:

    def test_stats_increment_on_success(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=_fake_runner(),
        )
        shim.apply(cfg, resolver)
        shim.apply(cfg, resolver)
        shim.apply(cfg, resolver)
        assert shim.applies == 3
        assert shim.writes == 3
        assert shim.reloads == 3
        assert shim.reload_failures == 0

    def test_stats_track_failure(self, policy_tree, tmp_path):
        cfg, resolver = _populated_ipsec(policy_tree, tmp_path)
        shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=_fake_runner(returncode=1, stderr="bad"),
        )
        with pytest.raises(IPSecShimError):
            shim.apply(cfg, resolver)
        assert shim.applies == 1
        assert shim.writes == 1   # files were written before reload failed
        assert shim.reload_failures == 1
        assert shim.reloads == 0

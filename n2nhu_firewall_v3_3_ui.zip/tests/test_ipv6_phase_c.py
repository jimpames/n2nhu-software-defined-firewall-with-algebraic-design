"""
Phase C tests — ICMPv6 semantics and IPv6 address scoping.
"""

from __future__ import annotations

import tempfile
from ipaddress import IPv6Address
from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.icmpv6 import (
    AddressScope, ICMPv6Category,
    DIAGNOSTIC_ICMPV6_TYPES, ESSENTIAL_ICMPV6_TYPES,
    classify_address, classify_icmpv6_type,
    is_essential_icmpv6, is_link_local, is_multicast,
    is_solicited_node_multicast,
)


class TestICMPv6Classification:
    def test_neighbor_solicitation_is_essential(self):
        """NS = type 135. Dropping this breaks v6 address resolution."""
        assert classify_icmpv6_type(135) == ICMPv6Category.MUST_PERMIT
        assert is_essential_icmpv6(135)

    def test_neighbor_advertisement_is_essential(self):
        assert classify_icmpv6_type(136) == ICMPv6Category.MUST_PERMIT

    def test_router_solicitation_is_essential(self):
        assert classify_icmpv6_type(133) == ICMPv6Category.MUST_PERMIT

    def test_router_advertisement_is_essential(self):
        """RA is how SLAAC works."""
        assert classify_icmpv6_type(134) == ICMPv6Category.MUST_PERMIT

    def test_packet_too_big_is_essential(self):
        """PTB is how PMTUD works in v6; dropping it breaks large transfers."""
        assert classify_icmpv6_type(2) == ICMPv6Category.MUST_PERMIT
        assert is_essential_icmpv6(2)

    def test_dest_unreachable_is_essential(self):
        assert classify_icmpv6_type(1) == ICMPv6Category.MUST_PERMIT

    def test_time_exceeded_is_essential(self):
        """TE = type 3; needed for traceroute and hop-limit errors."""
        assert classify_icmpv6_type(3) == ICMPv6Category.MUST_PERMIT

    def test_echo_request_is_should_permit(self):
        """Ping — not essential but normally permitted."""
        assert classify_icmpv6_type(128) == ICMPv6Category.SHOULD_PERMIT
        assert not is_essential_icmpv6(128)

    def test_echo_reply_is_should_permit(self):
        assert classify_icmpv6_type(129) == ICMPv6Category.SHOULD_PERMIT

    def test_mld_report_v2_is_essential(self):
        """MLDv2 is needed for multicast to function."""
        assert classify_icmpv6_type(143) == ICMPv6Category.MUST_PERMIT

    def test_unknown_type_is_unknown(self):
        assert classify_icmpv6_type(200) == ICMPv6Category.UNKNOWN
        assert not is_essential_icmpv6(200)

    def test_essential_list_contents(self):
        """The exported list matches the is_essential predicate exactly."""
        for t in ESSENTIAL_ICMPV6_TYPES:
            assert is_essential_icmpv6(t)
        # And nothing in the diagnostic list is "essential"
        for t in DIAGNOSTIC_ICMPV6_TYPES:
            assert not is_essential_icmpv6(t)


class TestAddressScoping:
    def test_link_local(self):
        assert classify_address(IPv6Address("fe80::1")) == AddressScope.LINK_LOCAL
        assert is_link_local(IPv6Address("fe80::1"))

    def test_link_local_boundary(self):
        """fe80::/10 covers fe80 through febf."""
        assert is_link_local(IPv6Address("fe80::"))
        assert is_link_local(IPv6Address("febf:ffff:ffff:ffff::"))
        # Just outside
        assert not is_link_local(IPv6Address("fec0::"))

    def test_loopback(self):
        assert classify_address(IPv6Address("::1")) == AddressScope.LOOPBACK

    def test_unspecified(self):
        assert classify_address(IPv6Address("::")) == AddressScope.UNSPECIFIED

    def test_multicast(self):
        assert classify_address(IPv6Address("ff02::1")) == AddressScope.MULTICAST
        assert is_multicast(IPv6Address("ff02::1"))
        assert not is_multicast(IPv6Address("2001:db8::1"))

    def test_unique_local(self):
        """fc00::/7 — private ULA range."""
        assert classify_address(IPv6Address("fc00::1")) == AddressScope.UNIQUE_LOCAL
        assert classify_address(IPv6Address("fd00::1")) == AddressScope.UNIQUE_LOCAL

    def test_site_local_deprecated(self):
        assert classify_address(IPv6Address("fec0::1")) == AddressScope.SITE_LOCAL

    def test_global(self):
        assert classify_address(IPv6Address("2001:db8::1")) == AddressScope.GLOBAL
        assert classify_address(IPv6Address("2600::1")) == AddressScope.GLOBAL
        assert not is_link_local(IPv6Address("2001:db8::1"))

    def test_solicited_node_multicast(self):
        """ff02::1:ff00:0/104 is where ND uses solicited-node addresses."""
        assert is_solicited_node_multicast(IPv6Address("ff02::1:ff00:1234"))
        assert not is_solicited_node_multicast(IPv6Address("ff02::1"))
        assert not is_solicited_node_multicast(IPv6Address("2001:db8::1"))


class TestICMPv6InConfig:
    """The services.ini now ships ICMPv6 definitions; the loader accepts them
    and the object resolver treats them as regular services."""

    @pytest.fixture
    def tree_with_icmpv6(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "objects").mkdir(); (root / "policies").mkdir()
            (root / "zones.ini").write_text(
                "[zones]\n"
                "trusted = lan\nuntrusted = wan1\n"
                "\n[defaults]\ndefault_any_to_any = DENY\n"
            )
            (root / "objects" / "addresses.ini").write_text(
                "[addr_any]\ntype = network\nvalue = ::/0\n"
            )
            (root / "objects" / "services.ini").write_text(
                "[svc_any]\nprotocol = any\n"
                "\n[svc_ns]\nprotocol = icmpv6\nicmp_type = 135\n"
                "\n[svc_na]\nprotocol = icmpv6\nicmp_type = 136\n"
                "\n[svc_ping6]\nprotocol = icmpv6\nicmp_type = 128\n"
                "\n[svcgrp_nd]\ntype = group\nmembers = svc_ns, svc_na\n"
            )
            (root / "objects" / "schedules.ini").write_text(
                "[sched_always]\ntype = always\n"
            )
            (root / "policies" / "security.ini").write_text(
                "[policy_order]\nrules = p_permit_nd\n"
                "\n[p_permit_nd]\n"
                "src_zone = any\ndst_zone = any\n"
                "src_addr = addr_any\ndst_addr = addr_any\n"
                "service = svcgrp_nd\nschedule = sched_always\n"
                "action = ALLOW\n"
            )
            yield root

    def test_loader_accepts_icmpv6_services(self, tree_with_icmpv6):
        cfg = ConfigLoader(tree_with_icmpv6).load()
        assert "svc_ns" in cfg.services
        assert cfg.services["svc_ns"].icmp_type == 135
        assert "svc_ping6" in cfg.services
        assert "svcgrp_nd" in cfg.services

    def test_rule_using_icmpv6_group_loads(self, tree_with_icmpv6):
        cfg = ConfigLoader(tree_with_icmpv6).load()
        assert "p_permit_nd" in {p.id for p in cfg.policies}


class TestICMPv6PermitListCompleteness:
    """Sanity: the fixture's svcgrp_icmpv6_essential matches what the
    RFC 4890 classifier says is essential, so the shipped default config
    is internally consistent."""

    def test_shipped_essential_group_matches_classifier(self):
        """The fixture services.ini defines svcgrp_icmpv6_essential with 7
        types. Those 7 must all be is_essential_icmpv6 == True."""
        shipped = {133, 134, 135, 136, 1, 2, 3}
        for t in shipped:
            assert is_essential_icmpv6(t), f"type {t} shipped in group but not essential"

"""
Phase F tests — ICMP/ICMPv6 cross-translation.
"""

from __future__ import annotations

import struct
from ipaddress import IPv4Address, IPv6Address, IPv6Network

import pytest

from n2nhu_policy.nat64_addr import WELL_KNOWN_PREFIX, embed_v4_in_v6
from n2nhu_policy.nat64_icmp import (
    ICMPTranslationError,
    map_v4_to_v6_type_code, map_v6_to_v4_type_code,
    translate_embedded_header_v4_to_v6, translate_embedded_header_v6_to_v4,
    translate_icmp_echo_to_v6, translate_icmpv6_echo_to_v4,
)
from n2nhu_policy.frame_codec_v6 import (
    IP_PROTO_ICMPV6, IP_PROTO_TCP, IP_PROTO_UDP, compute_l4_checksum_v6,
)


CLIENT_V6 = IPv6Address("2001:db8:cafe::100")
SERVER_V4 = IPv4Address("203.0.113.5")
SERVER_V6 = embed_v4_in_v6(SERVER_V4, WELL_KNOWN_PREFIX)
FIREWALL_V4 = IPv4Address("198.51.100.1")


class TestTypeCodeMapping:
    """Verify RFC 7915 §5 type/code tables."""

    def test_echo_v4_to_v6(self):
        assert map_v4_to_v6_type_code(8, 0) == (128, 0)
        assert map_v4_to_v6_type_code(0, 0) == (129, 0)

    def test_echo_v6_to_v4(self):
        assert map_v6_to_v4_type_code(128, 0) == (8, 0)
        assert map_v6_to_v4_type_code(129, 0) == (0, 0)

    def test_dest_unreachable_v4_to_v6(self):
        # ICMP type 3 code 0 (Net Unreachable) -> ICMPv6 type 1 code 0
        assert map_v4_to_v6_type_code(3, 0) == (1, 0)
        assert map_v4_to_v6_type_code(3, 1) == (1, 3)
        assert map_v4_to_v6_type_code(3, 3) == (1, 4)
        # Frag Needed -> Packet Too Big
        assert map_v4_to_v6_type_code(3, 4) == (2, 0)

    def test_time_exceeded(self):
        assert map_v4_to_v6_type_code(11, 0) == (3, 0)
        assert map_v6_to_v4_type_code(3, 0) == (11, 0)

    def test_packet_too_big_v6_to_v4(self):
        assert map_v6_to_v4_type_code(2, 0) == (3, 4)

    def test_source_quench_dropped(self):
        """Source Quench (v4 type 4) is deprecated and silently dropped
        rather than translated."""
        assert map_v4_to_v6_type_code(4, 0) is None

    def test_unsupported_returns_none(self):
        assert map_v4_to_v6_type_code(99, 0) is None
        assert map_v6_to_v4_type_code(200, 5) is None


class TestEchoTranslation:
    def test_icmpv6_echo_to_v4(self):
        """ICMPv6 Echo Request (128) translates to ICMP Echo Request (8)."""
        # Build an ICMPv6 Echo Request: type=128, code=0, checksum=?, id=0x1234, seq=1
        payload = bytearray(8 + 32)  # 8-byte ICMP header + 32 bytes of test data
        payload[0] = 128   # Echo Request
        payload[1] = 0
        # checksum bytes 2-3 left zero for now
        struct.pack_into("!H", payload, 4, 0x1234)  # Identifier
        struct.pack_into("!H", payload, 6, 0x0001)  # Sequence
        for i in range(32):
            payload[8 + i] = i  # test data pattern

        # Fix checksum under v6 pseudo-header
        cksum = compute_l4_checksum_v6(
            CLIENT_V6, SERVER_V6, IP_PROTO_ICMPV6, bytes(payload),
        )
        struct.pack_into("!H", payload, 2, cksum)

        # Translate
        v4_packet = translate_icmpv6_echo_to_v4(
            bytes(payload), FIREWALL_V4, SERVER_V4,
        )

        # Verify result: 20 bytes IPv4 header + ICMP
        assert len(v4_packet) == 20 + len(payload)
        assert v4_packet[0] == 0x45  # v4, IHL 5
        assert v4_packet[9] == 1  # ICMP protocol
        assert IPv4Address(v4_packet[12:16]) == FIREWALL_V4
        assert IPv4Address(v4_packet[16:20]) == SERVER_V4
        # ICMP type is Echo Request
        assert v4_packet[20] == 8
        assert v4_packet[21] == 0
        # Identifier preserved
        assert struct.unpack("!H", v4_packet[24:26])[0] == 0x1234
        # Data pattern preserved
        assert v4_packet[28:60] == bytes(range(32))

    def test_icmp_echo_to_v6(self):
        """ICMP Echo Request (8) translates to ICMPv6 Echo Request (128)."""
        payload = bytearray(8 + 16)
        payload[0] = 8   # Echo Request
        payload[1] = 0
        struct.pack_into("!H", payload, 4, 0xABCD)
        struct.pack_into("!H", payload, 6, 42)
        for i in range(16):
            payload[8 + i] = 0xAA

        # Translate
        v6_packet = translate_icmp_echo_to_v6(
            bytes(payload), SERVER_V6, CLIENT_V6,
        )

        # 40 bytes v6 header + ICMPv6 payload
        assert len(v6_packet) == 40 + len(payload)
        assert (v6_packet[0] >> 4) == 6  # version 6
        assert v6_packet[6] == IP_PROTO_ICMPV6
        # ICMPv6 type
        assert v6_packet[40] == 128  # Echo Request
        assert v6_packet[41] == 0
        # Identifier preserved
        assert struct.unpack("!H", v6_packet[44:46])[0] == 0xABCD

    def test_icmpv6_echo_v4_checksum_valid(self):
        """After v6→v4 translation, the ICMPv4 checksum should validate
        (ICMPv4 has no pseudo-header, so it's just over the ICMP data)."""
        payload = bytearray(8 + 8)
        payload[0] = 128
        payload[1] = 0
        struct.pack_into("!H", payload, 4, 1)
        struct.pack_into("!H", payload, 6, 1)
        cksum = compute_l4_checksum_v6(
            CLIENT_V6, SERVER_V6, IP_PROTO_ICMPV6, bytes(payload),
        )
        struct.pack_into("!H", payload, 2, cksum)

        v4_packet = translate_icmpv6_echo_to_v4(
            bytes(payload), FIREWALL_V4, SERVER_V4,
        )
        # Verify the translated ICMP checksum
        icmp = bytearray(v4_packet[20:])
        stored = struct.unpack("!H", icmp[2:4])[0]
        icmp[2:4] = b"\x00\x00"
        # Recompute manually
        total = 0
        for i in range(0, len(icmp), 2):
            total += (icmp[i] << 8) | (icmp[i + 1] if i + 1 < len(icmp) else 0)
        while total >> 16:
            total = (total & 0xFFFF) + (total >> 16)
        expected = (~total) & 0xFFFF
        assert stored == expected

    def test_icmp_echo_v6_checksum_valid_under_v6_pseudo(self):
        """After v4→v6 translation, the ICMPv6 checksum validates under
        the v6 pseudo-header."""
        payload = bytearray(8 + 8)
        payload[0] = 8
        payload[1] = 0
        v6_packet = translate_icmp_echo_to_v6(
            bytes(payload), SERVER_V6, CLIENT_V6,
        )
        # Extract ICMPv6, verify checksum
        icmp = bytearray(v6_packet[40:])
        stored = struct.unpack("!H", icmp[2:4])[0]
        icmp[2:4] = b"\x00\x00"
        recomputed = compute_l4_checksum_v6(
            SERVER_V6, CLIENT_V6, IP_PROTO_ICMPV6, bytes(icmp),
        )
        assert stored == recomputed


class TestUnsupported:
    def test_icmpv6_unsupported_type_raises(self):
        """An ICMPv6 message we don't know how to translate raises."""
        payload = bytearray(8)
        payload[0] = 150  # not in any mapping table
        with pytest.raises(ICMPTranslationError):
            translate_icmpv6_echo_to_v4(bytes(payload), FIREWALL_V4, SERVER_V4)

    def test_v4_source_quench_dropped(self):
        """Source Quench (type 4) cleanly errors out because it's None in map."""
        payload = bytearray(8)
        payload[0] = 4
        with pytest.raises(ICMPTranslationError):
            translate_icmp_echo_to_v6(bytes(payload), SERVER_V6, CLIENT_V6)

    def test_short_payload_raises(self):
        with pytest.raises(ICMPTranslationError):
            translate_icmpv6_echo_to_v4(b"\x80\x00", FIREWALL_V4, SERVER_V4)


class TestEmbeddedHeaderTranslation:
    def test_v4_to_v6_embedded_with_fallback(self):
        """When the session table can't resolve the original v6 tuple,
        addresses get embedded via the NAT64 prefix."""
        # Build an embedded v4 IP header: src = SERVER_V4, dst = FIREWALL_V4
        hdr = bytearray(20)
        hdr[0] = 0x45
        struct.pack_into("!H", hdr, 2, 60)  # total length 60
        hdr[8] = 32  # TTL
        hdr[9] = 6   # TCP
        hdr[12:16] = SERVER_V4.packed
        hdr[16:20] = FIREWALL_V4.packed

        v6_hdr = translate_embedded_header_v4_to_v6(
            bytes(hdr), WELL_KNOWN_PREFIX,
        )
        assert len(v6_hdr) == 40
        assert (v6_hdr[0] >> 4) == 6
        # next_header = TCP
        assert v6_hdr[6] == IP_PROTO_TCP
        # src v6 should be SERVER_V6 (embedded)
        assert IPv6Address(v6_hdr[8:24]) == SERVER_V6

    def test_v4_to_v6_embedded_with_explicit_mapping(self):
        """Operator provides the original v6 tuple from session lookup."""
        hdr = bytearray(20)
        hdr[0] = 0x45
        struct.pack_into("!H", hdr, 2, 60)
        hdr[9] = 6
        hdr[12:16] = SERVER_V4.packed
        hdr[16:20] = FIREWALL_V4.packed
        v6_hdr = translate_embedded_header_v4_to_v6(
            bytes(hdr), WELL_KNOWN_PREFIX,
            orig_v6_src=SERVER_V6, orig_v6_dst=CLIENT_V6,
        )
        assert IPv6Address(v6_hdr[8:24]) == SERVER_V6
        assert IPv6Address(v6_hdr[24:40]) == CLIENT_V6

    def test_v6_to_v4_embedded_extraction(self):
        """Embedded v6 addresses with NAT64 prefix extract cleanly."""
        # Build an embedded v6 header: src = SERVER_V6 (embedded v4),
        # dst = embedded v4 too (contrived, but tests the extraction)
        ANOTHER_V4 = IPv4Address("192.0.2.50")
        ANOTHER_V6 = embed_v4_in_v6(ANOTHER_V4, WELL_KNOWN_PREFIX)

        hdr = bytearray(40)
        # version 6, TC=0, FL=0
        hdr[0] = 0x60
        struct.pack_into("!H", hdr, 4, 8)  # payload length
        hdr[6] = IP_PROTO_UDP
        hdr[7] = 32  # hop limit
        hdr[8:24] = SERVER_V6.packed
        hdr[24:40] = ANOTHER_V6.packed

        v4_hdr = translate_embedded_header_v6_to_v4(
            bytes(hdr), WELL_KNOWN_PREFIX,
        )
        assert len(v4_hdr) == 20
        assert (v4_hdr[0] >> 4) == 4
        assert v4_hdr[9] == 17  # UDP
        assert IPv4Address(v4_hdr[12:16]) == SERVER_V4
        assert IPv4Address(v4_hdr[16:20]) == ANOTHER_V4

    def test_embedded_short_rejected(self):
        with pytest.raises(ICMPTranslationError):
            translate_embedded_header_v4_to_v6(b"\x45\x00", WELL_KNOWN_PREFIX)
        with pytest.raises(ICMPTranslationError):
            translate_embedded_header_v6_to_v4(b"\x60\x00", WELL_KNOWN_PREFIX)

    def test_embedded_unsupported_proto_rejected(self):
        """Embedded protocol we don't know how to translate."""
        hdr = bytearray(20)
        hdr[0] = 0x45
        struct.pack_into("!H", hdr, 2, 60)
        hdr[9] = 50  # ESP — not supported for translation in v1
        hdr[12:16] = SERVER_V4.packed
        hdr[16:20] = FIREWALL_V4.packed
        with pytest.raises(ICMPTranslationError):
            translate_embedded_header_v4_to_v6(bytes(hdr), WELL_KNOWN_PREFIX)

    def test_embedded_v6_out_of_prefix_rejected(self):
        """If the embedded v6 isn't in the NAT64 prefix, extraction fails."""
        hdr = bytearray(40)
        hdr[0] = 0x60
        struct.pack_into("!H", hdr, 4, 8)
        hdr[6] = IP_PROTO_TCP
        hdr[7] = 32
        # Global v6 address — not in 64:ff9b::/96
        hdr[8:24] = IPv6Address("2001:db8::1").packed
        hdr[24:40] = IPv6Address("2001:db8::2").packed
        with pytest.raises(ICMPTranslationError):
            translate_embedded_header_v6_to_v4(bytes(hdr), WELL_KNOWN_PREFIX)

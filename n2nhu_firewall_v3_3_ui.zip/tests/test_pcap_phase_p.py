"""
Phase P tests — n2nhu_pcap_tool CLI.

Covers:
  - Help works
  - stats on an empty file
  - stats on a populated file shows correct counts
  - stats decomposes by capture_point, decision, rule_id
  - list shows frames in order with annotations
  - list --limit caps output
  - list --match filters by key=value
  - Multiple --match filters AND together
  - Missing file exits non-zero
  - Invalid --match format exits non-zero
  - Tool reads files written by N2NHU's writer

These tests invoke main() programmatically via subprocess-free entry to
keep them fast and avoid system-binary dependency.
"""

from __future__ import annotations

import io
import sys
import time
from pathlib import Path

import pytest

# Make the script importable as a module
SCRIPT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SCRIPT_DIR))
import n2nhu_pcap_tool

from n2nhu_policy.pcapng_writer import PcapngWriter


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------


def _run(argv: list[str], capsys=None) -> tuple[int, str, str]:
    """Invoke the tool's main(); capture stdout/stderr."""
    buf_out = io.StringIO()
    buf_err = io.StringIO()
    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout = buf_out
    sys.stderr = buf_err
    try:
        try:
            rc = n2nhu_pcap_tool.main(argv)
        except SystemExit as e:
            rc = int(e.code) if isinstance(e.code, int) else 2
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
    return rc, buf_out.getvalue(), buf_err.getvalue()


def _make_capture(path: Path, frames: list[tuple[bytes, str]]) -> None:
    """Write a pcapng with the given (frame_bytes, comment) pairs."""
    w = PcapngWriter(path)
    for i, (frame, comment) in enumerate(frames):
        w.write_frame(
            frame,
            timestamp_us=10_000_000 + i * 1_000_000,
            comment=comment,
        )
    w.close()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestStatsCommand:

    def test_empty_file_zero_frames(self, tmp_path):
        path = tmp_path / "empty.pcapng"
        w = PcapngWriter(path)
        w.close()
        rc, out, err = _run(["stats", str(path)])
        assert rc == 0
        assert "0 frames" in out

    def test_simple_file_correct_counts(self, tmp_path):
        path = tmp_path / "simple.pcapng"
        comment = (
            "capture_point=ingress decision=allow rule_id=p_allow "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path, [(b"\xAA" * 60, comment)] * 5)

        rc, out, err = _run(["stats", str(path)])
        assert rc == 0
        assert "frames:" in out
        assert "5" in out
        assert "ingress" in out
        assert "allow" in out

    def test_stats_breakdown_by_decision(self, tmp_path):
        path = tmp_path / "mixed.pcapng"
        c_allow = (
            "capture_point=post_policy decision=allow rule_id=p_allow "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        c_deny = (
            "capture_point=post_policy decision=deny rule_id=p_block "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path,
            [(b"\x01" * 60, c_allow)] * 3 +
            [(b"\x02" * 60, c_deny)] * 7
        )
        rc, out, _ = _run(["stats", str(path)])
        assert rc == 0
        # Both decisions reported
        assert "allow" in out
        assert "deny" in out
        # Counts visible
        assert "3" in out
        assert "7" in out

    def test_stats_missing_file_returns_nonzero(self, tmp_path):
        rc, out, err = _run(["stats", str(tmp_path / "nope.pcapng")])
        assert rc != 0
        assert "not found" in err.lower()


class TestListCommand:

    def test_list_shows_each_frame(self, tmp_path):
        path = tmp_path / "list.pcapng"
        comment = (
            "capture_point=post_nat decision=allow rule_id=p_allow "
            "nat_rule_id=n_snat pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path, [(b"\xAA" * 60, comment)] * 3)
        rc, out, _ = _run(["list", str(path)])
        assert rc == 0
        # Three lines for three frames
        lines = [line for line in out.split("\n") if line.startswith("#")]
        assert len(lines) == 3

    def test_list_limit_caps_output(self, tmp_path):
        path = tmp_path / "list.pcapng"
        comment = (
            "capture_point=ingress decision=none rule_id= "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path, [(b"\xAA" * 60, comment)] * 10)
        rc, out, _ = _run(["list", str(path), "--limit", "3"])
        assert rc == 0
        lines = [line for line in out.split("\n") if line.startswith("#")]
        assert len(lines) == 3

    def test_list_match_filter(self, tmp_path):
        path = tmp_path / "filter.pcapng"
        c_allow = (
            "capture_point=post_policy decision=allow rule_id=p_allow "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        c_deny = (
            "capture_point=post_policy decision=deny rule_id=p_block "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path,
            [(b"\x01" * 60, c_allow)] * 5 +
            [(b"\x02" * 60, c_deny)] * 3
        )
        rc, out, _ = _run(["list", str(path), "--match", "decision=deny"])
        assert rc == 0
        lines = [line for line in out.split("\n") if line.startswith("#")]
        assert len(lines) == 3

    def test_list_multiple_matches_AND(self, tmp_path):
        path = tmp_path / "filter2.pcapng"
        c1 = (
            "capture_point=post_nat decision=allow rule_id=p_allow "
            "nat_rule_id=n1 pbr_rule_id= cap_rule=c1"
        )
        c2 = (
            "capture_point=post_nat decision=allow rule_id=p_allow "
            "nat_rule_id=n2 pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path,
            [(b"\x01" * 60, c1)] * 4 +
            [(b"\x02" * 60, c2)] * 6
        )
        rc, out, _ = _run([
            "list", str(path),
            "--match", "decision=allow",
            "--match", "nat_rule_id=n2",
        ])
        assert rc == 0
        lines = [line for line in out.split("\n") if line.startswith("#")]
        assert len(lines) == 6

    def test_list_no_matches_prints_message(self, tmp_path):
        path = tmp_path / "nomatch.pcapng"
        c = (
            "capture_point=post_policy decision=allow rule_id=p_allow "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path, [(b"\xAA" * 60, c)] * 5)
        rc, out, _ = _run([
            "list", str(path),
            "--match", "decision=deny",
        ])
        assert rc == 0
        assert "no matching frames" in out.lower()

    def test_list_invalid_match_returns_nonzero(self, tmp_path):
        path = tmp_path / "x.pcapng"
        _make_capture(path, [(b"\xAA" * 60, "cap_rule=c1")])
        rc, out, err = _run([
            "list", str(path), "--match", "no-equals-sign",
        ])
        assert rc != 0


class TestParseHelpers:

    def test_parse_comment_kv(self):
        comment = (
            "capture_point=post_nat decision=allow rule_id=p_main "
            "nat_rule_id=n_snat pbr_rule_id= cap_rule=c_default"
        )
        kv = n2nhu_pcap_tool.parse_comment_kv(comment)
        assert kv["capture_point"] == "post_nat"
        assert kv["decision"] == "allow"
        assert kv["rule_id"] == "p_main"
        assert kv["nat_rule_id"] == "n_snat"
        assert kv["pbr_rule_id"] == ""
        assert kv["cap_rule"] == "c_default"

    def test_parse_comment_kv_with_extra_whitespace(self):
        kv = n2nhu_pcap_tool.parse_comment_kv("  a=1   b=2  c=3  ")
        assert kv == {"a": "1", "b": "2", "c": "3"}

    def test_parse_comment_kv_empty(self):
        assert n2nhu_pcap_tool.parse_comment_kv("") == {}

    def test_iter_records_yields_dicts(self, tmp_path):
        path = tmp_path / "x.pcapng"
        comment = (
            "capture_point=ingress decision=none rule_id= "
            "nat_rule_id= pbr_rule_id= cap_rule=c1"
        )
        _make_capture(path, [(b"\xAA" * 60, comment)] * 2)
        records = list(n2nhu_pcap_tool.iter_records(path))
        assert len(records) == 2
        for r in records:
            assert r["capture_point"] == "ingress"
            assert r["captured_len"] == 60
            assert "captured" in r

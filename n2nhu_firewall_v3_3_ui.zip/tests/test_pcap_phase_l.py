"""
Phase L tests — capture.ini loader.

Covers:
  - Missing capture.ini → empty config (capture is opt-in)
  - Empty rules list → empty config (operator may have all rules disabled)
  - capture_order with valid rules round-trips correctly
  - capture_point parsing: ingress / post_policy / post_nat / invalid
  - match_action parsing: any / allow / deny / invalid
  - Defaults applied: enabled=true, src_zone=any, src_addr=addr_any, etc.
  - Cross-validation: undefined zone/addr/service rejected
  - Numeric bounds: rotate_size_mb >= 0, queue_depth >= 1
  - Required keys: capture_point, pcap_file
  - Unknown keys rejected (per the suite's strict-config convention)
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from n2nhu_policy.capture_config_loader import CaptureConfigLoader
from n2nhu_policy.capture_models import (
    CaptureConfig, CaptureMatchAction, CapturePoint, CaptureRule,
)
from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.errors import ConfigError


# ---------------------------------------------------------------------------
# Fixture — a minimal valid policy config tree to validate captures against
# ---------------------------------------------------------------------------


@pytest.fixture
def policy_tree(tmp_path):
    """Minimal valid policy config — zones, addresses, services, schedules,
    plus an empty security policy. Returns the root path."""
    root = tmp_path
    (root / "objects").mkdir()
    (root / "policies").mkdir()

    (root / "zones.ini").write_text(
        "[zones]\n"
        "trusted = lan\n"
        "untrusted = wan1\n"
        "\n[defaults]\n"
        "default_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan]\ntype = network\nvalue = 192.168.1.0/24\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
        "\n[svc_http]\nprotocol = tcp\ndst_port = 80\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\n"
        "src_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\n"
        "service = svc_any\nschedule = sched_always\n"
        "action = ALLOW\n"
    )
    return root


@pytest.fixture
def policy_config(policy_tree):
    return ConfigLoader(policy_tree).load()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestEmptyAndAbsent:

    def test_no_capture_ini_returns_empty(self, policy_tree, policy_config):
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert isinstance(cfg, CaptureConfig)
        assert cfg.rules == ()

    def test_empty_rules_list_returns_empty(self, policy_tree, policy_config):
        (policy_tree / "policies" / "capture.ini").write_text(
            "[capture_order]\nrules =\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert cfg.rules == ()

    def test_missing_capture_order_section_raises(self, policy_tree, policy_config):
        (policy_tree / "policies" / "capture.ini").write_text("# empty file\n")
        with pytest.raises(ConfigError, match="capture_order"):
            CaptureConfigLoader(policy_tree, policy_config).load()


class TestRuleParsing:

    def _write(self, policy_tree, body: str):
        (policy_tree / "policies" / "capture.ini").write_text(body)

    def test_minimal_valid_rule(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c1.pcapng\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert len(cfg.rules) == 1
        r = cfg.rules[0]
        assert r.id == "c1"
        assert r.capture_point == CapturePoint.INGRESS
        assert r.enabled is True
        # All other fields use defaults
        assert r.src_zone == "any"
        assert r.dst_zone == "any"
        assert r.src_addr == "addr_any"
        assert r.dst_addr == "addr_any"
        assert r.service == "svc_any"
        assert r.match_action == CaptureMatchAction.ANY
        assert r.rotate_size_mb == 0
        assert r.rotate_keep == 0
        assert r.snap_len == 0
        assert r.queue_depth == 4096

    def test_capture_point_post_policy(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = post_policy\n"
            "pcap_file = /tmp/c.pcapng\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert cfg.rules[0].capture_point == CapturePoint.POST_POLICY

    def test_capture_point_post_nat(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = post_nat\n"
            "pcap_file = /tmp/c.pcapng\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert cfg.rules[0].capture_point == CapturePoint.POST_NAT

    def test_capture_point_invalid_raises(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = midstream\n"
            "pcap_file = /tmp/c.pcapng\n"
        )
        with pytest.raises(ConfigError, match="capture_point"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_match_action_allow(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "match_action = allow\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert cfg.rules[0].match_action == CaptureMatchAction.ALLOW

    def test_match_action_deny(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = post_policy\n"
            "pcap_file = /tmp/c.pcapng\n"
            "match_action = deny\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert cfg.rules[0].match_action == CaptureMatchAction.DENY

    def test_match_action_invalid_raises(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "match_action = sometimes\n"
        )
        with pytest.raises(ConfigError, match="match_action"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_full_form_rule_all_fields(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = cap_full\n"
            "\n[cap_full]\n"
            "enabled = true\n"
            "capture_point = post_nat\n"
            "src_zone = trusted\n"
            "dst_zone = untrusted\n"
            "src_addr = addr_lan\n"
            "dst_addr = addr_any\n"
            "service = svc_http\n"
            "match_action = allow\n"
            "pcap_file = /var/log/n2nhu/cap_full.pcapng\n"
            "rotate_size_mb = 100\n"
            "rotate_keep = 5\n"
            "snap_len = 1500\n"
            "queue_depth = 8192\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        r = cfg.rules[0]
        assert r.enabled is True
        assert r.capture_point == CapturePoint.POST_NAT
        assert r.src_zone == "trusted"
        assert r.dst_zone == "untrusted"
        assert r.src_addr == "addr_lan"
        assert r.service == "svc_http"
        assert r.match_action == CaptureMatchAction.ALLOW
        assert r.pcap_file == "/var/log/n2nhu/cap_full.pcapng"
        assert r.rotate_size_mb == 100
        assert r.rotate_keep == 5
        assert r.snap_len == 1500
        assert r.queue_depth == 8192

    def test_disabled_rule_loads_but_marked_disabled(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "enabled = false\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        assert cfg.rules[0].enabled is False
        assert cfg.enabled_rules() == ()

    def test_required_capture_point_missing(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "pcap_file = /tmp/c.pcapng\n"
        )
        with pytest.raises(ConfigError, match="capture_point"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_required_pcap_file_missing(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
        )
        with pytest.raises(ConfigError, match="pcap_file"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_unknown_zone_rejected(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "src_zone = nonexistent\n"
        )
        with pytest.raises(ConfigError, match="src_zone"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_unknown_addr_rejected(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "src_addr = addr_does_not_exist\n"
        )
        with pytest.raises(ConfigError, match="src_addr"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_unknown_service_rejected(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "service = svc_imaginary\n"
        )
        with pytest.raises(ConfigError, match="service"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_unknown_key_rejected(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "magic_thing = enabled\n"
        )
        with pytest.raises(ConfigError):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_negative_rotate_size_rejected(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "rotate_size_mb = -10\n"
        )
        with pytest.raises(ConfigError, match="rotate_size_mb"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_zero_queue_depth_rejected(self, policy_tree, policy_config):
        self._write(policy_tree,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\n"
            "capture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "queue_depth = 0\n"
        )
        with pytest.raises(ConfigError, match="queue_depth"):
            CaptureConfigLoader(policy_tree, policy_config).load()


class TestMultipleRules:

    def test_order_preserved(self, policy_tree, policy_config):
        (policy_tree / "policies" / "capture.ini").write_text(
            "[capture_order]\nrules = b, a, c\n"
            "\n[a]\ncapture_point = ingress\npcap_file = /tmp/a.pcapng\n"
            "\n[b]\ncapture_point = post_policy\npcap_file = /tmp/b.pcapng\n"
            "\n[c]\ncapture_point = post_nat\npcap_file = /tmp/c.pcapng\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        ids = [r.id for r in cfg.rules]
        assert ids == ["b", "a", "c"]

    def test_undefined_rule_in_order_raises(self, policy_tree, policy_config):
        (policy_tree / "policies" / "capture.ini").write_text(
            "[capture_order]\nrules = a, b\n"
            "\n[a]\ncapture_point = ingress\npcap_file = /tmp/a.pcapng\n"
            # b never defined
        )
        with pytest.raises(ConfigError, match="undefined"):
            CaptureConfigLoader(policy_tree, policy_config).load()

    def test_rules_for_point_filter(self, policy_tree, policy_config):
        (policy_tree / "policies" / "capture.ini").write_text(
            "[capture_order]\nrules = i1, p1, n1, i2\n"
            "\n[i1]\ncapture_point = ingress\npcap_file = /tmp/i1.pcapng\n"
            "\n[p1]\ncapture_point = post_policy\npcap_file = /tmp/p1.pcapng\n"
            "\n[n1]\ncapture_point = post_nat\npcap_file = /tmp/n1.pcapng\n"
            "\n[i2]\ncapture_point = ingress\npcap_file = /tmp/i2.pcapng\n"
        )
        cfg = CaptureConfigLoader(policy_tree, policy_config).load()
        ingress_rules = cfg.rules_for_point(CapturePoint.INGRESS)
        assert {r.id for r in ingress_rules} == {"i1", "i2"}
        post_nat_rules = cfg.rules_for_point(CapturePoint.POST_NAT)
        assert {r.id for r in post_nat_rules} == {"n1"}

"""
Phase E tests — NAT64 packet translation (v6↔v4).

Covers:
  - v6 TCP → v4 TCP byte-by-byte correctness
  - v6 UDP → v4 UDP
  - v4 reply → v6 return
  - Round trip: v6 → v4 → (simulated reply) → v6
  - Checksums validate after translation in both directions
  - ICMP not yet supported (raises)
  - Dst IP extraction per RFC 6052
  - Src port and dst port rewriting
"""

from __future__ import annotations

import struct
from ipaddress import IPv4Address, IPv6Address, IPv6Network

import pytest

from n2nhu_policy.frame_codec import (
    build_tcp_frame as build_tcp_v4,
    build_udp_frame as build_udp_v4,
    parse_frame as parse_v4,
)
from n2nhu_policy.frame_codec_v6 import (
    build_tcp_frame_v6, build_udp_frame_v6, build_icmpv6_frame,
    compute_l4_checksum_v6, parse_frame_v6,
    IP_PROTO_TCP, IP_PROTO_UDP,
)
from n2nhu_policy.nat64_addr import WELL_KNOWN_PREFIX, embed_v4_in_v6
from n2nhu_policy.nat64_translator import (
    NAT64TranslationError,
    translate_v4_to_v6, translate_v6_to_v4,
)
from n2nhu_policy.models import Protocol


# Test addresses. Client is v6-only; server is v4-only.
# Well-known prefix maps the v4 server into v6 space.
CLIENT_V6 = IPv6Address("2001:db8:cafe:1::100")
SERVER_V4 = IPv4Address("203.0.113.5")
SERVER_V6 = embed_v4_in_v6(SERVER_V4, WELL_KNOWN_PREFIX)  # 64:ff9b::cb00:7105
FIREWALL_V4 = IPv4Address("198.51.100.1")


class TestV6ToV4TCP:
    def test_basic_translation(self):
        """v6 client → v6 dst in NAT64 prefix → translator produces valid v4."""
        original = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=40000, dst_port=443,
            payload=b"GET /"
        )
        parsed = parse_frame_v6(original)

        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, xlated_src_port=10500,
            nat64_prefix=WELL_KNOWN_PREFIX,
        )
        # Translated frame should parse as v4
        p4 = parse_v4(translated)
        assert p4.ip_version == 4
        assert p4.src_ip == FIREWALL_V4
        assert p4.dst_ip == SERVER_V4  # extracted from the v6 dst
        assert p4.l4_protocol == Protocol.TCP
        assert p4.src_port == 10500  # rewritten
        assert p4.dst_port == 443    # preserved

    def test_payload_preserved(self):
        payload = b"Hello, NAT64 world!" * 20
        original = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=40000, dst_port=80,
            payload=payload
        )
        parsed = parse_frame_v6(original)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 15000, WELL_KNOWN_PREFIX,
        )
        p4 = parse_v4(translated)
        l4_start = p4.l4_header_start
        # TCP header is 20 bytes; payload follows
        actual_payload = translated[l4_start + 20:l4_start + 20 + len(payload)]
        assert actual_payload == payload

    def test_ip_header_checksum_valid(self):
        """IPv4 header checksum must validate after translation."""
        original = build_tcp_frame_v6(CLIENT_V6, SERVER_V6, 1234, 80)
        parsed = parse_frame_v6(original)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 20000, WELL_KNOWN_PREFIX,
        )
        # Parse — parse_v4 doesn't validate checksum automatically, so
        # we manually verify
        from n2nhu_policy.checksum import calculate_ip_checksum
        # IP header is bytes 14..34
        ip_hdr = bytearray(translated[14:34])
        stored = struct.unpack("!H", ip_hdr[10:12])[0]
        ip_hdr[10:12] = b"\x00\x00"
        recomputed = calculate_ip_checksum(bytes(ip_hdr))
        assert stored == recomputed

    def test_tcp_checksum_valid_under_v4_pseudo(self):
        """TCP checksum must validate under the v4 pseudo-header after
        translation."""
        original = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6, 5000, 80, payload=b"X" * 50,
        )
        parsed = parse_frame_v6(original)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 33333, WELL_KNOWN_PREFIX,
        )
        p4 = parse_v4(translated)
        from n2nhu_policy.checksum import calculate_tcp_checksum
        l4_start = p4.l4_header_start
        l4_end = p4.ip_header_start + p4.ip_total_length
        segment = bytearray(translated[l4_start:l4_end])
        stored = struct.unpack("!H", segment[16:18])[0]
        segment[16:18] = b"\x00\x00"
        recomputed = calculate_tcp_checksum(
            p4.src_ip, p4.dst_ip, bytes(segment),
        )
        assert stored == recomputed

    def test_traffic_class_copied_to_tos(self):
        """RFC 7915 §5.1.1: traffic class copies to IPv4 TOS byte."""
        original = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6, 1, 2, traffic_class=0xB8,  # EF
        )
        parsed = parse_frame_v6(original)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 30000, WELL_KNOWN_PREFIX,
        )
        p4 = parse_v4(translated)
        assert p4.ip_tos == 0xB8


class TestV6ToV4UDP:
    def test_udp_translation(self):
        original = build_udp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=5353, dst_port=53,
            payload=b"\x00\x02\x01\x00" + b"\x00" * 20,
        )
        parsed = parse_frame_v6(original)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 49999, WELL_KNOWN_PREFIX,
        )
        p4 = parse_v4(translated)
        assert p4.l4_protocol == Protocol.UDP
        assert p4.src_port == 49999
        assert p4.dst_port == 53

    def test_udp_checksum_valid_v4(self):
        original = build_udp_frame_v6(
            CLIENT_V6, SERVER_V6, 1000, 2000, payload=b"data",
        )
        parsed = parse_frame_v6(original)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 40000, WELL_KNOWN_PREFIX,
        )
        p4 = parse_v4(translated)
        from n2nhu_policy.checksum import calculate_udp_checksum
        l4_start = p4.l4_header_start
        l4_end = p4.ip_header_start + p4.ip_total_length
        segment = bytearray(translated[l4_start:l4_end])
        stored = struct.unpack("!H", segment[6:8])[0]
        segment[6:8] = b"\x00\x00"
        recomputed = calculate_udp_checksum(
            p4.src_ip, p4.dst_ip, bytes(segment),
        )
        # v4 UDP may have 0 or actual value
        assert stored in (recomputed, 0) if recomputed != 0 else stored == 0


class TestV4ToV6Reply:
    def test_basic_reply(self):
        """A v4 reply from the server is translated back to v6 for the client."""
        # Server replies to firewall at port 10500
        reply = build_tcp_v4(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=10500,
            payload=b"HTTP/1.1 200 OK\r\n\r\n",
        )
        parsed = parse_v4(reply)

        # Translate back to v6; the session knew the original client
        translated = translate_v4_to_v6(
            parsed, orig_v6_src=CLIENT_V6, orig_v6_src_port=40000,
            nat64_prefix=WELL_KNOWN_PREFIX,
        )
        p6 = parse_frame_v6(translated)
        assert p6.ip_version == 6
        # Source of the v6 packet is the v4 server, embedded in the prefix
        assert p6.src_ip == SERVER_V6
        # Destination is the original client
        assert p6.dst_ip == CLIENT_V6
        assert p6.src_port == 80
        assert p6.dst_port == 40000

    def test_reply_checksum_valid_under_v6_pseudo(self):
        reply = build_tcp_v4(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=443, dst_port=33333,
            payload=b"reply-payload-bytes",
        )
        parsed = parse_v4(reply)
        translated = translate_v4_to_v6(
            parsed, CLIENT_V6, 55555, WELL_KNOWN_PREFIX,
        )
        p6 = parse_frame_v6(translated)
        # Extract L4 with checksum zeroed and recompute
        l4_start = p6.l4_header_start
        l4_end = 14 + 40 + p6.payload_length
        segment = bytearray(translated[l4_start:l4_end])
        stored = struct.unpack("!H", segment[16:18])[0]
        segment[16:18] = b"\x00\x00"
        recomputed = compute_l4_checksum_v6(
            p6.src_ip, p6.dst_ip, IP_PROTO_TCP, bytes(segment),
        )
        assert stored == recomputed


class TestFullRoundTrip:
    def test_v6_client_v4_server_round_trip(self):
        """A complete v6-only-client-to-v4-only-server flow:
        forward v6→v4 translation, then reply v4→v6 translation,
        and the final v6 frame arrives at the original client."""
        # Forward: client sends SYN
        forward_v6 = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=40000, dst_port=80,
            payload=b"",
        )
        parsed_fwd = parse_frame_v6(forward_v6)
        forward_v4 = translate_v6_to_v4(
            parsed_fwd, FIREWALL_V4, 12345, WELL_KNOWN_PREFIX,
        )
        parsed_v4 = parse_v4(forward_v4)
        assert parsed_v4.src_ip == FIREWALL_V4
        assert parsed_v4.dst_ip == SERVER_V4
        assert parsed_v4.src_port == 12345

        # Reply from server: goes to FIREWALL_V4:12345
        reply_v4 = build_tcp_v4(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=12345,
            payload=b"SYN-ACK-payload",
        )
        parsed_reply = parse_v4(reply_v4)
        reply_v6 = translate_v4_to_v6(
            parsed_reply, CLIENT_V6, 40000, WELL_KNOWN_PREFIX,
        )
        parsed_reply_v6 = parse_frame_v6(reply_v6)
        assert parsed_reply_v6.src_ip == SERVER_V6  # embedded v4 in prefix
        assert parsed_reply_v6.dst_ip == CLIENT_V6
        assert parsed_reply_v6.src_port == 80
        assert parsed_reply_v6.dst_port == 40000


class TestUnsupported:
    def test_icmpv6_rejected_in_v1(self):
        """ICMPv6 cross-translation is Phase F — Phase E rejects it
        cleanly with a typed error."""
        frame = build_icmpv6_frame(CLIENT_V6, SERVER_V6, icmp_type=128)
        parsed = parse_frame_v6(frame)
        with pytest.raises(NAT64TranslationError) as ei:
            translate_v6_to_v4(parsed, FIREWALL_V4, 1000, WELL_KNOWN_PREFIX)
        assert "not supported" in str(ei.value).lower()

    def test_v4_icmp_reply_not_handled_by_main_translator(self):
        """The main v4→v6 translator (Phase E) handles TCP/UDP only.
        ICMP goes through a separate code path (Phase F's
        translate_embedded_header_v4_to_v6 and translate_icmp_echo_to_v6).
        Verify the main path cleanly rejects ICMP so callers know to
        dispatch to the specialized function.
        """
        from ipaddress import IPv4Address
        from n2nhu_policy.frame_codec import parse_frame as parse_v4
        import struct as _s

        # Build an ICMP Echo Request v4 packet directly
        SERVER_V4_LOCAL = IPv4Address("203.0.113.5")
        FIREWALL_V4_LOCAL = IPv4Address("198.51.100.1")

        icmp = bytearray(8 + 16)
        icmp[0] = 8   # Echo Request
        icmp[1] = 0
        _s.pack_into("!H", icmp, 4, 0x1234)
        _s.pack_into("!H", icmp, 6, 1)

        # Compute ICMP checksum
        total = 0
        data = bytes(icmp)
        for i in range(0, len(data), 2):
            total += (data[i] << 8) | data[i + 1]
        while total >> 16:
            total = (total & 0xFFFF) + (total >> 16)
        _s.pack_into("!H", icmp, 2, (~total) & 0xFFFF)

        # Build v4 IP header
        ip = bytearray(20)
        ip[0] = 0x45
        _s.pack_into("!H", ip, 2, 20 + len(icmp))
        ip[8] = 64
        ip[9] = 1  # ICMP
        ip[12:16] = SERVER_V4_LOCAL.packed
        ip[16:20] = FIREWALL_V4_LOCAL.packed
        from n2nhu_policy.checksum import calculate_ip_checksum
        _s.pack_into("!H", ip, 10, calculate_ip_checksum(bytes(ip)))

        eth = b"\x00" * 12 + b"\x08\x00"
        frame = eth + bytes(ip) + bytes(icmp)
        parsed = parse_v4(frame)

        # The Phase-E translator should reject ICMP
        with pytest.raises(NAT64TranslationError):
            translate_v4_to_v6(
                parsed, CLIENT_V6, 40000, WELL_KNOWN_PREFIX,
            )


class TestCustomPrefix:
    def test_custom_prefix_roundtrip(self):
        """Translation works under an operator-custom /96 prefix."""
        custom = IPv6Network("2001:db8:abcd:ef00::/96")
        server_v4 = IPv4Address("198.51.100.42")
        server_v6 = embed_v4_in_v6(server_v4, custom)

        forward = build_tcp_frame_v6(
            CLIENT_V6, server_v6, 1111, 443, payload=b"x",
        )
        parsed = parse_frame_v6(forward)
        translated = translate_v6_to_v4(
            parsed, FIREWALL_V4, 22222, custom,
        )
        p4 = parse_v4(translated)
        assert p4.dst_ip == server_v4

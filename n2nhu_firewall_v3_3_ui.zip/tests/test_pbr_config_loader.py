"""Tests for PBRConfigLoader — INI parsing, validation, error paths."""

from __future__ import annotations

import pytest

from n2nhu_policy import ConfigError, ConfigLoader, DSCPMatchMode, PBRConfigLoader


@pytest.fixture
def policy_config(fixture_root):
    return ConfigLoader(fixture_root).load()


@pytest.fixture
def pbr_config(fixture_root, policy_config):
    return PBRConfigLoader(fixture_root, policy_config).load()


class TestValidFixtures:
    def test_all_rules_loaded(self, pbr_config):
        assert [r.id for r in pbr_config.rules] == [
            "pbr010_voip_to_wan2",
            "pbr020_guest_out_wan2",
            "pbr030_admin_via_wan1",
            "pbr040_lab_range_high_dscp",
        ]

    def test_voip_rule_uses_symbolic_dscp(self, pbr_config):
        r = next(r for r in pbr_config.rules if r.id == "pbr010_voip_to_wan2")
        assert r.dscp_mode == DSCPMatchMode.EQUAL
        assert r.dscp_value == 46  # "ef" resolves to 46
        assert r.egress_iface == "wan2"

    def test_guest_rule_has_no_dscp_filter(self, pbr_config):
        r = next(r for r in pbr_config.rules if r.id == "pbr020_guest_out_wan2")
        assert r.dscp_mode == DSCPMatchMode.ANY
        assert r.src_zone == "guest"

    def test_admin_rule_attributes(self, pbr_config):
        r = next(r for r in pbr_config.rules if r.id == "pbr030_admin_via_wan1")
        assert r.src_addr == "addr_admin_workstation"
        assert r.schedule == "sched_business_hours"
        assert r.egress_iface == "wan1"

    def test_dscp_range_rule(self, pbr_config):
        r = next(r for r in pbr_config.rules if r.id == "pbr040_lab_range_high_dscp")
        assert r.dscp_mode == DSCPMatchMode.RANGE
        assert r.dscp_min == 26
        assert r.dscp_max == 30


class TestMissingFile:
    def test_missing_pbr_ini_returns_empty_config(
        self, tmp_config_tree, policy_config,
    ):
        pbr_path = tmp_config_tree / "policies" / "pbr.ini"
        if pbr_path.exists():
            pbr_path.unlink()
        cfg = PBRConfigLoader(tmp_config_tree, policy_config).load()
        assert cfg.rules == ()


class TestDSCPParsing:
    """Symbolic DSCP names and bounds checking."""

    def _make_minimal_pbr(self, tmp_config_tree, extra_body: str) -> None:
        """Write a minimal PBR INI with one rule whose body is `extra_body`."""
        content = f"""\
[pbr_order]
rules = pbr_test

[pbr_test]
src_zone = any
dst_zone = any
src_addr = addr_any
dst_addr = addr_any
service = svc_any
schedule = sched_always
egress_iface = wan1
{extra_body}
"""
        (tmp_config_tree / "policies" / "pbr.ini").write_text(content)

    def test_symbolic_cs6(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp = cs6\n")
        cfg = PBRConfigLoader(tmp_config_tree, policy_config).load()
        assert cfg.rules[0].dscp_value == 48

    def test_symbolic_af41(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp = af41\n")
        cfg = PBRConfigLoader(tmp_config_tree, policy_config).load()
        assert cfg.rules[0].dscp_value == 34

    def test_numeric_dscp(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp = 22\n")
        cfg = PBRConfigLoader(tmp_config_tree, policy_config).load()
        assert cfg.rules[0].dscp_value == 22

    def test_out_of_range_rejected(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp = 64\n")
        with pytest.raises(ConfigError, match="out of range"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_negative_rejected(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp = -1\n")
        with pytest.raises(ConfigError, match="out of range"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_unknown_symbolic_rejected(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp = zebra\n")
        with pytest.raises(ConfigError, match="must be 0-63"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_dscp_and_range_mutually_exclusive(
        self, tmp_config_tree, policy_config,
    ):
        self._make_minimal_pbr(
            tmp_config_tree,
            "dscp = 46\ndscp_min = 10\ndscp_max = 20\n",
        )
        with pytest.raises(ConfigError, match="can't mix"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_dscp_min_without_max_rejected(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(tmp_config_tree, "dscp_min = 10\n")
        with pytest.raises(ConfigError, match="must both be set"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_dscp_range_reversed_rejected(self, tmp_config_tree, policy_config):
        self._make_minimal_pbr(
            tmp_config_tree,
            "dscp_min = 30\ndscp_max = 20\n",
        )
        with pytest.raises(ConfigError, match="> dscp_max"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()


class TestReferenceValidation:
    def test_undefined_egress_iface(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "pbr.ini"
        content = path.read_text().replace(
            "egress_iface = wan2", "egress_iface = nonexistent",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not declared"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_undefined_src_addr(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "pbr.ini"
        content = path.read_text().replace(
            "src_addr     = addr_admin_workstation",
            "src_addr     = addr_made_up",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not defined"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_missing_egress_iface(self, tmp_config_tree, policy_config):
        content = """\
[pbr_order]
rules = pbr_bad

[pbr_bad]
src_zone = any
dst_zone = any
src_addr = addr_any
dst_addr = addr_any
service = svc_any
schedule = sched_always
"""
        (tmp_config_tree / "policies" / "pbr.ini").write_text(content)
        with pytest.raises(ConfigError, match="egress_iface"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_unknown_key_rejected(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "pbr.ini"
        content = path.read_text().replace(
            "[pbr010_voip_to_wan2]",
            "[pbr010_voip_to_wan2]\nrogue_key = 1",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="unknown keys"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()


class TestOrdering:
    def test_undefined_rule_in_order(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "pbr.ini"
        content = path.read_text().replace(
            "pbr010_voip_to_wan2,",
            "pbr010_voip_to_wan2,\n        pbr_does_not_exist,",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="undefined"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

    def test_duplicate_in_order(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "pbr.ini"
        content = path.read_text().replace(
            "rules = pbr010_voip_to_wan2,",
            "rules = pbr010_voip_to_wan2, pbr010_voip_to_wan2,",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="duplicate"):
            PBRConfigLoader(tmp_config_tree, policy_config).load()

"""Tests for ObjectResolver — membership, group flattening, cycles."""

from __future__ import annotations

from ipaddress import IPv4Address

import pytest

from n2nhu_policy import CycleError, ObjectResolver, Protocol
from n2nhu_policy.errors import ResolverError
from n2nhu_policy.models import AddressObject, AddressType, PortRange, ServiceObject


class TestAddressMembership:
    def test_host_membership_hit(self, resolver):
        assert resolver.ip_in_address(IPv4Address("172.16.0.10"), "addr_dmz_webserver")

    def test_host_membership_miss(self, resolver):
        assert not resolver.ip_in_address(IPv4Address("172.16.0.11"), "addr_dmz_webserver")

    def test_network_membership(self, resolver):
        assert resolver.ip_in_address(IPv4Address("192.168.1.5"), "addr_lan_net")
        assert resolver.ip_in_address(IPv4Address("192.168.1.254"), "addr_lan_net")

    def test_network_membership_miss(self, resolver):
        assert not resolver.ip_in_address(IPv4Address("192.168.2.1"), "addr_lan_net")

    def test_range_membership(self, resolver):
        assert resolver.ip_in_address(IPv4Address("192.168.1.150"), "addr_range_lab")
        assert resolver.ip_in_address(IPv4Address("192.168.1.100"), "addr_range_lab")
        assert resolver.ip_in_address(IPv4Address("192.168.1.200"), "addr_range_lab")

    def test_range_membership_miss(self, resolver):
        assert not resolver.ip_in_address(IPv4Address("192.168.1.99"), "addr_range_lab")
        assert not resolver.ip_in_address(IPv4Address("192.168.1.201"), "addr_range_lab")

    def test_any_matches_everything(self, resolver):
        assert resolver.ip_in_address(IPv4Address("8.8.8.8"), "addr_any")
        assert resolver.ip_in_address(IPv4Address("192.168.1.1"), "addr_any")

    def test_flat_group(self, resolver):
        # addrgrp_rfc1918 = 10.0.0.0/8 + 172.16.0.0/12 + 192.168.0.0/16
        assert resolver.ip_in_address(IPv4Address("10.1.2.3"), "addrgrp_rfc1918")
        assert resolver.ip_in_address(IPv4Address("172.16.100.5"), "addrgrp_rfc1918")
        assert resolver.ip_in_address(IPv4Address("192.168.50.1"), "addrgrp_rfc1918")
        assert not resolver.ip_in_address(IPv4Address("8.8.8.8"), "addrgrp_rfc1918")

    def test_nested_group(self, resolver):
        # addrgrp_internal = addr_lan_net + addrgrp_rfc1918
        assert resolver.ip_in_address(IPv4Address("192.168.1.100"), "addrgrp_internal")
        assert resolver.ip_in_address(IPv4Address("10.0.0.1"), "addrgrp_internal")
        assert not resolver.ip_in_address(IPv4Address("8.8.8.8"), "addrgrp_internal")

    def test_unknown_address_raises(self, resolver):
        with pytest.raises(ResolverError, match="unknown"):
            resolver.ip_in_address(IPv4Address("1.2.3.4"), "addr_does_not_exist")

    def test_flatten_address(self, resolver):
        flat = resolver.flatten_address("addrgrp_rfc1918")
        assert "10.0.0.0/8" in flat["networks"]
        assert "172.16.0.0/12" in flat["networks"]


class TestServiceMatching:
    def test_tcp_port_match(self, resolver):
        assert resolver.service_matches(
            "svc_http", protocol=Protocol.TCP, dst_port=80, src_port=54321, icmp_type=None,
        )

    def test_tcp_port_miss(self, resolver):
        assert not resolver.service_matches(
            "svc_http", protocol=Protocol.TCP, dst_port=81, src_port=0, icmp_type=None,
        )

    def test_tcp_wrong_protocol(self, resolver):
        assert not resolver.service_matches(
            "svc_http", protocol=Protocol.UDP, dst_port=80, src_port=0, icmp_type=None,
        )

    def test_port_range_match(self, resolver):
        # svc_app_range = TCP 8080-8090
        assert resolver.service_matches(
            "svc_app_range", protocol=Protocol.TCP, dst_port=8085, src_port=0, icmp_type=None,
        )
        assert resolver.service_matches(
            "svc_app_range", protocol=Protocol.TCP, dst_port=8080, src_port=0, icmp_type=None,
        )
        assert resolver.service_matches(
            "svc_app_range", protocol=Protocol.TCP, dst_port=8090, src_port=0, icmp_type=None,
        )
        assert not resolver.service_matches(
            "svc_app_range", protocol=Protocol.TCP, dst_port=8091, src_port=0, icmp_type=None,
        )

    def test_icmp_type_match(self, resolver):
        assert resolver.service_matches(
            "svc_icmp_ping", protocol=Protocol.ICMP, dst_port=0, src_port=0, icmp_type=8,
        )
        assert not resolver.service_matches(
            "svc_icmp_ping", protocol=Protocol.ICMP, dst_port=0, src_port=0, icmp_type=0,
        )

    def test_any_service_matches_all(self, resolver):
        # svc_any has protocol=any and no ports
        assert resolver.service_matches(
            "svc_any", protocol=Protocol.TCP, dst_port=1234, src_port=0, icmp_type=None,
        )
        assert resolver.service_matches(
            "svc_any", protocol=Protocol.UDP, dst_port=53, src_port=0, icmp_type=None,
        )
        assert resolver.service_matches(
            "svc_any", protocol=Protocol.ICMP, dst_port=0, src_port=0, icmp_type=0,
        )

    def test_service_group_match(self, resolver):
        # svcgrp_web = svc_http + svc_https
        assert resolver.service_matches(
            "svcgrp_web", protocol=Protocol.TCP, dst_port=80, src_port=0, icmp_type=None,
        )
        assert resolver.service_matches(
            "svcgrp_web", protocol=Protocol.TCP, dst_port=443, src_port=0, icmp_type=None,
        )
        assert not resolver.service_matches(
            "svcgrp_web", protocol=Protocol.TCP, dst_port=22, src_port=0, icmp_type=None,
        )

    def test_dns_group_both_protocols(self, resolver):
        # svcgrp_dns = UDP/53 + TCP/53
        assert resolver.service_matches(
            "svcgrp_dns", protocol=Protocol.UDP, dst_port=53, src_port=0, icmp_type=None,
        )
        assert resolver.service_matches(
            "svcgrp_dns", protocol=Protocol.TCP, dst_port=53, src_port=0, icmp_type=None,
        )

    def test_unknown_service_raises(self, resolver):
        with pytest.raises(ResolverError, match="unknown"):
            resolver.service_matches(
                "svc_not_real", protocol=Protocol.TCP, dst_port=80, src_port=0, icmp_type=None,
            )


class TestCycleDetection:
    def test_direct_self_reference(self):
        addrs = {
            "a": AddressObject(id="a", type=AddressType.GROUP, members=("a",)),
        }
        with pytest.raises(CycleError):
            ObjectResolver(addrs, {})

    def test_two_node_cycle(self):
        addrs = {
            "a": AddressObject(id="a", type=AddressType.GROUP, members=("b",)),
            "b": AddressObject(id="b", type=AddressType.GROUP, members=("a",)),
        }
        with pytest.raises(CycleError) as info:
            ObjectResolver(addrs, {})
        assert "a" in info.value.cycle_path
        assert "b" in info.value.cycle_path

    def test_three_node_cycle(self):
        addrs = {
            "a": AddressObject(id="a", type=AddressType.GROUP, members=("b",)),
            "b": AddressObject(id="b", type=AddressType.GROUP, members=("c",)),
            "c": AddressObject(id="c", type=AddressType.GROUP, members=("a",)),
        }
        with pytest.raises(CycleError):
            ObjectResolver(addrs, {})

    def test_service_group_cycle(self):
        svcs = {
            "s1": ServiceObject(id="s1", is_group=True, members=("s2",)),
            "s2": ServiceObject(id="s2", is_group=True, members=("s1",)),
        }
        with pytest.raises(CycleError):
            ObjectResolver({}, svcs)

    def test_acyclic_deep_nesting_ok(self):
        addrs = {
            "leaf": AddressObject(
                id="leaf",
                type=AddressType.HOST,
                host=IPv4Address("1.2.3.4"),
            ),
            "g1": AddressObject(id="g1", type=AddressType.GROUP, members=("leaf",)),
            "g2": AddressObject(id="g2", type=AddressType.GROUP, members=("g1",)),
            "g3": AddressObject(id="g3", type=AddressType.GROUP, members=("g2",)),
        }
        resolver = ObjectResolver(addrs, {})
        assert resolver.ip_in_address(IPv4Address("1.2.3.4"), "g3")


class TestFQDN:
    def test_fqdn_without_resolver_matches_nothing(self, loaded_config):
        # No fqdn_resolver supplied — the resolver compiles but the object is empty
        from n2nhu_policy.models import AddressObject, AddressType
        addrs = dict(loaded_config.addresses)
        addrs["addr_fqdn_test"] = AddressObject(
            id="addr_fqdn_test", type=AddressType.FQDN, fqdn="example.com",
        )
        r = ObjectResolver(addrs, loaded_config.services)
        # Nothing matches — but it doesn't crash
        assert not r.ip_in_address(IPv4Address("1.1.1.1"), "addr_fqdn_test")

    def test_fqdn_with_custom_resolver(self, loaded_config):
        from n2nhu_policy.models import AddressObject, AddressType
        addrs = dict(loaded_config.addresses)
        addrs["addr_fqdn_test"] = AddressObject(
            id="addr_fqdn_test", type=AddressType.FQDN, fqdn="example.com",
        )

        def fake_dns(name):
            return [IPv4Address("93.184.216.34")] if name == "example.com" else []

        r = ObjectResolver(addrs, loaded_config.services, fqdn_resolver=fake_dns)
        assert r.ip_in_address(IPv4Address("93.184.216.34"), "addr_fqdn_test")
        assert not r.ip_in_address(IPv4Address("1.1.1.1"), "addr_fqdn_test")

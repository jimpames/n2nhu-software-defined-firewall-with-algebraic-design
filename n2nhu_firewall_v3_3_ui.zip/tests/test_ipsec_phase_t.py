"""
Phase T tests — RouterShim wired with the IPSec shim.

End-to-end: drive RouterShim with a config tree that includes ipsec.ini,
verify that the loaded IPSec config is correctly attached and that
apply_ipsec() flows through to the shim (with a mocked subprocess).

Covers:
  - Shim with no ipsec.ini: ipsec_config is empty, apply_ipsec is a no-op
  - Shim with ipsec.ini: ipsec_config populated, apply_ipsec writes files
  - Reload preserves the IPSec shim and re-loads ipsec.ini
  - check_ipsec_secret_files=False permits config tests on hosts that
    don't have the actual key files
  - apply_ipsec returns None when no shim, IPSecShimResult when shim provided
  - The reloaded shim sees changes to ipsec.ini between reloads
"""

from __future__ import annotations

import subprocess
from ipaddress import IPv4Address, IPv4Network
from pathlib import Path

import pytest

from n2nhu_policy.ipsec_shim import IPSecShim
from n2nhu_policy.router_shim import RouterShim


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _write_base_tree(root: Path) -> None:
    (root / "objects").mkdir(exist_ok=True)
    (root / "policies").mkdir(exist_ok=True)
    (root / "zones.ini").write_text(
        "[zones]\ntrusted = lan\nuntrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan_net]\ntype = network\nvalue = 192.168.1.0/24\n"
        "\n[addr_branch_net]\ntype = network\nvalue = 10.20.0.0/16\n"
        "\n[addr_dc_net]\ntype = network\nvalue = 172.16.0.0/16\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\nsrc_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\nservice = svc_any\n"
        "schedule = sched_always\naction = ALLOW\n"
    )


def _fake_runner(*, returncode: int = 0, stderr: str = ""):
    invocations: list[list[str]] = []

    def run(cmd: list[str]) -> subprocess.CompletedProcess:
        invocations.append(list(cmd))
        return subprocess.CompletedProcess(
            args=cmd, returncode=returncode, stdout="", stderr=stderr,
        )
    run.invocations = invocations
    return run


@pytest.fixture
def base_tree(tmp_path):
    root = tmp_path / "config"
    root.mkdir()
    _write_base_tree(root)
    return root


@pytest.fixture
def ipsec_tree(base_tree, tmp_path):
    """Base tree + ipsec.ini configured."""
    psk = tmp_path / "psk.key"
    psk.write_text("test-psk")
    (base_tree / "policies" / "ipsec.ini").write_text(
        "[ipsec_proposal_p1]\n"
        "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
        f"\n[ike_policy_branch1]\n"
        f"local_id = fw\nremote_id = branch1\nremote_addr = 1.2.3.4\n"
        f"auth_method = psk\npsk_file = {psk}\n"
        f"proposals = ipsec_proposal_p1\n"
        f"\n[ipsec_tunnel_branch1]\n"
        f"ike_policy = ike_policy_branch1\n"
        f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
        f"proposals = ipsec_proposal_p1\n"
    )
    return base_tree


def _shim_kwargs():
    return dict(
        interface_ips={
            "lan": IPv4Address("192.168.1.1"),
            "wan1": IPv4Address("198.51.100.1"),
        },
        interface_networks={
            "lan": IPv4Network("192.168.1.0/24"),
            "wan1": IPv4Network("0.0.0.0/0"),
        },
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestNoIPSecConfig:

    def test_empty_ipsec_config(self, base_tree):
        shim = RouterShim(config_root=base_tree, **_shim_kwargs())
        assert shim.ipsec_config.is_empty()
        assert shim.ipsec_shim is None

    def test_apply_ipsec_no_op_without_shim(self, base_tree):
        shim = RouterShim(config_root=base_tree, **_shim_kwargs())
        assert shim.apply_ipsec() is None


class TestIPSecConfigLoaded:

    def test_ipsec_config_attached(self, ipsec_tree):
        shim = RouterShim(config_root=ipsec_tree, **_shim_kwargs())
        assert not shim.ipsec_config.is_empty()
        assert "ipsec_tunnel_branch1" in {t.id for t in shim.ipsec_config.tunnels}

    def test_apply_ipsec_writes_files_via_shim(self, ipsec_tree, tmp_path):
        runner = _fake_runner()
        ipsec_shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=runner,
        )
        shim = RouterShim(
            config_root=ipsec_tree,
            ipsec_shim=ipsec_shim,
            **_shim_kwargs(),
        )
        result = shim.apply_ipsec()
        assert result is not None
        assert result.wrote_files is True
        assert result.reloaded_daemon is True
        assert (tmp_path / "ipsec.conf").exists()
        assert (tmp_path / "ipsec.secrets").exists()
        assert "conn ipsec_tunnel_branch1" in (
            tmp_path / "ipsec.conf"
        ).read_text()
        # Reload was invoked once
        assert len(runner.invocations) == 1

    def test_check_secret_files_false_allows_missing_psk(
        self, base_tree, tmp_path,
    ):
        """When the PSK file doesn't exist on this host, the operator
        can still load and validate the config (e.g. building from a
        config server that pushes to remote firewalls)."""
        nonexistent = tmp_path / "nope" / "psk.key"
        (base_tree / "policies" / "ipsec.ini").write_text(
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_x]\n"
            f"local_id = a\nremote_id = b\nremote_addr = 1.2.3.4\n"
            f"auth_method = psk\npsk_file = {nonexistent}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_x]\n"
            f"ike_policy = ike_policy_x\n"
            f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        # Default (strict): would fail
        with pytest.raises(Exception):
            RouterShim(config_root=base_tree, **_shim_kwargs())
        # Permissive: succeeds
        shim = RouterShim(
            config_root=base_tree,
            check_ipsec_secret_files=False,
            **_shim_kwargs(),
        )
        assert not shim.ipsec_config.is_empty()


class TestReload:

    def test_reload_preserves_ipsec_shim(self, ipsec_tree, tmp_path):
        ipsec_shim = IPSecShim(
            ipsec_conf_path=tmp_path / "ipsec.conf",
            ipsec_secrets_path=tmp_path / "ipsec.secrets",
            runner=_fake_runner(),
        )
        shim = RouterShim(
            config_root=ipsec_tree,
            ipsec_shim=ipsec_shim,
            **_shim_kwargs(),
        )
        new_shim = shim.reload()
        # Same shim instance threaded through
        assert new_shim.ipsec_shim is ipsec_shim

    def test_reload_picks_up_new_ipsec_config(self, ipsec_tree, tmp_path):
        """Modifying ipsec.ini and calling reload() should produce a
        shim that reflects the new tunnel set."""
        shim = RouterShim(config_root=ipsec_tree, **_shim_kwargs())
        assert {t.id for t in shim.ipsec_config.tunnels} == {"ipsec_tunnel_branch1"}

        # Add a second tunnel
        psk = tmp_path / "psk2.key"
        psk.write_text("psk-2")
        (ipsec_tree / "policies" / "ipsec.ini").write_text(
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_b1]\n"
            f"local_id = fw\nremote_id = b1\nremote_addr = 1.1.1.1\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ike_policy_b2]\n"
            f"local_id = fw\nremote_id = b2\nremote_addr = 2.2.2.2\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_b1]\n"
            f"ike_policy = ike_policy_b1\n"
            f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_b2]\n"
            f"ike_policy = ike_policy_b2\n"
            f"local_subnet = addr_lan_net\nremote_subnet = addr_dc_net\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        new_shim = shim.reload()
        assert {t.id for t in new_shim.ipsec_config.tunnels} == {
            "ipsec_tunnel_b1", "ipsec_tunnel_b2",
        }


class TestForwardingUnchanged:
    """Adding IPSec config must not perturb the v4 dataplane."""

    def test_forwarding_works_with_ipsec_loaded(self, ipsec_tree):
        from n2nhu_policy.frame_codec import build_tcp_frame
        from n2nhu_policy.router_shim import ForwardAction
        shim = RouterShim(config_root=ipsec_tree, **_shim_kwargs())
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD

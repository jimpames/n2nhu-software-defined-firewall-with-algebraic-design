"""
Phase M tests — CaptureEngine matching logic.

Covers:
  - Rule must be enabled to match
  - capture_point must align (rules at INGRESS don't fire at POST_NAT etc.)
  - Zone matching (any vs specific)
  - Address-object matching (family-strict, ranges, networks)
  - Service-object matching (proto + ports)
  - match_action filter: any / allow / deny
  - INGRESS path with decision_action=None
  - Multiple matching rules return in declared order
  - Empty config returns empty tuple
  - Disabled rules ignored even if they match
"""

from __future__ import annotations

from ipaddress import IPv4Address, IPv6Address
from pathlib import Path

import pytest

from n2nhu_policy.capture_config_loader import CaptureConfigLoader
from n2nhu_policy.capture_engine import CaptureEngine
from n2nhu_policy.capture_models import CapturePoint
from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.models import Action, Packet, Protocol


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def policy_tree(tmp_path):
    root = tmp_path
    (root / "objects").mkdir()
    (root / "policies").mkdir()
    (root / "zones.ini").write_text(
        "[zones]\n"
        "trusted = lan\n"
        "untrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan]\ntype = network\nvalue = 192.168.1.0/24\n"
        "\n[addr_dmz]\ntype = network\nvalue = 10.0.0.0/24\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
        "\n[svc_http]\nprotocol = tcp\ndst_port = 80\n"
        "\n[svc_https]\nprotocol = tcp\ndst_port = 443\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\nsrc_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\nservice = svc_any\n"
        "schedule = sched_always\naction = ALLOW\n"
    )
    return root


@pytest.fixture
def policy_config(policy_tree):
    return ConfigLoader(policy_tree).load()


def _build_engine(policy_tree, policy_config, capture_ini: str):
    (policy_tree / "policies" / "capture.ini").write_text(capture_ini)
    cap_cfg = CaptureConfigLoader(policy_tree, policy_config).load()
    return CaptureEngine(cap_cfg, policy_config)


def _packet(
    *,
    src_ip="192.168.1.50",
    dst_ip="203.0.113.1",
    src_port=40000,
    dst_port=80,
    protocol=Protocol.TCP,
    ingress="lan",
    egress="wan1",
) -> Packet:
    return Packet(
        ingress_iface=ingress,
        egress_iface=egress,
        src_ip=IPv4Address(src_ip),
        dst_ip=IPv4Address(dst_ip),
        protocol=protocol,
        src_port=src_port,
        dst_port=dst_port,
        icmp_type=None,
        dscp=0,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestEmptyConfig:

    def test_no_rules_no_matches(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules =\n"
        )
        result = eng.match(_packet(), Action.ALLOW, CapturePoint.POST_NAT)
        assert result == ()


class TestCapturePointFilter:

    def test_only_matching_point_fires(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1, c2\n"
            "\n[c1]\ncapture_point = ingress\npcap_file = /tmp/c1.pcapng\n"
            "\n[c2]\ncapture_point = post_nat\npcap_file = /tmp/c2.pcapng\n"
        )
        # INGRESS query: c1 matches, c2 does not
        result = eng.match(_packet(), None, CapturePoint.INGRESS)
        assert {r.id for r in result} == {"c1"}

        # POST_NAT query: c2 matches, c1 does not
        result = eng.match(_packet(), Action.ALLOW, CapturePoint.POST_NAT)
        assert {r.id for r in result} == {"c2"}

    def test_post_policy_isolated(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = post_policy\npcap_file = /tmp/c.pcapng\n"
        )
        # POST_POLICY matches, others don't
        assert eng.match(_packet(), Action.ALLOW, CapturePoint.INGRESS) == ()
        assert eng.match(_packet(), Action.ALLOW, CapturePoint.POST_NAT) == ()
        result = eng.match(_packet(), Action.ALLOW, CapturePoint.POST_POLICY)
        assert len(result) == 1


class TestEnabled:

    def test_disabled_rule_does_not_match(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\nenabled = false\ncapture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
        )
        result = eng.match(_packet(), None, CapturePoint.INGRESS)
        assert result == ()


class TestZoneFilter:

    def test_any_zone_matches_any(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "src_zone = any\ndst_zone = any\n"
        )
        result = eng.match(_packet(ingress="lan", egress="wan1"),
                           None, CapturePoint.INGRESS)
        assert len(result) == 1

    def test_specific_src_zone_matches(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "src_zone = trusted\n"
        )
        # From lan (trusted) — match
        assert len(eng.match(_packet(ingress="lan"), None, CapturePoint.INGRESS)) == 1
        # From wan1 (untrusted) — no match
        assert eng.match(_packet(ingress="wan1"), None, CapturePoint.INGRESS) == ()

    def test_specific_dst_zone_matches(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = post_nat\n"
            "pcap_file = /tmp/c.pcapng\n"
            "dst_zone = untrusted\n"
        )
        # Egress wan1 (untrusted) — match
        assert len(eng.match(
            _packet(egress="wan1"), Action.ALLOW, CapturePoint.POST_NAT
        )) == 1
        # Egress lan (trusted) — no match
        assert eng.match(
            _packet(egress="lan"), Action.ALLOW, CapturePoint.POST_NAT
        ) == ()


class TestAddressFilter:

    def test_src_addr_match(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "src_addr = addr_lan\n"
        )
        # 192.168.1.50 in addr_lan — match
        assert len(eng.match(
            _packet(src_ip="192.168.1.50"), None, CapturePoint.INGRESS,
        )) == 1
        # 10.0.0.5 not in addr_lan — no match
        assert eng.match(
            _packet(src_ip="10.0.0.5"), None, CapturePoint.INGRESS,
        ) == ()

    def test_dst_addr_match(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "dst_addr = addr_dmz\n"
        )
        assert len(eng.match(
            _packet(dst_ip="10.0.0.7"), None, CapturePoint.INGRESS,
        )) == 1
        assert eng.match(
            _packet(dst_ip="172.16.0.5"), None, CapturePoint.INGRESS,
        ) == ()


class TestServiceFilter:

    def test_service_proto_and_port(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = ingress\n"
            "pcap_file = /tmp/c.pcapng\n"
            "service = svc_http\n"
        )
        # TCP/80 — match
        assert len(eng.match(
            _packet(protocol=Protocol.TCP, dst_port=80),
            None, CapturePoint.INGRESS,
        )) == 1
        # TCP/443 — no match
        assert eng.match(
            _packet(protocol=Protocol.TCP, dst_port=443),
            None, CapturePoint.INGRESS,
        ) == ()
        # UDP/80 — no match (proto mismatch)
        assert eng.match(
            _packet(protocol=Protocol.UDP, dst_port=80),
            None, CapturePoint.INGRESS,
        ) == ()


class TestMatchAction:

    def test_action_any_matches_allow_and_deny(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = post_policy\n"
            "pcap_file = /tmp/c.pcapng\n"
            "match_action = any\n"
        )
        assert len(eng.match(_packet(), Action.ALLOW, CapturePoint.POST_POLICY)) == 1
        assert len(eng.match(_packet(), Action.DENY, CapturePoint.POST_POLICY)) == 1

    def test_action_allow_only_matches_allow(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = post_policy\n"
            "pcap_file = /tmp/c.pcapng\n"
            "match_action = allow\n"
        )
        assert len(eng.match(_packet(), Action.ALLOW, CapturePoint.POST_POLICY)) == 1
        assert eng.match(_packet(), Action.DENY, CapturePoint.POST_POLICY) == ()

    def test_action_deny_only_matches_deny(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = post_policy\n"
            "pcap_file = /tmp/c.pcapng\n"
            "match_action = deny\n"
        )
        assert eng.match(_packet(), Action.ALLOW, CapturePoint.POST_POLICY) == ()
        assert len(eng.match(_packet(), Action.DENY, CapturePoint.POST_POLICY)) == 1

    def test_ingress_with_none_action_only_matches_any(self, policy_tree, policy_config):
        """At INGRESS, no policy decision exists yet. Rules with match_action
        of allow/deny do not fire there; only any does."""
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c_any, c_allow, c_deny\n"
            "\n[c_any]\ncapture_point = ingress\npcap_file = /tmp/a.pcapng\nmatch_action = any\n"
            "\n[c_allow]\ncapture_point = ingress\npcap_file = /tmp/al.pcapng\nmatch_action = allow\n"
            "\n[c_deny]\ncapture_point = ingress\npcap_file = /tmp/de.pcapng\nmatch_action = deny\n"
        )
        result = eng.match(_packet(), None, CapturePoint.INGRESS)
        assert {r.id for r in result} == {"c_any"}


class TestMultipleRules:

    def test_match_returns_in_declared_order(self, policy_tree, policy_config):
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = b, a, c\n"
            "\n[a]\ncapture_point = ingress\npcap_file = /tmp/a.pcapng\n"
            "\n[b]\ncapture_point = ingress\npcap_file = /tmp/b.pcapng\n"
            "\n[c]\ncapture_point = ingress\npcap_file = /tmp/c.pcapng\n"
        )
        result = eng.match(_packet(), None, CapturePoint.INGRESS)
        ids = [r.id for r in result]
        assert ids == ["b", "a", "c"]

    def test_partial_match_still_matches_others(self, policy_tree, policy_config):
        """Rules with non-overlapping criteria are independent — one not
        matching does not stop another from matching."""
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c_lan, c_dmz\n"
            "\n[c_lan]\ncapture_point = ingress\npcap_file = /tmp/lan.pcapng\n"
            "src_addr = addr_lan\n"
            "\n[c_dmz]\ncapture_point = ingress\npcap_file = /tmp/dmz.pcapng\n"
            "src_addr = addr_dmz\n"
        )
        # Source 192.168.1.50 — only c_lan should fire
        result = eng.match(_packet(src_ip="192.168.1.50"),
                           None, CapturePoint.INGRESS)
        assert {r.id for r in result} == {"c_lan"}
        # Source 10.0.0.5 — only c_dmz should fire
        result = eng.match(_packet(src_ip="10.0.0.5"),
                           None, CapturePoint.INGRESS)
        assert {r.id for r in result} == {"c_dmz"}


class TestPureFunctionProperty:

    def test_engine_state_does_not_change(self, policy_tree, policy_config):
        """match() must be idempotent — repeated calls with the same
        inputs yield the same outputs."""
        eng = _build_engine(policy_tree, policy_config,
            "[capture_order]\nrules = c1\n"
            "\n[c1]\ncapture_point = ingress\npcap_file = /tmp/c.pcapng\n"
        )
        a = eng.match(_packet(), None, CapturePoint.INGRESS)
        b = eng.match(_packet(), None, CapturePoint.INGRESS)
        c = eng.match(_packet(), None, CapturePoint.INGRESS)
        assert a == b == c

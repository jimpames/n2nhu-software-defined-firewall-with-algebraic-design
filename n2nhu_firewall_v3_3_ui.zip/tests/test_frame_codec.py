"""Tests for frame_codec — byte-level frame parsing and rewriting."""

from __future__ import annotations

import struct
from ipaddress import IPv4Address

import pytest

from n2nhu_policy import (
    FrameParseError,
    build_tcp_frame,
    build_udp_frame,
    parse_frame,
    rewrite_frame_dnat,
    rewrite_frame_full,
    rewrite_frame_snat,
    verify_frame_checksums,
)
from n2nhu_policy.models import Protocol


class TestParseTCPFrame:
    def test_parse_basic_fields(self):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=54321,
            dst_port=443,
            payload=b"hello",
        )
        p = parse_frame(frame)
        assert p.src_ip == IPv4Address("192.168.1.10")
        assert p.dst_ip == IPv4Address("8.8.8.8")
        assert p.src_port == 54321
        assert p.dst_port == 443
        assert p.l4_protocol == Protocol.TCP
        assert p.ip_header_length == 20
        assert p.ip_header_start == 14

    def test_parse_preserves_payload(self):
        frame = build_tcp_frame(
            src_ip=IPv4Address("1.1.1.1"),
            dst_ip=IPv4Address("2.2.2.2"),
            src_port=1000,
            dst_port=2000,
            payload=b"the quick brown fox",
        )
        p = parse_frame(frame)
        payload_start = p.l4_header_start + 20
        payload_end = p.ip_header_start + p.ip_total_length
        assert frame[payload_start:payload_end] == b"the quick brown fox"


class TestParseUDPFrame:
    def test_parse_udp(self):
        frame = build_udp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("1.1.1.1"),
            src_port=33333,
            dst_port=53,
            payload=b"\x12\x34\x01\x00",  # DNS-ish
        )
        p = parse_frame(frame)
        assert p.src_port == 33333
        assert p.dst_port == 53
        assert p.l4_protocol == Protocol.UDP


class TestParseErrors:
    def test_too_short_raises(self):
        with pytest.raises(FrameParseError, match="too short"):
            parse_frame(b"\x00" * 20)

    def test_non_ipv4_ethertype_raises(self):
        # IPv6 ethertype = 0x86DD
        frame = (
            b"\x00" * 6 + b"\x00" * 6 +
            struct.pack("!H", 0x86DD) +
            b"\x00" * 40
        )
        with pytest.raises(FrameParseError, match="not IPv4"):
            parse_frame(frame)


class TestBuiltFrameChecksums:
    """Every frame the builders produce must have valid checksums."""

    def test_tcp_frame_checksums_valid(self):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=54321, dst_port=443,
            payload=b"GET / HTTP/1.1\r\n\r\n",
        )
        ip_ok, l4_ok = verify_frame_checksums(frame)
        assert ip_ok is True
        assert l4_ok is True

    def test_udp_frame_checksums_valid(self):
        frame = build_udp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("1.1.1.1"),
            src_port=33333, dst_port=53,
            payload=b"\x12\x34" + b"\x00" * 30,
        )
        ip_ok, l4_ok = verify_frame_checksums(frame)
        assert ip_ok is True
        assert l4_ok is True

    def test_empty_tcp_payload(self):
        frame = build_tcp_frame(
            src_ip=IPv4Address("10.0.0.1"),
            dst_ip=IPv4Address("10.0.0.2"),
            src_port=22, dst_port=22,
            payload=b"",
        )
        ip_ok, l4_ok = verify_frame_checksums(frame)
        assert ip_ok is True
        assert l4_ok is True

    def test_large_payload(self):
        frame = build_tcp_frame(
            src_ip=IPv4Address("10.0.0.1"),
            dst_ip=IPv4Address("10.0.0.2"),
            src_port=80, dst_port=54321,
            payload=b"X" * 1400,
        )
        ip_ok, l4_ok = verify_frame_checksums(frame)
        assert ip_ok is True
        assert l4_ok is True


class TestRewriteSNATTCP:
    def _base_frame(self, payload=b"data"):
        return build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=54321, dst_port=443,
            payload=payload,
        )

    def test_snat_rewrites_src_and_port(self):
        frame = self._base_frame()
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_snat(
            parsed, IPv4Address("203.0.113.1"), 10000,
        )
        new_parsed = parse_frame(new_frame)
        assert new_parsed.src_ip == IPv4Address("203.0.113.1")
        assert new_parsed.src_port == 10000
        # Unchanged
        assert new_parsed.dst_ip == IPv4Address("8.8.8.8")
        assert new_parsed.dst_port == 443

    def test_snat_preserves_checksums(self):
        frame = self._base_frame()
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_snat(
            parsed, IPv4Address("203.0.113.1"), 10000,
        )
        ip_ok, l4_ok = verify_frame_checksums(new_frame)
        assert ip_ok is True
        assert l4_ok is True

    def test_snat_preserves_payload(self):
        frame = self._base_frame(payload=b"the quick brown fox jumps over the lazy dog")
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_snat(
            parsed, IPv4Address("203.0.113.1"), 10000,
        )
        new_parsed = parse_frame(new_frame)
        payload_start = new_parsed.l4_header_start + 20
        payload_end = new_parsed.ip_header_start + new_parsed.ip_total_length
        assert new_frame[payload_start:payload_end] == \
            b"the quick brown fox jumps over the lazy dog"

    def test_snat_preserves_length(self):
        frame = self._base_frame()
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_snat(
            parsed, IPv4Address("203.0.113.1"), 10000,
        )
        assert len(new_frame) == len(frame)


class TestRewriteSNATUDP:
    def test_udp_snat(self):
        frame = build_udp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("1.1.1.1"),
            src_port=33333, dst_port=53,
            payload=b"dns query payload",
        )
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_snat(
            parsed, IPv4Address("203.0.113.1"), 20000,
        )
        ip_ok, l4_ok = verify_frame_checksums(new_frame)
        assert ip_ok is True
        assert l4_ok is True
        new_parsed = parse_frame(new_frame)
        assert new_parsed.src_ip == IPv4Address("203.0.113.1")
        assert new_parsed.src_port == 20000


class TestRewriteDNAT:
    def test_dnat_tcp(self):
        # Internet → our public IP on 443
        frame = build_tcp_frame(
            src_ip=IPv4Address("198.51.100.77"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=55555, dst_port=443,
            payload=b"GET / HTTP/1.1\r\n",
        )
        parsed = parse_frame(frame)
        # Port-forward to DMZ webserver on 8443
        new_frame = rewrite_frame_dnat(
            parsed, IPv4Address("172.16.0.10"), 8443,
        )
        ip_ok, l4_ok = verify_frame_checksums(new_frame)
        assert ip_ok is True
        assert l4_ok is True
        np = parse_frame(new_frame)
        assert np.dst_ip == IPv4Address("172.16.0.10")
        assert np.dst_port == 8443
        assert np.src_ip == IPv4Address("198.51.100.77")
        assert np.src_port == 55555

    def test_dnat_udp(self):
        frame = build_udp_frame(
            src_ip=IPv4Address("198.51.100.77"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=55555, dst_port=53,
            payload=b"\x12\x34" + b"\x00" * 20,
        )
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_dnat(
            parsed, IPv4Address("172.16.0.20"), 53,
        )
        ip_ok, l4_ok = verify_frame_checksums(new_frame)
        assert ip_ok is True
        assert l4_ok is True


class TestRewriteFull:
    def test_full_rewrite_both_sides(self):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=54321, dst_port=443,
            payload=b"payload",
        )
        parsed = parse_frame(frame)
        new_frame = rewrite_frame_full(
            parsed,
            IPv4Address("203.0.113.1"), 10000,
            IPv4Address("172.16.0.10"), 8443,
        )
        ip_ok, l4_ok = verify_frame_checksums(new_frame)
        assert ip_ok is True
        assert l4_ok is True
        np = parse_frame(new_frame)
        assert np.src_ip == IPv4Address("203.0.113.1")
        assert np.src_port == 10000
        assert np.dst_ip == IPv4Address("172.16.0.10")
        assert np.dst_port == 8443


class TestIncrementalMatchesFresh:
    """
    The fundamental NAT-correctness property: rewrite_frame_snat's incremental
    checksum update must produce the same bytes as a fresh compute.
    """

    def test_snat_incremental_equals_fresh_compute(self):
        # Build the original
        orig = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=54321, dst_port=443,
            payload=b"some payload bytes here",
        )
        parsed = parse_frame(orig)
        # Incremental-update version
        incremental = rewrite_frame_snat(
            parsed, IPv4Address("203.0.113.1"), 10000,
        )
        # Fresh-compute version: build a whole new frame with the new src
        fresh = build_tcp_frame(
            src_ip=IPv4Address("203.0.113.1"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=10000, dst_port=443,
            payload=b"some payload bytes here",
        )
        # Eth headers differ (our rewriter doesn't change them),
        # so compare IP+L4 only
        incremental_ip_onwards = incremental[14:]
        fresh_ip_onwards = fresh[14:]
        assert incremental_ip_onwards == fresh_ip_onwards

    def test_dnat_incremental_equals_fresh(self):
        orig = build_tcp_frame(
            src_ip=IPv4Address("198.51.100.77"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=55555, dst_port=443,
            payload=b"GET /index.html HTTP/1.1\r\n",
        )
        parsed = parse_frame(orig)
        incremental = rewrite_frame_dnat(
            parsed, IPv4Address("172.16.0.10"), 8443,
        )
        fresh = build_tcp_frame(
            src_ip=IPv4Address("198.51.100.77"),
            dst_ip=IPv4Address("172.16.0.10"),
            src_port=55555, dst_port=8443,
            payload=b"GET /index.html HTTP/1.1\r\n",
        )
        assert incremental[14:] == fresh[14:]

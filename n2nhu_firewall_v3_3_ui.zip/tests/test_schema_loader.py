"""Tests for schema_loader and schema_models."""

from __future__ import annotations

from pathlib import Path

import pytest

from n2nhu_ui.schema_loader import SchemaError, SchemaLoader
from n2nhu_ui.schema_models import FieldType, IniSchema, Registry, SectionKind


SCHEMA_DIR = Path(__file__).resolve().parent.parent / "n2nhu_ui" / "schemas"


@pytest.fixture
def registry() -> Registry:
    return SchemaLoader(SCHEMA_DIR).load_registry()


class TestRegistryLoads:
    def test_seven_schemas(self, registry):
        assert len(registry.schemas) == 9

    def test_all_names_unique(self, registry):
        names = [s.name for s in registry.schemas]
        assert len(names) == len(set(names))

    def test_ordered_by_order_field(self, registry):
        ordered = registry.ordered()
        for a, b in zip(ordered, ordered[1:]):
            assert a.order <= b.order

    def test_every_schema_has_default_content(self, registry):
        for s in registry.schemas:
            assert s.default_content.strip() != "", \
                f"schema {s.name!r} has no default_content"

    def test_every_schema_has_at_least_one_section(self, registry):
        for s in registry.schemas:
            assert len(s.sections) >= 1, f"schema {s.name!r} has no sections"

    def test_filenames_unique(self, registry):
        filenames = [s.filename for s in registry.schemas]
        assert len(filenames) == len(set(filenames))


class TestFieldTypes:
    def test_every_field_uses_valid_type(self, registry):
        valid = {t.value for t in FieldType}
        for schema in registry.schemas:
            for sect in schema.sections:
                for f in sect.fields:
                    assert f.type.value in valid

    def test_ref_fields_declare_ref_to(self, registry):
        for schema in registry.schemas:
            for sect in schema.sections:
                for f in sect.fields:
                    if f.type == FieldType.REF:
                        assert f.ref_to != "", (
                            f"ref field {schema.name}.{sect.name}.{f.name} "
                            f"has empty ref_to"
                        )

    def test_ref_targets_exist_in_registry(self, registry):
        registry_names = {s.name for s in registry.schemas}
        for schema in registry.schemas:
            for sect in schema.sections:
                for f in sect.fields:
                    if f.type == FieldType.REF:
                        assert f.ref_to in registry_names, (
                            f"ref field {schema.name}.{sect.name}.{f.name} "
                            f"points to unknown schema {f.ref_to!r}"
                        )

    def test_enum_fields_declare_choices(self, registry):
        for schema in registry.schemas:
            for sect in schema.sections:
                for f in sect.fields:
                    if f.type == FieldType.ENUM:
                        assert len(f.choices) > 0, (
                            f"enum field {schema.name}.{sect.name}.{f.name} "
                            f"has no choices"
                        )


class TestTemplateMatching:
    def test_zone_star_matches_zone_trusted(self, registry):
        zones = registry.by_name("zones")
        matched = zones.section_matching("zone_trusted")
        assert matched is not None
        assert matched.name == "zone_*"

    def test_zone_star_does_not_match_zones(self, registry):
        # "zones" is its own fixed section, should match exactly not the template
        zones = registry.by_name("zones")
        matched = zones.section_matching("zones")
        assert matched is not None
        assert matched.name == "zones"
        assert matched.kind == SectionKind.MAP

    def test_instance_label_extraction(self, registry):
        zones = registry.by_name("zones")
        assert zones.template_instance_label("zone_*", "zone_trusted") == "trusted"
        assert zones.template_instance_label("zone_*", "zone_mgt") == "mgt"

    def test_addr_star_matches(self, registry):
        addresses = registry.by_name("addresses")
        m = addresses.section_matching("addr_lan_net")
        assert m is not None
        assert m.name == "addr_*"

    def test_p_star_matches_policy_rules(self, registry):
        security = registry.by_name("security")
        m = security.section_matching("p010_block_malware")
        assert m is not None
        assert m.name == "p*"


class TestSchemaErrors:
    def test_missing_registry_raises(self, tmp_path):
        with pytest.raises(SchemaError, match="missing registry"):
            SchemaLoader(tmp_path).load_registry()

    def test_missing_schema_file_raises(self, tmp_path):
        (tmp_path / "registry.ini").write_text(
            "[foo]\nschema = nonexistent.schema.ini\n"
        )
        with pytest.raises(SchemaError, match="missing schema file"):
            SchemaLoader(tmp_path).load_registry()

    def test_registry_entry_missing_schema_key(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nother_key = 1\n")
        with pytest.raises(SchemaError, match="missing 'schema'"):
            SchemaLoader(tmp_path).load_registry()

    def test_schema_missing_meta(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nschema = foo.schema.ini\n")
        (tmp_path / "foo.schema.ini").write_text("[section:x]\nkind = fixed\n")
        with pytest.raises(SchemaError, match="__schema__"):
            SchemaLoader(tmp_path).load_registry()

    def test_schema_name_mismatch(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nschema = foo.schema.ini\n")
        (tmp_path / "foo.schema.ini").write_text(
            "[__schema__]\nname = bar\nfilename = bar.ini\ntitle = Bar\n"
        )
        with pytest.raises(SchemaError, match="does not match registry"):
            SchemaLoader(tmp_path).load_registry()

    def test_field_missing_type(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nschema = foo.schema.ini\n")
        (tmp_path / "foo.schema.ini").write_text("""
[__schema__]
name = foo
filename = foo.ini
title = Foo
[section:s]
kind = fixed
[field:s.x]
default = 0
""")
        with pytest.raises(SchemaError, match="missing 'type'"):
            SchemaLoader(tmp_path).load_registry()

    def test_field_references_unknown_section(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nschema = foo.schema.ini\n")
        (tmp_path / "foo.schema.ini").write_text("""
[__schema__]
name = foo
filename = foo.ini
title = Foo
[section:s]
kind = fixed
[field:t.x]
type = string
""")
        with pytest.raises(SchemaError, match="unknown section"):
            SchemaLoader(tmp_path).load_registry()

    def test_field_malformed_qualified_name(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nschema = foo.schema.ini\n")
        (tmp_path / "foo.schema.ini").write_text("""
[__schema__]
name = foo
filename = foo.ini
title = Foo
[section:s]
kind = fixed
[field:noDot]
type = string
""")
        with pytest.raises(SchemaError, match="section.field"):
            SchemaLoader(tmp_path).load_registry()

    def test_unknown_field_type(self, tmp_path):
        (tmp_path / "registry.ini").write_text("[foo]\nschema = foo.schema.ini\n")
        (tmp_path / "foo.schema.ini").write_text("""
[__schema__]
name = foo
filename = foo.ini
title = Foo
[section:s]
kind = fixed
[field:s.x]
type = quantum
""")
        with pytest.raises(ValueError, match="Unknown field type"):
            SchemaLoader(tmp_path).load_registry()

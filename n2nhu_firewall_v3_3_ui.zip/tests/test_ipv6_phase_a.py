"""
Phase A tests — IPv6 plumbing.

Covers:
  - Address loader accepts v6 host / network / range
  - Range family consistency (can't cross v4/v6 in one range)
  - Resolver matches v6 IPs against v6 objects
  - Resolver is family-strict: v4 IP never matches a v6 object and vice versa
  - Mixed-family address groups work (v4 member + v6 member)
  - Packet.version property
  - AddressObject.version property
"""

from __future__ import annotations

import tempfile
from ipaddress import IPv4Address, IPv6Address, ip_address, ip_network
from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.errors import ConfigError, ResolverError
from n2nhu_policy.models import (
    AddressObject, AddressType, Packet, Protocol,
)
from n2nhu_policy.object_resolver import ObjectResolver


def _build_addr(
    id_: str, type_: AddressType, *,
    host=None, network=None, range_start=None, range_end=None,
    members=(),
) -> AddressObject:
    return AddressObject(
        id=id_, type=type_,
        host=host, network=network,
        range_start=range_start, range_end=range_end,
        members=members,
    )


class TestAddressObjectVersion:
    def test_v4_host(self):
        a = _build_addr("h", AddressType.HOST, host=IPv4Address("10.0.0.1"))
        assert a.version == 4

    def test_v6_host(self):
        a = _build_addr("h", AddressType.HOST, host=IPv6Address("2001:db8::1"))
        assert a.version == 6

    def test_v4_network(self):
        a = _build_addr("n", AddressType.NETWORK, network=ip_network("10.0.0.0/8"))
        assert a.version == 4

    def test_v6_network(self):
        a = _build_addr("n", AddressType.NETWORK, network=ip_network("2001:db8::/32"))
        assert a.version == 6

    def test_group_version_is_none(self):
        """Groups can be mixed-family; .version returns None."""
        a = _build_addr("g", AddressType.GROUP, members=("a1", "a2"))
        assert a.version is None

    def test_fqdn_version_is_none(self):
        a = AddressObject(id="f", type=AddressType.FQDN, fqdn="example.com")
        assert a.version is None


class TestPacketVersion:
    def test_v4_packet(self):
        p = Packet(
            ingress_iface="lan", egress_iface="wan1",
            src_ip=IPv4Address("10.0.0.1"), dst_ip=IPv4Address("8.8.8.8"),
            protocol=Protocol.TCP, dst_port=80,
        )
        assert p.version == 4

    def test_v6_packet(self):
        p = Packet(
            ingress_iface="lan", egress_iface="wan1",
            src_ip=IPv6Address("2001:db8::1"), dst_ip=IPv6Address("2001:4860:4860::8888"),
            protocol=Protocol.TCP, dst_port=80,
        )
        assert p.version == 6


class TestConfigLoaderV6Addresses:
    """The config loader accepts v6 hosts, networks, and ranges in addresses.ini."""

    @pytest.fixture
    def v6_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "objects").mkdir()
            (root / "policies").mkdir()
            # Minimal zones
            (root / "zones.ini").write_text(
                "[zones]\n"
                "trusted = lan\n"
                "untrusted = wan1\n"
                "\n[defaults]\n"
                "default_any_to_any = DENY\n"
            )
            # v6 addresses
            (root / "objects" / "addresses.ini").write_text(
                "[addr_any]\n"
                "type = network\nvalue = 0.0.0.0/0\n"
                "\n[addr_any_v6]\n"
                "type = network\nvalue = ::/0\n"
                "\n[addr_lan_v6]\n"
                "type = network\nvalue = 2001:db8:cafe::/48\n"
                "\n[addr_server_v6]\n"
                "type = host\nvalue = 2001:db8:cafe:1::100\n"
                "\n[addr_dhcp_range_v6]\n"
                "type = range\nvalue = 2001:db8:cafe:1::1000-2001:db8:cafe:1::1fff\n"
                "\n[addrgrp_mixed]\n"
                "type = group\nmembers = addr_lan_v6, addr_any\n"
            )
            (root / "objects" / "services.ini").write_text(
                "[svc_any]\nprotocol = any\n"
            )
            (root / "objects" / "schedules.ini").write_text(
                "[sched_always]\ntype = always\n"
            )
            (root / "policies" / "security.ini").write_text(
                "[policy_order]\nrules = p_deny\n"
                "\n[p_deny]\n"
                "src_zone = any\ndst_zone = any\n"
                "src_addr = addr_any\ndst_addr = addr_any\n"
                "service = svc_any\nschedule = sched_always\n"
                "action = DENY\n"
            )
            yield root

    def test_loader_accepts_v6_addresses(self, v6_tree):
        cfg = ConfigLoader(v6_tree).load()
        assert "addr_any_v6" in cfg.addresses
        assert cfg.addresses["addr_any_v6"].network == ip_network("::/0")
        assert cfg.addresses["addr_server_v6"].host == IPv6Address("2001:db8:cafe:1::100")
        assert cfg.addresses["addr_lan_v6"].version == 6

    def test_loader_accepts_v6_range(self, v6_tree):
        cfg = ConfigLoader(v6_tree).load()
        obj = cfg.addresses["addr_dhcp_range_v6"]
        assert obj.range_start.version == 6
        assert obj.range_end.version == 6

    def test_loader_rejects_cross_family_range(self):
        """A range where start is v4 and end is v6 should be rejected."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "objects").mkdir(); (root / "policies").mkdir()
            (root / "zones.ini").write_text(
                "[zones]\ntrusted = lan\n\n[defaults]\ndefault_any_to_any = DENY\n"
            )
            (root / "objects" / "addresses.ini").write_text(
                "[addr_bad_range]\ntype = range\nvalue = 10.0.0.1-2001:db8::1\n"
            )
            (root / "objects" / "services.ini").write_text("[svc_any]\nprotocol = any\n")
            (root / "objects" / "schedules.ini").write_text("[sched_always]\ntype = always\n")
            (root / "policies" / "security.ini").write_text("[policy_order]\nrules =\n")
            with pytest.raises(ConfigError) as ei:
                ConfigLoader(root).load()
            assert "same IP version" in str(ei.value) or "v4-v6" in str(ei.value)

    def test_loader_rejects_v6_in_v4_slot_still_errors_on_malformed(self):
        """A malformed address is still rejected."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "objects").mkdir(); (root / "policies").mkdir()
            (root / "zones.ini").write_text(
                "[zones]\ntrusted = lan\n\n[defaults]\ndefault_any_to_any = DENY\n"
            )
            (root / "objects" / "addresses.ini").write_text(
                "[addr_bad]\ntype = host\nvalue = not-an-ip\n"
            )
            (root / "objects" / "services.ini").write_text("[svc_any]\nprotocol = any\n")
            (root / "objects" / "schedules.ini").write_text("[sched_always]\ntype = always\n")
            (root / "policies" / "security.ini").write_text("[policy_order]\nrules =\n")
            with pytest.raises(ConfigError):
                ConfigLoader(root).load()


class TestResolverFamilyStrict:
    """The object resolver is strict about IP family matching."""

    @pytest.fixture
    def resolver(self):
        addresses = {
            "addr_v4_lan": _build_addr(
                "addr_v4_lan", AddressType.NETWORK,
                network=ip_network("192.168.1.0/24"),
            ),
            "addr_v6_lan": _build_addr(
                "addr_v6_lan", AddressType.NETWORK,
                network=ip_network("2001:db8::/32"),
            ),
            "addr_v6_host": _build_addr(
                "addr_v6_host", AddressType.HOST,
                host=IPv6Address("2001:db8::1"),
            ),
            "addr_v6_range": _build_addr(
                "addr_v6_range", AddressType.RANGE,
                range_start=IPv6Address("2001:db8::1000"),
                range_end=IPv6Address("2001:db8::1fff"),
            ),
            "addrgrp_mixed": _build_addr(
                "addrgrp_mixed", AddressType.GROUP,
                members=("addr_v4_lan", "addr_v6_lan"),
            ),
        }
        return ObjectResolver(addresses, {})

    def test_v6_ip_matches_v6_network(self, resolver):
        assert resolver.ip_in_address(IPv6Address("2001:db8::1"), "addr_v6_lan")

    def test_v4_ip_does_NOT_match_v6_network(self, resolver):
        """Strict family: a v4 IP never matches a v6 object."""
        assert not resolver.ip_in_address(IPv4Address("192.168.1.1"), "addr_v6_lan")

    def test_v6_ip_does_NOT_match_v4_network(self, resolver):
        """Strict family: a v6 IP never matches a v4 object."""
        assert not resolver.ip_in_address(IPv6Address("2001:db8::1"), "addr_v4_lan")

    def test_v4_ip_matches_v4_network(self, resolver):
        assert resolver.ip_in_address(IPv4Address("192.168.1.100"), "addr_v4_lan")

    def test_v6_host_match(self, resolver):
        """A /128 v6 host should match only itself."""
        assert resolver.ip_in_address(IPv6Address("2001:db8::1"), "addr_v6_host")
        assert not resolver.ip_in_address(IPv6Address("2001:db8::2"), "addr_v6_host")

    def test_v6_range_match(self, resolver):
        """v6 ranges match inside, not outside."""
        assert resolver.ip_in_address(IPv6Address("2001:db8::1500"), "addr_v6_range")
        assert not resolver.ip_in_address(IPv6Address("2001:db8::2000"), "addr_v6_range")

    def test_mixed_family_group_matches_v4(self, resolver):
        """A group containing both v4 and v6 members matches either family."""
        assert resolver.ip_in_address(IPv4Address("192.168.1.5"), "addrgrp_mixed")

    def test_mixed_family_group_matches_v6(self, resolver):
        assert resolver.ip_in_address(IPv6Address("2001:db8::5"), "addrgrp_mixed")

    def test_mixed_family_group_rejects_non_member(self, resolver):
        """A v4 address not in the v4 member and a v6 address not in the v6 member."""
        assert not resolver.ip_in_address(IPv4Address("10.0.0.1"), "addrgrp_mixed")
        assert not resolver.ip_in_address(IPv6Address("fe80::1"), "addrgrp_mixed")


class TestResolverV6Groups:
    """Nested groups with v6 members work and don't create cycles."""

    def test_nested_v6_groups(self):
        addresses = {
            "v6_a": _build_addr("v6_a", AddressType.HOST, host=IPv6Address("2001:db8::1")),
            "v6_b": _build_addr("v6_b", AddressType.HOST, host=IPv6Address("2001:db8::2")),
            "grp_inner": _build_addr(
                "grp_inner", AddressType.GROUP, members=("v6_a", "v6_b"),
            ),
            "grp_outer": _build_addr(
                "grp_outer", AddressType.GROUP, members=("grp_inner",),
            ),
        }
        r = ObjectResolver(addresses, {})
        assert r.ip_in_address(IPv6Address("2001:db8::1"), "grp_outer")
        assert r.ip_in_address(IPv6Address("2001:db8::2"), "grp_outer")
        assert not r.ip_in_address(IPv6Address("2001:db8::3"), "grp_outer")

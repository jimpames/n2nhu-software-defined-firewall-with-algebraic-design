"""
Drift detection: ensures every schema's default_content is accepted by the
actual ConfigLoader / NATConfigLoader / PBRConfigLoader in n2nhu_policy.

This is the test Jim asked for: "A test that loads each schema, constructs
a matrix of (all fields the loader accepts) vs (all fields the schema
declares), and fails CI if they differ."

We do this by the most reliable method: write each schema's default content
to a temp directory and ask the real loader to parse it. If it parses
cleanly, the schema's defaults are compatible with the loader. If not,
the drift is real and the test catches it.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.nat_config_loader import NATConfigLoader
from n2nhu_policy.pbr_config_loader import PBRConfigLoader
from n2nhu_ui.schema_loader import SchemaLoader


SCHEMA_DIR = Path(__file__).resolve().parent.parent / "n2nhu_ui" / "schemas"


@pytest.fixture
def defaults_tree(tmp_path):
    """
    Write every schema's default_content into tmp_path in the same layout
    the engine expects (zones.ini at root, objects/*.ini under objects/,
    policies/*.ini under policies/).
    """
    registry = SchemaLoader(SCHEMA_DIR).load_registry()
    for schema in registry.schemas:
        file_path = tmp_path / schema.filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        content = schema.default_content
        if not content.endswith("\n"):
            content += "\n"
        file_path.write_text(content, encoding="utf-8")
    return tmp_path


class TestSchemaDefaultsAreEngineValid:
    """
    The defining invariant: every schema's default_content must be accepted
    by the real engine's config loaders. If this fails, the schema and loader
    have drifted and operators using Restore Defaults would produce broken
    configs.
    """

    def test_policy_config_loads_from_defaults(self, defaults_tree):
        cfg = ConfigLoader(defaults_tree).load()
        # Core invariants
        assert len(cfg.zones) > 0
        assert len(cfg.addresses) > 0
        assert len(cfg.services) > 0
        assert len(cfg.schedules) > 0
        assert len(cfg.policies) > 0

    def test_nat_config_loads_from_defaults(self, defaults_tree):
        policy_cfg = ConfigLoader(defaults_tree).load()
        nat_cfg = NATConfigLoader(defaults_tree, policy_cfg).load()
        assert len(nat_cfg.rules) > 0

    def test_pbr_config_loads_from_defaults(self, defaults_tree):
        policy_cfg = ConfigLoader(defaults_tree).load()
        pbr_cfg = PBRConfigLoader(defaults_tree, policy_cfg).load()
        assert len(pbr_cfg.rules) > 0

    def test_full_three_plane_load(self, defaults_tree):
        """Load all three planes together — proves the cross-plane refs resolve."""
        policy_cfg = ConfigLoader(defaults_tree).load()
        nat_cfg = NATConfigLoader(defaults_tree, policy_cfg).load()
        pbr_cfg = PBRConfigLoader(defaults_tree, policy_cfg).load()
        # Every address referenced by NAT rules must exist in policy_cfg
        for rule in nat_cfg.rules:
            for addr_attr in ("src_addr", "dst_addr"):
                addr = getattr(rule, addr_attr)
                if addr:
                    assert addr in policy_cfg.addresses, (
                        f"NAT rule {rule.id}.{addr_attr} references "
                        f"undefined address {addr!r}"
                    )

    def test_defaults_round_trip_through_restore(self, defaults_tree, tmp_path):
        """
        The exact flow the UI triggers: read schema defaults, write to disk,
        reload with the real engine. Proves the full user-visible 'Restore
        Defaults' button pipeline produces an engine-parseable config.
        """
        # Use a pristine empty directory
        work = tmp_path / "work"
        work.mkdir()

        registry = SchemaLoader(SCHEMA_DIR).load_registry()
        for schema in registry.schemas:
            target = work / schema.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            content = schema.default_content
            if not content.endswith("\n"):
                content += "\n"
            target.write_text(content, encoding="utf-8")

        # Now load from scratch
        policy_cfg = ConfigLoader(work).load()
        NATConfigLoader(work, policy_cfg).load()
        PBRConfigLoader(work, policy_cfg).load()


class TestSchemaFileFixturesAlign:
    """
    Also sanity-check that schema files reference only existing fixture objects
    where they can. This catches schemas that would render but refer to
    conceptual objects that don't exist.
    """

    def test_schema_default_mentions_plausible_addresses(self):
        """
        Every address mentioned by name in the NAT/PBR/security defaults
        (e.g. addr_lan_net) must actually appear in addresses.ini's defaults.
        """
        registry = SchemaLoader(SCHEMA_DIR).load_registry()
        addresses_schema = registry.by_name("addresses")
        # Extract all [addr_*] section names from its default content
        declared_addrs = set()
        for line in addresses_schema.default_content.splitlines():
            line = line.strip()
            if line.startswith("[") and line.endswith("]"):
                name = line[1:-1]
                if name.startswith("addr_"):
                    declared_addrs.add(name)

        assert "addr_any" in declared_addrs, \
            "addresses defaults must at minimum declare addr_any"
        assert "addr_lan_net" in declared_addrs

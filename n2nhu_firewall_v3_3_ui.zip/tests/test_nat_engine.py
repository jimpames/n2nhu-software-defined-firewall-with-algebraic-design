"""
Tests for NATEngine — the full translate(packet, now) pipeline.

Covers all four NAT types end-to-end, including forward + reverse flows,
session reuse, port pool exhaustion, and the overflow chain.
"""

from __future__ import annotations

from datetime import datetime
from ipaddress import IPv4Address
from zoneinfo import ZoneInfo

import pytest

from n2nhu_policy import (
    ConfigLoader,
    NATConfigLoader,
    NATDenied,
    NATEngine,
    NATType,
    Packet,
    PassThrough,
    Protocol,
    TranslatedPacket,
)

NY = ZoneInfo("America/New_York")
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def policy_config(fixture_root):
    return ConfigLoader(fixture_root).load()


@pytest.fixture
def nat_config(fixture_root, policy_config):
    return NATConfigLoader(fixture_root, policy_config).load()


@pytest.fixture
def interface_ips():
    return {
        "lan": IPv4Address("192.168.1.1"),
        "wan1": IPv4Address("203.0.113.1"),
        "wan2": IPv4Address("203.0.113.2"),
        "dmz": IPv4Address("172.16.0.1"),
        "wifi_guest": IPv4Address("192.168.99.1"),
        "wifi_corp": IPv4Address("192.168.1.2"),
        "mgt": IPv4Address("10.255.0.1"),
    }


@pytest.fixture
def nat_engine(policy_config, nat_config, interface_ips):
    return NATEngine(policy_config, nat_config, interface_ips=interface_ips)


def _pkt(
    ingress="lan",
    egress="wan1",
    src="192.168.1.10",
    dst="8.8.8.8",
    proto=Protocol.TCP,
    sport=54321,
    dport=443,
    icmp=None,
):
    return Packet(
        ingress_iface=ingress,
        egress_iface=egress,
        src_ip=IPv4Address(src),
        dst_ip=IPv4Address(dst),
        protocol=proto,
        src_port=sport,
        dst_port=dport,
        icmp_type=icmp,
    )


# ---------------------------------------------------------------------------
# SNAT
# ---------------------------------------------------------------------------


class TestSNATForward:
    def test_snat_translates_src(self, nat_engine):
        result = nat_engine.translate(_pkt(), BIZ)
        assert isinstance(result, TranslatedPacket)
        # src rewritten to public WAN IP
        assert result.src_ip == IPv4Address("203.0.113.1")
        # src port came from the pool
        assert 10000 <= result.src_port <= 60000
        # dst unchanged
        assert result.dst_ip == IPv4Address("8.8.8.8")
        assert result.dst_port == 443
        assert result.rule_id == "n010_lan_snat"

    def test_snat_creates_session(self, nat_engine):
        assert len(nat_engine.session_table) == 0
        nat_engine.translate(_pkt(), BIZ)
        assert len(nat_engine.session_table) == 1

    def test_snat_different_flows_get_different_ports(self, nat_engine):
        r1 = nat_engine.translate(_pkt(src="192.168.1.10", sport=11111), BIZ)
        r2 = nat_engine.translate(_pkt(src="192.168.1.11", sport=22222), BIZ)
        assert isinstance(r1, TranslatedPacket)
        assert isinstance(r2, TranslatedPacket)
        assert r1.src_port != r2.src_port

    def test_snat_same_flow_reuses_session(self, nat_engine):
        r1 = nat_engine.translate(_pkt(), BIZ)
        r2 = nat_engine.translate(_pkt(), BIZ)  # same tuple
        assert isinstance(r1, TranslatedPacket)
        assert isinstance(r2, TranslatedPacket)
        # Same session → same translated port
        assert r1.src_port == r2.src_port
        assert r1.session_id == r2.session_id
        # Only one session was created
        assert len(nat_engine.session_table) == 1

    def test_snat_udp_also_works(self, nat_engine):
        pkt = _pkt(proto=Protocol.UDP, dport=53, sport=33333)
        result = nat_engine.translate(pkt, BIZ)
        assert isinstance(result, TranslatedPacket)
        assert result.src_ip == IPv4Address("203.0.113.1")


class TestSNATReverse:
    def test_snat_return_packet_reverses_dst(self, nat_engine):
        # Forward: establish session
        fwd = nat_engine.translate(_pkt(src="192.168.1.10", sport=54321), BIZ)
        assert isinstance(fwd, TranslatedPacket)

        # Return: 8.8.8.8 replies to our public IP + xlated port
        return_pkt = _pkt(
            ingress="wan1", egress="lan",
            src="8.8.8.8", dst="203.0.113.1",
            sport=443, dport=fwd.src_port,
        )
        rev = nat_engine.translate(return_pkt, BIZ)
        assert isinstance(rev, TranslatedPacket)
        # dst rewritten back to original LAN client
        assert rev.dst_ip == IPv4Address("192.168.1.10")
        assert rev.dst_port == 54321
        # src unchanged (it's from the internet)
        assert rev.src_ip == IPv4Address("8.8.8.8")
        assert rev.src_port == 443

    def test_snat_return_before_forward_does_nothing(self, nat_engine):
        """A 'return' packet with no prior session just falls through."""
        return_pkt = _pkt(
            ingress="wan1", egress="lan",
            src="8.8.8.8", dst="203.0.113.1",
            sport=443, dport=55555,
        )
        result = nat_engine.translate(return_pkt, BIZ)
        # No matching rule for untrusted->trusted — falls through
        assert isinstance(result, PassThrough)


# ---------------------------------------------------------------------------
# DNAT
# ---------------------------------------------------------------------------


class TestDNAT:
    def test_dnat_translates_dst(self, nat_engine):
        pkt = _pkt(
            ingress="wan1", egress="wan1",
            src="198.51.100.77", dst="203.0.113.1",
            sport=55555, dport=443,
        )
        result = nat_engine.translate(pkt, BIZ)
        assert isinstance(result, TranslatedPacket)
        # dst rewritten to DMZ webserver
        assert result.dst_ip == IPv4Address("172.16.0.10")
        # dst port unchanged (translate_dst_port = 0 means keep)
        assert result.dst_port == 443
        # src unchanged
        assert result.src_ip == IPv4Address("198.51.100.77")
        assert result.src_port == 55555

    def test_dnat_return_traffic_reverses_src(self, nat_engine):
        # Forward: internet -> public IP -> DMZ rewrite
        fwd_pkt = _pkt(
            ingress="wan1", egress="wan1",
            src="198.51.100.77", dst="203.0.113.1",
            sport=55555, dport=443,
        )
        fwd = nat_engine.translate(fwd_pkt, BIZ)
        assert isinstance(fwd, TranslatedPacket)

        # Return: DMZ webserver sending reply back to internet client
        return_pkt = _pkt(
            ingress="dmz", egress="wan1",
            src="172.16.0.10", dst="198.51.100.77",
            sport=443, dport=55555,
        )
        rev = nat_engine.translate(return_pkt, BIZ)
        assert isinstance(rev, TranslatedPacket)
        # src rewritten to public-facing IP so the internet client sees the reply
        # coming from the same address it connected to
        assert rev.src_ip == IPv4Address("203.0.113.1")
        assert rev.src_port == 443


# ---------------------------------------------------------------------------
# Static NAT
# ---------------------------------------------------------------------------


class TestStaticNAT:
    def test_static_nat_forward_rewrites_src(self, nat_engine):
        # Mailserver sending outbound
        pkt = _pkt(
            ingress="dmz", egress="wan1",
            src="172.16.0.20", dst="8.8.8.8",
            sport=33333, dport=25,
        )
        result = nat_engine.translate(pkt, BIZ)
        assert isinstance(result, TranslatedPacket)
        assert result.src_ip == IPv4Address("203.0.113.25")
        assert result.src_port == 33333  # port unchanged for static NAT
        assert result.rule_id == "n030_mail_static_nat"

    def test_static_nat_reverse_rewrites_dst(self, nat_engine):
        # Internet client hitting the mailserver's public IP
        pkt = _pkt(
            ingress="wan1", egress="dmz",
            src="198.51.100.99", dst="203.0.113.25",
            sport=44444, dport=25,
        )
        result = nat_engine.translate(pkt, BIZ)
        assert isinstance(result, TranslatedPacket)
        assert result.dst_ip == IPv4Address("172.16.0.20")
        assert result.dst_port == 25  # port unchanged
        assert result.rule_id == "n030_mail_static_nat"

    def test_static_nat_is_stateless(self, nat_engine):
        """Static NAT should NOT create session table entries."""
        nat_engine.translate(
            _pkt(
                ingress="dmz", egress="wan1",
                src="172.16.0.20", dst="8.8.8.8",
                sport=33333, dport=25,
            ),
            BIZ,
        )
        # No sessions created
        assert len(nat_engine.session_table) == 0


# ---------------------------------------------------------------------------
# No-NAT (bypass)
# ---------------------------------------------------------------------------


class TestNoNAT:
    def test_intrazone_passes_through(self, nat_engine):
        pkt = _pkt(
            ingress="lan", egress="lan",
            src="192.168.1.10", dst="192.168.1.50",
            sport=22222, dport=80,
        )
        result = nat_engine.translate(pkt, BIZ)
        assert isinstance(result, PassThrough)
        assert result.rule_id == "n099_no_nat_intrazone"

    def test_no_session_created(self, nat_engine):
        nat_engine.translate(
            _pkt(
                ingress="lan", egress="lan",
                src="192.168.1.10", dst="192.168.1.50",
                sport=22222, dport=80,
            ),
            BIZ,
        )
        assert len(nat_engine.session_table) == 0


# ---------------------------------------------------------------------------
# Rule ordering and matching
# ---------------------------------------------------------------------------


class TestRuleOrdering:
    def test_no_match_passes_through(self, nat_engine):
        # dmz -> untrusted is not covered by any NAT rule in the fixture
        # (static_nat matches on address, not zone pair)
        pkt = _pkt(
            ingress="dmz", egress="wan1",
            src="172.16.0.99",  # not the mailserver, not the webserver
            dst="8.8.8.8",
            sport=11111, dport=80,
        )
        result = nat_engine.translate(pkt, BIZ)
        assert isinstance(result, PassThrough)

    def test_rule_order_preserved(self, nat_config):
        ids = [r.id for r in nat_config.rules]
        assert ids[0] == "n010_lan_snat"
        assert ids[-1] == "n099_no_nat_intrazone"


# ---------------------------------------------------------------------------
# Port pool exhaustion
# ---------------------------------------------------------------------------


class TestPortPoolExhaustion:
    def test_exhausted_pool_returns_denied(self, policy_config, interface_ips):
        """
        Build a NATConfig with a tiny 2-port pool and a simple overflow-empty
        chain, drain it, and verify the third allocation returns NATDenied.
        """
        from n2nhu_policy import NATConfig, NATRule, PortPoolSpec

        small_pool_rule = NATRule(
            id="n_tiny",
            type=NATType.SOURCE_NAT,
            src_zone="trusted", dst_zone="untrusted",
            src_addr="addrgrp_internal", dst_addr="addr_any",
            service="svc_any", schedule="sched_always",
            translate_src_to="interface",
            port_pool=PortPoolSpec(20000, 20001),  # only 2 ports
        )
        cfg = NATConfig(rules=(small_pool_rule,))
        engine = NATEngine(policy_config, cfg, interface_ips=interface_ips)

        # First two succeed
        r1 = engine.translate(_pkt(src="192.168.1.10", sport=111), BIZ)
        r2 = engine.translate(_pkt(src="192.168.1.11", sport=222), BIZ)
        assert isinstance(r1, TranslatedPacket)
        assert isinstance(r2, TranslatedPacket)

        # Third should be denied (pool empty, no overflow)
        r3 = engine.translate(_pkt(src="192.168.1.12", sport=333), BIZ)
        assert isinstance(r3, NATDenied)
        assert "exhausted" in r3.reason

    def test_overflow_chain_picks_up_the_slack(self, policy_config, interface_ips):
        """When primary pool is exhausted, overflow chain is consulted."""
        from n2nhu_policy import NATConfig, NATRule, PortPoolSpec

        primary = NATRule(
            id="n_primary",
            type=NATType.SOURCE_NAT,
            src_zone="trusted", dst_zone="untrusted",
            src_addr="addrgrp_internal", dst_addr="addr_any",
            service="svc_any", schedule="sched_always",
            translate_src_to="interface",
            port_pool=PortPoolSpec(20000, 20000),  # single port
        )
        backup = NATRule(
            id="n_backup",
            type=NATType.SOURCE_NAT,
            src_zone="trusted", dst_zone="untrusted",
            src_addr="addrgrp_internal", dst_addr="addr_any",
            service="svc_any", schedule="sched_always",
            translate_src_to="interface",
            port_pool=PortPoolSpec(30000, 30000),
        )
        cfg = NATConfig(
            rules=(primary, backup),
            overflow_chain=("n_backup",),
        )
        engine = NATEngine(policy_config, cfg, interface_ips=interface_ips)

        r1 = engine.translate(_pkt(src="192.168.1.10", sport=111), BIZ)
        r2 = engine.translate(_pkt(src="192.168.1.11", sport=222), BIZ)
        assert isinstance(r1, TranslatedPacket)
        assert isinstance(r2, TranslatedPacket)
        # First came from primary, second from backup
        assert r1.src_port == 20000
        assert r2.src_port == 30000
        assert r1.rule_id == "n_primary"
        assert r2.rule_id == "n_backup"


# ---------------------------------------------------------------------------
# Session expiry integration
# ---------------------------------------------------------------------------


class TestSessionExpiry:
    def test_expired_session_frees_port(self, policy_config, interface_ips):
        """After reaper evicts, the port returns to the pool and can reallocate."""
        from n2nhu_policy import NATConfig, NATRule, PortPoolSpec

        rule = NATRule(
            id="n_small",
            type=NATType.SOURCE_NAT,
            src_zone="trusted", dst_zone="untrusted",
            src_addr="addrgrp_internal", dst_addr="addr_any",
            service="svc_any", schedule="sched_always",
            translate_src_to="interface",
            port_pool=PortPoolSpec(20000, 20000),  # single port
            tcp_half_open_timeout=10,
        )
        # Use controllable clock
        clock_now = [1000.0]
        def clock():
            return clock_now[0]

        cfg = NATConfig(rules=(rule,))
        engine = NATEngine(
            policy_config, cfg,
            interface_ips=interface_ips,
            clock=clock,
        )

        r1 = engine.translate(_pkt(src="192.168.1.10", sport=111), BIZ)
        assert isinstance(r1, TranslatedPacket)
        assert r1.src_port == 20000

        # Second allocation would fail immediately (pool empty)
        r_denied = engine.translate(_pkt(src="192.168.1.11", sport=222), BIZ)
        assert isinstance(r_denied, NATDenied)

        # Advance clock past timeout and reap
        clock_now[0] = 1020.0
        evicted = engine.session_table.reap_once()
        assert evicted == 1

        # Now a new allocation succeeds
        r2 = engine.translate(_pkt(src="192.168.1.12", sport=333), BIZ)
        assert isinstance(r2, TranslatedPacket)
        assert r2.src_port == 20000


# ---------------------------------------------------------------------------
# Interface IP resolution
# ---------------------------------------------------------------------------


class TestInterfaceMode:
    def test_translate_src_to_interface_uses_egress_iface_ip(
        self, policy_config, interface_ips,
    ):
        from n2nhu_policy import NATConfig, NATRule, PortPoolSpec

        rule = NATRule(
            id="n_iface",
            type=NATType.SOURCE_NAT,
            src_zone="trusted", dst_zone="untrusted",
            src_addr="addrgrp_internal", dst_addr="addr_any",
            service="svc_any", schedule="sched_always",
            translate_src_to="interface",   # use interface IP
            port_pool=PortPoolSpec(10000, 10999),
        )
        cfg = NATConfig(rules=(rule,))
        engine = NATEngine(policy_config, cfg, interface_ips=interface_ips)

        r1 = engine.translate(_pkt(egress="wan1"), BIZ)
        r2 = engine.translate(
            _pkt(egress="wan2", src="192.168.1.11", sport=22222),
            BIZ,
        )
        assert isinstance(r1, TranslatedPacket)
        assert isinstance(r2, TranslatedPacket)
        # Different egress interfaces → different translated src IPs
        assert r1.src_ip == IPv4Address("203.0.113.1")
        assert r2.src_ip == IPv4Address("203.0.113.2")

    def test_interface_mode_with_no_iface_ip_denied(self, policy_config):
        from n2nhu_policy import NATConfig, NATRule, PortPoolSpec

        rule = NATRule(
            id="n_iface",
            type=NATType.SOURCE_NAT,
            src_zone="trusted", dst_zone="untrusted",
            src_addr="addrgrp_internal", dst_addr="addr_any",
            service="svc_any", schedule="sched_always",
            translate_src_to="interface",
            port_pool=PortPoolSpec(10000, 10999),
        )
        cfg = NATConfig(rules=(rule,))
        # Empty interface_ips — wan1 has no assigned IP
        engine = NATEngine(policy_config, cfg, interface_ips={})

        result = engine.translate(_pkt(), BIZ)
        assert isinstance(result, NATDenied)
        assert "no IP" in result.reason

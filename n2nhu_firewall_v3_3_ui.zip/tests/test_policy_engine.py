"""Tests for PolicyEngine — first-match semantics, wildcards, defaults."""

from __future__ import annotations

from datetime import datetime
from ipaddress import IPv4Address
from zoneinfo import ZoneInfo

import pytest

from n2nhu_policy import Action, Packet, Protocol

NY = ZoneInfo("America/New_York")


def _pkt(
    ingress="lan",
    egress="wan1",
    src="192.168.1.10",
    dst="8.8.8.8",
    proto=Protocol.TCP,
    sport=54321,
    dport=80,
    icmp=None,
):
    return Packet(
        ingress_iface=ingress,
        egress_iface=egress,
        src_ip=IPv4Address(src),
        dst_ip=IPv4Address(dst),
        protocol=proto,
        src_port=sport,
        dst_port=dport,
        icmp_type=icmp,
    )


# Any weekday business-hours timestamp
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)
WEEKEND = datetime(2026, 2, 22, 10, 0, tzinfo=NY)


class TestFirstMatchWins:
    def test_malware_block_beats_implicit_deny(self, engine):
        # p010 matches any->any if dst is in blocklist. Should hit p010, not p099.
        pkt = _pkt(dst="203.0.113.66")
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.DENY
        assert d.rule_id == "p010_block_malware"

    def test_malware_block_wins_over_lan_web_allow(self, engine):
        # LAN user trying to reach a blocklisted IP on HTTP — p010 must win over p030.
        pkt = _pkt(dst="203.0.113.66", dport=80)
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.DENY
        assert d.rule_id == "p010_block_malware"


class TestScheduleGating:
    def test_admin_ssh_business_hours_allowed(self, engine):
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.50", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p020_admin_ssh"

    def test_admin_ssh_weekend_falls_through(self, engine):
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.50", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, WEEKEND)
        # Schedule misses on p020, nothing else matches this tuple, falls to p099
        assert d.action == Action.DENY
        assert d.rule_id == "p099_implicit_deny"

    def test_non_admin_ssh_to_dmz_denied(self, engine):
        # A non-admin workstation trying SSH to DMZ in business hours still denied
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.51",  # not admin_workstation
            dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.DENY
        assert d.rule_id == "p099_implicit_deny"


class TestAddressMatching:
    def test_lan_web_allowed(self, engine):
        pkt = _pkt(dport=443, proto=Protocol.TCP)
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p030_lan_web"

    def test_external_web_to_dmz_allowed(self, engine):
        pkt = _pkt(
            ingress="wan1", egress="dmz",
            src="198.51.100.5", dst="172.16.0.10",
            proto=Protocol.TCP, dport=443,
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p040_dmz_web_in"

    def test_external_ssh_to_dmz_denied(self, engine):
        pkt = _pkt(
            ingress="wan1", egress="dmz",
            src="198.51.100.5", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.DENY
        assert d.rule_id == "p099_implicit_deny"


class TestGuestRules:
    def test_guest_internet_web_allowed(self, engine):
        pkt = _pkt(
            ingress="wifi_guest", egress="wan1",
            src="192.168.99.10", dst="8.8.8.8",
            proto=Protocol.TCP, dport=443,
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p050_guest_internet"

    def test_guest_to_internal_blocked(self, engine):
        # A guest trying to reach an internal LAN host — p060 hits.
        pkt = _pkt(
            ingress="wifi_guest", egress="lan",
            src="192.168.99.10", dst="192.168.1.50",
            proto=Protocol.TCP, dport=445,  # SMB
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.action == Action.DENY
        assert d.rule_id == "p060_block_guest_internal"


class TestDefaultsFallthrough:
    def test_falls_to_defaults_when_no_rule_matches(self, engine):
        # Create a scenario where no rule matches at all — dmz to trusted on some random port.
        # We need to be careful: p099 always matches, so we can't easily test pure default fallthrough
        # with the canonical policy set. But we can test via a stripped-down engine.
        pass

    def test_logged_flag_propagated(self, engine):
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.50", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, BIZ)
        assert d.log is True  # p020_admin_ssh has log=true


class TestPureDefaultFallthrough:
    """
    Test that when NO policy rule matches (not even an implicit deny),
    the default matrix kicks in and the decision is marked matched_default=True.
    """

    def test_default_matrix_kicks_in(self, loaded_config, resolver, zone_map, schedule_evaluator):
        from dataclasses import replace
        from n2nhu_policy import PolicyEngine

        # Strip out p099 (implicit deny) so the engine can actually fall through
        policies_sans_implicit = tuple(
            r for r in loaded_config.policies if r.id != "p099_implicit_deny"
        )
        cfg_stripped = replace(loaded_config, policies=policies_sans_implicit)
        stripped_engine = PolicyEngine(
            cfg_stripped, resolver, zone_map, schedule_evaluator,
        )

        # Pick a packet that matches no real rule: LAN to WAN on port 9999
        pkt = _pkt(
            ingress="lan", egress="wan1",
            src="192.168.1.10", dst="8.8.8.8",
            proto=Protocol.TCP, dport=9999,
        )
        d = stripped_engine.evaluate(pkt, BIZ)
        # trusted->untrusted default is ALLOW
        assert d.action == Action.ALLOW
        assert d.matched_default is True
        assert d.log is True  # defaults always log

    def test_default_any_to_mgt_denies(
        self, loaded_config, resolver, zone_map, schedule_evaluator,
    ):
        from dataclasses import replace
        from n2nhu_policy import PolicyEngine

        cfg_stripped = replace(
            loaded_config,
            policies=tuple(
                r for r in loaded_config.policies if r.id != "p099_implicit_deny"
            ),
        )
        stripped_engine = PolicyEngine(
            cfg_stripped, resolver, zone_map, schedule_evaluator,
        )
        # Some LAN host attacking the mgt plane
        pkt = _pkt(
            ingress="lan", egress="mgt",
            src="192.168.1.10", dst="192.168.200.1",
            proto=Protocol.TCP, dport=22,
        )
        d = stripped_engine.evaluate(pkt, BIZ)
        assert d.action == Action.DENY
        assert d.matched_default is True


class TestRuleOrdering:
    def test_order_preserved_from_ini(self, loaded_config):
        ids = [r.id for r in loaded_config.policies]
        assert ids.index("p010_block_malware") < ids.index("p099_implicit_deny")
        assert ids.index("p020_admin_ssh") < ids.index("p030_lan_web")

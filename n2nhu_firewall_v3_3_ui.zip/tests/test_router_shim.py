"""Tests for RouterShim — the integration layer."""

from __future__ import annotations

from datetime import datetime, timezone
from ipaddress import IPv4Address, IPv4Network
from zoneinfo import ZoneInfo

import pytest

from n2nhu_policy import (
    ForwardAction,
    RouterShim,
    build_tcp_frame,
    build_udp_frame,
    parse_frame,
    verify_frame_checksums,
)

NY = ZoneInfo("America/New_York")
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def interface_networks():
    """Route table: longest-prefix wins."""
    return {
        "lan":        IPv4Network("192.168.1.0/24"),
        "wifi_corp":  IPv4Network("192.168.2.0/24"),
        "dmz":        IPv4Network("172.16.0.0/24"),
        "wifi_guest": IPv4Network("192.168.99.0/24"),
        "mgt":        IPv4Network("10.255.0.0/24"),
        "wan2":       IPv4Network("203.0.113.0/24"),  # specific
        "wan1":       IPv4Network("0.0.0.0/0"),       # default
    }


@pytest.fixture
def interface_ips():
    return {
        "lan":        IPv4Address("192.168.1.1"),
        "wifi_corp":  IPv4Address("192.168.2.1"),
        "dmz":        IPv4Address("172.16.0.1"),
        "wifi_guest": IPv4Address("192.168.99.1"),
        "mgt":        IPv4Address("10.255.0.1"),
        "wan1":       IPv4Address("203.0.113.1"),
        "wan2":       IPv4Address("203.0.113.2"),
    }


@pytest.fixture
def fixed_clock():
    """Returns BIZ every call — makes tests deterministic against schedule."""
    return lambda: BIZ


@pytest.fixture
def shim(fixture_root, interface_ips, interface_networks, fixed_clock):
    return RouterShim(
        fixture_root, interface_ips, interface_networks, clock=fixed_clock,
    )


# ---------------------------------------------------------------------------
# Route lookup
# ---------------------------------------------------------------------------


class TestRouteLookup:
    def test_lan_route(self, shim):
        assert shim.route_lookup(IPv4Address("192.168.1.50")) == "lan"

    def test_dmz_route(self, shim):
        assert shim.route_lookup(IPv4Address("172.16.0.10")) == "dmz"

    def test_default_route_wan1(self, shim):
        assert shim.route_lookup(IPv4Address("8.8.8.8")) == "wan1"

    def test_longest_prefix_wan2_wins(self, shim):
        # 203.0.113.x matches wan2 (specific) and wan1 (default) — wan2 should win
        assert shim.route_lookup(IPv4Address("203.0.113.50")) == "wan2"

    def test_guest_route(self, shim):
        assert shim.route_lookup(IPv4Address("192.168.99.10")) == "wifi_guest"


# ---------------------------------------------------------------------------
# SNAT forward + return
# ---------------------------------------------------------------------------


class TestSNATRoundtrip:
    def test_outbound_lan_to_internet_snat(self, shim):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),
            src_port=54321, dst_port=443,
            payload=b"TLS ClientHello",
        )
        decision = shim.process_frame("lan", frame)

        assert decision.action == ForwardAction.FORWARD
        assert decision.egress_iface == "wan1"
        assert decision.policy_rule_id == "p030_lan_web"
        assert decision.nat_rule_id == "n010_lan_snat"

        parsed = parse_frame(decision.frame)
        assert parsed.src_ip == IPv4Address("203.0.113.1")
        assert 10000 <= parsed.src_port <= 60000
        # Dst unchanged
        assert parsed.dst_ip == IPv4Address("8.8.8.8")
        assert parsed.dst_port == 443

        # Checksums correct
        ip_ok, l4_ok = verify_frame_checksums(decision.frame)
        assert ip_ok
        assert l4_ok

    def test_return_traffic_reverses_dst(self, shim):
        # Forward first
        fwd = shim.process_frame(
            "lan",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("8.8.8.8"),
                src_port=54321, dst_port=443,
                payload=b"client hello",
            ),
        )
        assert fwd.action == ForwardAction.FORWARD
        fwd_out = parse_frame(fwd.frame)
        xlated_port = fwd_out.src_port

        # Return: 8.8.8.8 sends reply back to our public IP + xlated port
        # Note: policy on the return would typically require a rule allowing
        # untrusted -> trusted; our default matrix has that as DENY. So in
        # the current fixture, the return actually fails policy. Let's test
        # the NAT reversal behavior separately from policy allow/deny.
        return_frame = build_tcp_frame(
            src_ip=IPv4Address("8.8.8.8"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=443, dst_port=xlated_port,
            payload=b"server hello",
        )
        ret_decision = shim.process_frame("wan1", return_frame)
        # Even though policy may deny, NAT engine reversed the mapping.
        # The shim reports policy decision — which for return traffic with
        # our current fixture is DENY (no stateful-allow rule yet).
        # What we care about here: if it forwards, the dst was reversed.
        if ret_decision.action == ForwardAction.FORWARD:
            parsed = parse_frame(ret_decision.frame)
            assert parsed.dst_ip == IPv4Address("192.168.1.10")
            assert parsed.dst_port == 54321
        else:
            # DENY is also acceptable here given the current policy set —
            # production would add a stateful-inspection shortcut.
            assert ret_decision.action == ForwardAction.DROP


# ---------------------------------------------------------------------------
# DNAT
# ---------------------------------------------------------------------------


class TestDNAT:
    def test_inbound_port_forward(self, shim):
        # Internet user hitting our public IP on 443
        frame = build_tcp_frame(
            src_ip=IPv4Address("198.51.100.77"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=55555, dst_port=443,
            payload=b"GET / HTTP/1.1",
        )
        # Simulate packet arriving on wan1
        decision = shim.process_frame("wan1", frame)

        # Policy sees pre-NAT: dst is 203.0.113.1 (router's own public IP).
        # No policy rule matches that exact tuple → implicit deny.
        # This test documents the expected behavior: operators add a rule
        # "untrusted -> untrusted, dst=addr_wan_public_ip, svc=web ALLOW"
        # to permit DNAT'd inbound traffic.
        if decision.action == ForwardAction.FORWARD:
            parsed = parse_frame(decision.frame)
            assert parsed.dst_ip == IPv4Address("172.16.0.10")
        else:
            assert decision.action == ForwardAction.DROP
            assert decision.policy_rule_id == "p099_implicit_deny"


# ---------------------------------------------------------------------------
# Policy-deny cases
# ---------------------------------------------------------------------------


class TestPolicyDeny:
    def test_guest_to_internal_denied(self, shim):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.99.10"),
            dst_ip=IPv4Address("192.168.1.50"),
            src_port=33333, dst_port=445,
            payload=b"SMB attempt",
        )
        decision = shim.process_frame("wifi_guest", frame)
        assert decision.action == ForwardAction.DROP
        assert decision.policy_rule_id == "p060_block_guest_internal"

    def test_lan_to_blocklisted_denied(self, shim):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("203.0.113.66"),  # blocklist
            src_port=54321, dst_port=80,
            payload=b"HTTP",
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        assert decision.policy_rule_id == "p010_block_malware"


# ---------------------------------------------------------------------------
# Parse errors
# ---------------------------------------------------------------------------


class TestParseErrors:
    def test_short_frame_is_parse_error(self, shim):
        decision = shim.process_frame("lan", b"\x00" * 10)
        assert decision.action == ForwardAction.PARSE_ERROR

    def test_non_ipv4_frame(self, shim):
        # ethertype 0x86DD (IPv6)
        frame = b"\x00" * 6 + b"\xff" * 6 + b"\x86\xdd" + b"\x00" * 40
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.PARSE_ERROR


# ---------------------------------------------------------------------------
# No route
# ---------------------------------------------------------------------------


class TestNoRoute:
    def test_unknown_dst_dropped(self, fixture_root, interface_ips, fixed_clock):
        # Create a shim with NO default route
        partial_nets = {
            "lan": IPv4Network("192.168.1.0/24"),
            "wan1": IPv4Network("203.0.113.0/24"),  # specific only
            "wan2": IPv4Network("192.168.2.0/24"),
            "dmz": IPv4Network("172.16.0.0/24"),
            "wifi_guest": IPv4Network("192.168.99.0/24"),
            "wifi_corp": IPv4Network("192.168.10.0/24"),
            "mgt": IPv4Network("10.255.0.0/24"),
        }
        shim = RouterShim(fixture_root, interface_ips, partial_nets, clock=fixed_clock)

        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("8.8.8.8"),  # matches nothing
            src_port=54321, dst_port=443,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.UNKNOWN_INTERFACE


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


class TestStats:
    def test_counters_accumulate(self, shim):
        # One allowed LAN->internet
        shim.process_frame(
            "lan",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("8.8.8.8"),
                src_port=54321, dst_port=443,
            ),
        )
        # One blocked guest->internal
        shim.process_frame(
            "wifi_guest",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.99.10"),
                dst_ip=IPv4Address("192.168.1.50"),
                src_port=44444, dst_port=445,
            ),
        )
        # One parse error
        shim.process_frame("lan", b"too short")

        stats = shim.get_stats()
        assert stats.frames_in == 3
        assert stats.frames_forwarded == 1
        assert stats.frames_dropped == 2
        assert stats.parse_errors == 1
        assert stats.policy_denies == 1
        assert stats.nat_translations == 1


# ---------------------------------------------------------------------------
# Session sharing across packets
# ---------------------------------------------------------------------------


class TestPolicyEvaluatedBeforeNAT:
    """
    Invariant: when policy denies a packet, the NAT engine must NOT have
    created a session or allocated a port. Previously the shim called
    nat.translate() first, which leaked a session and port on every
    policy-denied packet. This test pins the fix.
    """

    def test_policy_deny_does_not_create_nat_session(self, shim):
        # LAN -> blocklisted IP on HTTP: policy DENIES via p010_block_malware.
        # Before the fix, NAT would have created a session + allocated a port
        # for this packet, then the shim would have dropped it.
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.10"),
            dst_ip=IPv4Address("203.0.113.66"),  # blocklisted
            src_port=54321, dst_port=80,
            payload=b"GET /",
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        assert decision.policy_rule_id == "p010_block_malware"
        # The key assertion: NO session was created
        assert shim.session_count() == 0

    def test_session_count_matches_unique_flows_even_with_denies(self, shim):
        # One allowed flow
        shim.process_frame(
            "lan",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("8.8.8.8"),
                src_port=54321, dst_port=443,
            ),
        )
        # Five denied flows (different src ports so they'd each allocate
        # a port if NAT ran before policy)
        for sport in (11111, 22222, 33333, 44444, 55555):
            shim.process_frame(
                "lan",
                build_tcp_frame(
                    src_ip=IPv4Address("192.168.1.10"),
                    dst_ip=IPv4Address("203.0.113.66"),
                    src_port=sport, dst_port=80,
                ),
            )
        # Exactly one session — the one allowed flow
        assert shim.session_count() == 1


class TestSessionPersistence:
    def test_same_flow_reuses_session(self, shim):
        # Send 5 packets for the same flow
        for _ in range(5):
            shim.process_frame(
                "lan",
                build_tcp_frame(
                    src_ip=IPv4Address("192.168.1.10"),
                    dst_ip=IPv4Address("8.8.8.8"),
                    src_port=54321, dst_port=443,
                ),
            )
        # Exactly one session
        assert shim.session_count() == 1


# ---------------------------------------------------------------------------
# Reload
# ---------------------------------------------------------------------------


class TestReload:
    def test_reload_returns_new_shim(self, shim):
        new = shim.reload()
        assert new is not shim
        assert new.config_root == shim.config_root

    def test_reloaded_shim_works(self, shim):
        new = shim.reload()
        decision = new.process_frame(
            "lan",
            build_tcp_frame(
                src_ip=IPv4Address("192.168.1.10"),
                dst_ip=IPv4Address("8.8.8.8"),
                src_port=54321, dst_port=443,
            ),
        )
        assert decision.action == ForwardAction.FORWARD

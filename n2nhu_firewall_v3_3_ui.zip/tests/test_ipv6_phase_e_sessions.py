"""
Phase E+ — NAT64 session binding tests.

Verifies the session table correctly binds a v6 pre-NAT flow to its
v4 post-NAT translation and allows both forward (v6→v4) and reverse
(v4→v6) lookups.

This is the invariant that makes stateful NAT64 work: when a v4 reply
arrives at the firewall addressed to FIREWALL_V4:xlated_port, we must
be able to find the session it belongs to and thus the original v6
client waiting for the reply.
"""

from __future__ import annotations

from ipaddress import IPv4Address, IPv6Address

import pytest

from n2nhu_policy.nat64_addr import WELL_KNOWN_PREFIX, embed_v4_in_v6
from n2nhu_policy.nat_models import (
    Direction, NATConfig, NATRule, NATSession, NATType,
)
from n2nhu_policy.models import Protocol
from n2nhu_policy.session_table import SessionTable


CLIENT_V6 = IPv6Address("2001:db8:cafe:1::100")
SERVER_V4 = IPv4Address("203.0.113.5")
SERVER_V6 = embed_v4_in_v6(SERVER_V4, WELL_KNOWN_PREFIX)
FIREWALL_V4 = IPv4Address("198.51.100.1")


@pytest.fixture
def nat_rule():
    return NATRule(
        id="nat64_primary",
        type=NATType.NAT64,
        src_zone="trusted", dst_zone="untrusted",
        src_addr="addr_v6_clients", dst_addr="addr_any",
        service="svc_any", schedule="sched_always",
        nat64_prefix="64:ff9b::/96",
        translate_src_to_v4="addr_fw_v4",
    )


@pytest.fixture
def session_table(nat_rule):
    cfg = NATConfig(rules=(nat_rule,))
    return SessionTable(cfg, rule_lookup=lambda rid: nat_rule)


class TestNAT64SessionBinding:
    def test_create_session_with_mixed_families(self, session_table):
        """A NAT64 session has v6 orig and v4 xlated addresses, which
        previously would have type-clashed."""
        session = session_table.create_session(
            rule_id="nat64_primary",
            nat_type=NATType.NAT64,
            protocol=Protocol.TCP,
            orig_src_ip=CLIENT_V6, orig_src_port=40000,
            orig_dst_ip=SERVER_V6, orig_dst_port=80,
            xlated_src_ip=FIREWALL_V4, xlated_src_port=12345,
            xlated_dst_ip=SERVER_V4, xlated_dst_port=80,
        )
        assert session.nat_type == NATType.NAT64
        assert session.orig_src_ip == CLIENT_V6
        assert session.xlated_src_ip == FIREWALL_V4

    def test_forward_lookup_finds_session(self, session_table):
        """A packet from the original v6 client finds the session on its
        forward key (v6 5-tuple)."""
        session_table.create_session(
            rule_id="nat64_primary",
            nat_type=NATType.NAT64,
            protocol=Protocol.TCP,
            orig_src_ip=CLIENT_V6, orig_src_port=40000,
            orig_dst_ip=SERVER_V6, orig_dst_port=80,
            xlated_src_ip=FIREWALL_V4, xlated_src_port=12345,
            xlated_dst_ip=SERVER_V4, xlated_dst_port=80,
        )
        found = session_table.lookup_forward(
            CLIENT_V6, 40000, SERVER_V6, 80, Protocol.TCP,
        )
        assert found is not None
        assert found.xlated_src_port == 12345

    def test_reverse_lookup_finds_session(self, session_table):
        """A reply from the v4 server arrives at FIREWALL_V4:12345 from
        SERVER_V4:80 — reverse lookup uses the v4 tuple (with sides
        swapped)."""
        session_table.create_session(
            rule_id="nat64_primary",
            nat_type=NATType.NAT64,
            protocol=Protocol.TCP,
            orig_src_ip=CLIENT_V6, orig_src_port=40000,
            orig_dst_ip=SERVER_V6, orig_dst_port=80,
            xlated_src_ip=FIREWALL_V4, xlated_src_port=12345,
            xlated_dst_ip=SERVER_V4, xlated_dst_port=80,
        )
        # Reply: from SERVER_V4:80 to FIREWALL_V4:12345
        found = session_table.lookup_reverse(
            SERVER_V4, 80, FIREWALL_V4, 12345, Protocol.TCP,
        )
        assert found is not None
        assert found.orig_src_ip == CLIENT_V6
        assert found.orig_src_port == 40000

    def test_v4_reverse_does_not_collide_with_v6_forward(self, session_table):
        """Even though the session table uses stringified IPs as keys,
        v4 vs v6 strings are distinct so no cross-family collision."""
        # Make two sessions: one NAT64, one regular SNAT using the
        # same "CLIENT_V6 string representation" would be impossible
        # since v4 and v6 stringify differently. Sanity check:
        session_table.create_session(
            rule_id="nat64_primary",
            nat_type=NATType.NAT64,
            protocol=Protocol.TCP,
            orig_src_ip=CLIENT_V6, orig_src_port=40000,
            orig_dst_ip=SERVER_V6, orig_dst_port=80,
            xlated_src_ip=FIREWALL_V4, xlated_src_port=12345,
            xlated_dst_ip=SERVER_V4, xlated_dst_port=80,
        )
        # Look for a v4 forward from CLIENT_V6 — shouldn't match (wrong family)
        found_wrong = session_table.lookup_forward(
            IPv4Address("192.168.1.1"), 40000,
            IPv4Address("203.0.113.5"), 80, Protocol.TCP,
        )
        assert found_wrong is None

    def test_session_touch_increments_counters(self, session_table):
        """Bidirectional counters work for NAT64 sessions."""
        s = session_table.create_session(
            rule_id="nat64_primary",
            nat_type=NATType.NAT64,
            protocol=Protocol.TCP,
            orig_src_ip=CLIENT_V6, orig_src_port=40000,
            orig_dst_ip=SERVER_V6, orig_dst_port=80,
            xlated_src_ip=FIREWALL_V4, xlated_src_port=12345,
            xlated_dst_ip=SERVER_V4, xlated_dst_port=80,
        )
        s.touch(100.0, Direction.FORWARD, 1500)
        s.touch(100.1, Direction.REVERSE, 3000)
        assert s.packets_forward == 1
        assert s.packets_reverse == 1
        assert s.bytes_forward == 1500
        assert s.bytes_reverse == 3000

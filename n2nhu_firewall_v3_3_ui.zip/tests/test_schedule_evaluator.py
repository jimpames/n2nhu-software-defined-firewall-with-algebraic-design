"""Tests for ScheduleEvaluator — time-window semantics with tz awareness."""

from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

import pytest

from n2nhu_policy.errors import ResolverError

NY = ZoneInfo("America/New_York")
UTC = ZoneInfo("UTC")


class TestAlwaysSchedule:
    def test_always_matches_anytime(self, schedule_evaluator):
        assert schedule_evaluator.matches(
            "sched_always", datetime(2026, 1, 1, 3, 0, tzinfo=UTC),
        )
        assert schedule_evaluator.matches(
            "sched_always", datetime(2026, 7, 15, 23, 59, tzinfo=UTC),
        )


class TestRecurringSchedule:
    def test_inside_business_hours(self, schedule_evaluator):
        # Tuesday 10am NY time
        t = datetime(2026, 2, 24, 10, 0, tzinfo=NY)
        assert schedule_evaluator.matches("sched_business_hours", t)

    def test_business_hours_start_boundary(self, schedule_evaluator):
        # Tuesday exactly 08:00 NY — inclusive start
        t = datetime(2026, 2, 24, 8, 0, tzinfo=NY)
        assert schedule_evaluator.matches("sched_business_hours", t)

    def test_business_hours_end_boundary_exclusive(self, schedule_evaluator):
        # Tuesday exactly 18:00 NY — exclusive end
        t = datetime(2026, 2, 24, 18, 0, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_business_hours", t)

    def test_before_business_hours(self, schedule_evaluator):
        # Tuesday 07:59 NY
        t = datetime(2026, 2, 24, 7, 59, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_business_hours", t)

    def test_after_business_hours(self, schedule_evaluator):
        # Tuesday 19:00 NY
        t = datetime(2026, 2, 24, 19, 0, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_business_hours", t)

    def test_wrong_day_weekend(self, schedule_evaluator):
        # Sunday 10am NY — not a weekday
        t = datetime(2026, 2, 22, 10, 0, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_business_hours", t)

    def test_saturday_on_weekends_schedule(self, schedule_evaluator):
        t = datetime(2026, 2, 21, 12, 0, tzinfo=NY)
        assert schedule_evaluator.matches("sched_weekends", t)

    def test_tuesday_on_weekends_schedule(self, schedule_evaluator):
        t = datetime(2026, 2, 24, 12, 0, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_weekends", t)


class TestTimezoneHandling:
    def test_utc_input_converted_to_ny(self, schedule_evaluator):
        # 13:00 UTC = 08:00 EST (winter, UTC-5) = inside business hours
        t = datetime(2026, 2, 24, 13, 0, tzinfo=UTC)
        assert schedule_evaluator.matches("sched_business_hours", t)

    def test_utc_input_outside_ny_business_hours(self, schedule_evaluator):
        # 05:00 UTC = 00:00 EST = not business hours
        t = datetime(2026, 2, 24, 5, 0, tzinfo=UTC)
        assert not schedule_evaluator.matches("sched_business_hours", t)

    def test_naive_datetime_rejected(self, schedule_evaluator):
        with pytest.raises(ResolverError, match="tz-aware"):
            schedule_evaluator.matches(
                "sched_business_hours", datetime(2026, 2, 24, 10, 0),
            )


class TestOneTimeSchedule:
    def test_inside_maintenance_window(self, schedule_evaluator):
        # 2026-04-20 03:00 NY — within 02:00-04:00
        t = datetime(2026, 4, 20, 3, 0, tzinfo=NY)
        assert schedule_evaluator.matches("sched_maintenance_window", t)

    def test_before_maintenance_window(self, schedule_evaluator):
        t = datetime(2026, 4, 20, 1, 59, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_maintenance_window", t)

    def test_after_maintenance_window(self, schedule_evaluator):
        t = datetime(2026, 4, 20, 4, 1, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_maintenance_window", t)

    def test_different_day_entirely(self, schedule_evaluator):
        t = datetime(2026, 4, 21, 3, 0, tzinfo=NY)
        assert not schedule_evaluator.matches("sched_maintenance_window", t)


class TestErrorPaths:
    def test_unknown_schedule(self, schedule_evaluator):
        with pytest.raises(ResolverError, match="unknown schedule"):
            schedule_evaluator.matches(
                "sched_does_not_exist", datetime(2026, 1, 1, tzinfo=UTC),
            )

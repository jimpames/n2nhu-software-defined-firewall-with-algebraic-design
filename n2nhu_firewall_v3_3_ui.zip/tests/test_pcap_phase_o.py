"""
Phase O tests — Capture wired into RouterShim.

End-to-end integration: drive process_frame() and assert that the right
frames land in the right pcap files at the right capture points with
correct annotations.

Covers:
  - Shim with no capture.ini: capture_manager is None, behavior unchanged
  - Shim with capture.ini: capture_manager exists, files created
  - INGRESS captures fire on every entering frame
  - POST_POLICY captures fire after policy with the correct decision
  - POST_NAT captures fire only on forwarded packets and contain the
    post-NAT bytes (different from ingress bytes when NAT rewrites)
  - POST_POLICY captures with match_action=deny only fire on denies
  - rule_id, nat_rule_id, pbr_rule_id annotations populate correctly
  - shutdown() drains and closes pcap files
  - reload() rebuilds the capture pipeline cleanly
"""

from __future__ import annotations

import struct
from ipaddress import IPv4Address, IPv4Network
from pathlib import Path

import pytest

from n2nhu_policy.frame_codec import build_tcp_frame, parse_frame as parse_v4
from n2nhu_policy.router_shim import ForwardAction, RouterShim
from tests.test_pcapng_phase_k import read_pcapng


# ---------------------------------------------------------------------------
# Fixtures — full policy + NAT + capture trees
# ---------------------------------------------------------------------------


def _write_base_tree(root: Path):
    """Write a minimal but complete policy tree."""
    (root / "objects").mkdir(exist_ok=True)
    (root / "policies").mkdir(exist_ok=True)

    (root / "zones.ini").write_text(
        "[zones]\ntrusted = lan\nuntrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan]\ntype = network\nvalue = 192.168.1.0/24\n"
        "\n[addr_fw_wan]\ntype = host\nvalue = 198.51.100.1\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
        "\n[svc_http]\nprotocol = tcp\ndst_port = 80\n"
        "\n[svc_blocked]\nprotocol = tcp\ndst_port = 1337\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_block_blocked, p_allow\n"
        "\n[p_block_blocked]\n"
        "src_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\n"
        "service = svc_blocked\nschedule = sched_always\n"
        "action = DENY\n"
        "\n[p_allow]\n"
        "src_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\n"
        "service = svc_any\nschedule = sched_always\n"
        "action = ALLOW\n"
    )
    (root / "policies" / "nat.ini").write_text(
        "[nat_order]\nrules = n_snat\n"
        "\n[n_snat]\n"
        "type = source_nat\n"
        "src_zone = trusted\ndst_zone = untrusted\n"
        "src_addr = addr_lan\ndst_addr = addr_any\n"
        "service = svc_any\nschedule = sched_always\n"
        "translate_src_to = addr_fw_wan\n"
        "port_pool = 20000-29999\n"
    )


@pytest.fixture
def shim_no_capture(tmp_path):
    """RouterShim with no capture.ini → capture_manager is None."""
    _write_base_tree(tmp_path)
    return RouterShim(
        config_root=tmp_path,
        interface_ips={
            "lan": IPv4Address("192.168.1.1"),
            "wan1": IPv4Address("198.51.100.1"),
        },
        interface_networks={
            "lan": IPv4Network("192.168.1.0/24"),
            "wan1": IPv4Network("0.0.0.0/0"),
        },
    )


@pytest.fixture
def shim_with_capture(tmp_path):
    """RouterShim with three capture rules: one per capture point."""
    _write_base_tree(tmp_path)
    out_in = tmp_path / "ingress.pcapng"
    out_pol = tmp_path / "policy.pcapng"
    out_nat = tmp_path / "post_nat.pcapng"
    (tmp_path / "policies" / "capture.ini").write_text(
        f"[capture_order]\nrules = c_in, c_pol, c_nat\n"
        f"\n[c_in]\ncapture_point = ingress\npcap_file = {out_in}\n"
        f"\n[c_pol]\ncapture_point = post_policy\npcap_file = {out_pol}\n"
        f"\n[c_nat]\ncapture_point = post_nat\npcap_file = {out_nat}\n"
    )
    shim = RouterShim(
        config_root=tmp_path,
        interface_ips={
            "lan": IPv4Address("192.168.1.1"),
            "wan1": IPv4Address("198.51.100.1"),
        },
        interface_networks={
            "lan": IPv4Network("192.168.1.0/24"),
            "wan1": IPv4Network("0.0.0.0/0"),
        },
    )
    yield shim, out_in, out_pol, out_nat
    shim.shutdown()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestNoCaptureConfig:

    def test_no_capture_ini_no_manager(self, shim_no_capture):
        assert shim_no_capture.capture_manager is None
        assert shim_no_capture.capture_config.rules == ()

    def test_forwarding_unchanged_when_no_capture(self, shim_no_capture):
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=80,
        )
        decision = shim_no_capture.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD


class TestThreePoints:

    def test_ingress_capture_records_original_frame(self, shim_with_capture):
        shim, out_in, _out_pol, _out_nat = shim_with_capture
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        shim.shutdown()

        _shb, _idb, epbs = read_pcapng(out_in)
        assert len(epbs) == 1
        # Ingress captures see the original frame bytes
        assert epbs[0]["captured_data"] == frame
        comment = epbs[0]["options"][1][0].decode()
        assert "capture_point=ingress" in comment
        assert "decision=none" in comment

    def test_post_policy_captures_with_decision(self, shim_with_capture):
        shim, _out_in, out_pol, _out_nat = shim_with_capture
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=80,
        )
        shim.process_frame("lan", frame)
        shim.shutdown()

        _shb, _idb, epbs = read_pcapng(out_pol)
        assert len(epbs) == 1
        comment = epbs[0]["options"][1][0].decode()
        assert "capture_point=post_policy" in comment
        assert "decision=allow" in comment
        assert "rule_id=p_allow" in comment

    def test_post_nat_captures_translated_frame(self, shim_with_capture):
        shim, _out_in, _out_pol, out_nat = shim_with_capture
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=80,
            payload=b"payload-XYZ",
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        # Output frame should differ from input — NAT rewrote the source
        assert decision.frame != frame
        shim.shutdown()

        _shb, _idb, epbs = read_pcapng(out_nat)
        assert len(epbs) == 1
        # Post-NAT capture must record the post-NAT frame
        assert epbs[0]["captured_data"] == decision.frame
        # And NOT the original
        assert epbs[0]["captured_data"] != frame
        comment = epbs[0]["options"][1][0].decode()
        assert "capture_point=post_nat" in comment
        assert "rule_id=p_allow" in comment
        assert "nat_rule_id=n_snat" in comment

    def test_dropped_frame_no_post_nat_capture(self, shim_with_capture):
        """A frame denied by policy never reaches POST_NAT — that capture
        file should remain empty for it."""
        shim, _out_in, out_pol, out_nat = shim_with_capture
        # Denied by p_block_blocked (svc_blocked = TCP/1337)
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=1337,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        shim.shutdown()

        # POST_POLICY did fire (captures the deny)
        _shb, _idb, epbs_pol = read_pcapng(out_pol)
        assert len(epbs_pol) == 1
        assert "decision=deny" in epbs_pol[0]["options"][1][0].decode()

        # POST_NAT did NOT fire
        _shb, _idb, epbs_nat = read_pcapng(out_nat)
        assert epbs_nat == []


class TestMatchActionFilter:

    def test_match_action_deny_only_records_denies(self, tmp_path):
        """A capture rule restricted to match_action=deny only records
        denied flows, not allowed ones."""
        _write_base_tree(tmp_path)
        out_deny = tmp_path / "denies.pcapng"
        (tmp_path / "policies" / "capture.ini").write_text(
            f"[capture_order]\nrules = c_deny\n"
            f"\n[c_deny]\ncapture_point = post_policy\n"
            f"pcap_file = {out_deny}\n"
            f"match_action = deny\n"
        )
        shim = RouterShim(
            config_root=tmp_path,
            interface_ips={
                "lan": IPv4Address("192.168.1.1"),
                "wan1": IPv4Address("198.51.100.1"),
            },
            interface_networks={
                "lan": IPv4Network("192.168.1.0/24"),
                "wan1": IPv4Network("0.0.0.0/0"),
            },
        )

        # Allowed
        good_frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=80,
        )
        shim.process_frame("lan", good_frame)

        # Denied
        bad_frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.1"),
            src_port=40000, dst_port=1337,
        )
        shim.process_frame("lan", bad_frame)

        shim.shutdown()

        _shb, _idb, epbs = read_pcapng(out_deny)
        # Only the denied flow should be captured
        assert len(epbs) == 1
        comment = epbs[0]["options"][1][0].decode()
        assert "decision=deny" in comment


class TestStatsAndShutdown:

    def test_capture_manager_stats_reflect_writes(self, shim_with_capture):
        shim, _out_in, _out_pol, _out_nat = shim_with_capture
        # Forward 5 frames
        for i in range(5):
            frame = build_tcp_frame(
                src_ip=IPv4Address("192.168.1.50"),
                dst_ip=IPv4Address(f"203.0.113.{i+1}"),
                src_port=40000 + i, dst_port=80,
            )
            shim.process_frame("lan", frame)

        shim.shutdown()

        stats = shim.capture_manager.stats()
        # All three rules should record some frames; ingress and
        # post_policy and post_nat each fire once per allowed frame.
        assert stats["c_in"].frames_written == 5
        assert stats["c_pol"].frames_written == 5
        assert stats["c_nat"].frames_written == 5

    def test_shutdown_idempotent(self, shim_with_capture):
        shim, *_ = shim_with_capture
        shim.shutdown()
        shim.shutdown()  # must not raise

    def test_no_capture_shutdown_safe(self, shim_no_capture):
        # Even with no capture configured, shutdown() should be safe
        shim_no_capture.shutdown()


class TestMultipleFlows:

    def test_many_frames_all_captured(self, shim_with_capture):
        """A burst of forwarded frames produces a complete record at
        each of the three capture points."""
        shim, out_in, out_pol, out_nat = shim_with_capture
        N = 20
        for i in range(N):
            frame = build_tcp_frame(
                src_ip=IPv4Address("192.168.1.50"),
                dst_ip=IPv4Address(f"203.0.113.{(i % 254) + 1}"),
                src_port=40000 + i, dst_port=80,
            )
            shim.process_frame("lan", frame)

        shim.shutdown()

        for path, point in [(out_in, "ingress"),
                            (out_pol, "post_policy"),
                            (out_nat, "post_nat")]:
            _shb, _idb, epbs = read_pcapng(path)
            assert len(epbs) == N, \
                f"{path} expected {N} frames, got {len(epbs)}"
            for epb in epbs:
                comment = epb["options"][1][0].decode()
                assert f"capture_point={point}" in comment

"""Tests for NATConfigLoader — parsing nat.ini, validating references."""

from __future__ import annotations

import pytest

from n2nhu_policy import ConfigError, ConfigLoader, NATConfigLoader, NATType


@pytest.fixture
def policy_config(fixture_root):
    return ConfigLoader(fixture_root).load()


@pytest.fixture
def nat_config(fixture_root, policy_config):
    return NATConfigLoader(fixture_root, policy_config).load()


class TestValidFixtures:
    def test_all_rules_loaded(self, nat_config):
        assert [r.id for r in nat_config.rules] == [
            "n010_lan_snat",
            "n020_dmz_web_dnat",
            "n030_mail_static_nat",
            "n099_no_nat_intrazone",
        ]

    def test_snat_rule_attributes(self, nat_config):
        r = next(r for r in nat_config.rules if r.id == "n010_lan_snat")
        assert r.type == NATType.SOURCE_NAT
        assert r.src_zone == "trusted"
        assert r.dst_zone == "untrusted"
        assert r.src_addr == "addrgrp_internal"
        assert r.translate_src_to == "addr_wan_public_ip"
        assert r.port_pool is not None
        assert r.port_pool.start == 10000
        assert r.port_pool.end == 60000

    def test_dnat_rule_attributes(self, nat_config):
        r = next(r for r in nat_config.rules if r.id == "n020_dmz_web_dnat")
        assert r.type == NATType.DESTINATION_NAT
        assert r.translate_dst_to == "addr_dmz_webserver"
        assert r.translate_dst_port == 0  # keep original
        assert r.log is True

    def test_static_rule_attributes(self, nat_config):
        r = next(r for r in nat_config.rules if r.id == "n030_mail_static_nat")
        assert r.type == NATType.STATIC_NAT
        assert r.internal_addr == "addr_dmz_mailserver"
        assert r.external_addr == "addr_wan_public_mail"
        assert r.bidirectional is True

    def test_no_nat_rule_attributes(self, nat_config):
        r = next(r for r in nat_config.rules if r.id == "n099_no_nat_intrazone")
        assert r.type == NATType.NO_NAT
        assert r.src_zone == "trusted"
        assert r.dst_zone == "trusted"

    def test_defaults(self, nat_config):
        assert nat_config.tcp_established_timeout == 3600
        assert nat_config.tcp_half_open_timeout == 30
        assert nat_config.udp_timeout == 180
        assert nat_config.icmp_timeout == 60
        assert nat_config.reaper_interval == 10


class TestMissingFile:
    def test_missing_nat_ini_returns_empty_config(
        self, tmp_config_tree, policy_config,
    ):
        # Remove nat.ini to prove it's optional
        nat_path = tmp_config_tree / "policies" / "nat.ini"
        if nat_path.exists():
            nat_path.unlink()
        cfg = NATConfigLoader(tmp_config_tree, policy_config).load()
        assert cfg.rules == ()


class TestUnknownKeys:
    def test_unknown_rule_key_rejected(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "[n010_lan_snat]\ntype             = source_nat",
            "[n010_lan_snat]\ntype             = source_nat\nrogue_key = 1",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="unknown keys"):
            NATConfigLoader(tmp_config_tree, policy_config).load()


class TestBadReferences:
    def test_undefined_src_addr(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "src_addr         = addrgrp_internal",
            "src_addr         = addr_does_not_exist",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not defined"):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_undefined_translate_src_to(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "translate_src_to = addr_wan_public_ip",
            "translate_src_to = addr_not_real",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="must be 'interface'"):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_undefined_translate_dst_to(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "translate_dst_to   = addr_dmz_webserver",
            "translate_dst_to   = addr_bogus",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not defined"):
            NATConfigLoader(tmp_config_tree, policy_config).load()


class TestRequiredFields:
    def test_snat_missing_translate_src_to(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "translate_src_to = addr_wan_public_ip\n",
            "",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="translate_src_to"):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_snat_missing_port_pool(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "port_pool        = 10000-60000\n",
            "",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="port_pool"):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_dnat_missing_translate_dst_to(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "translate_dst_to   = addr_dmz_webserver\n",
            "",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="translate_dst_to"):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_static_missing_internal_addr(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "internal_addr = addr_dmz_mailserver\n",
            "",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="internal_addr"):
            NATConfigLoader(tmp_config_tree, policy_config).load()


class TestOrderValidation:
    def test_nat_order_references_missing_rule(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "rules = n010_lan_snat,",
            "rules = n010_lan_snat,\n        n_does_not_exist,",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="undefined rules"):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_duplicate_in_order(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "rules = n010_lan_snat,",
            "rules = n010_lan_snat, n010_lan_snat,",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="duplicate"):
            NATConfigLoader(tmp_config_tree, policy_config).load()


class TestPortPoolParsing:
    def test_bad_port_pool_format(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "port_pool        = 10000-60000",
            "port_pool        = not-a-range",
        )
        path.write_text(content)
        with pytest.raises(ConfigError):
            NATConfigLoader(tmp_config_tree, policy_config).load()

    def test_port_pool_reversed(self, tmp_config_tree, policy_config):
        path = tmp_config_tree / "policies" / "nat.ini"
        content = path.read_text().replace(
            "port_pool        = 10000-60000",
            "port_pool        = 60000-10000",
        )
        path.write_text(content)
        with pytest.raises(ConfigError):
            NATConfigLoader(tmp_config_tree, policy_config).load()

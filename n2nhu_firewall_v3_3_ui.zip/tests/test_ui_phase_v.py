"""
Phase V tests — capture and IPSec schemas registered and renderable.

Covers:
  - Both schemas appear in the registry
  - Each has the expected sections and template prefixes
  - Default content writes acceptable empty INI
  - Schema loader resolves three distinct IPSec template prefixes
    without ambiguity
  - section_matching() routes a real section to the correct template
  - Required fields are flagged in the schema
"""

from __future__ import annotations

from pathlib import Path

import pytest

from n2nhu_ui.schema_loader import SchemaLoader
from n2nhu_ui.schema_models import FieldType, SectionKind


@pytest.fixture
def registry():
    return SchemaLoader(Path("n2nhu_ui/schemas")).load_registry()


# ---------------------------------------------------------------------------
# Capture schema
# ---------------------------------------------------------------------------


class TestCaptureSchema:

    def test_present_in_registry(self, registry):
        assert registry.by_name("capture") is not None

    def test_filename_correct(self, registry):
        s = registry.by_name("capture")
        assert s.filename == "policies/capture.ini"

    def test_has_order_section(self, registry):
        s = registry.by_name("capture")
        order = s.section_by_name("capture_order")
        assert order is not None
        assert order.kind == SectionKind.FIXED

    def test_has_template_section(self, registry):
        s = registry.by_name("capture")
        cap = s.section_by_name("cap*")
        assert cap is not None
        assert cap.kind == SectionKind.TEMPLATE

    def test_template_matches_real_name(self, registry):
        s = registry.by_name("capture")
        spec = s.section_matching("cap_lan_egress")
        assert spec is not None
        assert spec.name == "cap*"

    def test_capture_point_is_enum(self, registry):
        s = registry.by_name("capture")
        cap = s.section_by_name("cap*")
        cp_field = cap.field_by_name("capture_point")
        assert cp_field is not None
        assert cp_field.type == FieldType.ENUM
        assert "ingress" in cp_field.choices
        assert "post_policy" in cp_field.choices
        assert "post_nat" in cp_field.choices

    def test_pcap_file_required(self, registry):
        s = registry.by_name("capture")
        cap = s.section_by_name("cap*")
        f = cap.field_by_name("pcap_file")
        assert f.required is True


# ---------------------------------------------------------------------------
# IPSec schema
# ---------------------------------------------------------------------------


class TestIPSecSchema:

    def test_present_in_registry(self, registry):
        assert registry.by_name("ipsec") is not None

    def test_filename_correct(self, registry):
        s = registry.by_name("ipsec")
        assert s.filename == "policies/ipsec.ini"

    def test_three_distinct_template_prefixes(self, registry):
        s = registry.by_name("ipsec")
        prop = s.section_by_name("ipsec_proposal_*")
        ike = s.section_by_name("ike_policy_*")
        tun = s.section_by_name("ipsec_tunnel_*")
        assert prop is not None and prop.kind == SectionKind.TEMPLATE
        assert ike is not None and ike.kind == SectionKind.TEMPLATE
        assert tun is not None and tun.kind == SectionKind.TEMPLATE

    def test_proposal_template_matches_real_name(self, registry):
        s = registry.by_name("ipsec")
        spec = s.section_matching("ipsec_proposal_default")
        assert spec is not None
        assert spec.name == "ipsec_proposal_*"

    def test_ike_policy_template_matches_real_name(self, registry):
        s = registry.by_name("ipsec")
        spec = s.section_matching("ike_policy_branch1")
        assert spec is not None
        assert spec.name == "ike_policy_*"

    def test_tunnel_template_matches_real_name(self, registry):
        s = registry.by_name("ipsec")
        spec = s.section_matching("ipsec_tunnel_branch1")
        assert spec is not None
        assert spec.name == "ipsec_tunnel_*"

    def test_proposal_template_has_crypto_enums(self, registry):
        s = registry.by_name("ipsec")
        prop = s.section_by_name("ipsec_proposal_*")
        enc = prop.field_by_name("encryption")
        assert enc.type == FieldType.ENUM
        assert "aes256" in enc.choices
        assert "aes256gcm16" in enc.choices

    def test_ike_policy_auth_method_enum(self, registry):
        s = registry.by_name("ipsec")
        ike = s.section_by_name("ike_policy_*")
        auth = ike.field_by_name("auth_method")
        assert auth.choices == ("psk", "pubkey")

    def test_ike_policy_default_v2(self, registry):
        s = registry.by_name("ipsec")
        ike = s.section_by_name("ike_policy_*")
        v = ike.field_by_name("ike_version")
        assert v.default == "ikev2"

    def test_tunnel_auto_choices(self, registry):
        s = registry.by_name("ipsec")
        tun = s.section_by_name("ipsec_tunnel_*")
        auto = tun.field_by_name("auto")
        assert set(auto.choices) == {"start", "route", "add"}

    def test_tunnel_subnets_are_address_refs(self, registry):
        s = registry.by_name("ipsec")
        tun = s.section_by_name("ipsec_tunnel_*")
        local = tun.field_by_name("local_subnet")
        assert local.type == FieldType.REF
        assert local.ref_to == "addresses"

    def test_no_template_prefix_overlap(self, registry):
        """The three template prefixes must dispatch unambiguously."""
        s = registry.by_name("ipsec")
        # ipsec_proposal_x must not match ipsec_tunnel_*'s prefix
        spec_p = s.section_matching("ipsec_proposal_x")
        spec_t = s.section_matching("ipsec_tunnel_x")
        assert spec_p.name == "ipsec_proposal_*"
        assert spec_t.name == "ipsec_tunnel_*"


# ---------------------------------------------------------------------------
# Registry-level assertions
# ---------------------------------------------------------------------------


class TestRegistryComposition:

    def test_total_count(self, registry):
        names = {s.name for s in registry.schemas}
        # 7 baseline + 2 new
        assert len(names) == 9
        assert "capture" in names
        assert "ipsec" in names

    def test_ordered_includes_new_schemas(self, registry):
        names_in_order = [s.name for s in registry.ordered()]
        assert names_in_order.index("capture") > names_in_order.index("pbr")
        assert names_in_order.index("ipsec") > names_in_order.index("capture")

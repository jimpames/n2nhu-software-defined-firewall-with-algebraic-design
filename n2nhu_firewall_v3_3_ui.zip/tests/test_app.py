"""Tests for the Flask app: routes, restore-defaults, ini_reader."""

from __future__ import annotations

from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_ui.app import create_app
from n2nhu_ui.ini_reader import read_ini
from n2nhu_ui.schema_loader import SchemaLoader


SCHEMA_DIR = Path(__file__).resolve().parent.parent / "n2nhu_ui" / "schemas"
FIXTURE_ROOT = Path(__file__).resolve().parent.parent / "fixtures"


@pytest.fixture
def client():
    app = create_app(
        config_root=str(FIXTURE_ROOT),
        schema_dir=str(SCHEMA_DIR),
    )
    app.config["TESTING"] = True
    return app.test_client()


@pytest.fixture
def empty_tree_client(tmp_path):
    app = create_app(
        config_root=str(tmp_path),
        schema_dir=str(SCHEMA_DIR),
    )
    app.config["TESTING"] = True
    return app.test_client(), tmp_path


class TestRoutes:
    def test_dashboard_ok(self, client):
        r = client.get("/")
        assert r.status_code == 200
        assert b"N2NHU" in r.data

    def test_health_ok(self, client):
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json == {"status": "ok", "schemas_loaded": 9}

    def test_unknown_schema_404(self, client):
        r = client.get("/ini/nonexistent")
        assert r.status_code == 404

    @pytest.mark.parametrize("name", [
        "zones", "addresses", "services", "schedules",
        "security", "nat", "pbr",
    ])
    def test_each_schema_renders(self, client, name):
        r = client.get(f"/ini/{name}")
        assert r.status_code == 200
        # The page should mention the filename
        assert name.encode() in r.data.lower()

    @pytest.mark.parametrize("name", [
        "zones", "addresses", "services", "schedules",
        "security", "nat", "pbr",
    ])
    def test_each_raw_view_renders(self, client, name):
        r = client.get(f"/ini/{name}/raw")
        assert r.status_code == 200

    def test_static_htmx_served(self, client):
        r = client.get("/static/js/htmx.min.js")
        assert r.status_code == 200
        assert b"htmx" in r.data[:200].lower()

    def test_static_tailwind_served(self, client):
        r = client.get("/static/css/tailwind.min.css")
        assert r.status_code == 200


class TestIniReader:
    def test_read_existing_ini_populates_sections(self):
        loader = SchemaLoader(SCHEMA_DIR)
        schema = loader.load_registry().by_name("zones")
        rendered = read_ini(schema, FIXTURE_ROOT)
        assert rendered.file_exists is True
        # zones.ini should have [zones], [zone_*] instances, [defaults]
        assert len(rendered.sections) >= 3

    def test_read_missing_ini_returns_empty(self, tmp_path):
        loader = SchemaLoader(SCHEMA_DIR)
        schema = loader.load_registry().by_name("zones")
        rendered = read_ini(schema, tmp_path)
        assert rendered.file_exists is False
        assert rendered.sections == []
        assert rendered.raw_text == ""

    def test_template_sections_labeled(self):
        loader = SchemaLoader(SCHEMA_DIR)
        schema = loader.load_registry().by_name("zones")
        rendered = read_ini(schema, FIXTURE_ROOT)
        # Find the zone_trusted instance
        zone_sections = [s for s in rendered.sections if s.real_name.startswith("zone_")]
        assert len(zone_sections) > 0
        for s in zone_sections:
            assert s.template_instance != ""

    def test_default_flag_set_on_absent_fields(self, tmp_path):
        """Fields present in schema but absent from INI should flag is_default=True."""
        loader = SchemaLoader(SCHEMA_DIR)
        schema = loader.load_registry().by_name("zones")
        # Write a minimal zones.ini that declares a zone but no attrs
        (tmp_path / "zones.ini").write_text("""
[zones]
trusted = lan
[zone_trusted]
[defaults]
default_any_to_any = DENY
""")
        rendered = read_ini(schema, tmp_path)
        zone_trusted = next(s for s in rendered.sections if s.real_name == "zone_trusted")
        # All 3 template fields should be is_default=True since the section is empty
        for fname, rf in zone_trusted.fields.items():
            assert rf.is_default is True, f"field {fname} should be using default"


class TestRestoreDefaults:
    def test_restore_writes_file(self, empty_tree_client):
        client, tree = empty_tree_client
        # Confirm file doesn't exist yet
        zones_path = tree / "zones.ini"
        assert not zones_path.exists()

        # POST to restore
        r = client.post("/ini/zones/restore", follow_redirects=False)
        assert r.status_code == 302  # redirect after POST

        # File should exist now
        assert zones_path.exists()
        content = zones_path.read_text()
        assert "[zones]" in content
        assert "trusted" in content

    def test_restore_creates_subdirectories(self, empty_tree_client):
        """security.ini lives under policies/ — parent dir must be created."""
        client, tree = empty_tree_client
        assert not (tree / "policies").exists()

        r = client.post("/ini/security/restore")
        assert r.status_code == 302

        security_path = tree / "policies" / "security.ini"
        assert security_path.exists()

    def test_restore_defaults_produces_engine_valid_tree(self, empty_tree_client):
        """
        The full foolproof invariant: restoring defaults for EVERY schema
        produces a config tree that the real engine can load without error.
        This is what makes the Restore button safe for operators.
        """
        client, tree = empty_tree_client
        for name in ["zones", "addresses", "services", "schedules",
                     "security", "nat", "pbr"]:
            r = client.post(f"/ini/{name}/restore")
            assert r.status_code == 302

        # Now load with the real engine
        from n2nhu_policy.nat_config_loader import NATConfigLoader
        from n2nhu_policy.pbr_config_loader import PBRConfigLoader
        pcfg = ConfigLoader(tree).load()
        NATConfigLoader(tree, pcfg).load()
        PBRConfigLoader(tree, pcfg).load()

    def test_restore_unknown_schema_404(self, client):
        r = client.post("/ini/nonexistent/restore")
        assert r.status_code == 404

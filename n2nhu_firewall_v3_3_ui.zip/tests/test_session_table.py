"""Tests for SessionTable — session lifecycle and reaper."""

from __future__ import annotations

import time
from ipaddress import IPv4Address

import pytest

from n2nhu_policy import (
    NATConfig,
    NATRule,
    NATType,
    PortPool,
    PortPoolSpec,
    Protocol,
    SessionTable,
)
from n2nhu_policy.nat_models import Direction


def _snat_rule(rule_id="r_snat", pool=(10000, 10999), tcp_est=3600, tcp_half=30):
    return NATRule(
        id=rule_id,
        type=NATType.SOURCE_NAT,
        translate_src_to="interface",
        port_pool=PortPoolSpec(*pool),
        tcp_established_timeout=tcp_est,
        tcp_half_open_timeout=tcp_half,
    )


class _MockClock:
    def __init__(self, start: float = 1000.0):
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float):
        self.now += seconds


@pytest.fixture
def clock():
    return _MockClock()


@pytest.fixture
def snat_rule():
    return _snat_rule()


@pytest.fixture
def config(snat_rule):
    return NATConfig(rules=(snat_rule,), reaper_interval=1)


@pytest.fixture
def rule_lookup(snat_rule):
    rules = {snat_rule.id: snat_rule}
    def lookup(rid):
        if rid not in rules:
            raise KeyError(rid)
        return rules[rid]
    return lookup


@pytest.fixture
def port_pool(snat_rule):
    return PortPool(snat_rule.port_pool)


@pytest.fixture
def table(config, rule_lookup, port_pool, snat_rule, clock):
    return SessionTable(
        config, rule_lookup,
        port_pools={snat_rule.id: port_pool},
        clock=clock,
    )


class TestSessionCreation:
    def test_create_returns_session_with_ids(self, table, snat_rule):
        sess = table.create_session(
            rule_id=snat_rule.id,
            nat_type=NATType.SOURCE_NAT,
            protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        assert sess.session_id
        assert sess.rule_id == snat_rule.id
        assert sess.nat_type == NATType.SOURCE_NAT
        assert sess.protocol == Protocol.TCP
        assert len(table) == 1


class TestSessionLookup:
    def test_forward_lookup_hit(self, table, snat_rule):
        table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        hit = table.lookup_forward(
            IPv4Address("192.168.1.10"), 54321,
            IPv4Address("8.8.8.8"), 443,
            Protocol.TCP,
        )
        assert hit is not None
        assert hit.xlated_src_port == 10000

    def test_forward_lookup_miss(self, table):
        assert table.lookup_forward(
            IPv4Address("1.1.1.1"), 1, IPv4Address("2.2.2.2"), 2, Protocol.TCP,
        ) is None

    def test_snat_reverse_lookup_hit(self, table, snat_rule):
        table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        # Return packet: 8.8.8.8:443 -> 203.0.113.1:10000
        hit = table.lookup_reverse(
            IPv4Address("8.8.8.8"), 443,
            IPv4Address("203.0.113.1"), 10000,
            Protocol.TCP,
        )
        assert hit is not None
        assert hit.orig_src_ip == IPv4Address("192.168.1.10")

    def test_dnat_reverse_lookup_hit(self, table):
        table.create_session(
            rule_id="r_dnat", nat_type=NATType.DESTINATION_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("198.51.100.77"), orig_src_port=55555,
            orig_dst_ip=IPv4Address("203.0.113.1"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("198.51.100.77"), xlated_src_port=55555,
            xlated_dst_ip=IPv4Address("172.16.0.10"), xlated_dst_port=443,
        )
        # Return packet: 172.16.0.10:443 -> 198.51.100.77:55555
        hit = table.lookup_reverse(
            IPv4Address("172.16.0.10"), 443,
            IPv4Address("198.51.100.77"), 55555,
            Protocol.TCP,
        )
        assert hit is not None


class TestEviction:
    def test_evict_removes_from_both_indexes(self, table, snat_rule):
        sess = table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        table.evict(sess)
        assert len(table) == 0
        assert table.lookup_forward(
            IPv4Address("192.168.1.10"), 54321,
            IPv4Address("8.8.8.8"), 443, Protocol.TCP,
        ) is None
        assert table.lookup_reverse(
            IPv4Address("8.8.8.8"), 443,
            IPv4Address("203.0.113.1"), 10000, Protocol.TCP,
        ) is None

    def test_evict_returns_port_to_pool(self, table, snat_rule, port_pool):
        # Simulate port allocation by draining one port manually
        port_pool.allocate()  # simulate that this port was allocated for a session
        assert port_pool.in_use() == 1
        sess = table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        table.evict(sess)
        assert port_pool.in_use() == 0  # port released


class TestReaper:
    def test_reap_evicts_expired_tcp_half_open(self, table, snat_rule, clock):
        sess = table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        # tcp_half_open_timeout = 30s, advance past
        clock.advance(31)
        evicted = table.reap_once()
        assert evicted == 1
        assert len(table) == 0

    def test_reap_does_not_evict_active_tcp_established(self, table, snat_rule, clock):
        sess = table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        sess.tcp_established = True
        # 30 minutes pass — still under 3600s timeout
        clock.advance(1800)
        evicted = table.reap_once()
        assert evicted == 0
        assert len(table) == 1

    def test_reap_udp_timeout(self, table, snat_rule, clock):
        table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.UDP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=33333,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=53,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=20000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=53,
        )
        clock.advance(100)  # under 180s
        assert table.reap_once() == 0
        clock.advance(100)  # now 200s total, past 180s
        assert table.reap_once() == 1

    def test_touch_refreshes_last_seen(self, table, snat_rule, clock):
        sess = table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        sess.tcp_established = True
        # 50 minutes pass
        clock.advance(3000)
        # Touch session
        sess.touch(clock.now, Direction.FORWARD)
        # Another 50 minutes (total 100, but last_seen was refreshed)
        clock.advance(3000)
        # Still under 3600s since last touch
        assert table.reap_once() == 0


class TestReaperThread:
    def test_background_reaper_starts_and_stops(self, snat_rule, rule_lookup, port_pool):
        # Use real time for this test since we're testing the actual thread
        config = NATConfig(rules=(snat_rule,), reaper_interval=1)
        table = SessionTable(
            config, rule_lookup, port_pools={snat_rule.id: port_pool},
        )
        table.start_reaper()
        assert table._reaper_thread is not None
        assert table._reaper_thread.is_alive()
        table.stop_reaper()
        assert table._reaper_thread is None

    def test_stop_reaper_idempotent(self, snat_rule, rule_lookup, port_pool):
        config = NATConfig(rules=(snat_rule,), reaper_interval=1)
        table = SessionTable(
            config, rule_lookup, port_pools={snat_rule.id: port_pool},
        )
        table.stop_reaper()  # never started — should not error
        table.start_reaper()
        table.stop_reaper()
        table.stop_reaper()  # double-stop


class TestCounters:
    def test_touch_updates_counters(self, table, snat_rule, clock):
        sess = table.create_session(
            rule_id=snat_rule.id, nat_type=NATType.SOURCE_NAT, protocol=Protocol.TCP,
            orig_src_ip=IPv4Address("192.168.1.10"), orig_src_port=54321,
            orig_dst_ip=IPv4Address("8.8.8.8"), orig_dst_port=443,
            xlated_src_ip=IPv4Address("203.0.113.1"), xlated_src_port=10000,
            xlated_dst_ip=IPv4Address("8.8.8.8"), xlated_dst_port=443,
        )
        sess.touch(clock.now, Direction.FORWARD, byte_count=1500)
        sess.touch(clock.now, Direction.FORWARD, byte_count=1500)
        sess.touch(clock.now, Direction.REVERSE, byte_count=500)
        assert sess.packets_forward == 2
        assert sess.packets_reverse == 1
        assert sess.bytes_forward == 3000
        assert sess.bytes_reverse == 500

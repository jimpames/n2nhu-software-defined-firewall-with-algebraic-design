"""
Phase G tests — RouterShim integration with NAT64.

Covers:
  - v6 frame with NAT64 prefix dst → translated to v4 and forwarded
  - v6 frame without matching NAT64 rule → dropped cleanly
  - Stats counters updated correctly for v6 vs v4
  - Session created in the session table after v6→v4
  - Reverse path: v4 reply gets looked up by session and we know
    original v6 tuple
  - Malformed ethertype handling
"""

from __future__ import annotations

import struct
import tempfile
from ipaddress import IPv4Address, IPv6Address, IPv6Network
from pathlib import Path

import pytest

from n2nhu_policy.frame_codec_v6 import (
    ETH_P_IPV6, build_tcp_frame_v6, parse_frame_v6,
)
from n2nhu_policy.frame_codec import parse_frame as parse_v4
from n2nhu_policy.nat64_addr import WELL_KNOWN_PREFIX, embed_v4_in_v6
from n2nhu_policy.nat_models import NATType
from n2nhu_policy.router_shim import ForwardAction, RouterShim


CLIENT_V6 = IPv6Address("2001:db8:cafe::100")
SERVER_V4 = IPv4Address("203.0.113.5")
SERVER_V6 = embed_v4_in_v6(SERVER_V4, WELL_KNOWN_PREFIX)
FIREWALL_V4 = IPv4Address("198.51.100.1")


@pytest.fixture
def nat64_tree():
    """Build a complete config tree with a NAT64 rule."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "objects").mkdir()
        (root / "policies").mkdir()

        (root / "zones.ini").write_text(
            "[zones]\n"
            "trusted = lan\n"
            "untrusted = wan1\n"
            "\n[defaults]\n"
            "default_any_to_any = ALLOW\n"
        )
        (root / "objects" / "addresses.ini").write_text(
            "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
            "\n[addr_any_v6]\ntype = network\nvalue = ::/0\n"
            "\n[addr_v6_clients]\ntype = network\nvalue = 2001:db8::/32\n"
            "\n[addr_fw_v4]\ntype = host\nvalue = 198.51.100.1\n"
            "\n[addr_server_v4]\ntype = host\nvalue = 203.0.113.5\n"
        )
        (root / "objects" / "services.ini").write_text(
            "[svc_any]\nprotocol = any\n"
        )
        (root / "objects" / "schedules.ini").write_text(
            "[sched_always]\ntype = always\n"
        )
        (root / "policies" / "security.ini").write_text(
            "[policy_order]\nrules = p_allow\n"
            "\n[p_allow]\n"
            "src_zone = any\ndst_zone = any\n"
            "src_addr = addr_any\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "action = ALLOW\n"
        )
        (root / "policies" / "nat.ini").write_text(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\ndst_zone = untrusted\n"
            "src_addr = addr_v6_clients\ndst_addr = addr_any_v6\n"
            "service = svc_any\nschedule = sched_always\n"
            "translate_src_to_v4 = addr_fw_v4\n"
            "port_pool = 20000-29999\n"
        )
        yield root


@pytest.fixture
def shim(nat64_tree):
    """A RouterShim with WAN1 routing to a v4-server network."""
    return RouterShim(
        config_root=nat64_tree,
        interface_ips={
            "lan": IPv4Address("192.168.1.1"),
            "wan1": FIREWALL_V4,
        },
        interface_networks={
            "lan": IPv4Network_helper("192.168.1.0/24"),
            "wan1": IPv4Network_helper("0.0.0.0/0"),  # default route
        },
    )


def IPv4Network_helper(s):
    from ipaddress import IPv4Network
    return IPv4Network(s)


class TestShimNAT64Forward:
    def test_v6_packet_in_prefix_gets_translated(self, shim):
        """A v6 frame with dst in 64:ff9b::/96 arrives → shim translates
        to v4 and returns FORWARD."""
        frame = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=45000, dst_port=80,
            payload=b"GET / HTTP/1.0\r\n\r\n",
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD, \
            f"expected FORWARD, got {decision.action} ({decision.drop_reason})"
        assert decision.egress_iface == "wan1"
        # The new frame should parse as v4
        p4 = parse_v4(decision.frame)
        assert p4.ip_version == 4
        assert p4.src_ip == FIREWALL_V4
        assert p4.dst_ip == SERVER_V4

    def test_v6_packet_not_in_prefix_dropped(self, shim):
        """A v6 frame destined to a non-NAT64 v6 address is dropped in v1."""
        frame = build_tcp_frame_v6(
            CLIENT_V6, IPv6Address("2001:db8:9999::1"),  # not in 64:ff9b::/96
            src_port=45000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        assert "no NAT64 rule" in decision.drop_reason

    def test_stats_updated(self, shim):
        frame = build_tcp_frame_v6(CLIENT_V6, SERVER_V6, 1, 2)
        shim.process_frame("lan", frame)
        stats = shim._stats
        assert stats["frames_in"] == 1
        assert stats["frames_in_v6"] == 1
        assert stats["nat64_v6_to_v4"] == 1
        assert stats["frames_forwarded"] == 1

    def test_session_created_after_translation(self, shim):
        """After translating a v6 frame, a session exists keyed on the
        original v6 tuple."""
        frame = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=45000, dst_port=80,
        )
        shim.process_frame("lan", frame)
        from n2nhu_policy.models import Protocol
        found = shim.session_table.lookup_forward(
            CLIENT_V6, 45000, SERVER_V6, 80, Protocol.TCP,
        )
        assert found is not None
        assert found.nat_type == NATType.NAT64

    def test_reverse_session_lookup_works(self, shim):
        """After a v6→v4 translation, a v4 reply's 5-tuple should find
        the session. This is the invariant that makes reply handling work."""
        frame = build_tcp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=45000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        # Extract the xlated_src_port from the translated frame
        p4 = parse_v4(decision.frame)
        xlated_src_port = p4.src_port

        # Now look up as if a v4 reply arrived: from server:80 to fw:xlated_port
        from n2nhu_policy.models import Protocol
        session = shim.session_table.lookup_reverse(
            SERVER_V4, 80,
            FIREWALL_V4, xlated_src_port,
            Protocol.TCP,
        )
        assert session is not None
        assert session.orig_src_ip == CLIENT_V6
        assert session.orig_src_port == 45000

    def test_unknown_ethertype_drops_cleanly(self, shim):
        """A frame with some random ethertype is dropped with a clean reason."""
        frame = b"\x00" * 12 + struct.pack("!H", 0x8863) + b"\x00" * 50  # PPPoE Disc
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.PARSE_ERROR
        assert "ethertype" in decision.drop_reason

    def test_short_frame_drops_cleanly(self, shim):
        frame = b"\x00" * 5  # too short
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.PARSE_ERROR

    def test_v4_path_still_works(self, shim):
        """Regression: adding v6 dispatch must not break v4 forwarding."""
        from n2nhu_policy.frame_codec import build_tcp_frame
        frame = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.5"),
            src_port=40000, dst_port=443,
            payload=b"test",
        )
        decision = shim.process_frame("lan", frame)
        # Forward or at least not a parse error — the v4 pipeline should handle it
        assert decision.action != ForwardAction.PARSE_ERROR

    def test_v4_counter_separate_from_v6(self, shim):
        """frames_in_v4 and frames_in_v6 count separately."""
        # Send one v6
        v6 = build_tcp_frame_v6(CLIENT_V6, SERVER_V6, 1, 2)
        shim.process_frame("lan", v6)
        # Send one v4
        from n2nhu_policy.frame_codec import build_tcp_frame
        v4 = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.5"),
            src_port=1, dst_port=80,
        )
        shim.process_frame("lan", v4)
        assert shim._stats["frames_in_v4"] == 1
        assert shim._stats["frames_in_v6"] == 1
        assert shim._stats["frames_in"] == 2

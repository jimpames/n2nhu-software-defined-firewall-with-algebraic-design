"""
Integration tests — full-stack scenarios from the foundation spec.

These are the seven canonical checks that pin down the contract of the system.
Any change that breaks one of these is a policy-visible regression.
"""

from __future__ import annotations

from datetime import datetime
from ipaddress import IPv4Address
from zoneinfo import ZoneInfo

import pytest

from n2nhu_policy import Action, AuditLog, Packet, Protocol, Stats

NY = ZoneInfo("America/New_York")


def _pkt(**kwargs):
    return Packet(
        ingress_iface=kwargs.get("ingress", "lan"),
        egress_iface=kwargs.get("egress", "wan1"),
        src_ip=IPv4Address(kwargs.get("src", "192.168.1.10")),
        dst_ip=IPv4Address(kwargs.get("dst", "8.8.8.8")),
        protocol=kwargs.get("proto", Protocol.TCP),
        src_port=kwargs.get("sport", 54321),
        dst_port=kwargs.get("dport", 80),
        icmp_type=kwargs.get("icmp"),
    )


# Fixed timestamps for reproducible tests
BIZ_TUE_10AM = datetime(2026, 2, 24, 10, 0, tzinfo=NY)
SUN_10AM = datetime(2026, 2, 22, 10, 0, tzinfo=NY)
MAINT_WINDOW = datetime(2026, 4, 20, 3, 0, tzinfo=NY)


class TestCanonicalScenarios:
    """Seven scenarios that pin down the contract."""

    def test_1_lan_workstation_to_internet_http(self, engine):
        """LAN workstation -> Internet HTTP -> ALLOW via p030."""
        pkt = _pkt(
            ingress="lan", egress="wan1",
            src="192.168.1.10", dst="198.51.100.1",
            proto=Protocol.TCP, dport=80,
        )
        d = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p030_lan_web"

    def test_2_admin_ssh_dmz_business_hours(self, engine):
        """Admin WS -> DMZ web SSH at Tuesday 10am -> ALLOW via p020."""
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.50", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p020_admin_ssh"
        assert d.log is True

    def test_3_admin_ssh_dmz_sunday_denied(self, engine):
        """Same packet on a Sunday -> DENY (schedule miss, falls to p099)."""
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.50", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d = engine.evaluate(pkt, SUN_10AM)
        assert d.action == Action.DENY
        assert d.rule_id == "p099_implicit_deny"

    def test_4_guest_to_internal_lan_denied(self, engine):
        """Guest -> internal 192.168.1.50 -> DENY via p060."""
        pkt = _pkt(
            ingress="wifi_guest", egress="lan",
            src="192.168.99.10", dst="192.168.1.50",
            proto=Protocol.TCP, dport=445,
        )
        d = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d.action == Action.DENY
        assert d.rule_id == "p060_block_guest_internal"

    def test_5_any_to_blocklist_blocked(self, engine):
        """
        Anyone -> blocklisted IP -> DENY via p010
        (precedence over otherwise-allowed traffic).
        """
        # LAN user going to http on malware IP — p030 would allow but p010 fires first
        pkt = _pkt(
            ingress="lan", egress="wan1",
            src="192.168.1.10", dst="203.0.113.66",
            proto=Protocol.TCP, dport=80,
        )
        d = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d.action == Action.DENY
        assert d.rule_id == "p010_block_malware"

    def test_6_external_web_to_dmz_allowed(self, engine):
        """Internet -> DMZ web on HTTPS -> ALLOW via p040."""
        pkt = _pkt(
            ingress="wan1", egress="dmz",
            src="198.51.100.77", dst="172.16.0.10",
            proto=Protocol.TCP, dport=443,
        )
        d = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p040_dmz_web_in"

    def test_7_guest_web_to_internet_allowed(self, engine):
        """Guest -> Internet HTTPS -> ALLOW via p050."""
        pkt = _pkt(
            ingress="wifi_guest", egress="wan1",
            src="192.168.99.10", dst="1.1.1.1",
            proto=Protocol.TCP, dport=443,
        )
        d = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d.action == Action.ALLOW
        assert d.rule_id == "p050_guest_internet"


class TestStatsAndAudit:
    def test_stats_accumulate(self, engine):
        stats = Stats()
        packets = [
            _pkt(dport=80),   # p030 hit
            _pkt(dport=443),  # p030 hit
            _pkt(dst="203.0.113.66", dport=80),  # p010 hit
        ]
        for p in packets:
            stats.record(engine.evaluate(p, BIZ_TUE_10AM))
        summary = stats.as_dict()
        assert summary["total_decisions"] == 3
        assert summary["by_rule"]["p030_lan_web"] == 2
        assert summary["by_rule"]["p010_block_malware"] == 1
        assert summary["by_action"]["ALLOW"] == 2
        assert summary["by_action"]["DENY"] == 1

    def test_audit_log_writes_only_flagged(self, engine, tmp_path):
        log_path = tmp_path / "audit.log"
        audit = AuditLog(path=log_path)
        try:
            # p030 has log=false — should not write
            p1 = _pkt(dport=80)
            d1 = engine.evaluate(p1, BIZ_TUE_10AM)
            audit.log(p1, d1, BIZ_TUE_10AM)

            # p010 has log=true — should write
            p2 = _pkt(dst="203.0.113.66", dport=80)
            d2 = engine.evaluate(p2, BIZ_TUE_10AM)
            audit.log(p2, d2, BIZ_TUE_10AM)
        finally:
            audit.close()

        content = log_path.read_text()
        lines = [line for line in content.strip().split("\n") if line]
        assert len(lines) == 1  # Only the blocklist hit logged
        assert "p010_block_malware" in lines[0]
        assert "DENY" in lines[0]


class TestDeterminism:
    def test_same_input_same_output(self, engine):
        pkt = _pkt(
            ingress="lan", egress="dmz",
            src="192.168.1.50", dst="172.16.0.10",
            proto=Protocol.TCP, dport=22,
        )
        d1 = engine.evaluate(pkt, BIZ_TUE_10AM)
        d2 = engine.evaluate(pkt, BIZ_TUE_10AM)
        d3 = engine.evaluate(pkt, BIZ_TUE_10AM)
        assert d1 == d2 == d3

    def test_every_packet_gets_a_decision(self, engine):
        """Fuzz-style: no combination of (zone, proto, port) leaves us without a verdict."""
        for ingress in ["lan", "wan1", "dmz", "wifi_guest", "mgt"]:
            for egress in ["lan", "wan1", "dmz", "wifi_guest", "mgt"]:
                for proto in [Protocol.TCP, Protocol.UDP, Protocol.ICMP]:
                    for dport in [22, 80, 443, 53, 9999]:
                        pkt = _pkt(
                            ingress=ingress, egress=egress,
                            proto=proto, dport=dport,
                            icmp=(8 if proto == Protocol.ICMP else None),
                        )
                        d = engine.evaluate(pkt, BIZ_TUE_10AM)
                        assert d.action in (Action.ALLOW, Action.DENY, Action.REJECT)
                        assert d.rule_id

"""
Phase N tests — CaptureManager: async write path, queue isolation,
lifecycle, comment formatting, file aggregation.

Covers:
  - Manager creates one writer per unique pcap_file
  - Two rules sharing a pcap_file share a writer
  - submit() routes the same frame to multiple writers when many rules match
  - Frames written are recoverable from the resulting pcapng files
  - Comment format is correct and parseable
  - Queue overflow drops frames without affecting other writers
  - stop() flushes pending writes and closes files
  - stop() is idempotent
  - Disabled rules don't create writers
  - Empty config produces zero writers
"""

from __future__ import annotations

import struct
import sys
import threading
import time
from pathlib import Path

import pytest

from n2nhu_policy.capture_config_loader import CaptureConfigLoader
from n2nhu_policy.capture_manager import (
    CaptureManager, format_capture_comment,
)
from n2nhu_policy.capture_models import (
    CaptureConfig, CaptureMatchAction, CapturePoint, CaptureRule,
)
from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.models import Action

# Reuse the pcapng parser from Phase K's test file
from tests.test_pcapng_phase_k import read_pcapng


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def policy_tree(tmp_path):
    root = tmp_path
    (root / "objects").mkdir()
    (root / "policies").mkdir()
    (root / "zones.ini").write_text(
        "[zones]\ntrusted = lan\nuntrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\nsrc_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\nservice = svc_any\n"
        "schedule = sched_always\naction = ALLOW\n"
    )
    return root


def _capture_config_from_text(policy_tree, text: str) -> CaptureConfig:
    (policy_tree / "policies" / "capture.ini").write_text(text)
    pol = ConfigLoader(policy_tree).load()
    return CaptureConfigLoader(policy_tree, pol).load()


def _drain(cm: CaptureManager, *, sleep_s: float = 0.2) -> None:
    """Wait for writer threads to drain pending work before assertion."""
    time.sleep(sleep_s)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCommentFormatter:

    def test_minimal(self):
        comment = format_capture_comment(
            capture_rule_id="cap1",
            capture_point=CapturePoint.INGRESS,
            decision_action=None,
        )
        assert "capture_point=ingress" in comment
        assert "decision=none" in comment
        assert "cap_rule=cap1" in comment

    def test_with_decision_and_rules(self):
        comment = format_capture_comment(
            capture_rule_id="cap_main",
            capture_point=CapturePoint.POST_NAT,
            decision_action=Action.ALLOW,
            policy_rule_id="p_allow_lan",
            nat_rule_id="n_snat_wan",
            pbr_rule_id="pbr_voice",
        )
        assert "capture_point=post_nat" in comment
        assert "decision=allow" in comment
        assert "rule_id=p_allow_lan" in comment
        assert "nat_rule_id=n_snat_wan" in comment
        assert "pbr_rule_id=pbr_voice" in comment
        assert "cap_rule=cap_main" in comment

    def test_deny_action(self):
        comment = format_capture_comment(
            capture_rule_id="x",
            capture_point=CapturePoint.POST_POLICY,
            decision_action=Action.DENY,
        )
        assert "decision=deny" in comment


class TestManagerLifecycle:

    def test_empty_config_no_workers(self, policy_tree, tmp_path):
        cfg = _capture_config_from_text(policy_tree,
            "[capture_order]\nrules =\n"
        )
        cm = CaptureManager(cfg)
        assert cm.active_files == ()
        cm.stop()

    def test_stop_is_idempotent(self, policy_tree, tmp_path):
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
        )
        cm = CaptureManager(cfg)
        cm.stop()
        cm.stop()  # must not raise
        cm.stop()

    def test_disabled_rules_dont_create_workers(self, policy_tree, tmp_path):
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\nenabled = false\n"
            f"capture_point = ingress\npcap_file = {out}\n"
        )
        cm = CaptureManager(cfg)
        assert cm.active_files == ()
        cm.stop()

    def test_one_worker_per_unique_file(self, policy_tree, tmp_path):
        out_a = tmp_path / "a.pcapng"
        out_b = tmp_path / "b.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1, c2, c3\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out_a}\n"
            f"\n[c2]\ncapture_point = post_nat\npcap_file = {out_a}\n"
            f"\n[c3]\ncapture_point = ingress\npcap_file = {out_b}\n"
        )
        cm = CaptureManager(cfg)
        # Two unique files → two workers
        assert set(cm.active_files) == {str(out_a), str(out_b)}
        cm.stop()


class TestSubmit:

    def test_single_writer_writes_frame(self, policy_tree, tmp_path):
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
        )
        cm = CaptureManager(cfg)
        rule = cfg.rules[0]

        frame = b"\xAA" * 64
        cm.submit(
            (rule,), frame,
            timestamp_us=12345,
            capture_point=CapturePoint.INGRESS,
            policy_rule_id="p_test",
        )
        cm.stop()

        _shb, _idb, epbs = read_pcapng(out)
        assert len(epbs) == 1
        assert epbs[0]["captured_data"] == frame
        assert epbs[0]["timestamp_us"] == 12345
        # Comment carries the annotations
        comment = epbs[0]["options"][1][0].decode("utf-8")
        assert "rule_id=p_test" in comment
        assert "cap_rule=c1" in comment
        assert "capture_point=ingress" in comment

    def test_two_rules_same_file_share_writer(self, policy_tree, tmp_path):
        """Two rules pointing at the same pcap_file produce two EPBs in
        the same file (one per submit), with each rule's comment."""
        out = tmp_path / "shared.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1, c2\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
            f"\n[c2]\ncapture_point = ingress\npcap_file = {out}\n"
        )
        cm = CaptureManager(cfg)
        # Both rules match — one frame, two submissions
        cm.submit(
            cfg.rules, b"\xBB" * 80,
            timestamp_us=1, capture_point=CapturePoint.INGRESS,
        )
        cm.stop()

        _shb, _idb, epbs = read_pcapng(out)
        assert len(epbs) == 2
        rule_tags = sorted(
            epb["options"][1][0].decode("utf-8").split("cap_rule=")[1]
            for epb in epbs
        )
        assert rule_tags == ["c1", "c2"]

    def test_two_rules_different_files_each_get_one(self, policy_tree, tmp_path):
        out_a = tmp_path / "a.pcapng"
        out_b = tmp_path / "b.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = ca, cb\n"
            f"\n[ca]\ncapture_point = ingress\npcap_file = {out_a}\n"
            f"\n[cb]\ncapture_point = ingress\npcap_file = {out_b}\n"
        )
        cm = CaptureManager(cfg)
        cm.submit(
            cfg.rules, b"\xCC" * 60,
            timestamp_us=1, capture_point=CapturePoint.INGRESS,
        )
        cm.stop()

        for path in (out_a, out_b):
            _shb, _idb, epbs = read_pcapng(path)
            assert len(epbs) == 1, f"{path} expected 1 frame"
            assert epbs[0]["captured_data"] == b"\xCC" * 60

    def test_submit_after_stop_is_noop(self, policy_tree, tmp_path):
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
        )
        cm = CaptureManager(cfg)
        cm.stop()
        # After stop, submit returns 0
        accepted = cm.submit(
            cfg.rules, b"\x00" * 60,
            timestamp_us=1, capture_point=CapturePoint.INGRESS,
        )
        assert accepted == 0

    def test_submit_routes_only_to_named_rules(self, policy_tree, tmp_path):
        """If matching_rules contains only c1, only c1's file gets written."""
        out_a = tmp_path / "a.pcapng"
        out_b = tmp_path / "b.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = ca, cb\n"
            f"\n[ca]\ncapture_point = ingress\npcap_file = {out_a}\n"
            f"\n[cb]\ncapture_point = ingress\npcap_file = {out_b}\n"
        )
        cm = CaptureManager(cfg)
        # Submit only ca's rule
        only_ca = (cfg.rules[0],)
        cm.submit(
            only_ca, b"\xDD" * 60,
            timestamp_us=1, capture_point=CapturePoint.INGRESS,
        )
        cm.stop()

        _shb_a, _idb_a, epbs_a = read_pcapng(out_a)
        assert len(epbs_a) == 1
        # File b never opened — but writer creates the SHB+IDB on construction
        _shb_b, _idb_b, epbs_b = read_pcapng(out_b)
        assert epbs_b == []


class TestQueueOverflow:

    def test_overflow_drops_without_blocking(self, policy_tree, tmp_path):
        """A bursty submitter with a tiny queue should see drops, not
        blocking. Verified by counting frames + drops sum to the
        submission count, and submission completes promptly."""
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
            f"queue_depth = 4\n"
        )
        cm = CaptureManager(cfg)
        rules = cfg.rules

        # Slam 1000 frames in tightly — most will overflow the depth-4 queue
        N = 1000
        start = time.time()
        for i in range(N):
            cm.submit(
                rules, b"\xEE" * 60,
                timestamp_us=i, capture_point=CapturePoint.INGRESS,
            )
        elapsed = time.time() - start
        # Submission must not block on the queue — the whole burst
        # completes very fast even though most frames are dropped.
        assert elapsed < 1.0, f"submit blocked: took {elapsed:.3f}s"
        cm.stop()

        # Check that frames_written + drops accounts for the submissions
        stats = cm.stats()
        s = stats["c1"]
        assert s.frames_written + s.frames_dropped_queue_full == N


class TestStats:

    def test_stats_counts_writes(self, policy_tree, tmp_path):
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
        )
        cm = CaptureManager(cfg)
        N = 25
        for _ in range(N):
            cm.submit(
                cfg.rules, b"\x00" * 60,
                timestamp_us=int(time.time() * 1e6),
                capture_point=CapturePoint.INGRESS,
            )
        # Wait for drain
        _drain(cm)
        stats = cm.stats()
        cm.stop()
        assert stats["c1"].frames_written == N

    def test_stats_per_rule_separate(self, policy_tree, tmp_path):
        out_a = tmp_path / "a.pcapng"
        out_b = tmp_path / "b.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = ca, cb\n"
            f"\n[ca]\ncapture_point = ingress\npcap_file = {out_a}\n"
            f"\n[cb]\ncapture_point = ingress\npcap_file = {out_b}\n"
        )
        cm = CaptureManager(cfg)
        for _ in range(3):
            cm.submit(
                (cfg.rules[0],), b"\x00" * 60,
                timestamp_us=1, capture_point=CapturePoint.INGRESS,
            )
        for _ in range(7):
            cm.submit(
                (cfg.rules[1],), b"\x00" * 60,
                timestamp_us=1, capture_point=CapturePoint.INGRESS,
            )
        _drain(cm)
        stats = cm.stats()
        cm.stop()
        assert stats["ca"].frames_written == 3
        assert stats["cb"].frames_written == 7


class TestContextManager:

    def test_context_manager_closes_on_exit(self, policy_tree, tmp_path):
        out = tmp_path / "x.pcapng"
        cfg = _capture_config_from_text(policy_tree,
            f"[capture_order]\nrules = c1\n"
            f"\n[c1]\ncapture_point = ingress\npcap_file = {out}\n"
        )
        with CaptureManager(cfg) as cm:
            cm.submit(
                cfg.rules, b"\xFF" * 60,
                timestamp_us=1, capture_point=CapturePoint.INGRESS,
            )
        # On exit, file is closed and parseable
        _shb, _idb, epbs = read_pcapng(out)
        assert len(epbs) == 1

"""
Phase I tests — NAT64 reply path (v4 → v6).

Covers:
  - A v4 frame whose dst matches the NAT64 pool address and whose 5-tuple
    matches an established session is reverse-translated to v6 and emitted
    on the original v6 client's ingress iface.
  - The session's reverse counters update on each reply.
  - A v4 frame matching the pool address but with no session falls through
    to the normal v4 pipeline (no false positives).
  - A v4 frame matching no NAT64 rule's pool address is unaffected.
  - Unknown protocols inside the v4 envelope (e.g. ICMP) are not mishandled
    by the reply detector — they fall through to the main pipeline.
  - Reply path bypasses policy evaluation (stateful permit on session).
  - client_ingress_iface is correctly populated on the session at create time.
"""

from __future__ import annotations

import tempfile
from ipaddress import IPv4Address, IPv4Network, IPv6Address
from pathlib import Path

import pytest

from n2nhu_policy.frame_codec import build_tcp_frame, parse_frame as parse_v4
from n2nhu_policy.frame_codec_v6 import (
    build_tcp_frame_v6, parse_frame_v6,
)
from n2nhu_policy.models import Protocol
from n2nhu_policy.nat64_addr import WELL_KNOWN_PREFIX, embed_v4_in_v6
from n2nhu_policy.nat_models import NATType
from n2nhu_policy.router_shim import ForwardAction, RouterShim


CLIENT_V6 = IPv6Address("2001:db8:cafe::100")
SERVER_V4 = IPv4Address("203.0.113.5")
SERVER_V6 = embed_v4_in_v6(SERVER_V4, WELL_KNOWN_PREFIX)
FIREWALL_V4 = IPv4Address("198.51.100.1")
LAN_V4 = IPv4Address("192.168.1.1")


@pytest.fixture
def nat64_tree():
    """Build a complete config tree with a NAT64 rule (mirrors phase G)."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "objects").mkdir()
        (root / "policies").mkdir()

        (root / "zones.ini").write_text(
            "[zones]\n"
            "trusted = lan\n"
            "untrusted = wan1\n"
            "\n[defaults]\n"
            "default_any_to_any = ALLOW\n"
        )
        (root / "objects" / "addresses.ini").write_text(
            "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
            "\n[addr_any_v6]\ntype = network\nvalue = ::/0\n"
            "\n[addr_v6_clients]\ntype = network\nvalue = 2001:db8::/32\n"
            "\n[addr_fw_v4]\ntype = host\nvalue = 198.51.100.1\n"
            "\n[addr_server_v4]\ntype = host\nvalue = 203.0.113.5\n"
        )
        (root / "objects" / "services.ini").write_text(
            "[svc_any]\nprotocol = any\n"
        )
        (root / "objects" / "schedules.ini").write_text(
            "[sched_always]\ntype = always\n"
        )
        (root / "policies" / "security.ini").write_text(
            "[policy_order]\nrules = p_allow\n"
            "\n[p_allow]\n"
            "src_zone = any\ndst_zone = any\n"
            "src_addr = addr_any\ndst_addr = addr_any\n"
            "service = svc_any\nschedule = sched_always\n"
            "action = ALLOW\n"
        )
        (root / "policies" / "nat.ini").write_text(
            "[nat_order]\nrules = n_nat64\n"
            "\n[n_nat64]\n"
            "type = nat64\n"
            "src_zone = trusted\ndst_zone = untrusted\n"
            "src_addr = addr_v6_clients\ndst_addr = addr_any_v6\n"
            "service = svc_any\nschedule = sched_always\n"
            "translate_src_to_v4 = addr_fw_v4\n"
            "port_pool = 20000-29999\n"
        )
        yield root


@pytest.fixture
def shim(nat64_tree):
    """A RouterShim with WAN1 routing to a v4-server network."""
    return RouterShim(
        config_root=nat64_tree,
        interface_ips={
            "lan": LAN_V4,
            "wan1": FIREWALL_V4,
        },
        interface_networks={
            "lan": IPv4Network("192.168.1.0/24"),
            "wan1": IPv4Network("0.0.0.0/0"),  # default route
        },
    )


def _establish_session(shim) -> int:
    """Send one v6 frame to set up a NAT64 session. Returns the
    pool-allocated v4 src port that the reply will be addressed to."""
    forward_frame = build_tcp_frame_v6(
        CLIENT_V6, SERVER_V6,
        src_port=45000, dst_port=80,
        payload=b"GET / HTTP/1.0\r\n\r\n",
    )
    decision = shim.process_frame("lan", forward_frame)
    assert decision.action == ForwardAction.FORWARD, \
        f"forward setup failed: {decision.drop_reason}"
    p4 = parse_v4(decision.frame)
    return p4.src_port


class TestNAT64ReplyPath:
    """The v4-side reply leg of an established NAT64 session is
    reverse-translated to v6 and emitted on the original client iface."""

    def test_session_records_client_ingress_iface(self, shim):
        """v6 forward path stores the client's ingress iface on the session."""
        _establish_session(shim)
        session = shim.session_table.lookup_forward(
            CLIENT_V6, 45000, SERVER_V6, 80, Protocol.TCP,
        )
        assert session is not None
        assert session.client_ingress_iface == "lan"

    def test_v4_reply_is_reverse_translated_to_v6(self, shim):
        """The reply leg of an established session emerges as v6."""
        xlated_port = _establish_session(shim)

        # Build a v4 reply: server → firewall pool address & port
        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
            payload=b"HTTP/1.0 200 OK\r\n\r\n",
            flags=0x18,
        )
        decision = shim.process_frame("wan1", reply_frame)
        assert decision.action == ForwardAction.FORWARD, \
            f"reply forward failed: {decision.drop_reason}"
        # Output should be a v6 frame
        parsed_v6_reply = parse_frame_v6(decision.frame)
        # Source: NAT64-embedded v4 server
        assert parsed_v6_reply.src_ip == SERVER_V6
        # Destination: the original v6 client
        assert parsed_v6_reply.dst_ip == CLIENT_V6
        # Source port preserved (port 80)
        assert parsed_v6_reply.src_port == 80
        # Destination port restored to client's original
        assert parsed_v6_reply.dst_port == 45000

    def test_reply_egresses_on_client_ingress_iface(self, shim):
        """The reply must go out the iface the v6 client originally came in on."""
        xlated_port = _establish_session(shim)
        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
        )
        decision = shim.process_frame("wan1", reply_frame)
        assert decision.action == ForwardAction.FORWARD
        assert decision.egress_iface == "lan"

    def test_reply_path_increments_v4_to_v6_counter(self, shim):
        xlated_port = _establish_session(shim)
        before = shim._stats["nat64_v4_to_v6"]
        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
        )
        shim.process_frame("wan1", reply_frame)
        assert shim._stats["nat64_v4_to_v6"] == before + 1

    def test_reply_path_updates_session_reverse_counters(self, shim):
        xlated_port = _establish_session(shim)
        session = shim.session_table.lookup_forward(
            CLIENT_V6, 45000, SERVER_V6, 80, Protocol.TCP,
        )
        before_reverse_packets = session.packets_reverse
        before_reverse_bytes = session.bytes_reverse

        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
            payload=b"x" * 100,
        )
        shim.process_frame("wan1", reply_frame)

        # Re-fetch (same instance, but defensive)
        session = shim.session_table.lookup_forward(
            CLIENT_V6, 45000, SERVER_V6, 80, Protocol.TCP,
        )
        assert session.packets_reverse == before_reverse_packets + 1
        assert session.bytes_reverse > before_reverse_bytes

    def test_v4_to_pool_with_no_session_falls_through(self, shim):
        """A v4 frame matching the pool address but with no established
        session must NOT be reverse-translated. It falls through to the
        normal v4 pipeline (which will route it normally)."""
        # No prior session created — this is the first frame
        bogus_reply = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=22999,  # in pool range but no session
        )
        decision = shim.process_frame("wan1", bogus_reply)
        # We don't assert FORWARD vs DROP here — depends on the v4 policy
        # path. The key invariant is that no v4→v6 translation happened.
        assert shim._stats["nat64_v4_to_v6"] == 0
        # No v6 frame should have been produced
        if decision.action == ForwardAction.FORWARD:
            from n2nhu_policy.frame_codec_v6 import ETH_P_IPV6
            import struct
            ethertype = struct.unpack("!H", decision.frame[12:14])[0]
            assert ethertype != ETH_P_IPV6, \
                "should not have produced a v6 frame without a session"

    def test_v4_to_unrelated_address_unaffected(self, shim):
        """A v4 frame addressed to a non-pool v4 address never goes
        through reply detection."""
        # Send normal v4 not to firewall pool address
        ordinary_v4 = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("203.0.113.99"),
            src_port=40000, dst_port=443,
        )
        before = shim._stats["nat64_v4_to_v6"]
        shim.process_frame("lan", ordinary_v4)
        assert shim._stats["nat64_v4_to_v6"] == before

    def test_reply_path_does_not_double_increment_frames_in_v6(self, shim):
        """A v4 reply that gets reverse-translated should still be
        accounted as v4 ingress, not v6."""
        xlated_port = _establish_session(shim)
        v6_in_before = shim._stats["frames_in_v6"]
        v4_in_before = shim._stats["frames_in_v4"]

        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
        )
        shim.process_frame("wan1", reply_frame)
        assert shim._stats["frames_in_v6"] == v6_in_before
        assert shim._stats["frames_in_v4"] == v4_in_before + 1

    def test_full_round_trip_session_consistent(self, shim):
        """Forward + reply leg both touch the same session, both directions
        update counters, and the session is reachable via either index."""
        xlated_port = _establish_session(shim)
        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
        )
        shim.process_frame("wan1", reply_frame)

        session_fwd = shim.session_table.lookup_forward(
            CLIENT_V6, 45000, SERVER_V6, 80, Protocol.TCP,
        )
        session_rev = shim.session_table.lookup_reverse(
            SERVER_V4, 80, FIREWALL_V4, xlated_port, Protocol.TCP,
        )
        assert session_fwd is session_rev
        assert session_fwd.packets_forward >= 1
        assert session_fwd.packets_reverse >= 1

    def test_udp_reply_path_works(self, shim):
        """The reply path supports UDP just as it does TCP."""
        from n2nhu_policy.frame_codec_v6 import build_udp_frame_v6
        from n2nhu_policy.frame_codec import build_udp_frame

        # Forward UDP
        forward = build_udp_frame_v6(
            CLIENT_V6, SERVER_V6,
            src_port=45000, dst_port=53, payload=b"\x00" * 20,
        )
        decision = shim.process_frame("lan", forward)
        assert decision.action == ForwardAction.FORWARD
        p4 = parse_v4(decision.frame)
        xlated_port = p4.src_port

        # Reply UDP
        reply = build_udp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=53, dst_port=xlated_port,
            payload=b"\x00" * 30,
        )
        decision_reply = shim.process_frame("wan1", reply)
        assert decision_reply.action == ForwardAction.FORWARD
        parsed_reply_v6 = parse_frame_v6(decision_reply.frame)
        assert parsed_reply_v6.dst_ip == CLIENT_V6
        assert parsed_reply_v6.dst_port == 45000

    def test_reply_path_records_nat_rule_id(self, shim):
        """The decision should carry the NAT64 rule_id so log/audit code
        can attribute the reply correctly."""
        xlated_port = _establish_session(shim)
        reply_frame = build_tcp_frame(
            src_ip=SERVER_V4, dst_ip=FIREWALL_V4,
            src_port=80, dst_port=xlated_port,
        )
        decision = shim.process_frame("wan1", reply_frame)
        assert decision.nat_rule_id == "n_nat64"

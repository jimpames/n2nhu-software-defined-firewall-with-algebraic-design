"""
Phase K tests — PcapNG writer format correctness.

These tests verify that the bytes the writer emits are valid PcapNG by
reading them back with a pure-Python parser (also defined here, so the
test does not depend on any third-party pcapng library). We assert:

  - File starts with a valid SHB
  - Followed by an IDB declaring Ethernet
  - Each EPB has correct length, captured/original lengths, padding
  - opt_comment options round-trip exactly (UTF-8, including non-ASCII)
  - Multiple frames in one file are individually retrievable
  - Rotation creates a new file at the configured size threshold
  - Snap-length truncates captured bytes but preserves original length
  - Concurrent writers from multiple threads don't corrupt the file
"""

from __future__ import annotations

import struct
import sys
import threading
import time
from pathlib import Path

import pytest

from n2nhu_policy.pcapng_writer import (
    BLOCK_TYPE_SHB, BLOCK_TYPE_IDB, BLOCK_TYPE_EPB,
    BYTE_ORDER_MAGIC, LINKTYPE_ETHERNET,
    OPT_COMMENT, OPT_END,
    PcapngWriter,
    encode_shb, encode_idb, encode_epb,
)


# ---------------------------------------------------------------------------
# Pure-Python parser used only for validation
# ---------------------------------------------------------------------------


_NATIVE = "<" if sys.byteorder == "little" else ">"


def _parse_options(buf: bytes) -> dict[int, list[bytes]]:
    """Parse a pcapng options blob into a {code: [value, ...]} dict.

    Returns empty dict if buf is empty. Stops at opt_endofopt.
    """
    out: dict[int, list[bytes]] = {}
    i = 0
    while i + 4 <= len(buf):
        code, length = struct.unpack(_NATIVE + "HH", buf[i : i + 4])
        i += 4
        if code == OPT_END and length == 0:
            break
        value = buf[i : i + length]
        # advance past the value, including padding to 4-byte boundary
        i += (length + 3) & ~3
        out.setdefault(code, []).append(value)
    return out


def _iter_blocks(data: bytes):
    """Yield (block_type, body_bytes, total_len) for each block in `data`."""
    i = 0
    while i + 8 <= len(data):
        block_type, total_len = struct.unpack(_NATIVE + "II", data[i : i + 8])
        if total_len < 12 or i + total_len > len(data):
            raise ValueError(
                f"corrupt pcapng: block at offset {i} declares total_len={total_len}"
            )
        body = data[i + 8 : i + total_len - 4]
        trailer = struct.unpack(_NATIVE + "I", data[i + total_len - 4 : i + total_len])[0]
        if trailer != total_len:
            raise ValueError(
                f"pcapng block trailer mismatch: header={total_len} trailer={trailer}"
            )
        yield block_type, body, total_len
        i += total_len


def parse_shb(body: bytes) -> dict:
    """Parse SHB body. Returns dict with byte_order_magic, version,
    section_length, options."""
    if len(body) < 16:
        raise ValueError("SHB body too short")
    bom, major, minor, sec_len = struct.unpack(_NATIVE + "IHHQ", body[:16])
    return {
        "byte_order_magic": bom,
        "version": (major, minor),
        "section_length": sec_len,
        "options": _parse_options(body[16:]),
    }


def parse_idb(body: bytes) -> dict:
    """Parse IDB body. Returns linktype, snap_len, options."""
    if len(body) < 8:
        raise ValueError("IDB body too short")
    linktype, _reserved, snap_len = struct.unpack(_NATIVE + "HHI", body[:8])
    return {
        "linktype": linktype,
        "snap_len": snap_len,
        "options": _parse_options(body[8:]),
    }


def parse_epb(body: bytes) -> dict:
    """Parse EPB body. Returns interface_id, timestamp_us, captured_len,
    original_len, captured_data, options."""
    if len(body) < 20:
        raise ValueError("EPB body too short")
    iface_id, ts_high, ts_low, captured_len, original_len = struct.unpack(
        _NATIVE + "IIIII", body[:20]
    )
    timestamp_us = (ts_high << 32) | ts_low
    captured_padded_len = (captured_len + 3) & ~3
    captured_data = body[20 : 20 + captured_len]
    options_offset = 20 + captured_padded_len
    options = _parse_options(body[options_offset:])
    return {
        "interface_id": iface_id,
        "timestamp_us": timestamp_us,
        "captured_len": captured_len,
        "original_len": original_len,
        "captured_data": captured_data,
        "options": options,
    }


def read_pcapng(path) -> tuple[dict, dict, list[dict]]:
    """Read a complete pcapng file, return (shb, idb, [epb, epb, ...])."""
    data = Path(path).read_bytes()
    shb = idb = None
    epbs = []
    for block_type, body, _total_len in _iter_blocks(data):
        if block_type == BLOCK_TYPE_SHB:
            shb = parse_shb(body)
        elif block_type == BLOCK_TYPE_IDB:
            idb = parse_idb(body)
        elif block_type == BLOCK_TYPE_EPB:
            epbs.append(parse_epb(body))
    return shb, idb, epbs


# ---------------------------------------------------------------------------
# Encoder-level tests
# ---------------------------------------------------------------------------


class TestBlockEncoding:
    """Test the encode_* functions in isolation, without touching files."""

    def test_shb_roundtrip(self):
        block = encode_shb()
        blocks = list(_iter_blocks(block))
        assert len(blocks) == 1
        bt, body, total_len = blocks[0]
        assert bt == BLOCK_TYPE_SHB
        assert total_len == len(block)
        shb = parse_shb(body)
        assert shb["byte_order_magic"] == BYTE_ORDER_MAGIC
        assert shb["version"] == (1, 0)
        # Section length -1 (unspecified) is the standard "unknown" sentinel
        assert shb["section_length"] == (1 << 64) - 1

    def test_idb_roundtrip_no_name(self):
        block = encode_idb(snap_len=1500)
        bt, body, _ = next(_iter_blocks(block))
        assert bt == BLOCK_TYPE_IDB
        idb = parse_idb(body)
        assert idb["linktype"] == LINKTYPE_ETHERNET
        assert idb["snap_len"] == 1500
        assert idb["options"] == {}

    def test_idb_with_interface_name(self):
        block = encode_idb(snap_len=65535, name="lan0")
        bt, body, _ = next(_iter_blocks(block))
        idb = parse_idb(body)
        assert b"lan0" in idb["options"][2]   # OPT_IF_NAME = 2

    def test_epb_basic_roundtrip(self):
        frame = b"\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\x08\x00" + b"X" * 50
        block = encode_epb(0, 1234567890123456, frame, len(frame))
        bt, body, _ = next(_iter_blocks(block))
        assert bt == BLOCK_TYPE_EPB
        epb = parse_epb(body)
        assert epb["interface_id"] == 0
        assert epb["timestamp_us"] == 1234567890123456
        assert epb["captured_len"] == len(frame)
        assert epb["original_len"] == len(frame)
        assert epb["captured_data"] == frame

    def test_epb_with_comment(self):
        frame = b"X" * 60
        block = encode_epb(0, 0, frame, len(frame),
                           comment="rule_id=p_lan_out decision=allow")
        bt, body, _ = next(_iter_blocks(block))
        epb = parse_epb(body)
        assert epb["options"][OPT_COMMENT][0] == \
            b"rule_id=p_lan_out decision=allow"

    def test_epb_comment_utf8(self):
        """Non-ASCII in a comment round-trips through utf-8 cleanly."""
        frame = b"\x00" * 64
        block = encode_epb(0, 0, frame, len(frame),
                           comment="règle=allow π=3.14159")
        bt, body, _ = next(_iter_blocks(block))
        epb = parse_epb(body)
        assert epb["options"][OPT_COMMENT][0].decode("utf-8") == \
            "règle=allow π=3.14159"

    def test_epb_padding_for_non_aligned_length(self):
        """A 7-byte frame must be padded to 8 bytes in the block but the
        captured_len header still says 7."""
        frame = b"\x01\x02\x03\x04\x05\x06\x07"  # 7 bytes
        block = encode_epb(0, 0, frame, 7)
        bt, body, total_len = next(_iter_blocks(block))
        # block_total_length must be a multiple of 4
        assert total_len % 4 == 0
        epb = parse_epb(body)
        assert epb["captured_len"] == 7
        assert epb["captured_data"] == frame


# ---------------------------------------------------------------------------
# File-writer tests
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_pcap(tmp_path):
    return tmp_path / "out.pcapng"


class TestPcapngWriter:

    def test_writes_shb_and_idb_on_open(self, tmp_pcap):
        w = PcapngWriter(tmp_pcap)
        w.close()
        shb, idb, epbs = read_pcapng(tmp_pcap)
        assert shb is not None
        assert idb is not None
        assert idb["linktype"] == LINKTYPE_ETHERNET
        assert epbs == []

    def test_writes_one_frame(self, tmp_pcap):
        frame = b"\xAA" * 80
        w = PcapngWriter(tmp_pcap)
        w.write_frame(frame, timestamp_us=10_000_000, comment="x=1")
        w.close()
        _shb, _idb, epbs = read_pcapng(tmp_pcap)
        assert len(epbs) == 1
        assert epbs[0]["captured_data"] == frame
        assert epbs[0]["timestamp_us"] == 10_000_000
        assert epbs[0]["options"][OPT_COMMENT][0] == b"x=1"

    def test_writes_multiple_frames(self, tmp_pcap):
        frames = [b"\x00" * 60, b"\x01" * 70, b"\x02" * 80]
        w = PcapngWriter(tmp_pcap)
        for i, f in enumerate(frames):
            w.write_frame(f, timestamp_us=i * 1_000_000, comment=f"i={i}")
        w.close()
        _shb, _idb, epbs = read_pcapng(tmp_pcap)
        assert len(epbs) == 3
        for i, epb in enumerate(epbs):
            assert epb["captured_data"] == frames[i]
            assert epb["options"][OPT_COMMENT][0] == f"i={i}".encode()

    def test_snap_len_truncates_but_preserves_original(self, tmp_pcap):
        frame = b"X" * 1500
        w = PcapngWriter(tmp_pcap, snap_len=200)
        w.write_frame(frame)
        w.close()
        _shb, _idb, epbs = read_pcapng(tmp_pcap)
        assert epbs[0]["captured_len"] == 200
        assert epbs[0]["original_len"] == 1500
        assert epbs[0]["captured_data"] == frame[:200]

    def test_byte_order_magic_correct(self, tmp_pcap):
        w = PcapngWriter(tmp_pcap)
        w.close()
        shb, _, _ = read_pcapng(tmp_pcap)
        assert shb["byte_order_magic"] == BYTE_ORDER_MAGIC

    def test_frame_count_property(self, tmp_pcap):
        w = PcapngWriter(tmp_pcap)
        w.write_frame(b"\x00" * 60)
        w.write_frame(b"\x00" * 60)
        w.write_frame(b"\x00" * 60)
        assert w.frames_written == 3
        w.close()

    def test_bytes_written_property_grows(self, tmp_pcap):
        w = PcapngWriter(tmp_pcap)
        before = w.bytes_written  # SHB + IDB only
        assert before > 0
        w.write_frame(b"\xFF" * 100)
        assert w.bytes_written > before
        w.close()

    def test_reopen_appends_does_not_redo_shb(self, tmp_pcap):
        w1 = PcapngWriter(tmp_pcap)
        w1.write_frame(b"A" * 60, timestamp_us=1, comment="a")
        w1.close()

        w2 = PcapngWriter(tmp_pcap)
        w2.write_frame(b"B" * 60, timestamp_us=2, comment="b")
        w2.close()

        # File should still parse correctly with one SHB and two EPBs
        shb, idb, epbs = read_pcapng(tmp_pcap)
        assert shb is not None
        assert idb is not None
        assert len(epbs) == 2
        assert epbs[0]["options"][OPT_COMMENT][0] == b"a"
        assert epbs[1]["options"][OPT_COMMENT][0] == b"b"

    def test_close_is_idempotent(self, tmp_pcap):
        w = PcapngWriter(tmp_pcap)
        w.close()
        w.close()  # must not raise

    def test_context_manager_closes(self, tmp_pcap):
        with PcapngWriter(tmp_pcap) as w:
            w.write_frame(b"\x00" * 60)
        # File must still be parseable after exit
        _shb, _idb, epbs = read_pcapng(tmp_pcap)
        assert len(epbs) == 1


class TestRotation:

    def test_rotation_at_size_threshold(self, tmp_pcap):
        """When bytes_written exceeds rotate_size_bytes, a new file
        is started and the old one is renamed with a timestamp suffix."""
        # Each frame is ~140 bytes (60 frame + EPB overhead ~80).
        # Rotate at 500 bytes — should rotate after a handful of frames.
        w = PcapngWriter(tmp_pcap, rotate_size_bytes=500)
        for _ in range(20):
            w.write_frame(b"\xAA" * 60, timestamp_us=int(time.time() * 1e6))
        w.close()

        # The primary file exists
        assert tmp_pcap.exists()
        # At least one rotated sibling exists
        siblings = list(tmp_pcap.parent.glob(f"{tmp_pcap.stem}.*{tmp_pcap.suffix}"))
        assert len(siblings) >= 1
        # All siblings parse successfully
        for s in siblings:
            shb, idb, epbs = read_pcapng(s)
            assert shb is not None
            assert idb is not None

    def test_rotation_keep_count(self, tmp_pcap):
        """rotate_keep limits how many rotated files survive."""
        w = PcapngWriter(
            tmp_pcap,
            rotate_size_bytes=300,
            rotate_keep=2,
        )
        for i in range(50):
            w.write_frame(b"\xAA" * 60,
                          timestamp_us=int(time.time() * 1e6) + i)
            time.sleep(0.001)  # ensure rotated filenames differ
        w.close()
        siblings = list(tmp_pcap.parent.glob(f"{tmp_pcap.stem}.*{tmp_pcap.suffix}"))
        assert len(siblings) <= 2, \
            f"rotate_keep=2 violated, found {len(siblings)} siblings"

    def test_no_rotation_when_disabled(self, tmp_pcap):
        """rotate_size_bytes=0 means never rotate, regardless of size."""
        w = PcapngWriter(tmp_pcap, rotate_size_bytes=0)
        for _ in range(50):
            w.write_frame(b"\xAA" * 200)
        w.close()
        siblings = list(tmp_pcap.parent.glob(f"{tmp_pcap.stem}.*{tmp_pcap.suffix}"))
        assert siblings == []
        # Primary file holds all 50 frames
        _shb, _idb, epbs = read_pcapng(tmp_pcap)
        assert len(epbs) == 50


class TestThreadSafety:

    def test_concurrent_writers_no_corruption(self, tmp_pcap):
        """N threads writing to the same writer must produce a file that
        parses cleanly with exactly N*M frames in it (in some order)."""
        w = PcapngWriter(tmp_pcap)
        N_THREADS = 8
        FRAMES_PER_THREAD = 25

        def worker(tid):
            for i in range(FRAMES_PER_THREAD):
                w.write_frame(
                    b"\xAB" * 80,
                    timestamp_us=tid * 1_000_000 + i,
                    comment=f"t={tid} i={i}",
                )

        threads = [threading.Thread(target=worker, args=(t,))
                   for t in range(N_THREADS)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        w.close()

        _shb, _idb, epbs = read_pcapng(tmp_pcap)
        assert len(epbs) == N_THREADS * FRAMES_PER_THREAD
        for epb in epbs:
            assert epb["captured_data"] == b"\xAB" * 80
            assert b"t=" in epb["options"][OPT_COMMENT][0]

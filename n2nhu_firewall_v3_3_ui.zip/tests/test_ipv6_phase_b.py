"""
Phase B tests — IPv6 frame codec.

Covers:
  - parse_frame_v6 on valid TCP/UDP/ICMPv6 frames
  - Rejection of too-short / wrong-ethertype / wrong-version frames
  - Checksum correctness for all three L4 protocols
  - Extension header chain walking (hop-by-hop, destination options, fragment)
  - Max-chain-length protection against malicious frames
  - Round-trip: build → parse → parse fields match
  - DNAT66 rewrite produces valid checksum
"""

from __future__ import annotations

import struct
from ipaddress import IPv6Address

import pytest

from n2nhu_policy.frame_codec_v6 import (
    ETH_P_IPV6, IP_PROTO_DSTOPTS, IP_PROTO_FRAGMENT, IP_PROTO_HOPOPT,
    IP_PROTO_ICMPV6, IP_PROTO_TCP, IP_PROTO_UDP,
    FrameParseErrorV6, ParsedFrameV6,
    build_icmpv6_frame, build_tcp_frame_v6, build_udp_frame_v6,
    compute_l4_checksum_v6, parse_frame_v6, rewrite_frame_dnat_v6,
)
from n2nhu_policy.models import Protocol


SRC = IPv6Address("2001:db8:1::100")
DST = IPv6Address("2001:db8:2::200")


class TestParseTCP:
    def test_parses_minimal_tcp_frame(self):
        frame = build_tcp_frame_v6(SRC, DST, 12345, 80)
        p = parse_frame_v6(frame)
        assert p.ip_version == 6
        assert p.src_ip == SRC
        assert p.dst_ip == DST
        assert p.l4_protocol == Protocol.TCP
        assert p.src_port == 12345
        assert p.dst_port == 80
        assert p.final_next_header == IP_PROTO_TCP
        assert p.extension_header_length == 0

    def test_parses_tcp_with_payload(self):
        payload = b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"
        frame = build_tcp_frame_v6(SRC, DST, 40000, 443, payload=payload)
        p = parse_frame_v6(frame)
        assert p.src_port == 40000
        assert p.dst_port == 443
        # Payload length = 20 TCP header + len(payload)
        assert p.payload_length == 20 + len(payload)

    def test_parses_traffic_class_and_dscp(self):
        frame = build_tcp_frame_v6(SRC, DST, 1, 2, traffic_class=0xB8)  # EF = 0xB8
        p = parse_frame_v6(frame)
        assert p.traffic_class == 0xB8
        # DSCP is top 6 bits
        assert (p.traffic_class >> 2) == 46  # EF


class TestParseUDP:
    def test_parses_minimal_udp(self):
        frame = build_udp_frame_v6(SRC, DST, 5000, 53, payload=b"\xde\xad" * 4)
        p = parse_frame_v6(frame)
        assert p.l4_protocol == Protocol.UDP
        assert p.src_port == 5000
        assert p.dst_port == 53

    def test_udp_checksum_nonzero(self):
        """UDP mandates non-zero checksum in IPv6 (RFC 8200 §8.1)."""
        frame = build_udp_frame_v6(SRC, DST, 1000, 2000)
        p = parse_frame_v6(frame)
        assert p.l4_checksum != 0


class TestParseICMPv6:
    def test_parses_echo_request(self):
        frame = build_icmpv6_frame(SRC, DST, icmp_type=128, payload=b"hello")
        p = parse_frame_v6(frame)
        assert p.icmpv6_type == 128
        assert p.final_next_header == IP_PROTO_ICMPV6

    def test_parses_neighbor_solicitation(self):
        frame = build_icmpv6_frame(SRC, DST, icmp_type=135)
        p = parse_frame_v6(frame)
        assert p.icmpv6_type == 135


class TestParseErrors:
    def test_too_short(self):
        with pytest.raises(FrameParseErrorV6):
            parse_frame_v6(b"\x00" * 30)

    def test_wrong_ethertype(self):
        # An IPv4 frame (0x0800) in the ethertype position
        frame = bytearray(100)
        frame[12:14] = struct.pack("!H", 0x0800)
        with pytest.raises(FrameParseErrorV6):
            parse_frame_v6(bytes(frame))

    def test_wrong_version(self):
        """IPv6 ethertype but version nibble says 4."""
        frame = bytearray(14 + 40 + 20)
        frame[12:14] = struct.pack("!H", ETH_P_IPV6)
        frame[14] = 0x40  # version = 4, wrong
        with pytest.raises(FrameParseErrorV6):
            parse_frame_v6(bytes(frame))

    def test_truncated_within_payload(self):
        """Header says payload is 100 bytes but frame only contains 20."""
        frame = bytearray(14 + 40 + 20)
        frame[12:14] = struct.pack("!H", ETH_P_IPV6)
        frame[14] = 0x60  # v6
        frame[14 + 4:14 + 6] = struct.pack("!H", 100)  # payload_length = 100
        frame[14 + 6] = IP_PROTO_TCP
        with pytest.raises(FrameParseErrorV6):
            parse_frame_v6(bytes(frame))


class TestChecksums:
    def test_tcp_checksum_validates(self):
        """A freshly built frame's parsed checksum should be the same
        value we computed when building it."""
        frame = build_tcp_frame_v6(SRC, DST, 1234, 5678, payload=b"hi")
        p = parse_frame_v6(frame)

        # Extract L4 payload with its checksum; zero the checksum field;
        # recompute; compare to what was stored.
        l4_start = p.l4_header_start
        l4_end = 14 + 40 + p.payload_length
        l4_payload = bytearray(frame[l4_start:l4_end])
        stored = struct.unpack("!H", l4_payload[16:18])[0]
        l4_payload[16:18] = b"\x00\x00"
        computed = compute_l4_checksum_v6(
            SRC, DST, IP_PROTO_TCP, bytes(l4_payload),
        )
        assert stored == computed

    def test_udp_checksum_validates(self):
        frame = build_udp_frame_v6(SRC, DST, 1000, 2000, payload=b"data")
        p = parse_frame_v6(frame)
        l4_start = p.l4_header_start
        l4_payload = bytearray(frame[l4_start:l4_start + p.payload_length])
        stored = struct.unpack("!H", l4_payload[6:8])[0]
        l4_payload[6:8] = b"\x00\x00"
        computed = compute_l4_checksum_v6(
            SRC, DST, IP_PROTO_UDP, bytes(l4_payload),
        )
        # UDP stores 0xFFFF when computed is 0
        expected = computed if computed != 0 else 0xFFFF
        assert stored == expected

    def test_icmpv6_checksum_validates(self):
        frame = build_icmpv6_frame(SRC, DST, 128, payload=b"ping-payload")
        p = parse_frame_v6(frame)
        l4_start = p.l4_header_start
        l4_payload = bytearray(frame[l4_start:l4_start + p.payload_length])
        stored = struct.unpack("!H", l4_payload[2:4])[0]
        l4_payload[2:4] = b"\x00\x00"
        computed = compute_l4_checksum_v6(
            SRC, DST, IP_PROTO_ICMPV6, bytes(l4_payload),
        )
        assert stored == computed


class TestExtensionHeaders:
    def _wrap_with_hbh_before_tcp(self, tcp_frame: bytes) -> bytes:
        """Insert a minimal 8-byte Hop-by-Hop header between IPv6 header
        and what was previously the first thing after the header.

        Correctly chains: the new HBH's next_header field points to whatever
        was previously the IPv6 fixed header's next_header (which might itself
        be another extension header from a previous wrap).
        """
        eth = tcp_frame[:14]
        ip = bytearray(tcp_frame[14:54])
        rest = tcp_frame[54:]
        previous_next = ip[6]  # whatever the fixed header previously pointed to
        # Build HBH: next_hdr=<previous>, hdr_ext_len=0 (means 8 bytes total),
        # 6 bytes of pad1/padn options
        hbh = struct.pack("!BB", previous_next, 0) + b"\x01\x04\x00\x00\x00\x00"
        # Update fixed header: next_header := HOPOPT, payload_length += 8
        ip[6] = IP_PROTO_HOPOPT
        new_payload_length = struct.unpack("!H", ip[4:6])[0] + len(hbh)
        ip[4:6] = struct.pack("!H", new_payload_length)
        return eth + bytes(ip) + hbh + rest

    def test_hop_by_hop_then_tcp(self):
        base = build_tcp_frame_v6(SRC, DST, 1, 2, payload=b"x")
        with_hbh = self._wrap_with_hbh_before_tcp(base)
        p = parse_frame_v6(with_hbh)
        assert p.first_next_header == IP_PROTO_HOPOPT
        assert p.final_next_header == IP_PROTO_TCP
        assert p.extension_header_length == 8
        assert p.l4_protocol == Protocol.TCP
        assert p.src_port == 1
        assert p.dst_port == 2

    def test_chain_too_long_rejected(self):
        """A deliberately nested chain of 10 hop-by-hop headers is rejected
        as paranoid defense against crafted frames."""
        base = build_tcp_frame_v6(SRC, DST, 1, 2)
        frame = base
        # Each wrap adds 8 bytes of extension; do it 10 times
        for _ in range(10):
            frame = self._wrap_with_hbh_before_tcp(frame)
        with pytest.raises(FrameParseErrorV6):
            parse_frame_v6(frame)


class TestDNAT66Rewrite:
    def test_rewrites_dst_ip_and_port(self):
        original = build_tcp_frame_v6(SRC, DST, 40000, 443, payload=b"hello")
        p = parse_frame_v6(original)

        NEW_DST = IPv6Address("2001:db8:99::1")
        rewritten = rewrite_frame_dnat_v6(p, NEW_DST, 8443)
        p2 = parse_frame_v6(rewritten)

        assert p2.dst_ip == NEW_DST
        assert p2.dst_port == 8443
        # Source unchanged
        assert p2.src_ip == SRC
        assert p2.src_port == 40000

    def test_rewritten_checksum_valid(self):
        """After rewrite, the new frame's checksum must validate against
        the new pseudo-header."""
        original = build_tcp_frame_v6(SRC, DST, 40000, 443, payload=b"hello")
        p = parse_frame_v6(original)

        NEW_DST = IPv6Address("2001:db8:99::1")
        rewritten = rewrite_frame_dnat_v6(p, NEW_DST, 8443)
        p2 = parse_frame_v6(rewritten)

        # Extract L4 bytes, zero the stored checksum, recompute,
        # compare to what's stored.
        l4_start = p2.l4_header_start
        l4_end = 14 + 40 + p2.payload_length
        l4_payload = bytearray(rewritten[l4_start:l4_end])
        stored = struct.unpack("!H", l4_payload[16:18])[0]
        l4_payload[16:18] = b"\x00\x00"
        computed = compute_l4_checksum_v6(
            SRC, NEW_DST, IP_PROTO_TCP, bytes(l4_payload),
        )
        assert stored == computed

    def test_rewrite_udp(self):
        original = build_udp_frame_v6(SRC, DST, 5353, 53, payload=b"query")
        p = parse_frame_v6(original)
        NEW_DST = IPv6Address("2001:db8:99::53")
        rewritten = rewrite_frame_dnat_v6(p, NEW_DST, 5353)
        p2 = parse_frame_v6(rewritten)
        assert p2.dst_ip == NEW_DST
        assert p2.dst_port == 5353

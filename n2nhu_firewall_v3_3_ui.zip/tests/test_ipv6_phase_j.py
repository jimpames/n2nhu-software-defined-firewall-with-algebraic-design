"""
Phase J tests — native v6 forwarding (no NAT64).

Covers:
  - Pure v6→v6 forwarding when interface_networks_v6 is configured.
  - Frame is forwarded byte-identical (no rewrite, no checksum touch).
  - v6 route lookup uses longest-prefix match.
  - Policy evaluation applies (deny works, allow works).
  - PBR can override v6 egress based on DSCP.
  - Backward compatibility: when interface_networks_v6 is None/empty,
    behavior matches the legacy v1 drop with "no NAT64 rule" reason.
  - The native-v6 path does not interfere with NAT64 (a NAT64 rule still
    matches first when both exist).
  - Family strictness: a v4 address-object rule does not match v6 packets.
"""

from __future__ import annotations

import tempfile
from ipaddress import IPv4Address, IPv4Network, IPv6Address, IPv6Network
from pathlib import Path

import pytest

from n2nhu_policy.frame_codec_v6 import (
    build_tcp_frame_v6, build_udp_frame_v6, parse_frame_v6,
)
from n2nhu_policy.router_shim import ForwardAction, RouterShim


# Fixed addresses for clarity
LAN_V6_CLIENT = IPv6Address("2001:db8:1::100")
DMZ_V6_HOST = IPv6Address("2001:db8:2::200")
INTERNET_V6 = IPv6Address("2001:db8:9999::1")
WAN_V6_OUT = IPv6Address("2001:db8:cafe::1")


# ---------------------------------------------------------------------------
# Fixture — multi-iface dual-stack tree
# ---------------------------------------------------------------------------


@pytest.fixture
def v6_tree():
    """Config tree with v6 zones, v6 address objects, and an allow-from-LAN
    policy. No NAT64 rule — pure v6 forwarding only."""
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "objects").mkdir()
        (root / "policies").mkdir()

        (root / "zones.ini").write_text(
            "[zones]\n"
            "trusted = lan\n"
            "dmz = dmz\n"
            "untrusted = wan1\n"
            "\n[defaults]\n"
            "default_any_to_any = DENY\n"
        )
        (root / "objects" / "addresses.ini").write_text(
            "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
            "\n[addr_any_v6]\ntype = network\nvalue = ::/0\n"
            "\n[addr_lan_v6]\ntype = network\nvalue = 2001:db8:1::/64\n"
            "\n[addr_dmz_v6]\ntype = network\nvalue = 2001:db8:2::/64\n"
            "\n[addr_internet_v6]\ntype = network\nvalue = 2001:db8:9999::/64\n"
        )
        (root / "objects" / "services.ini").write_text(
            "[svc_any]\nprotocol = any\n"
        )
        (root / "objects" / "schedules.ini").write_text(
            "[sched_always]\ntype = always\n"
        )
        (root / "policies" / "security.ini").write_text(
            "[policy_order]\nrules = p_lan_v6_out\n"
            "\n[p_lan_v6_out]\n"
            "src_zone = trusted\ndst_zone = any\n"
            "src_addr = addr_lan_v6\ndst_addr = addr_any_v6\n"
            "service = svc_any\nschedule = sched_always\n"
            "action = ALLOW\n"
        )
        # No nat.ini — NAT is optional. Phase J tests pure v6 forwarding.
        yield root


@pytest.fixture
def v6_shim(v6_tree):
    """Shim with both v4 and v6 routes configured."""
    return RouterShim(
        config_root=v6_tree,
        interface_ips={
            "lan": IPv4Address("192.168.1.1"),
            "dmz": IPv4Address("172.16.1.1"),
            "wan1": IPv4Address("198.51.100.1"),
        },
        interface_networks={
            "lan": IPv4Network("192.168.1.0/24"),
            "dmz": IPv4Network("172.16.1.0/24"),
            "wan1": IPv4Network("0.0.0.0/0"),
        },
        interface_networks_v6={
            "lan": IPv6Network("2001:db8:1::/64"),
            "dmz": IPv6Network("2001:db8:2::/64"),
            "wan1": IPv6Network("::/0"),  # default v6 route
        },
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestNativeV6Forwarding:

    def test_v6_forwarded_to_correct_iface_lan_to_dmz(self, v6_shim):
        """A v6 frame from LAN to DMZ goes out the DMZ iface."""
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, DMZ_V6_HOST,
            src_port=40000, dst_port=80,
            payload=b"GET / HTTP/1.0\r\n\r\n",
        )
        decision = v6_shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD, \
            f"expected FORWARD, got {decision.action} ({decision.drop_reason})"
        assert decision.egress_iface == "dmz"

    def test_v6_forwarded_to_default_route_for_internet_destination(self, v6_shim):
        """A v6 frame to a non-local v6 prefix uses the wan1 default route."""
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, INTERNET_V6,
            src_port=40000, dst_port=443,
        )
        decision = v6_shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        assert decision.egress_iface == "wan1"

    def test_v6_frame_forwarded_byte_identical(self, v6_shim):
        """Native v6 forwarding does NOT rewrite the frame — output bytes
        equal input bytes."""
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, DMZ_V6_HOST,
            src_port=40000, dst_port=80,
            payload=b"X" * 100,
        )
        decision = v6_shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        assert decision.frame == frame

    def test_v6_forwarded_native_counter_increments(self, v6_shim):
        """The native-v6 forward path uses its own counter."""
        before = v6_shim._stats["v6_forwarded_native"]
        frame = build_tcp_frame_v6(LAN_V6_CLIENT, DMZ_V6_HOST, 1, 2)
        v6_shim.process_frame("lan", frame)
        assert v6_shim._stats["v6_forwarded_native"] == before + 1

    def test_v6_route_lookup_longest_prefix(self, v6_shim):
        """Direct route_lookup_v6 honors longest-prefix match."""
        assert v6_shim.route_lookup_v6(LAN_V6_CLIENT) == "lan"
        assert v6_shim.route_lookup_v6(DMZ_V6_HOST) == "dmz"
        assert v6_shim.route_lookup_v6(INTERNET_V6) == "wan1"

    def test_v6_policy_can_deny(self, v6_tree):
        """A policy that denies a specific v6 flow should drop it."""
        # Override the security policy to deny everything by default
        (v6_tree / "policies" / "security.ini").write_text(
            "[policy_order]\nrules = p_deny_all\n"
            "\n[p_deny_all]\n"
            "src_zone = any\ndst_zone = any\n"
            "src_addr = addr_any_v6\ndst_addr = addr_any_v6\n"
            "service = svc_any\nschedule = sched_always\n"
            "action = DENY\n"
        )
        shim = RouterShim(
            config_root=v6_tree,
            interface_ips={
                "lan": IPv4Address("192.168.1.1"),
                "dmz": IPv4Address("172.16.1.1"),
                "wan1": IPv4Address("198.51.100.1"),
            },
            interface_networks={
                "lan": IPv4Network("192.168.1.0/24"),
                "wan1": IPv4Network("0.0.0.0/0"),
            },
            interface_networks_v6={
                "lan": IPv6Network("2001:db8:1::/64"),
                "dmz": IPv6Network("2001:db8:2::/64"),
                "wan1": IPv6Network("::/0"),
            },
        )

        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, DMZ_V6_HOST,
            src_port=40000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        assert "policy" in decision.drop_reason.lower()
        assert shim._stats["v6_policy_denies"] >= 1

    def test_legacy_no_v6_routes_drops_with_no_nat64_rule_message(self, v6_tree):
        """If no interface_networks_v6 is configured, the legacy v1 drop
        message ('no NAT64 rule') is preserved for backward compatibility."""
        shim = RouterShim(
            config_root=v6_tree,
            interface_ips={
                "lan": IPv4Address("192.168.1.1"),
                "wan1": IPv4Address("198.51.100.1"),
            },
            interface_networks={
                "lan": IPv4Network("192.168.1.0/24"),
                "wan1": IPv4Network("0.0.0.0/0"),
            },
            # No interface_networks_v6
        )
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, IPv6Address("2001:db8:9999::1"),
            src_port=40000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        assert "no NAT64 rule" in decision.drop_reason
        # Counter still increments for the legacy case
        assert shim._stats["v6_no_nat64_rule"] >= 1

    def test_v6_no_route_counter_when_routes_exist_but_no_match(self, v6_tree):
        """If v6 routes exist but the dst doesn't match any of them,
        the v6_no_route counter increments and the message says 'no v6 route'."""
        shim = RouterShim(
            config_root=v6_tree,
            interface_ips={
                "lan": IPv4Address("192.168.1.1"),
            },
            interface_networks={
                "lan": IPv4Network("192.168.1.0/24"),
            },
            interface_networks_v6={
                "lan": IPv6Network("2001:db8:1::/64"),
                # No default route — destinations outside 2001:db8:1::/64 won't match
            },
        )
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, IPv6Address("2001:db8:9999::1"),
            src_port=40000, dst_port=80,
        )
        decision = shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.DROP
        assert "no v6 route" in decision.drop_reason
        assert shim._stats["v6_no_route"] >= 1

    def test_v6_udp_forwarded_natively(self, v6_shim):
        """Native v6 forwarding works for UDP."""
        frame = build_udp_frame_v6(
            LAN_V6_CLIENT, DMZ_V6_HOST,
            src_port=53000, dst_port=53,
            payload=b"\x00" * 30,
        )
        decision = v6_shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        assert decision.egress_iface == "dmz"
        assert decision.frame == frame

    def test_v6_native_forward_records_policy_rule_id(self, v6_shim):
        """The decision carries the matched policy rule_id for audit."""
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, DMZ_V6_HOST,
            src_port=40000, dst_port=80,
        )
        decision = v6_shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        assert decision.policy_rule_id == "p_lan_v6_out"

    def test_v4_path_unaffected_by_v6_routes(self, v6_shim):
        """Adding v6 routes must not perturb v4 forwarding."""
        from n2nhu_policy.frame_codec import build_tcp_frame
        v4 = build_tcp_frame(
            src_ip=IPv4Address("192.168.1.50"),
            dst_ip=IPv4Address("172.16.1.10"),
            src_port=40000, dst_port=80,
        )
        decision = v6_shim.process_frame("lan", v4)
        # v4 path runs as before — exact action depends on the v4 default
        # zone defaults (deny here), but the path itself must not error.
        assert decision.action in (ForwardAction.FORWARD, ForwardAction.DROP)
        # Most importantly: not a parse error
        assert decision.action != ForwardAction.PARSE_ERROR

    def test_v6_traffic_class_dscp_extracted(self, v6_shim):
        """DSCP from the v6 traffic_class field reaches the engines."""
        # Build a v6 frame with non-zero traffic class (dscp=46 = EF)
        frame = build_tcp_frame_v6(
            LAN_V6_CLIENT, DMZ_V6_HOST,
            src_port=40000, dst_port=5060,
            traffic_class=(46 << 2),  # EF DSCP
        )
        decision = v6_shim.process_frame("lan", frame)
        assert decision.action == ForwardAction.FORWARD
        # We're not asserting any DSCP-specific behavior here — just that
        # the path didn't crash on a non-zero TC byte. PBR-with-v6-DSCP
        # gets its own test below.

    def test_reload_preserves_v6_routes(self, v6_shim):
        """reload() builds a fresh shim — v6 routes must survive."""
        new_shim = v6_shim.reload()
        assert new_shim.route_lookup_v6(LAN_V6_CLIENT) == "lan"
        assert new_shim.route_lookup_v6(DMZ_V6_HOST) == "dmz"
        assert new_shim.route_lookup_v6(INTERNET_V6) == "wan1"


class TestNativeV6Stats:
    """Counter wiring for the native-v6 path."""

    def test_v6_forward_stats_distinct_from_nat64(self, v6_shim):
        """Native v6 forward increments v6_forwarded_native, NOT
        nat64_v6_to_v4."""
        frame = build_tcp_frame_v6(LAN_V6_CLIENT, DMZ_V6_HOST, 1, 2)
        v6_shim.process_frame("lan", frame)
        assert v6_shim._stats["v6_forwarded_native"] == 1
        assert v6_shim._stats["nat64_v6_to_v4"] == 0
        assert v6_shim._stats["frames_forwarded"] == 1

    def test_v6_in_counter_still_increments(self, v6_shim):
        """frames_in_v6 increments for native-v6 forward as for NAT64."""
        frame = build_tcp_frame_v6(LAN_V6_CLIENT, DMZ_V6_HOST, 1, 2)
        v6_shim.process_frame("lan", frame)
        assert v6_shim._stats["frames_in_v6"] == 1

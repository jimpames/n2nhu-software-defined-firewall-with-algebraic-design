"""
Phase W tests — adding, deleting, and reordering template instances.

The form_helpers module gained three new functions:
  add_template_instance(schema, pattern, instance_id, config_root) -> str
  delete_template_instance(schema, instance_real_name, config_root) -> str
  reorder_template_instances(schema, pattern, new_order, config_root) -> str

These produce new INI text from the live config tree, ready for the
existing preview/commit pipeline.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from n2nhu_ui.form_helpers import (
    InstanceError,
    add_template_instance,
    delete_template_instance,
    reorder_template_instances,
)
from n2nhu_ui.schema_loader import SchemaLoader


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def registry():
    return SchemaLoader(Path("n2nhu_ui/schemas")).load_registry()


@pytest.fixture
def config_root(tmp_path):
    """Materialize a config tree from the schema defaults so we have
    something to read."""
    src = Path("n2nhu_ui/schemas/defaults")
    root = tmp_path / "config"
    root.mkdir()
    (root / "objects").mkdir()
    (root / "policies").mkdir()
    # Copy each default file to the right relative path
    for default in src.glob("*.ini"):
        # Look up where it goes from the schema's filename
        if default.name in ("zones.ini", "addresses.ini", "services.ini",
                            "schedules.ini"):
            if default.name == "zones.ini":
                shutil.copy(default, root / "zones.ini")
            else:
                shutil.copy(default, root / "objects" / default.name)
        else:
            shutil.copy(default, root / "policies" / default.name)
    return root


# ---------------------------------------------------------------------------
# add_template_instance
# ---------------------------------------------------------------------------


class TestAddInstance:

    def test_add_to_empty_template_section(self, registry, config_root):
        schema = registry.by_name("capture")
        text = add_template_instance(
            schema, pattern="cap*", instance_id="cap_lan_egress",
            config_root=config_root,
        )
        assert "[cap_lan_egress]" in text
        # Default fields populated where defaults exist
        assert "match_action" in text   # default = any

    def test_added_instance_appears_in_order_field(self, registry, config_root):
        schema = registry.by_name("capture")
        text = add_template_instance(
            schema, pattern="cap*", instance_id="cap_test",
            config_root=config_root,
        )
        # Find the rules = line and check our new ID is on it
        for line in text.split("\n"):
            if line.strip().startswith("rules"):
                assert "cap_test" in line
                break
        else:
            pytest.fail("no rules = line found in output")

    def test_id_can_be_full_or_partial(self, registry, config_root):
        schema = registry.by_name("capture")
        # Pattern is cap* with prefix cap, so user can supply 'lan' or 'cap_lan'
        text1 = add_template_instance(
            schema, "cap*", "lan", config_root=config_root,
        )
        # Should produce [caplan]
        assert "[caplan]" in text1

    def test_duplicate_id_rejected(self, registry, config_root):
        schema = registry.by_name("capture")
        # First add succeeds
        first = add_template_instance(
            schema, "cap*", "cap_demo", config_root=config_root,
        )
        # Persist that file so a second add sees it
        (config_root / "policies" / "capture.ini").write_text(first)
        # Second add of the same id must fail
        with pytest.raises(InstanceError, match="already exists"):
            add_template_instance(
                schema, "cap*", "cap_demo", config_root=config_root,
            )

    def test_invalid_id_chars_rejected(self, registry, config_root):
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="invalid characters"):
            add_template_instance(
                schema, "cap*", "bad name", config_root=config_root,
            )

    def test_empty_id_rejected(self, registry, config_root):
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="empty"):
            add_template_instance(
                schema, "cap*", "", config_root=config_root,
            )

    def test_non_template_pattern_rejected(self, registry, config_root):
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="not a template"):
            add_template_instance(
                schema, "capture_order", "x", config_root=config_root,
            )

    def test_unknown_pattern_rejected(self, registry, config_root):
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="unknown section pattern"):
            add_template_instance(
                schema, "imaginary_*", "x", config_root=config_root,
            )

    def test_ipsec_proposal_template_works(self, registry, config_root):
        schema = registry.by_name("ipsec")
        text = add_template_instance(
            schema, "ipsec_proposal_*", "ipsec_proposal_default",
            config_root=config_root,
        )
        assert "[ipsec_proposal_default]" in text

    def test_ipsec_tunnel_added_to_tunnels_order(self, registry, config_root):
        schema = registry.by_name("ipsec")
        text = add_template_instance(
            schema, "ipsec_tunnel_*", "ipsec_tunnel_branch1",
            config_root=config_root,
        )
        # The order field is `tunnels`, not `rules`
        for line in text.split("\n"):
            if line.strip().startswith("tunnels"):
                assert "ipsec_tunnel_branch1" in line
                break
        else:
            pytest.fail("no tunnels = line found")

    def test_proposal_added_when_no_order_for_proposals(
        self, registry, config_root,
    ):
        """ipsec_proposal_* doesn't have an order field of its own;
        adding a proposal should NOT touch the [ipsec_order] tunnels list."""
        schema = registry.by_name("ipsec")
        text = add_template_instance(
            schema, "ipsec_proposal_*", "ipsec_proposal_default",
            config_root=config_root,
        )
        # Section was created
        assert "[ipsec_proposal_default]" in text
        # tunnels = line is still empty (no proposals leaked into it)
        for line in text.split("\n"):
            if line.strip().startswith("tunnels"):
                assert "ipsec_proposal_default" not in line
                break


# ---------------------------------------------------------------------------
# delete_template_instance
# ---------------------------------------------------------------------------


class TestDeleteInstance:

    def test_delete_existing_instance(self, registry, config_root):
        schema = registry.by_name("capture")
        # Set up: add an instance and persist
        text = add_template_instance(
            schema, "cap*", "cap_to_delete", config_root=config_root,
        )
        (config_root / "policies" / "capture.ini").write_text(text)
        # Now delete it
        new_text = delete_template_instance(
            schema, "cap_to_delete", config_root=config_root,
        )
        assert "[cap_to_delete]" not in new_text

    def test_deleted_id_removed_from_order(self, registry, config_root):
        schema = registry.by_name("capture")
        text = add_template_instance(
            schema, "cap*", "cap_x", config_root=config_root,
        )
        (config_root / "policies" / "capture.ini").write_text(text)
        new_text = delete_template_instance(
            schema, "cap_x", config_root=config_root,
        )
        for line in new_text.split("\n"):
            if line.strip().startswith("rules"):
                assert "cap_x" not in line
                break

    def test_delete_nonexistent_raises(self, registry, config_root):
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="does not exist"):
            delete_template_instance(
                schema, "cap_imaginary", config_root=config_root,
            )

    def test_cannot_delete_fixed_section(self, registry, config_root):
        """[capture_order] is FIXED, not a template instance."""
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="not a template"):
            delete_template_instance(
                schema, "capture_order", config_root=config_root,
            )


# ---------------------------------------------------------------------------
# reorder_template_instances
# ---------------------------------------------------------------------------


class TestReorderInstances:

    def test_reorder_two_rules(self, registry, config_root):
        schema = registry.by_name("capture")
        # Add two
        text = add_template_instance(
            schema, "cap*", "cap_alpha", config_root=config_root,
        )
        (config_root / "policies" / "capture.ini").write_text(text)
        text = add_template_instance(
            schema, "cap*", "cap_beta", config_root=config_root,
        )
        (config_root / "policies" / "capture.ini").write_text(text)

        # Reorder beta before alpha
        new_text = reorder_template_instances(
            schema, "cap*",
            new_order=["cap_beta", "cap_alpha"],
            config_root=config_root,
        )
        for line in new_text.split("\n"):
            if line.strip().startswith("rules"):
                # cap_beta should appear first, cap_alpha second
                a = line.find("cap_alpha")
                b = line.find("cap_beta")
                assert b < a, f"order incorrect: {line}"
                break

    def test_unknown_id_in_new_order_rejected(self, registry, config_root):
        schema = registry.by_name("capture")
        with pytest.raises(InstanceError, match="unknown"):
            reorder_template_instances(
                schema, "cap*",
                new_order=["cap_imaginary"],
                config_root=config_root,
            )

    def test_id_matching_wrong_template_rejected(self, registry, config_root):
        """An ID that doesn't exist in the file is rejected."""
        schema = registry.by_name("capture")
        # Add a cap rule
        text = add_template_instance(
            schema, "cap*", "cap_x", config_root=config_root,
        )
        (config_root / "policies" / "capture.ini").write_text(text)
        # Reorder with a name that's not in the file
        with pytest.raises(InstanceError, match="unknown"):
            reorder_template_instances(
                schema, "cap*",
                new_order=["does_not_exist_section"],
                config_root=config_root,
            )

    def test_schema_without_order_rejects_reorder(self, registry, config_root):
        """Some schemas have no *_order field. Calling reorder on them
        should fail loud."""
        schema = registry.by_name("addresses")  # no order list
        with pytest.raises(InstanceError, match="no order field"):
            reorder_template_instances(
                schema, "addr_*",
                new_order=[],
                config_root=config_root,
            )

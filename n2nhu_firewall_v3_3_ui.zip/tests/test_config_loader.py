"""Tests for ConfigLoader — parsing, validation, error paths."""

from __future__ import annotations

import pytest

from n2nhu_policy import Action, ConfigError, ConfigLoader
from n2nhu_policy.models import AddressType, Protocol, ScheduleType


class TestValidFixtures:
    def test_all_zones_loaded(self, loaded_config):
        assert set(loaded_config.zones.keys()) == {
            "trusted", "untrusted", "dmz", "guest", "mgt",
        }

    def test_zone_attributes(self, loaded_config):
        trusted = loaded_config.zones["trusted"]
        assert trusted.security_level == 100
        assert "Internal" in trusted.description

        mgt = loaded_config.zones["mgt"]
        assert mgt.mgt_plane is True
        assert mgt.security_level == 100

    def test_interface_mapping(self, loaded_config):
        assert loaded_config.interface_to_zone["lan"] == "trusted"
        assert loaded_config.interface_to_zone["wifi_corp"] == "trusted"
        assert loaded_config.interface_to_zone["wan1"] == "untrusted"
        assert loaded_config.interface_to_zone["wan2"] == "untrusted"
        assert loaded_config.interface_to_zone["mgt"] == "mgt"

    def test_defaults_matrix(self, loaded_config):
        d = loaded_config.defaults
        assert d[("trusted", "untrusted")] == Action.ALLOW
        assert d[("untrusted", "trusted")] == Action.DENY
        assert d[("any", "mgt")] == Action.DENY
        assert d[("any", "any")] == Action.DENY

    def test_address_types(self, loaded_config):
        a = loaded_config.addresses
        assert a["addr_dmz_webserver"].type == AddressType.HOST
        assert a["addr_lan_net"].type == AddressType.NETWORK
        assert a["addr_range_lab"].type == AddressType.RANGE
        assert a["addrgrp_internal"].type == AddressType.GROUP

    def test_address_host_value(self, loaded_config):
        assert str(loaded_config.addresses["addr_dmz_webserver"].host) == "172.16.0.10"

    def test_address_network_value(self, loaded_config):
        assert str(loaded_config.addresses["addr_lan_net"].network) == "192.168.1.0/24"

    def test_address_range_value(self, loaded_config):
        r = loaded_config.addresses["addr_range_lab"]
        assert str(r.range_start) == "192.168.1.100"
        assert str(r.range_end) == "192.168.1.200"

    def test_address_group_members(self, loaded_config):
        grp = loaded_config.addresses["addrgrp_internal"]
        assert grp.members == ("addr_lan_net", "addrgrp_rfc1918")

    def test_service_leaf(self, loaded_config):
        http = loaded_config.services["svc_http"]
        assert http.protocol == Protocol.TCP
        assert http.dst_port.start == 80 and http.dst_port.end == 80
        assert http.is_group is False

    def test_service_port_range(self, loaded_config):
        rng = loaded_config.services["svc_app_range"]
        assert rng.dst_port.start == 8080
        assert rng.dst_port.end == 8090

    def test_service_group(self, loaded_config):
        web = loaded_config.services["svcgrp_web"]
        assert web.is_group is True
        assert web.members == ("svc_http", "svc_https")

    def test_service_icmp(self, loaded_config):
        ping = loaded_config.services["svc_icmp_ping"]
        assert ping.protocol == Protocol.ICMP
        assert ping.icmp_type == 8

    def test_schedule_always(self, loaded_config):
        s = loaded_config.schedules["sched_always"]
        assert s.type == ScheduleType.ALWAYS

    def test_schedule_recurring(self, loaded_config):
        s = loaded_config.schedules["sched_business_hours"]
        assert s.type == ScheduleType.RECURRING
        # Mon-Fri = 0..4
        assert s.days == (0, 1, 2, 3, 4)
        assert s.start_time == "08:00"
        assert s.end_time == "18:00"
        assert s.timezone == "America/New_York"

    def test_schedule_one_time(self, loaded_config):
        s = loaded_config.schedules["sched_maintenance_window"]
        assert s.type == ScheduleType.ONE_TIME
        assert "2026-04-20" in s.start_datetime

    def test_policies_ordered(self, loaded_config):
        ids = [p.id for p in loaded_config.policies]
        assert ids == [
            "p010_block_malware",
            "p020_admin_ssh",
            "p025_lan_sip",
            "p030_lan_web",
            "p040_dmz_web_in",
            "p050_guest_internet",
            "p060_block_guest_internal",
            "p099_implicit_deny",
        ]

    def test_policy_attributes(self, loaded_config):
        p = next(r for r in loaded_config.policies if r.id == "p020_admin_ssh")
        assert p.src_zone == "trusted"
        assert p.dst_zone == "dmz"
        assert p.src_addr == "addr_admin_workstation"
        assert p.dst_addr == "addr_dmz_webserver"
        assert p.service == "svc_ssh"
        assert p.schedule == "sched_business_hours"
        assert p.action == Action.ALLOW
        assert p.log is True


class TestMissingFiles:
    def test_missing_zones_ini(self, tmp_path):
        (tmp_path / "objects").mkdir()
        (tmp_path / "policies").mkdir()
        with pytest.raises(ConfigError, match="missing file"):
            ConfigLoader(tmp_path).load()

    def test_missing_addresses_ini(self, tmp_config_tree):
        (tmp_config_tree / "objects" / "addresses.ini").unlink()
        with pytest.raises(ConfigError, match="missing file"):
            ConfigLoader(tmp_config_tree).load()


class TestUnknownKeys:
    def test_unknown_zone_key_rejected(self, tmp_config_tree):
        path = tmp_config_tree / "zones.ini"
        content = path.read_text().replace(
            "[zone_trusted]\nsecurity_level = 100",
            "[zone_trusted]\nsecurity_level = 100\nbogus_key = 1",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="unknown keys"):
            ConfigLoader(tmp_config_tree).load()

    def test_unknown_policy_key_rejected(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "[p099_implicit_deny]",
            "[p099_implicit_deny]\ntypo_key = yes",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="unknown keys"):
            ConfigLoader(tmp_config_tree).load()


class TestBadValues:
    def test_bad_ip_address(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "addresses.ini"
        bad = "\n[addr_bogus]\ntype = host\nvalue = not.an.ip.addr\n"
        path.write_text(path.read_text() + bad)
        with pytest.raises(ConfigError):
            ConfigLoader(tmp_config_tree).load()

    def test_bad_network_cidr(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "addresses.ini"
        path.write_text(path.read_text() + "\n[addr_bad]\ntype = network\nvalue = 999.999.0.0/16\n")
        with pytest.raises(ConfigError):
            ConfigLoader(tmp_config_tree).load()

    def test_range_start_after_end(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "addresses.ini"
        path.write_text(
            path.read_text()
            + "\n[addr_bad]\ntype = range\nvalue = 192.168.1.200-192.168.1.100\n"
        )
        with pytest.raises(ConfigError, match="start > end"):
            ConfigLoader(tmp_config_tree).load()

    def test_port_out_of_range(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "services.ini"
        path.write_text(
            path.read_text()
            + "\n[svc_bad]\nprotocol = tcp\ndst_port = 99999\n"
        )
        with pytest.raises(ConfigError, match="out of range"):
            ConfigLoader(tmp_config_tree).load()

    def test_port_range_reversed(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "services.ini"
        path.write_text(
            path.read_text()
            + "\n[svc_bad]\nprotocol = tcp\ndst_port = 100-50\n"
        )
        with pytest.raises(ConfigError, match="start > end"):
            ConfigLoader(tmp_config_tree).load()

    def test_icmp_type_on_tcp_rejected(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "services.ini"
        path.write_text(
            path.read_text()
            + "\n[svc_bad]\nprotocol = tcp\nicmp_type = 8\n"
        )
        with pytest.raises(ConfigError, match="icmp_type"):
            ConfigLoader(tmp_config_tree).load()

    def test_dst_port_on_icmp_rejected(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "services.ini"
        path.write_text(
            path.read_text()
            + "\n[svc_bad]\nprotocol = icmp\ndst_port = 80\n"
        )
        with pytest.raises(ConfigError, match="dst_port"):
            ConfigLoader(tmp_config_tree).load()

    def test_bad_hhmm_in_schedule(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "schedules.ini"
        path.write_text(
            path.read_text()
            + "\n[sched_bad]\ntype = recurring\ndays = mon\nstart = 25:00\nend = 26:00\n"
        )
        with pytest.raises(ConfigError, match="out of range"):
            ConfigLoader(tmp_config_tree).load()

    def test_bad_weekday(self, tmp_config_tree):
        path = tmp_config_tree / "objects" / "schedules.ini"
        path.write_text(
            path.read_text()
            + "\n[sched_bad]\ntype = recurring\ndays = funday\nstart = 08:00\nend = 18:00\n"
        )
        with pytest.raises(ConfigError, match="unknown day"):
            ConfigLoader(tmp_config_tree).load()


class TestPolicyValidation:
    def test_undefined_zone_in_rule(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "[p020_admin_ssh]\nsrc_zone = trusted",
            "[p020_admin_ssh]\nsrc_zone = nonexistent_zone",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not declared"):
            ConfigLoader(tmp_config_tree).load()

    def test_undefined_address_in_rule(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "src_addr = addr_admin_workstation",
            "src_addr = addr_does_not_exist",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not defined"):
            ConfigLoader(tmp_config_tree).load()

    def test_undefined_service_in_rule(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "service  = svc_ssh",
            "service  = svc_not_real",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not defined"):
            ConfigLoader(tmp_config_tree).load()

    def test_undefined_schedule_in_rule(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "schedule = sched_business_hours",
            "schedule = sched_does_not_exist",
            1,
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="not defined"):
            ConfigLoader(tmp_config_tree).load()

    def test_policy_order_references_missing_rule(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "p020_admin_ssh,",
            "p020_admin_ssh,\n        p_does_not_exist,",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="undefined rules"):
            ConfigLoader(tmp_config_tree).load()

    def test_invalid_action_value(self, tmp_config_tree):
        path = tmp_config_tree / "policies" / "security.ini"
        content = path.read_text().replace(
            "action   = DENY\nlog      = true\ncomment  = Implicit deny",
            "action   = MAYBE\nlog      = true\ncomment  = Implicit deny",
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="Unknown action"):
            ConfigLoader(tmp_config_tree).load()


class TestInterfaceConsistency:
    def test_duplicate_interface_assignment(self, tmp_config_tree):
        path = tmp_config_tree / "zones.ini"
        content = path.read_text().replace(
            "untrusted = wan1, wan2",
            "untrusted = wan1, wan2, lan",  # lan is already in trusted
        )
        path.write_text(content)
        with pytest.raises(ConfigError, match="multiple zones"):
            ConfigLoader(tmp_config_tree).load()

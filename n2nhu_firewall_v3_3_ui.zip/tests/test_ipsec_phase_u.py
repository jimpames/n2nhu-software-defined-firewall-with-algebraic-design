"""
Phase U tests — n2nhu_ipsec_tool CLI.

Covers:
  - show on empty config (no ipsec.ini)
  - show on populated config prints proposals/policies/tunnels
  - emit prints both ipsec.conf and ipsec.secrets
  - emit with no tunnels prints the empty-config marker
  - apply --dry-run announces what would happen, writes nothing
  - apply with mocked subprocess writes files and "reloads"
  - --no-check allows config with missing PSK file
  - Missing config root exits non-zero
  - Malformed config emits a config error and exits non-zero
"""

from __future__ import annotations

import io
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Make the script importable
SCRIPT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SCRIPT_DIR))
import n2nhu_ipsec_tool


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(argv: list[str]) -> tuple[int, str, str]:
    """Invoke main() and capture stdout/stderr."""
    buf_out = io.StringIO()
    buf_err = io.StringIO()
    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout = buf_out
    sys.stderr = buf_err
    try:
        try:
            rc = n2nhu_ipsec_tool.main(argv)
        except SystemExit as e:
            rc = int(e.code) if isinstance(e.code, int) else 2
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
    return rc, buf_out.getvalue(), buf_err.getvalue()


def _write_base_tree(root: Path) -> None:
    (root / "objects").mkdir(exist_ok=True)
    (root / "policies").mkdir(exist_ok=True)
    (root / "zones.ini").write_text(
        "[zones]\ntrusted = lan\nuntrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan_net]\ntype = network\nvalue = 192.168.1.0/24\n"
        "\n[addr_branch_net]\ntype = network\nvalue = 10.20.0.0/16\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\nsrc_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\nservice = svc_any\n"
        "schedule = sched_always\naction = ALLOW\n"
    )


def _write_ipsec(tree: Path, psk_path: Path) -> None:
    psk_path.write_text("test-psk-value")
    (tree / "policies" / "ipsec.ini").write_text(
        "[ipsec_proposal_p1]\n"
        "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
        f"\n[ike_policy_branch1]\n"
        f"local_id = fw\nremote_id = branch1\nremote_addr = 1.2.3.4\n"
        f"auth_method = psk\npsk_file = {psk_path}\n"
        f"proposals = ipsec_proposal_p1\n"
        f"\n[ipsec_tunnel_branch1]\n"
        f"ike_policy = ike_policy_branch1\n"
        f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
        f"proposals = ipsec_proposal_p1\n"
    )


@pytest.fixture
def tree(tmp_path):
    root = tmp_path / "config"
    root.mkdir()
    _write_base_tree(root)
    return root


@pytest.fixture
def populated_tree(tree, tmp_path):
    _write_ipsec(tree, tmp_path / "psk.key")
    return tree


# ---------------------------------------------------------------------------
# show subcommand
# ---------------------------------------------------------------------------


class TestShow:

    def test_show_empty_config(self, tree):
        rc, out, _err = _run(["--config", str(tree), "show"])
        assert rc == 0
        out_lower = out.lower()
        assert "no ipsec config" in out_lower or "tunnels: (none)" in out_lower

    def test_show_populated_config(self, populated_tree):
        rc, out, _err = _run(["--config", str(populated_tree), "show"])
        assert rc == 0
        assert "Proposals" in out
        assert "ipsec_proposal_p1" in out
        assert "aes256-sha256-modp2048" in out
        assert "ipsec_tunnel_branch1" in out
        assert "addr_lan_net" in out
        assert "addr_branch_net" in out

    def test_show_disabled_tunnel_marked(self, tree, tmp_path):
        psk = tmp_path / "psk.key"
        psk.write_text("p")
        (tree / "policies" / "ipsec.ini").write_text(
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_x]\n"
            f"local_id = a\nremote_id = b\nremote_addr = 1.2.3.4\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_off]\n"
            f"enabled = false\n"
            f"ike_policy = ike_policy_x\n"
            f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        rc, out, _err = _run(["--config", str(tree), "show"])
        assert rc == 0
        assert "DISABLED" in out


# ---------------------------------------------------------------------------
# emit subcommand
# ---------------------------------------------------------------------------


class TestEmit:

    def test_emit_prints_both_files(self, populated_tree):
        rc, out, _err = _run(["--config", str(populated_tree), "emit"])
        assert rc == 0
        assert "ipsec.conf" in out
        assert "ipsec.secrets" in out
        assert "conn ipsec_tunnel_branch1" in out
        assert 'PSK "test-psk-value"' in out

    def test_emit_empty_config(self, tree):
        rc, out, _err = _run(["--config", str(tree), "emit"])
        assert rc == 0
        assert "No tunnels configured" in out

    def test_emit_uses_custom_paths_in_header(self, populated_tree):
        rc, out, _err = _run([
            "--config", str(populated_tree), "emit",
            "--ipsec-conf", "/custom/path/ipsec.conf",
            "--ipsec-secrets", "/custom/path/ipsec.secrets",
        ])
        assert rc == 0
        assert "/custom/path/ipsec.conf" in out
        assert "/custom/path/ipsec.secrets" in out


# ---------------------------------------------------------------------------
# apply subcommand
# ---------------------------------------------------------------------------


class TestApply:

    def test_apply_dry_run_writes_nothing(self, populated_tree, tmp_path):
        conf = tmp_path / "out.conf"
        secrets = tmp_path / "out.secrets"
        rc, out, _err = _run([
            "--config", str(populated_tree), "apply",
            "--ipsec-conf", str(conf),
            "--ipsec-secrets", str(secrets),
            "--dry-run",
        ])
        assert rc == 0
        assert "(dry-run)" in out
        assert not conf.exists()
        assert not secrets.exists()

    def test_apply_with_mocked_subprocess(self, populated_tree, tmp_path):
        """Patch subprocess.run inside the shim path so we don't actually exec ipsec."""
        conf = tmp_path / "out.conf"
        secrets = tmp_path / "out.secrets"

        import subprocess
        fake_cp = subprocess.CompletedProcess(
            args=["ipsec", "reload"],
            returncode=0, stdout="", stderr="",
        )
        with patch("n2nhu_policy.ipsec_shim.subprocess.run",
                   return_value=fake_cp) as mock_run:
            rc, out, err = _run([
                "--config", str(populated_tree), "apply",
                "--ipsec-conf", str(conf),
                "--ipsec-secrets", str(secrets),
            ])
        assert rc == 0, f"rc={rc} stderr={err}"
        assert conf.exists()
        assert secrets.exists()
        assert "wrote" in out
        assert "rc=0" in out
        assert mock_run.called


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrors:

    def test_missing_config_root_returns_nonzero(self, tmp_path):
        rc, _out, err = _run([
            "--config", str(tmp_path / "does-not-exist"), "show",
        ])
        assert rc != 0
        assert "not found" in err.lower()

    def test_malformed_ipsec_returns_config_error(self, tree):
        (tree / "policies" / "ipsec.ini").write_text(
            "[ipsec_proposal_bad]\n"
            "encryption = des\nintegrity = sha256\ndh_group = modp2048\n"
        )
        rc, _out, err = _run(["--config", str(tree), "show"])
        assert rc != 0
        assert "config error" in err.lower()

    def test_no_check_allows_missing_psk(self, tree, tmp_path):
        nonexistent = tmp_path / "missing" / "psk.key"
        (tree / "policies" / "ipsec.ini").write_text(
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_x]\n"
            f"local_id = a\nremote_id = b\nremote_addr = 1.2.3.4\n"
            f"auth_method = psk\npsk_file = {nonexistent}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_x]\n"
            f"ike_policy = ike_policy_x\n"
            f"local_subnet = addr_lan_net\nremote_subnet = addr_branch_net\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        # Strict (default) — should fail
        rc, _out, err = _run(["--config", str(tree), "show"])
        assert rc != 0

        # Permissive — should succeed
        rc, out, _err = _run(["--config", str(tree), "--no-check", "show"])
        assert rc == 0
        assert "ipsec_tunnel_x" in out

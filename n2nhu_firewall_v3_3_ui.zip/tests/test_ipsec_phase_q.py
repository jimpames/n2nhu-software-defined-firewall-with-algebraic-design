"""
Phase Q tests — IPSec models and config loader.

Covers:
  - Empty / absent ipsec.ini → empty IPSecConfig
  - Single proposal parses correctly
  - Single IKE policy parses correctly with PSK auth
  - Single tunnel parses correctly
  - Cross-reference validation: undefined proposal/ike_policy/address rejected
  - Crypto enums: known values accepted, unknown rejected
  - PSK requires psk_file, pubkey requires both certs
  - Secret-file existence checked unless overridden
  - DPD action validation
  - auto field validation
  - Lifetimes validated for sensible minimums
  - Ordering: [ipsec_order] honored, default = sorted by section name
  - to_strongswan_string() produces correct proposal tokens
  - AEAD ciphers omit integrity in proposal string
"""

from __future__ import annotations

from pathlib import Path

import pytest

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.errors import ConfigError
from n2nhu_policy.ipsec_config_loader import IPSecConfigLoader
from n2nhu_policy.ipsec_models import (
    IKEVersion, IPSecAuth, IPSecConfig, IPSecDHGroup, IPSecEncryption,
    IPSecIntegrity, IPSecMode, IPSecProposal,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def policy_tree(tmp_path):
    """Minimal policy tree with the addresses our IPSec rules will reference."""
    root = tmp_path
    (root / "objects").mkdir()
    (root / "policies").mkdir()
    (root / "zones.ini").write_text(
        "[zones]\ntrusted = lan\nuntrusted = wan1\n"
        "\n[defaults]\ndefault_any_to_any = ALLOW\n"
    )
    (root / "objects" / "addresses.ini").write_text(
        "[addr_any]\ntype = network\nvalue = 0.0.0.0/0\n"
        "\n[addr_lan_net]\ntype = network\nvalue = 192.168.1.0/24\n"
        "\n[addr_branch_net]\ntype = network\nvalue = 10.20.0.0/16\n"
        "\n[addr_dc_net]\ntype = network\nvalue = 172.16.0.0/16\n"
    )
    (root / "objects" / "services.ini").write_text(
        "[svc_any]\nprotocol = any\n"
    )
    (root / "objects" / "schedules.ini").write_text(
        "[sched_always]\ntype = always\n"
    )
    (root / "policies" / "security.ini").write_text(
        "[policy_order]\nrules = p_allow\n"
        "\n[p_allow]\nsrc_zone = any\ndst_zone = any\n"
        "src_addr = addr_any\ndst_addr = addr_any\nservice = svc_any\n"
        "schedule = sched_always\naction = ALLOW\n"
    )
    return root


@pytest.fixture
def policy_config(policy_tree):
    return ConfigLoader(policy_tree).load()


def _write_ipsec_ini(policy_tree: Path, body: str) -> None:
    (policy_tree / "policies" / "ipsec.ini").write_text(body)


def _make_psk_file(tmp_path: Path, content: str = "supersecret") -> Path:
    p = tmp_path / "psk.key"
    p.write_text(content)
    return p


# ---------------------------------------------------------------------------
# Empty / absent
# ---------------------------------------------------------------------------


class TestEmptyConfig:

    def test_no_ipsec_ini_returns_empty(self, policy_tree, policy_config):
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        assert isinstance(cfg, IPSecConfig)
        assert cfg.is_empty()
        assert cfg.tunnels == ()
        assert cfg.proposals == {}
        assert cfg.ike_policies == {}

    def test_only_proposals_no_tunnels_is_empty_for_runtime(
        self, policy_tree, policy_config,
    ):
        """Defining proposals without tunnels is allowed (operator might be
        building config incrementally) and produces a config with proposals
        but is_empty() because no tunnels are active."""
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_aes256]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
        )
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        assert "ipsec_proposal_aes256" in cfg.proposals
        assert cfg.is_empty()


# ---------------------------------------------------------------------------
# Proposal parsing
# ---------------------------------------------------------------------------


class TestProposals:

    def test_parses_single_proposal(self, policy_tree, policy_config):
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_strong]\n"
            "encryption = aes256\nintegrity = sha384\ndh_group = ecp384\n"
        )
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        p = cfg.proposals["ipsec_proposal_strong"]
        assert p.encryption == IPSecEncryption.AES256
        assert p.integrity == IPSecIntegrity.SHA384
        assert p.dh_group == IPSecDHGroup.ECP384

    def test_strongswan_string_standard(self):
        p = IPSecProposal(
            id="x",
            encryption=IPSecEncryption.AES256,
            integrity=IPSecIntegrity.SHA256,
            dh_group=IPSecDHGroup.MODP2048,
        )
        assert p.to_strongswan_string() == "aes256-sha256-modp2048"

    def test_strongswan_string_aead_omits_integrity(self):
        p = IPSecProposal(
            id="x",
            encryption=IPSecEncryption.AES256GCM16,
            integrity=IPSecIntegrity.SHA256,   # ignored for AEAD
            dh_group=IPSecDHGroup.ECP256,
        )
        assert p.to_strongswan_string() == "aes256gcm16-ecp256"

    def test_unknown_encryption_rejected(self, policy_tree, policy_config):
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_bad]\n"
            "encryption = des\nintegrity = sha256\ndh_group = modp2048\n"
        )
        with pytest.raises(ConfigError, match="encryption"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_unknown_dh_group_rejected(self, policy_tree, policy_config):
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_bad]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp768\n"
        )
        with pytest.raises(ConfigError, match="dh_group"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_missing_required_key_rejected(self, policy_tree, policy_config):
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_x]\n"
            "encryption = aes256\nintegrity = sha256\n"
            # dh_group missing
        )
        with pytest.raises(ConfigError, match="dh_group"):
            IPSecConfigLoader(policy_tree, policy_config).load()


# ---------------------------------------------------------------------------
# IKE policy parsing
# ---------------------------------------------------------------------------


class TestIKEPolicy:

    def test_psk_policy_loads(self, policy_tree, policy_config, tmp_path):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_branch1]\n"
            f"local_id = firewall.example.com\n"
            f"remote_id = branch1.example.com\n"
            f"remote_addr = branch1.example.com\n"
            f"auth_method = psk\n"
            f"psk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        pol = cfg.ike_policies["ike_policy_branch1"]
        assert pol.ike_version == IKEVersion.IKEV2  # default
        assert pol.auth_method == IPSecAuth.PSK
        assert pol.psk_file == str(psk)
        assert pol.proposal_ids == ("ipsec_proposal_p1",)
        # Defaults
        assert pol.dpd_action == "clear"
        assert pol.dpd_delay_seconds == 30
        assert pol.ike_lifetime_seconds == 10800
        assert pol.mobike is True

    def test_psk_without_psk_file_rejected(
        self, policy_tree, policy_config,
    ):
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            "\n[ike_policy_x]\n"
            "local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            "auth_method = psk\n"
            "proposals = ipsec_proposal_p1\n"
        )
        with pytest.raises(ConfigError, match="psk_file"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_pubkey_requires_both_certs(
        self, policy_tree, policy_config, tmp_path,
    ):
        cert = tmp_path / "fw.crt"
        cert.write_text("dummy")
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            "\n[ike_policy_x]\n"
            "local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            "auth_method = pubkey\n"
            f"local_cert = {cert}\n"  # remote_cert missing
            "proposals = ipsec_proposal_p1\n"
        )
        with pytest.raises(ConfigError, match="local_cert and remote_cert"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_psk_file_existence_checked(self, policy_tree, policy_config):
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            "\n[ike_policy_x]\n"
            "local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            "auth_method = psk\n"
            "psk_file = /nonexistent/path/psk.key\n"
            "proposals = ipsec_proposal_p1\n"
        )
        with pytest.raises(ConfigError, match="psk_file does not exist"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_check_secret_files_disabled(self, policy_tree, policy_config):
        """When operator disables file checking (e.g. building config for
        a different host), missing secret files don't fail load."""
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            "\n[ike_policy_x]\n"
            "local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            "auth_method = psk\n"
            "psk_file = /not/here/psk.key\n"
            "proposals = ipsec_proposal_p1\n"
        )
        cfg = IPSecConfigLoader(
            policy_tree, policy_config, check_secret_files=False,
        ).load()
        assert "ike_policy_x" in cfg.ike_policies

    def test_unknown_proposal_reference_rejected(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_x]\n"
            f"local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = does_not_exist\n"
        )
        with pytest.raises(ConfigError, match="unknown proposal"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_dpd_action_validation(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_x]\n"
            f"local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"dpd_action = pretend\n"
        )
        with pytest.raises(ConfigError, match="dpd_action"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_lifetime_minimum(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_x]\n"
            f"local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"ike_lifetime_seconds = 30\n"
        )
        with pytest.raises(ConfigError, match="ike_lifetime_seconds"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_ikev1_opt_in(self, policy_tree, policy_config, tmp_path):
        """IKEv1 must be explicitly requested (default is v2)."""
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_legacy]\n"
            f"ike_version = ikev1\n"
            f"local_id = a\nremote_id = b\nremote_addr = 10.0.0.1\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        assert cfg.ike_policies["ike_policy_legacy"].ike_version == IKEVersion.IKEV1


# ---------------------------------------------------------------------------
# Tunnel parsing
# ---------------------------------------------------------------------------


def _full_psk_setup(policy_tree, tmp_path, extra_tunnel_keys: str = "") -> None:
    """Helper that builds a complete proposal+ike+tunnel ini."""
    psk = _make_psk_file(tmp_path)
    _write_ipsec_ini(policy_tree,
        "[ipsec_proposal_p1]\n"
        "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
        f"\n[ike_policy_branch1]\n"
        f"local_id = fw\nremote_id = branch1\nremote_addr = 198.51.100.10\n"
        f"auth_method = psk\npsk_file = {psk}\n"
        f"proposals = ipsec_proposal_p1\n"
        f"\n[ipsec_tunnel_branch1]\n"
        f"ike_policy = ike_policy_branch1\n"
        f"local_subnet = addr_lan_net\n"
        f"remote_subnet = addr_branch_net\n"
        f"proposals = ipsec_proposal_p1\n"
        + extra_tunnel_keys
    )


class TestTunnel:

    def test_basic_tunnel(self, policy_tree, policy_config, tmp_path):
        _full_psk_setup(policy_tree, tmp_path)
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        assert len(cfg.tunnels) == 1
        t = cfg.tunnels[0]
        assert t.id == "ipsec_tunnel_branch1"
        assert t.ike_policy_id == "ike_policy_branch1"
        assert t.local_subnet == "addr_lan_net"
        assert t.remote_subnet == "addr_branch_net"
        assert t.mode == IPSecMode.TUNNEL
        assert t.use_vti is True
        assert t.pfs is True
        assert t.auto == "start"
        assert t.enabled is True

    def test_unknown_ike_policy_rejected(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_real]\n"
            f"local_id = fw\nremote_id = branch1\nremote_addr = 1.2.3.4\n"
            f"auth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_x]\n"
            f"ike_policy = ike_policy_does_not_exist\n"
            f"local_subnet = addr_lan_net\n"
            f"remote_subnet = addr_branch_net\n"
            f"proposals = ipsec_proposal_p1\n"
        )
        with pytest.raises(ConfigError, match="unknown ike_policy"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_unknown_local_subnet_rejected(
        self, policy_tree, policy_config, tmp_path,
    ):
        _full_psk_setup(policy_tree, tmp_path)
        # Replace subnet with a non-existent one
        ipsec_text = (policy_tree / "policies" / "ipsec.ini").read_text()
        ipsec_text = ipsec_text.replace(
            "local_subnet = addr_lan_net",
            "local_subnet = addr_imaginary",
        )
        (policy_tree / "policies" / "ipsec.ini").write_text(ipsec_text)
        with pytest.raises(ConfigError, match="local_subnet"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_invalid_auto_rejected(
        self, policy_tree, policy_config, tmp_path,
    ):
        _full_psk_setup(policy_tree, tmp_path, "auto = on-demand\n")
        with pytest.raises(ConfigError, match="auto"):
            IPSecConfigLoader(policy_tree, policy_config).load()

    def test_disabled_tunnel(
        self, policy_tree, policy_config, tmp_path,
    ):
        _full_psk_setup(policy_tree, tmp_path, "enabled = false\n")
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        assert len(cfg.tunnels) == 1
        assert cfg.enabled_tunnels() == ()

    def test_transport_mode(
        self, policy_tree, policy_config, tmp_path,
    ):
        _full_psk_setup(policy_tree, tmp_path, "mode = transport\n")
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        assert cfg.tunnels[0].mode == IPSecMode.TRANSPORT


# ---------------------------------------------------------------------------
# Multi-tunnel ordering
# ---------------------------------------------------------------------------


class TestMultiTunnelOrdering:

    def test_default_order_is_alphabetical(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_a]\n"
            f"local_id = a\nremote_id = a2\nremote_addr = 1.1.1.1\n"
            f"auth_method = psk\npsk_file = {psk}\nproposals = ipsec_proposal_p1\n"
            f"\n[ike_policy_b]\n"
            f"local_id = b\nremote_id = b2\nremote_addr = 2.2.2.2\n"
            f"auth_method = psk\npsk_file = {psk}\nproposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_zulu]\n"
            f"ike_policy = ike_policy_a\nlocal_subnet = addr_lan_net\n"
            f"remote_subnet = addr_branch_net\nproposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_alpha]\n"
            f"ike_policy = ike_policy_b\nlocal_subnet = addr_lan_net\n"
            f"remote_subnet = addr_dc_net\nproposals = ipsec_proposal_p1\n"
        )
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        ids = [t.id for t in cfg.tunnels]
        assert ids == ["ipsec_tunnel_alpha", "ipsec_tunnel_zulu"]

    def test_explicit_order_honored(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_order]\ntunnels = ipsec_tunnel_zulu, ipsec_tunnel_alpha\n"
            "\n[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_a]\nlocal_id = a\nremote_id = a2\n"
            f"remote_addr = 1.1.1.1\nauth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_zulu]\n"
            f"ike_policy = ike_policy_a\nlocal_subnet = addr_lan_net\n"
            f"remote_subnet = addr_branch_net\nproposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_alpha]\n"
            f"ike_policy = ike_policy_a\nlocal_subnet = addr_lan_net\n"
            f"remote_subnet = addr_dc_net\nproposals = ipsec_proposal_p1\n"
        )
        cfg = IPSecConfigLoader(policy_tree, policy_config).load()
        ids = [t.id for t in cfg.tunnels]
        assert ids == ["ipsec_tunnel_zulu", "ipsec_tunnel_alpha"]

    def test_order_referencing_undefined_tunnel_rejected(
        self, policy_tree, policy_config, tmp_path,
    ):
        psk = _make_psk_file(tmp_path)
        _write_ipsec_ini(policy_tree,
            "[ipsec_order]\ntunnels = ipsec_tunnel_a, ipsec_tunnel_phantom\n"
            "\n[ipsec_proposal_p1]\n"
            "encryption = aes256\nintegrity = sha256\ndh_group = modp2048\n"
            f"\n[ike_policy_a]\nlocal_id = a\nremote_id = a2\n"
            f"remote_addr = 1.1.1.1\nauth_method = psk\npsk_file = {psk}\n"
            f"proposals = ipsec_proposal_p1\n"
            f"\n[ipsec_tunnel_a]\n"
            f"ike_policy = ike_policy_a\nlocal_subnet = addr_lan_net\n"
            f"remote_subnet = addr_branch_net\nproposals = ipsec_proposal_p1\n"
        )
        with pytest.raises(ConfigError, match="phantom"):
            IPSecConfigLoader(policy_tree, policy_config).load()

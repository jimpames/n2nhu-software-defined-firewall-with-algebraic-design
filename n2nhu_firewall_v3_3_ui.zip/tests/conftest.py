"""Shared pytest fixtures."""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

import pytest

# Make the package importable without install
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from n2nhu_policy import (  # noqa: E402
    ConfigLoader,
    ObjectResolver,
    PolicyEngine,
    ScheduleEvaluator,
    ZoneMap,
)


FIXTURE_ROOT = ROOT / "fixtures"


@pytest.fixture
def fixture_root() -> Path:
    """Path to the canonical fixtures directory (read-only)."""
    return FIXTURE_ROOT


@pytest.fixture
def loaded_config(fixture_root):
    """A fully-parsed Config from the canonical fixtures."""
    return ConfigLoader(fixture_root).load()


@pytest.fixture
def resolver(loaded_config):
    return ObjectResolver(loaded_config.addresses, loaded_config.services)


@pytest.fixture
def zone_map(loaded_config):
    return ZoneMap(
        loaded_config.zones,
        loaded_config.interface_to_zone,
        loaded_config.defaults,
    )


@pytest.fixture
def schedule_evaluator(loaded_config):
    return ScheduleEvaluator(loaded_config.schedules)


@pytest.fixture
def engine(loaded_config, resolver, zone_map, schedule_evaluator):
    return PolicyEngine(loaded_config, resolver, zone_map, schedule_evaluator)


@pytest.fixture
def tmp_config_tree(tmp_path, fixture_root):
    """
    A writable copy of the fixture tree, for tests that need to corrupt a file.
    Returns the path to the copied root.
    """
    dst = tmp_path / "config"
    shutil.copytree(fixture_root, dst)
    return dst

#!/usr/bin/env python3
"""
n2nhu_ipsec_tool — inspect, dry-run, and apply N2NHU IPSec config.

Subcommands:
    show                Print the loaded IPSec config in human form
    emit                Print the strongSwan files we would write
    apply               Write the files and reload the daemon

The default config root is the current directory; pass --config to
override. --check / --no-check controls whether secret files are
required to exist (useful when validating a config destined for
another host).

Examples:
    n2nhu_ipsec_tool show --config /etc/n2nhu
    n2nhu_ipsec_tool emit --config /etc/n2nhu
    n2nhu_ipsec_tool apply --config /etc/n2nhu --no-check
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

# When invoked as a script the package needs to be on sys.path
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.errors import ConfigError
from n2nhu_policy.ipsec_config_loader import IPSecConfigLoader
from n2nhu_policy.ipsec_models import IPSecAuth, IPSecConfig
from n2nhu_policy.ipsec_shim import IPSecShim, IPSecShimError
from n2nhu_policy.object_resolver import ObjectResolver
from n2nhu_policy.strongswan_emitter import emit_all


def _load(args) -> tuple[IPSecConfig, ObjectResolver]:
    root = Path(args.config)
    if not root.exists():
        print(f"config root not found: {root}", file=sys.stderr)
        sys.exit(2)
    try:
        pcfg = ConfigLoader(root).load()
        cfg = IPSecConfigLoader(
            root, pcfg, check_secret_files=args.check,
        ).load()
    except ConfigError as exc:
        print(f"config error: {exc}", file=sys.stderr)
        sys.exit(2)
    resolver = ObjectResolver(pcfg.addresses, pcfg.services)
    return cfg, resolver


# ---------------------------------------------------------------------------
# show — pretty-print the loaded config
# ---------------------------------------------------------------------------


def cmd_show(args) -> int:
    cfg, _resolver = _load(args)
    if cfg.is_empty() and not cfg.proposals and not cfg.ike_policies:
        print("(no IPSec config)")
        return 0

    if cfg.proposals:
        print("Proposals:")
        for pid, p in sorted(cfg.proposals.items()):
            print(
                f"  {pid:30s} {p.to_strongswan_string()}"
            )
        print()

    if cfg.ike_policies:
        print("IKE policies:")
        for pid, p in sorted(cfg.ike_policies.items()):
            auth = p.auth_method.value
            cred = (
                f"psk_file={p.psk_file}" if p.auth_method == IPSecAuth.PSK
                else f"local_cert={p.local_cert}"
            )
            print(
                f"  {pid:30s} {p.ike_version.value} "
                f"{p.local_id} <-> {p.remote_id} ({p.remote_addr}) "
                f"auth={auth} {cred}"
            )
        print()

    if cfg.tunnels:
        print("Tunnels:")
        for t in cfg.tunnels:
            status = "enabled" if t.enabled else "DISABLED"
            print(
                f"  {t.id:30s} {status:8s} "
                f"{t.local_subnet} <-> {t.remote_subnet} "
                f"via {t.ike_policy_id} mode={t.mode.value} "
                f"vti={'yes' if t.use_vti else 'no'} "
                f"pfs={'yes' if t.pfs else 'no'} auto={t.auto}"
            )
        print()
    else:
        print("Tunnels: (none)")
    return 0


# ---------------------------------------------------------------------------
# emit — print files we would write
# ---------------------------------------------------------------------------


def cmd_emit(args) -> int:
    cfg, resolver = _load(args)
    emitted = emit_all(cfg, resolver)
    print("=" * 60)
    print(f"# {args.ipsec_conf}")
    print("=" * 60)
    print(emitted.ipsec_conf)
    print()
    print("=" * 60)
    print(f"# {args.ipsec_secrets}")
    print("=" * 60)
    print(emitted.ipsec_secrets)
    return 0


# ---------------------------------------------------------------------------
# apply — write files + reload daemon
# ---------------------------------------------------------------------------


def cmd_apply(args) -> int:
    cfg, resolver = _load(args)
    shim = IPSecShim(
        ipsec_conf_path=args.ipsec_conf,
        ipsec_secrets_path=args.ipsec_secrets,
        reload_command=tuple(args.reload_command.split()),
        dry_run=args.dry_run,
    )
    try:
        result = shim.apply(cfg, resolver)
    except IPSecShimError as exc:
        print(f"apply failed: {exc}", file=sys.stderr)
        return 3

    if args.dry_run:
        print(f"(dry-run) would write {args.ipsec_conf}")
        print(f"(dry-run) would write {args.ipsec_secrets}")
        print(f"(dry-run) would invoke {args.reload_command!r}")
    else:
        print(f"wrote   {result.ipsec_conf_path}")
        print(f"wrote   {result.ipsec_secrets_path}")
        print(f"reload  rc={result.reload_returncode}")
        if result.reload_stderr:
            print(f"stderr: {result.reload_stderr.strip()}")
    return 0


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="n2nhu_ipsec_tool",
        description="Inspect and apply N2NHU IPSec config to strongSwan.",
    )
    p.add_argument("--config", default=".",
                   help="Path to N2NHU config root (default: cwd)")
    p.add_argument("--no-check", dest="check", action="store_false", default=True,
                   help="Skip existence-check on PSK / cert files")

    sub = p.add_subparsers(dest="cmd", required=True)

    p_show = sub.add_parser("show", help="Pretty-print the loaded config")
    p_show.set_defaults(func=cmd_show)

    p_emit = sub.add_parser("emit", help="Print ipsec.conf and ipsec.secrets")
    p_emit.add_argument("--ipsec-conf", default="/etc/ipsec.conf")
    p_emit.add_argument("--ipsec-secrets", default="/etc/ipsec.secrets")
    p_emit.set_defaults(func=cmd_emit)

    p_apply = sub.add_parser("apply", help="Write files and reload daemon")
    p_apply.add_argument("--ipsec-conf", default="/etc/ipsec.conf")
    p_apply.add_argument("--ipsec-secrets", default="/etc/ipsec.secrets")
    p_apply.add_argument("--reload-command", default="ipsec reload")
    p_apply.add_argument("--dry-run", action="store_true")
    p_apply.set_defaults(func=cmd_apply)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

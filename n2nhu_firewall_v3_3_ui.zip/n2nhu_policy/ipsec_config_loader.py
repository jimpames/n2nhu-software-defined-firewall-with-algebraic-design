"""
IPSecConfigLoader — parses policies/ipsec.ini into an IPSecConfig.

Single file (ipsec.ini) containing three section types, distinguished by
section-id prefix convention rather than by INI nesting:

    [ipsec_proposal_NNN]   crypto suite — leaf object
    [ike_policy_NNN]       Phase 1 — references one or more proposals
    [ipsec_tunnel_NNN]     Phase 2 — references an IKE policy + proposals

A separate `[ipsec_order]` section lists tunnel ids in evaluation order.
The order matters because strongSwan's `auto = start` connections come
up in declaration order; deterministic ordering helps debugging.

Cross-validation:
  - Every proposal_ids entry on a policy/tunnel must exist
  - Every ike_policy_id on a tunnel must exist
  - Every local_subnet / remote_subnet must be a defined address object
  - PSK auth requires psk_file; pubkey auth requires local_cert+remote_cert
  - PSK files and cert files are checked for existence at load time
    (operator-facing — better to fail at load than at daemon reload)

If ipsec.ini is absent the loader returns an empty config, mirroring
the NAT/PBR/capture convention: IPSec is opt-in.
"""

from __future__ import annotations

import configparser
from pathlib import Path

from .config_loader import _check_keys, _parse_bool, _parse_csv, _parse_int, _read_ini
from .errors import ConfigError
from .ipsec_models import (
    IKEPolicy, IKEVersion,
    IPSecAuth, IPSecConfig, IPSecDHGroup, IPSecEncryption, IPSecIntegrity,
    IPSecMode, IPSecProposal, IPSecTunnel,
)
from .models import Config


_PROPOSAL_KEYS = {"encryption", "integrity", "dh_group", "comment"}
_IKE_POLICY_KEYS = {
    "ike_version", "local_id", "remote_id", "remote_addr",
    "auth_method", "psk_file", "local_cert", "remote_cert",
    "proposals", "dpd_action", "dpd_delay_seconds",
    "ike_lifetime_seconds", "mobike", "comment",
}
_TUNNEL_KEYS = {
    "enabled", "ike_policy", "local_subnet", "remote_subnet",
    "proposals", "mode", "use_vti", "pfs",
    "ipsec_lifetime_seconds", "auto", "comment",
}

_VALID_DPD_ACTIONS = {"clear", "hold", "restart", "none"}
_VALID_AUTO_MODES = {"start", "route", "add"}

_PROPOSAL_PREFIX = "ipsec_proposal_"
_IKE_POLICY_PREFIX = "ike_policy_"
_TUNNEL_PREFIX = "ipsec_tunnel_"


def _parse_enum(enum_cls, raw: str, *, source: str, section: str, field: str):
    """Generic enum parser with helpful error message."""
    raw = raw.strip().lower()
    try:
        return enum_cls(raw)
    except ValueError:
        valid = ", ".join(e.value for e in enum_cls)
        raise ConfigError(
            f"{field} must be one of: {valid} (got {raw!r})",
            source=source, section=section,
        ) from None


class IPSecConfigLoader:
    def __init__(
        self,
        root: str | Path,
        policy_config: Config,
        *,
        check_secret_files: bool = True,
    ):
        self.root = Path(root)
        self.policy_config = policy_config
        # In tests we sometimes load configs whose secret files don't
        # exist on disk. Production code paths leave this on.
        self.check_secret_files = check_secret_files

    def load(self) -> IPSecConfig:
        path = self.root / "policies" / "ipsec.ini"
        if not path.exists():
            return IPSecConfig(
                proposals={}, ike_policies={}, tunnels=(),
            )

        cp = _read_ini(path)
        source = "policies/ipsec.ini"

        proposals = self._load_proposals(cp, source)
        ike_policies = self._load_ike_policies(cp, source, proposals)
        tunnels = self._load_tunnels(cp, source, proposals, ike_policies)

        return IPSecConfig(
            proposals=proposals,
            ike_policies=ike_policies,
            tunnels=tunnels,
        )

    # -----------------------------------------------------------------
    # Proposals
    # -----------------------------------------------------------------

    def _load_proposals(
        self, cp: configparser.ConfigParser, source: str,
    ) -> dict[str, IPSecProposal]:
        out: dict[str, IPSecProposal] = {}
        for section_name in cp.sections():
            if not section_name.startswith(_PROPOSAL_PREFIX):
                continue
            section = cp[section_name]
            _check_keys(
                section.keys(), _PROPOSAL_KEYS,
                source=source, section=section_name,
            )
            for required in ("encryption", "integrity", "dh_group"):
                if required not in section:
                    raise ConfigError(
                        f"missing required key '{required}'",
                        source=source, section=section_name,
                    )
            out[section_name] = IPSecProposal(
                id=section_name,
                encryption=_parse_enum(
                    IPSecEncryption, section["encryption"],
                    source=source, section=section_name, field="encryption",
                ),
                integrity=_parse_enum(
                    IPSecIntegrity, section["integrity"],
                    source=source, section=section_name, field="integrity",
                ),
                dh_group=_parse_enum(
                    IPSecDHGroup, section["dh_group"],
                    source=source, section=section_name, field="dh_group",
                ),
            )
        return out

    # -----------------------------------------------------------------
    # IKE policies
    # -----------------------------------------------------------------

    def _load_ike_policies(
        self,
        cp: configparser.ConfigParser,
        source: str,
        proposals: dict[str, IPSecProposal],
    ) -> dict[str, IKEPolicy]:
        out: dict[str, IKEPolicy] = {}
        for section_name in cp.sections():
            if not section_name.startswith(_IKE_POLICY_PREFIX):
                continue
            section = cp[section_name]
            _check_keys(
                section.keys(), _IKE_POLICY_KEYS,
                source=source, section=section_name,
            )

            # Required fields
            for required in ("local_id", "remote_id", "remote_addr",
                             "auth_method", "proposals"):
                if required not in section:
                    raise ConfigError(
                        f"missing required key '{required}'",
                        source=source, section=section_name,
                    )

            # Auth method dictates which credential fields are required
            auth = _parse_enum(
                IPSecAuth, section["auth_method"],
                source=source, section=section_name, field="auth_method",
            )
            psk_file = section.get("psk_file") or None
            local_cert = section.get("local_cert") or None
            remote_cert = section.get("remote_cert") or None

            if auth == IPSecAuth.PSK:
                if not psk_file:
                    raise ConfigError(
                        "auth_method=psk requires psk_file",
                        source=source, section=section_name,
                    )
                if self.check_secret_files and not Path(psk_file).exists():
                    raise ConfigError(
                        f"psk_file does not exist: {psk_file}",
                        source=source, section=section_name,
                    )
            else:  # PUBKEY
                if not local_cert or not remote_cert:
                    raise ConfigError(
                        "auth_method=pubkey requires both local_cert and remote_cert",
                        source=source, section=section_name,
                    )
                if self.check_secret_files:
                    for path_str, label in (
                        (local_cert, "local_cert"),
                        (remote_cert, "remote_cert"),
                    ):
                        if not Path(path_str).exists():
                            raise ConfigError(
                                f"{label} does not exist: {path_str}",
                                source=source, section=section_name,
                            )

            # Proposal references must all exist
            proposal_ids = _parse_csv(section["proposals"])
            if not proposal_ids:
                raise ConfigError(
                    "proposals list cannot be empty",
                    source=source, section=section_name,
                )
            for pid in proposal_ids:
                if pid not in proposals:
                    raise ConfigError(
                        f"unknown proposal {pid!r} (defined: {sorted(proposals)})",
                        source=source, section=section_name,
                    )

            # DPD parameters
            dpd_action = section.get("dpd_action", "clear").strip().lower()
            if dpd_action not in _VALID_DPD_ACTIONS:
                raise ConfigError(
                    f"dpd_action must be one of {sorted(_VALID_DPD_ACTIONS)}, "
                    f"got {dpd_action!r}",
                    source=source, section=section_name,
                )
            dpd_delay_seconds = _parse_int(
                section.get("dpd_delay_seconds", "30"),
                source=source, section=section_name, key="dpd_delay_seconds",
            )
            if dpd_delay_seconds < 0:
                raise ConfigError(
                    f"dpd_delay_seconds must be >= 0, got {dpd_delay_seconds}",
                    source=source, section=section_name,
                )

            ike_lifetime = _parse_int(
                section.get("ike_lifetime_seconds", "10800"),
                source=source, section=section_name, key="ike_lifetime_seconds",
            )
            if ike_lifetime < 60:
                raise ConfigError(
                    f"ike_lifetime_seconds must be >= 60, got {ike_lifetime}",
                    source=source, section=section_name,
                )

            mobike = _parse_bool(
                section.get("mobike", "true"),
                source=source, section=section_name, key="mobike",
            )

            out[section_name] = IKEPolicy(
                id=section_name,
                ike_version=_parse_enum(
                    IKEVersion, section.get("ike_version", "ikev2"),
                    source=source, section=section_name, field="ike_version",
                ),
                local_id=section["local_id"].strip(),
                remote_id=section["remote_id"].strip(),
                remote_addr=section["remote_addr"].strip(),
                auth_method=auth,
                psk_file=psk_file,
                local_cert=local_cert,
                remote_cert=remote_cert,
                proposal_ids=proposal_ids,
                dpd_action=dpd_action,
                dpd_delay_seconds=dpd_delay_seconds,
                ike_lifetime_seconds=ike_lifetime,
                mobike=mobike,
            )
        return out

    # -----------------------------------------------------------------
    # Tunnels
    # -----------------------------------------------------------------

    def _load_tunnels(
        self,
        cp: configparser.ConfigParser,
        source: str,
        proposals: dict[str, IPSecProposal],
        ike_policies: dict[str, IKEPolicy],
    ) -> tuple[IPSecTunnel, ...]:
        # Optional [ipsec_order] section enforces declaration order
        order: list[str]
        if "ipsec_order" in cp and "tunnels" in cp["ipsec_order"]:
            order = list(_parse_csv(cp["ipsec_order"]["tunnels"]))
        else:
            order = sorted(
                s for s in cp.sections() if s.startswith(_TUNNEL_PREFIX)
            )

        # Verify every order entry has a section
        for tid in order:
            if tid not in cp:
                raise ConfigError(
                    f"ipsec_order references undefined tunnel {tid!r}",
                    source=source, section="ipsec_order",
                )

        out: list[IPSecTunnel] = []
        for section_name in order:
            if not section_name.startswith(_TUNNEL_PREFIX):
                raise ConfigError(
                    f"section {section_name!r} in ipsec_order is not a tunnel "
                    f"(expected {_TUNNEL_PREFIX}* prefix)",
                    source=source, section="ipsec_order",
                )
            section = cp[section_name]
            _check_keys(
                section.keys(), _TUNNEL_KEYS,
                source=source, section=section_name,
            )
            for required in ("ike_policy", "local_subnet", "remote_subnet",
                             "proposals"):
                if required not in section:
                    raise ConfigError(
                        f"missing required key '{required}'",
                        source=source, section=section_name,
                    )

            ike_policy_id = section["ike_policy"].strip()
            if ike_policy_id not in ike_policies:
                raise ConfigError(
                    f"unknown ike_policy {ike_policy_id!r} "
                    f"(defined: {sorted(ike_policies)})",
                    source=source, section=section_name,
                )

            local_subnet = section["local_subnet"].strip()
            remote_subnet = section["remote_subnet"].strip()
            if local_subnet not in self.policy_config.addresses:
                raise ConfigError(
                    f"local_subnet {local_subnet!r} not defined in addresses.ini",
                    source=source, section=section_name,
                )
            if remote_subnet not in self.policy_config.addresses:
                raise ConfigError(
                    f"remote_subnet {remote_subnet!r} not defined in addresses.ini",
                    source=source, section=section_name,
                )

            proposal_ids = _parse_csv(section["proposals"])
            if not proposal_ids:
                raise ConfigError(
                    "proposals list cannot be empty",
                    source=source, section=section_name,
                )
            for pid in proposal_ids:
                if pid not in proposals:
                    raise ConfigError(
                        f"unknown proposal {pid!r}",
                        source=source, section=section_name,
                    )

            mode = _parse_enum(
                IPSecMode, section.get("mode", "tunnel"),
                source=source, section=section_name, field="mode",
            )
            auto = section.get("auto", "start").strip().lower()
            if auto not in _VALID_AUTO_MODES:
                raise ConfigError(
                    f"auto must be one of {sorted(_VALID_AUTO_MODES)}, "
                    f"got {auto!r}",
                    source=source, section=section_name,
                )

            ipsec_lifetime = _parse_int(
                section.get("ipsec_lifetime_seconds", "3600"),
                source=source, section=section_name,
                key="ipsec_lifetime_seconds",
            )
            if ipsec_lifetime < 60:
                raise ConfigError(
                    f"ipsec_lifetime_seconds must be >= 60, got {ipsec_lifetime}",
                    source=source, section=section_name,
                )

            out.append(IPSecTunnel(
                id=section_name,
                ike_policy_id=ike_policy_id,
                local_subnet=local_subnet,
                remote_subnet=remote_subnet,
                proposal_ids=proposal_ids,
                mode=mode,
                use_vti=_parse_bool(
                    section.get("use_vti", "true"),
                    source=source, section=section_name, key="use_vti",
                ),
                pfs=_parse_bool(
                    section.get("pfs", "true"),
                    source=source, section=section_name, key="pfs",
                ),
                ipsec_lifetime_seconds=ipsec_lifetime,
                auto=auto,
                enabled=_parse_bool(
                    section.get("enabled", "true"),
                    source=source, section=section_name, key="enabled",
                ),
            ))

        return tuple(out)

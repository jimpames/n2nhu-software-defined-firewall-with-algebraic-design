"""
router_shim — the glue between the TAP read/write loop and our engines.

The main class `RouterShim` replaces the procedural NAT + firewall logic in
`multi_interface_firewall_v2.py` with our pure-function engines. It is
I/O-free: it does not touch TAP adapters itself. The caller hands it raw
bytes in, and receives bytes out + a forwarding decision.

This design means:
  - Tests can exercise the full packet path with synthetic frames (no TAP).
  - The actual TAP read/write loop on Windows (in multi_interface_firewall_v2.py)
    calls `shim.process_frame(iface, bytes)` and uses the return value.
  - Hot reload is a pointer swap of a single RouterShim instance.

Integration contract for the TAP-loop caller:

    shim = RouterShim(config_root, interface_ips)
    ...
    async def read_loop(iface_name, tap):
        while running:
            frame = await tap.read_frame()
            if frame is None: continue
            decision = shim.process_frame(iface_name, frame)
            if decision.action == ForwardAction.FORWARD:
                await taps[decision.egress_iface].write_frame(decision.frame)
            # else drop
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from ipaddress import IPv4Address, IPv4Network, IPv6Address, IPv6Network, ip_network
from pathlib import Path
from typing import Callable, Optional

from .capture_config_loader import CaptureConfigLoader
from .capture_engine import CaptureEngine
from .capture_manager import CaptureManager
from .capture_models import CapturePoint
from .config_loader import ConfigLoader
from .ipsec_config_loader import IPSecConfigLoader
from .ipsec_models import IPSecConfig
from .ipsec_shim import IPSecShim, IPSecShimError
from .frame_codec import (
    ETH_P_IP,
    FrameParseError,
    ParsedFrame,
    parse_frame,
    rewrite_frame_dnat,
    rewrite_frame_full,
    rewrite_frame_snat,
)
from .frame_codec_v6 import (
    ETH_P_IPV6,
    FrameParseErrorV6,
    parse_frame_v6,
)
from .models import Action, Config, Packet, Protocol
from .nat_config_loader import NATConfigLoader
from .nat_engine import NATEngine
from .nat_models import NATConfig, NATDenied, NATType, PassThrough, TranslatedPacket
from .nat64_addr import is_nat64_address, parse_nat64_prefix
from .nat64_translator import NAT64TranslationError, translate_v4_to_v6, translate_v6_to_v4
from .pbr_config_loader import PBRConfigLoader
from .pbr_engine import PBREngine
from .pbr_models import PBRConfig, PBRMatch
from .policy_engine import PolicyEngine
from .stats import Stats

logger = logging.getLogger(__name__)


class ForwardAction(enum.Enum):
    FORWARD = "forward"
    DROP = "drop"
    PARSE_ERROR = "parse_error"
    UNKNOWN_INTERFACE = "unknown_interface"


@dataclass(frozen=True)
class ForwardDecision:
    """What the TAP-loop should do with this frame."""

    action: ForwardAction
    frame: bytes = b""           # possibly rewritten frame (if FORWARD)
    egress_iface: str = ""       # which TAP to write to (if FORWARD)
    drop_reason: str = ""        # populated if DROP
    policy_rule_id: str = ""     # rule that matched (for logging)
    nat_rule_id: str = ""        # NAT rule that matched (for logging)
    pbr_rule_id: str = ""        # PBR rule that overrode routing (for logging)


@dataclass(frozen=True)
class RouterStats:
    """Lightweight counters. Read via shim.get_stats()."""

    frames_in: int = 0
    frames_forwarded: int = 0
    frames_dropped: int = 0
    parse_errors: int = 0
    policy_denies: int = 0
    nat_translations: int = 0
    nat_denies: int = 0
    passthroughs: int = 0


class RouterShim:
    """
    The integrated router data plane: parse → NAT → policy → rewrite → forward.

    Separates cleanly from TAP I/O: the caller owns the TAPs, this class
    owns the packet-processing logic. Thread-safe for read operations;
    reload is a full instance replacement (the atomic pointer swap).
    """

    def __init__(
        self,
        config_root: str | Path,
        interface_ips: dict[str, IPv4Address],
        interface_networks: dict[str, IPv4Network] | None = None,
        *,
        interface_networks_v6: dict[str, IPv6Network] | None = None,
        clock: Callable[[], datetime] | None = None,
        ipsec_shim: Optional["IPSecShim"] = None,
        check_ipsec_secret_files: bool = True,
    ):
        """
        Args:
            config_root: path to the INI tree (zones/objects/policies).
            interface_ips: logical iface name -> assigned IP for SNAT
                           'translate_src_to = interface' rules.
            interface_networks: logical iface name -> IPv4Network. Used
                           by the route-lookup to pick an egress interface.
                           If None, inferred from interface_ips (single-IP /32).
            interface_networks_v6: logical iface name -> IPv6Network. Used
                           for pure v6 forwarding. If None, no v6 routes
                           are configured and v6 frames without a NAT64 rule
                           match are dropped (legacy v1 behavior).
            clock: returns the current tz-aware datetime. Default uses UTC.
        """
        self.config_root = Path(config_root)
        self.interface_ips = dict(interface_ips)
        self._clock = clock or (lambda: datetime.now(timezone.utc))

        # Load all three configs atomically
        self.policy_config: Config = ConfigLoader(self.config_root).load()
        self.nat_config: NATConfig = NATConfigLoader(
            self.config_root, self.policy_config,
        ).load()
        self.pbr_config: PBRConfig = PBRConfigLoader(
            self.config_root, self.policy_config,
        ).load()

        # Build routing table: iface -> network
        if interface_networks is not None:
            self.interface_networks = dict(interface_networks)
        else:
            self.interface_networks = {
                name: IPv4Network(f"{ip}/32") for name, ip in interface_ips.items()
            }
        # Sort networks by prefix length desc — longest-match first
        self._route_table = sorted(
            self.interface_networks.items(),
            key=lambda kv: kv[1].prefixlen,
            reverse=True,
        )

        # Build the v6 route table (optional — empty if not configured).
        # Same longest-prefix-match discipline as v4.
        self.interface_networks_v6 = dict(interface_networks_v6 or {})
        self._route_table_v6 = sorted(
            self.interface_networks_v6.items(),
            key=lambda kv: kv[1].prefixlen,
            reverse=True,
        )

        # Construct engines
        self.policy_engine = PolicyEngine(self.policy_config)
        self.nat_engine = NATEngine(
            self.policy_config, self.nat_config,
            interface_ips=self.interface_ips,
        )
        self.pbr_engine = PBREngine(self.policy_config, self.pbr_config)

        # Load capture config (optional — empty if no capture.ini)
        self.capture_config = CaptureConfigLoader(
            self.config_root, self.policy_config,
        ).load()
        self.capture_engine = CaptureEngine(
            self.capture_config, self.policy_config,
        )
        self.capture_manager: Optional[CaptureManager] = None
        if self.capture_config.enabled_rules():
            self.capture_manager = CaptureManager(self.capture_config)

        # Load IPSec config (optional — empty if no ipsec.ini)
        self.ipsec_config: IPSecConfig = IPSecConfigLoader(
            self.config_root, self.policy_config,
            check_secret_files=check_ipsec_secret_files,
        ).load()
        self.ipsec_shim: Optional[IPSecShim] = ipsec_shim
        self._check_ipsec_secret_files = check_ipsec_secret_files

        # Counters
        self._stats = {
            "frames_in": 0,
            "frames_in_v4": 0,
            "frames_in_v6": 0,
            "frames_forwarded": 0,
            "frames_dropped": 0,
            "parse_errors": 0,
            "policy_denies": 0,
            "nat_translations": 0,
            "nat_denies": 0,
            "passthroughs": 0,
            "pbr_overrides": 0,
            "nat64_v6_to_v4": 0,
            "nat64_v4_to_v6": 0,
            "nat64_no_session": 0,
            "v6_no_nat64_rule": 0,
            "v6_no_route": 0,
            "v6_forwarded_native": 0,
            "v6_policy_denies": 0,
        }
        self.policy_stats = Stats()

        # Pre-compute a NAT64-prefix index for fast lookup
        self._nat64_rules = [r for r in self.nat_config.rules
                             if r.type == NATType.NAT64]
        self._nat64_parsed_prefixes = [
            (parse_nat64_prefix(r.nat64_prefix), r) for r in self._nat64_rules
        ]

    # -----------------------------------------------------------------------
    # Route lookup
    # -----------------------------------------------------------------------

    def route_lookup(self, dst_ip: IPv4Address) -> Optional[str]:
        """
        Find the egress interface for a dst IP using longest-prefix match
        over the configured interface networks. Returns iface name or None.
        """
        for name, network in self._route_table:
            if dst_ip in network:
                return name
        return None

    def route_lookup_v6(self, dst_ip: IPv6Address) -> Optional[str]:
        """
        Same longest-prefix-match discipline as route_lookup(), but on
        the v6 route table. Returns iface name or None. Returns None
        for any v6 dst if the operator did not configure v6 networks
        (legacy v1 behavior).
        """
        for name, network in self._route_table_v6:
            if dst_ip in network:
                return name
        return None

    def find_nat64_rule_for_v6_dst(self, dst_v6):
        """Return the NAT64 rule whose prefix contains dst_v6, or None."""
        for prefix, rule in self._nat64_parsed_prefixes:
            if dst_v6 in prefix:
                return rule, prefix
        return None, None

    def find_nat64_rule_for_v4_reply(self, dst_v4):
        """For a v4 reply arriving at the firewall, find the rule whose
        v4 pool this belongs to. In v1 (single address per rule) we
        resolve `translate_src_to_v4` to an IP and compare."""
        from .models import AddressType
        for rule in self._nat64_rules:
            addr_id = rule.translate_src_to_v4
            addr_obj = self.policy_config.addresses.get(addr_id)
            if addr_obj is None:
                continue
            if addr_obj.type == AddressType.HOST and addr_obj.host == dst_v4:
                return rule
        return None

    # -----------------------------------------------------------------------
    # Frame pipeline
    # -----------------------------------------------------------------------

    def process_frame(self, ingress_iface: str, frame: bytes) -> ForwardDecision:
        """
        Full pipeline: parse → route lookup → NAT → policy → rewrite → forward.

        Dispatches on the outer Ethernet type:
          0x0800 IPv4  — the original v4 pipeline below
          0x86DD IPv6  — if dst is in a NAT64 prefix, translate to v4 and
                         push into the v4 pipeline; otherwise drop in v1
                         (pure v6 forwarding is a future enhancement)

        Returns a ForwardDecision telling the caller what to do.
        """
        self._stats["frames_in"] += 1

        if len(frame) < 14:
            self._stats["parse_errors"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.PARSE_ERROR,
                drop_reason="frame shorter than Ethernet header",
            )

        import struct
        ethertype = struct.unpack("!H", frame[12:14])[0]

        if ethertype == ETH_P_IPV6:
            self._stats["frames_in_v6"] += 1
            return self._process_frame_v6(ingress_iface, frame)

        if ethertype == ETH_P_IP:
            self._stats["frames_in_v4"] += 1
            return self._process_frame_v4(ingress_iface, frame)

        # Unknown ethertype — not something we can forward
        self._stats["frames_dropped"] += 1
        return ForwardDecision(
            action=ForwardAction.PARSE_ERROR,
            drop_reason=f"unsupported ethertype 0x{ethertype:04x}",
        )

    def _process_frame_v6(self, ingress_iface: str, frame: bytes) -> ForwardDecision:
        """Process an IPv6 frame.

        v1 scope: if dst is in a NAT64 prefix, translate v6→v4 and forward
        as v4. If dst is NOT in a NAT64 prefix, drop (pure v6 forwarding
        is a future enhancement — requires v6 route table, v6 policy
        evaluation, v6 rewrite paths).
        """
        # Parse v6
        try:
            parsed_v6 = parse_frame_v6(frame)
        except FrameParseErrorV6 as exc:
            self._stats["parse_errors"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.PARSE_ERROR,
                drop_reason=str(exc),
            )

        # Find the NAT64 rule whose prefix matches the destination
        nat64_rule, prefix = self.find_nat64_rule_for_v6_dst(parsed_v6.dst_ip)
        if nat64_rule is None:
            # No NAT64 rule applies — try pure v6 forwarding.
            # If no v6 routes configured, this falls through to a drop.
            return self._forward_native_v6(ingress_iface, parsed_v6, frame)

        # Resolve the v4 pool address
        from .models import AddressType
        pool_addr_id = nat64_rule.translate_src_to_v4
        pool_addr = self.policy_config.addresses.get(pool_addr_id)
        if pool_addr is None or pool_addr.type != AddressType.HOST:
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"NAT64 rule {nat64_rule.id} v4 pool unresolvable",
            )
        xlated_src_v4 = pool_addr.host

        # Allocate a source port from the rule's pool (or default 10000+)
        pool = self.nat_engine._port_pools.get(nat64_rule.id)
        if pool is not None:
            try:
                xlated_src_port = pool.allocate()
            except Exception:
                self._stats["nat_denies"] += 1
                self._stats["frames_dropped"] += 1
                return ForwardDecision(
                    action=ForwardAction.DROP,
                    drop_reason=f"NAT64 port pool exhausted on rule {nat64_rule.id}",
                )
        else:
            # Fallback: no pool declared — use source port as-is. Works for
            # single-client scenarios; operators should declare a pool for
            # anything production.
            xlated_src_port = parsed_v6.src_port

        # Translate the packet v6→v4
        try:
            v4_frame = translate_v6_to_v4(
                parsed_v6, xlated_src_v4, xlated_src_port, prefix,
            )
        except NAT64TranslationError as exc:
            self._stats["frames_dropped"] += 1
            # Release the port if we allocated one
            if pool is not None:
                pool.release(xlated_src_port)
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"NAT64 translation failed: {exc}",
            )

        # Create / update the session so v4 replies can be reverse-translated
        from .nat64_addr import extract_v4_from_v6
        xlated_dst_v4 = extract_v4_from_v6(parsed_v6.dst_ip, prefix)
        session = self.session_table.create_session(
            rule_id=nat64_rule.id,
            nat_type=NATType.NAT64,
            protocol=parsed_v6.l4_protocol,
            orig_src_ip=parsed_v6.src_ip, orig_src_port=parsed_v6.src_port,
            orig_dst_ip=parsed_v6.dst_ip, orig_dst_port=parsed_v6.dst_port,
            xlated_src_ip=xlated_src_v4, xlated_src_port=xlated_src_port,
            xlated_dst_ip=xlated_dst_v4, xlated_dst_port=parsed_v6.dst_port,
            client_ingress_iface=ingress_iface,
        )
        session.touch(
            now=self._clock().timestamp() if hasattr(self._clock(), 'timestamp') else 0.0,
            direction=self._forward_direction(),
            byte_count=len(frame),
        )
        self._stats["nat64_v6_to_v4"] += 1
        self._stats["nat_translations"] += 1

        # Route the new v4 packet — egress interface determined by the
        # translated destination (the real v4 server)
        egress_iface = self.route_lookup(xlated_dst_v4)
        if egress_iface is None:
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.UNKNOWN_INTERFACE,
                drop_reason=f"no v4 route to {xlated_dst_v4}",
            )

        self._stats["frames_forwarded"] += 1
        return ForwardDecision(
            action=ForwardAction.FORWARD,
            egress_iface=egress_iface,
            frame=v4_frame,
        )

    def _forward_native_v6(
        self,
        ingress_iface: str,
        parsed_v6,
        frame: bytes,
    ) -> ForwardDecision:
        """Native v6 forwarding path. Used when no NAT64 rule matches.

        Pipeline (v6 has no NAT in v1, so the steps are smaller than v4):
            1. v6 route lookup → egress iface
            2. PBR override (DSCP-aware, family-agnostic)
            3. Policy evaluation (family-strict address objects)
            4. Forward as-is (no rewrite, no checksum touch)

        If no v6 routes are configured, drops with v6_no_route counter.
        Policy denies drop with v6_policy_denies counter.
        """
        # 1. v6 route lookup
        egress_iface = self.route_lookup_v6(parsed_v6.dst_ip)
        if egress_iface is None:
            # No v6 route. If the operator never configured v6 networks
            # this is the legacy v1 "v6 dropped" behavior; the counter
            # name distinguishes the two cases.
            if not self._route_table_v6:
                self._stats["v6_no_nat64_rule"] += 1
                self._stats["frames_dropped"] += 1
                return ForwardDecision(
                    action=ForwardAction.DROP,
                    drop_reason=f"no NAT64 rule for v6 dst {parsed_v6.dst_ip}",
                )
            self._stats["v6_no_route"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"no v6 route for {parsed_v6.dst_ip}",
            )

        # 2. Build a Packet for the engines. Address objects are
        #    family-strict so v6 fields naturally don't match v4 rules.
        v6_dscp = (parsed_v6.traffic_class >> 2) & 0x3F
        packet = Packet(
            ingress_iface=ingress_iface,
            egress_iface=egress_iface,
            src_ip=parsed_v6.src_ip,
            dst_ip=parsed_v6.dst_ip,
            protocol=parsed_v6.l4_protocol,
            src_port=parsed_v6.src_port,
            dst_port=parsed_v6.dst_port,
            icmp_type=parsed_v6.icmpv6_type,
            dscp=v6_dscp,
        )
        now = self._clock()

        # 3. PBR (may override egress based on DSCP/match)
        pbr_rule_id = ""
        pbr_result = self.pbr_engine.route_override(packet, now)
        if isinstance(pbr_result, PBRMatch):
            pbr_rule_id = pbr_result.rule_id
            self._stats["pbr_overrides"] += 1
            egress_iface = pbr_result.egress_iface
            packet = Packet(
                ingress_iface=ingress_iface,
                egress_iface=egress_iface,
                src_ip=parsed_v6.src_ip,
                dst_ip=parsed_v6.dst_ip,
                protocol=parsed_v6.l4_protocol,
                src_port=parsed_v6.src_port,
                dst_port=parsed_v6.dst_port,
                icmp_type=parsed_v6.icmpv6_type,
                dscp=v6_dscp,
            )

        # 4. Policy evaluation (no NAT for native v6, so policy is final)
        decision = self.policy_engine.evaluate(packet, now)
        self.policy_stats.record(decision)
        if decision.action != Action.ALLOW:
            self._stats["v6_policy_denies"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"v6 policy {decision.action.value}",
                policy_rule_id=decision.rule_id,
                pbr_rule_id=pbr_rule_id,
            )

        # 5. Forward unchanged. v6 has no NAT so no rewrite, no checksum
        #    update — the original frame bytes are forwarded verbatim.
        self._stats["v6_forwarded_native"] += 1
        self._stats["frames_forwarded"] += 1
        return ForwardDecision(
            action=ForwardAction.FORWARD,
            egress_iface=egress_iface,
            frame=frame,
            policy_rule_id=decision.rule_id,
            pbr_rule_id=pbr_rule_id,
        )

    @property
    def session_table(self):
        """Expose the NAT engine's session table at the shim layer too."""
        return self.nat_engine.session_table

    def _capture(
        self,
        packet: Packet,
        frame: bytes,
        capture_point: CapturePoint,
        decision_action: Optional[Action] = None,
        policy_rule_id: str = "",
        nat_rule_id: str = "",
        pbr_rule_id: str = "",
    ) -> None:
        """Emit a frame to capture if any rule matches. Safe no-op when
        no capture manager is configured. The frame parameter is the
        bytes that should be recorded — caller decides whether that's
        the original ingress bytes or a post-NAT translated frame."""
        if self.capture_manager is None:
            return
        rules = self.capture_engine.match(packet, decision_action, capture_point)
        if not rules:
            return
        ts = self._clock()
        ts_us = int(ts.timestamp() * 1_000_000) if hasattr(ts, "timestamp") else 0
        self.capture_manager.submit(
            rules, frame,
            timestamp_us=ts_us,
            capture_point=capture_point,
            decision_action=decision_action,
            policy_rule_id=policy_rule_id,
            nat_rule_id=nat_rule_id,
            pbr_rule_id=pbr_rule_id,
        )

    def shutdown(self) -> None:
        """Stop the capture manager, closing all pcap files. Idempotent.
        Should be called by the operator on graceful shutdown."""
        if self.capture_manager is not None:
            self.capture_manager.stop()

    def apply_ipsec(self):
        """Render the IPSec config and reload strongSwan via the shim.

        No-op (returns None) if no ipsec_shim is configured. Raises
        IPSecShimError if the shim's apply() fails. Operators are
        expected to call apply_ipsec() once after RouterShim
        construction and again after each reload(); the call is not
        invoked automatically because some operators want a manual
        confirmation step before pushing to a daemon.
        """
        if self.ipsec_shim is None:
            return None
        # Build a resolver matching the current policy config
        from .object_resolver import ObjectResolver
        resolver = ObjectResolver(
            self.policy_config.addresses, self.policy_config.services,
        )
        return self.ipsec_shim.apply(self.ipsec_config, resolver)

    def _forward_direction(self):
        """Return the forward Direction enum value (helper for readability)."""
        from .nat_models import Direction
        return Direction.FORWARD

    def _maybe_reverse_translate_nat64(
        self,
        ingress_iface: str,
        parsed: ParsedFrame,
        frame: bytes,
    ) -> Optional[ForwardDecision]:
        """If `parsed` is the reply leg of a known NAT64 session, return the
        reverse-translated forwarding decision. Otherwise return None.

        The session table's reverse index is keyed on the post-NAT 5-tuple
        as it appears on the v4 reply: src=v4 server, dst=firewall v4 pool.
        A hit means we have an established v6 client to reply to.
        """
        session = self.session_table.lookup_reverse(
            parsed.src_ip, parsed.src_port,
            parsed.dst_ip, parsed.dst_port,
            parsed.l4_protocol,
        )
        if session is None or session.nat_type != NATType.NAT64:
            return None

        # Find the rule and its prefix so we can rebuild the v6 src
        nat64_rule = None
        nat64_prefix = None
        for prefix, rule in self._nat64_parsed_prefixes:
            if rule.id == session.rule_id:
                nat64_rule = rule
                nat64_prefix = prefix
                break
        if nat64_rule is None or nat64_prefix is None:
            # Rule was reloaded out from under the session — drop, don't crash
            self._stats["nat64_no_session"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"NAT64 reply: rule {session.rule_id} no longer present",
            )

        # The reply's egress is the v6 client's original ingress iface
        egress = session.client_ingress_iface
        if egress is None:
            # Sessions created before this field existed: cannot route reply
            self._stats["nat64_no_session"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason="NAT64 reply: session has no client_ingress_iface",
            )

        # Reverse-translate v4→v6
        try:
            v6_frame = translate_v4_to_v6(
                parsed,
                session.orig_src_ip,           # v6 client (becomes dst of v6 reply)
                session.orig_src_port,         # v6 client port
                nat64_prefix,
            )
        except NAT64TranslationError as exc:
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"NAT64 reverse translate failed: {exc}",
            )

        # Update session counters in the REVERSE direction
        from .nat_models import Direction
        session.touch(
            now=self._clock().timestamp() if hasattr(self._clock(), 'timestamp') else 0.0,
            direction=Direction.REVERSE,
            byte_count=len(frame),
        )
        self._stats["nat64_v4_to_v6"] += 1
        self._stats["nat_translations"] += 1
        self._stats["frames_forwarded"] += 1
        return ForwardDecision(
            action=ForwardAction.FORWARD,
            egress_iface=egress,
            frame=v6_frame,
            nat_rule_id=session.rule_id,
        )

    def _process_frame_v4(self, ingress_iface: str, frame: bytes) -> ForwardDecision:
        """Original v4 pipeline, factored out of process_frame for clarity.

        Before the standard pipeline runs we check whether this v4 frame is
        the reply leg of an established NAT64 session. If so, we reverse-
        translate v4→v6 and emit on the original v6 client's ingress iface.
        Reply traffic on an established session is the stateful permit —
        policy is not re-evaluated, matching production firewall convention.
        """

        # Parse first — needed by both the reply-path check and the main pipeline.
        try:
            parsed = parse_frame(frame)
        except FrameParseError as exc:
            self._stats["parse_errors"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.PARSE_ERROR,
                drop_reason=str(exc),
            )

        # CAPTURE point: INGRESS — frame as it arrived. egress not yet known,
        # so we substitute the ingress iface; capture rules with dst_zone=any
        # still match. INGRESS is for "show me everything coming in."
        if self.capture_manager is not None:
            ingress_packet = Packet(
                ingress_iface=ingress_iface,
                egress_iface=ingress_iface,  # placeholder; real egress later
                src_ip=parsed.src_ip,
                dst_ip=parsed.dst_ip,
                protocol=parsed.l4_protocol,
                src_port=parsed.src_port,
                dst_port=parsed.dst_port,
                icmp_type=parsed.icmp_type,
                dscp=(parsed.ip_tos >> 2) & 0x3F,
            )
            self._capture(
                ingress_packet, frame, CapturePoint.INGRESS,
                decision_action=None,
            )

        # NAT64 reply-path detection. A v4 frame whose dst matches a NAT64
        # rule's v4 pool address may be a reply to an established v6 client.
        # Look up the reverse session; if found, reverse-translate.
        if self._nat64_rules and parsed.l4_protocol in (Protocol.TCP, Protocol.UDP):
            nat64_reply_decision = self._maybe_reverse_translate_nat64(
                ingress_iface, parsed, frame,
            )
            if nat64_reply_decision is not None:
                return nat64_reply_decision

        # 2. Route lookup → egress iface
        egress_iface = self.route_lookup(parsed.dst_ip)
        if egress_iface is None:
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.UNKNOWN_INTERFACE,
                drop_reason=f"no route to {parsed.dst_ip}",
            )

        # 3. Build our Packet type for the engines (includes DSCP for PBR)
        packet = Packet(
            ingress_iface=ingress_iface,
            egress_iface=egress_iface,
            src_ip=parsed.src_ip,
            dst_ip=parsed.dst_ip,
            protocol=parsed.l4_protocol,
            src_port=parsed.src_port,
            dst_port=parsed.dst_port,
            icmp_type=parsed.icmp_type,
            dscp=(parsed.ip_tos >> 2) & 0x3F,
        )
        now = self._clock()

        # 4. PBR — may override egress_iface based on match criteria + DSCP.
        # Done BEFORE policy/NAT so they see the corrected egress zone.
        pbr_rule_id = ""
        pbr_result = self.pbr_engine.route_override(packet, now)
        if isinstance(pbr_result, PBRMatch):
            pbr_rule_id = pbr_result.rule_id
            self._stats["pbr_overrides"] += 1
            # Rebuild packet with new egress
            egress_iface = pbr_result.egress_iface
            packet = Packet(
                ingress_iface=ingress_iface,
                egress_iface=egress_iface,
                src_ip=parsed.src_ip,
                dst_ip=parsed.dst_ip,
                protocol=parsed.l4_protocol,
                src_port=parsed.src_port,
                dst_port=parsed.dst_port,
                icmp_type=parsed.icmp_type,
                dscp=(parsed.ip_tos >> 2) & 0x3F,
            )

        # 5. Policy evaluation ALWAYS on pre-NAT addresses (SonicWall convention).
        # Done BEFORE NAT so denied packets never allocate a NAT session/port.
        decision = self.policy_engine.evaluate(packet, now)
        self.policy_stats.record(decision)

        # CAPTURE point: POST_POLICY — fires for both allow and deny.
        # Captures see the policy decision and the original (pre-NAT) frame.
        self._capture(
            packet, frame, CapturePoint.POST_POLICY,
            decision_action=decision.action,
            policy_rule_id=decision.rule_id,
            pbr_rule_id=pbr_rule_id,
        )

        if decision.action != Action.ALLOW:
            self._stats["policy_denies"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"policy {decision.action.value}",
                policy_rule_id=decision.rule_id,
                pbr_rule_id=pbr_rule_id,
            )

        # 6. NAT translation — only for allowed packets
        nat_result = self.nat_engine.translate(packet, now)

        if isinstance(nat_result, NATDenied):
            self._stats["nat_denies"] += 1
            self._stats["frames_dropped"] += 1
            return ForwardDecision(
                action=ForwardAction.DROP,
                drop_reason=f"NAT denied: {nat_result.reason}",
                nat_rule_id=nat_result.rule_id or "",
                policy_rule_id=decision.rule_id,
                pbr_rule_id=pbr_rule_id,
            )

        # 7. Apply NAT translation (if any) to the frame bytes
        out_frame = frame
        nat_rule_id = ""
        if isinstance(nat_result, TranslatedPacket):
            nat_rule_id = nat_result.rule_id or ""
            out_frame = self._apply_translation(parsed, packet, nat_result)
            self._stats["nat_translations"] += 1
        elif isinstance(nat_result, PassThrough):
            nat_rule_id = nat_result.rule_id or ""
            self._stats["passthroughs"] += 1

        # CAPTURE point: POST_NAT — frame as it will be forwarded.
        # For TranslatedPacket the bytes have been rewritten; for
        # PassThrough or no-NAT they're the original.
        self._capture(
            packet, out_frame, CapturePoint.POST_NAT,
            decision_action=decision.action,
            policy_rule_id=decision.rule_id,
            nat_rule_id=nat_rule_id,
            pbr_rule_id=pbr_rule_id,
        )

        # 8. Forward
        self._stats["frames_forwarded"] += 1
        return ForwardDecision(
            action=ForwardAction.FORWARD,
            frame=out_frame,
            egress_iface=egress_iface,
            policy_rule_id=decision.rule_id,
            nat_rule_id=nat_rule_id,
            pbr_rule_id=pbr_rule_id,
        )

    def _apply_translation(
        self,
        parsed: ParsedFrame,
        original_packet: Packet,
        xlation: TranslatedPacket,
    ) -> bytes:
        """
        Take the TranslatedPacket result and apply it to the frame bytes.
        Picks the right rewrite function based on what changed.
        """
        src_changed = (xlation.src_ip != parsed.src_ip or
                       xlation.src_port != parsed.src_port)
        dst_changed = (xlation.dst_ip != parsed.dst_ip or
                       xlation.dst_port != parsed.dst_port)

        if src_changed and dst_changed:
            # Rare: both sides rewritten. Use the full-recompute path.
            return rewrite_frame_full(
                parsed,
                xlation.src_ip, xlation.src_port,
                xlation.dst_ip, xlation.dst_port,
            )
        if src_changed:
            return rewrite_frame_snat(parsed, xlation.src_ip, xlation.src_port)
        if dst_changed:
            return rewrite_frame_dnat(parsed, xlation.dst_ip, xlation.dst_port)
        # Nothing changed — return original
        return parsed.raw

    # -----------------------------------------------------------------------
    # Stats / introspection
    # -----------------------------------------------------------------------

    def get_stats(self) -> RouterStats:
        s = self._stats
        return RouterStats(
            frames_in=s["frames_in"],
            frames_forwarded=s["frames_forwarded"],
            frames_dropped=s["frames_dropped"],
            parse_errors=s["parse_errors"],
            policy_denies=s["policy_denies"],
            nat_translations=s["nat_translations"],
            nat_denies=s["nat_denies"],
            passthroughs=s["passthroughs"],
        )

    def session_count(self) -> int:
        return len(self.nat_engine.session_table)

    # -----------------------------------------------------------------------
    # Reload
    # -----------------------------------------------------------------------

    def reload(self) -> "RouterShim":
        """
        Build a new RouterShim from the same config root and return it.
        Callers should atomically swap their reference; the old shim
        (with its sessions) can be kept alive briefly for in-flight packets.
        """
        return RouterShim(
            self.config_root,
            self.interface_ips,
            self.interface_networks,
            interface_networks_v6=self.interface_networks_v6,
            clock=self._clock,
            ipsec_shim=self.ipsec_shim,
            check_ipsec_secret_files=self._check_ipsec_secret_files,
        )

"""
nat64_addr — RFC 6052 IPv4/IPv6 address embedding/extraction.

For a /96 prefix (the case we support in v1), the IPv4 address occupies
the low 32 bits of the IPv6 address. Other prefix lengths (/32, /40,
/48, /56, /64) per RFC 6052 §2.2 are deferred to v1.1.

Well-known prefix: 64:ff9b::/96 (RFC 6052 §2.1). Recommended for traffic
that does not cross AS boundaries. For enterprise deployments needing
cross-AS traffic, operators configure their own /96 within their
assigned IPv6 range.
"""

from __future__ import annotations

from ipaddress import IPv4Address, IPv6Address, IPv6Network


# The well-known prefix — always supported, even if operators add a
# custom one. This is the Google-Public-DNS-compatible prefix.
WELL_KNOWN_PREFIX = IPv6Network("64:ff9b::/96")


class NAT64AddressError(ValueError):
    """Raised when an address cannot be mapped between families."""


def embed_v4_in_v6(v4: IPv4Address, prefix: IPv6Network) -> IPv6Address:
    """Embed an IPv4 address into an IPv6 NAT64 prefix (/96 only, v1).

    Example: embed_v4_in_v6("203.0.113.5", 64:ff9b::/96) -> 64:ff9b::cb00:7105
    """
    if prefix.prefixlen != 96:
        raise NAT64AddressError(
            f"only /96 NAT64 prefixes supported in v1, got /{prefix.prefixlen}"
        )
    # Combine: top 96 bits from prefix, low 32 bits are the v4 address
    prefix_int = int(prefix.network_address)
    v4_int = int(v4)
    combined = prefix_int | v4_int   # prefix's low 32 bits are all-zero
    return IPv6Address(combined)


def extract_v4_from_v6(v6: IPv6Address, prefix: IPv6Network) -> IPv4Address:
    """Extract the embedded IPv4 address from a NAT64 IPv6 address.

    Raises NAT64AddressError if v6 is not within the prefix.
    """
    if prefix.prefixlen != 96:
        raise NAT64AddressError(
            f"only /96 NAT64 prefixes supported in v1, got /{prefix.prefixlen}"
        )
    if v6 not in prefix:
        raise NAT64AddressError(
            f"address {v6} is not within prefix {prefix}"
        )
    v6_int = int(v6)
    v4_int = v6_int & 0xFFFFFFFF  # low 32 bits
    return IPv4Address(v4_int)


def is_nat64_address(v6: IPv6Address, prefix: IPv6Network) -> bool:
    """True if the v6 address falls within the NAT64 prefix."""
    return v6 in prefix


def parse_nat64_prefix(text: str) -> IPv6Network:
    """Parse a NAT64 prefix string, enforcing /96.

    Accepts "64:ff9b::/96" or just "64:ff9b::" (defaults to /96 per
    RFC 6052 for v1.0).
    """
    text = text.strip()
    if "/" not in text:
        text = text + "/96"
    net = IPv6Network(text, strict=False)
    if net.prefixlen != 96:
        raise NAT64AddressError(
            f"NAT64 prefix must be /96 in v1, got /{net.prefixlen}"
        )
    return net

"""
ipsec_shim — write strongSwan config, reload the daemon, manage lifecycle.

The shim is the place where N2NHU touches the world. The emitter is
pure; the shim handles:

  - Writing ipsec.conf and ipsec.secrets atomically (write to .new, then
    rename — strongSwan reads files at reload time, so a partial write
    visible to the daemon would be a real bug)
  - chmod 0600 on ipsec.secrets (always)
  - chmod 0644 on ipsec.conf (always)
  - Invoking `ipsec reload` (or a configurable command) to pick up the
    new config
  - Optional dry-run mode that emits but does not write or reload —
    useful for the CLI tool

The reload command is configurable so tests can substitute a mock and
operators can adapt to non-default daemon paths. The default is
`["ipsec", "reload"]` which works for any standard strongSwan install.

Failure handling:
  - File write errors raise IPSecShimError with the underlying cause
  - Daemon reload errors raise IPSecShimError but the files have
    already been written; operator can investigate why reload failed
    (most commonly a syntax error introduced by manual edit, but our
    emitter should not produce those — if it does, a regression test
    is needed)

The shim is single-instance per RouterShim. It does NOT manage
strongSwan's own startup — that's the operator's responsibility (systemd
unit, init script, container entrypoint). The shim assumes strongSwan
is already running and only signals reload.
"""

from __future__ import annotations

import logging
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from .ipsec_models import IPSecConfig
from .object_resolver import ObjectResolver
from .strongswan_emitter import emit_all


_log = logging.getLogger(__name__)


class IPSecShimError(Exception):
    """Raised when the shim cannot fulfill a write or reload request."""


@dataclass
class IPSecShimResult:
    """Outcome of a single render-and-reload cycle."""

    wrote_files: bool
    reloaded_daemon: bool
    ipsec_conf_path: Optional[str]
    ipsec_secrets_path: Optional[str]
    reload_returncode: Optional[int]
    reload_stderr: str = ""
    skipped_reason: str = ""


# Subprocess invocation — typed for easy mocking in tests
SubprocessRunner = Callable[[list[str]], "subprocess.CompletedProcess"]


def _real_runner(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        check=False,
        capture_output=True,
        text=True,
        timeout=15.0,
    )


class IPSecShim:
    """Manages strongSwan config emission and reload.

    Args:
        ipsec_conf_path: Where to write the conn blocks. Default
            /etc/ipsec.conf.
        ipsec_secrets_path: Where to write credentials. Default
            /etc/ipsec.secrets.
        reload_command: argv for the reload invocation. Default
            ["ipsec", "reload"].
        runner: callable that takes argv and returns CompletedProcess.
            Used by tests to substitute a fake. Default is the real
            subprocess.run.
        dry_run: if True, never write files and never invoke reload.
            apply() returns a result describing what would have happened.
    """

    def __init__(
        self,
        *,
        ipsec_conf_path: str | Path = "/etc/ipsec.conf",
        ipsec_secrets_path: str | Path = "/etc/ipsec.secrets",
        reload_command: tuple[str, ...] = ("ipsec", "reload"),
        runner: SubprocessRunner = _real_runner,
        dry_run: bool = False,
    ):
        self.ipsec_conf_path = Path(ipsec_conf_path)
        self.ipsec_secrets_path = Path(ipsec_secrets_path)
        self.reload_command = list(reload_command)
        self.runner = runner
        self.dry_run = dry_run

        # Stats accumulated across apply() calls
        self.applies = 0
        self.writes = 0
        self.reloads = 0
        self.reload_failures = 0

    def apply(
        self,
        cfg: IPSecConfig,
        resolver: ObjectResolver,
    ) -> IPSecShimResult:
        """Render config and (in non-dry-run mode) write + reload.

        If cfg is empty AND no existing files would change, this is a
        no-op except for stats. We still emit and compare so that going
        from a non-empty to empty config correctly removes the conn blocks.
        """
        self.applies += 1
        emitted = emit_all(cfg, resolver)

        if self.dry_run:
            return IPSecShimResult(
                wrote_files=False,
                reloaded_daemon=False,
                ipsec_conf_path=str(self.ipsec_conf_path),
                ipsec_secrets_path=str(self.ipsec_secrets_path),
                reload_returncode=None,
                skipped_reason="dry-run",
            )

        # Write atomically: write to .new, fsync, rename
        try:
            self._write_atomic(
                self.ipsec_conf_path, emitted.ipsec_conf, mode=0o644,
            )
            self._write_atomic(
                self.ipsec_secrets_path, emitted.ipsec_secrets, mode=0o600,
            )
            self.writes += 1
        except OSError as exc:
            raise IPSecShimError(
                f"failed to write strongSwan config: {exc}"
            ) from exc

        # Reload daemon
        cmd = list(self.reload_command)
        try:
            cp = self.runner(cmd)
        except (OSError, subprocess.TimeoutExpired) as exc:
            self.reload_failures += 1
            raise IPSecShimError(
                f"failed to invoke {' '.join(cmd)}: {exc}"
            ) from exc

        if cp.returncode != 0:
            self.reload_failures += 1
            raise IPSecShimError(
                f"reload command exited {cp.returncode}: "
                f"{(cp.stderr or '').strip()}"
            )

        self.reloads += 1
        return IPSecShimResult(
            wrote_files=True,
            reloaded_daemon=True,
            ipsec_conf_path=str(self.ipsec_conf_path),
            ipsec_secrets_path=str(self.ipsec_secrets_path),
            reload_returncode=cp.returncode,
            reload_stderr=cp.stderr or "",
        )

    @staticmethod
    def _write_atomic(path: Path, content: str, *, mode: int) -> None:
        """Write `content` to `path` via a tmp file + rename. The rename
        is atomic on POSIX. Permissions set BEFORE the rename so the
        secrets file never appears with default mode 0644."""
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".new")
        with open(tmp, "w") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)

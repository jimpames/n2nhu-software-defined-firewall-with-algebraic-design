"""
PolicyEngine — the matrix lookup that replaces conditional logic.

evaluate(packet, now) -> Decision

No I/O. No mutation. Pure function of (Config, Packet, now).
"""

from __future__ import annotations

from datetime import datetime
from typing import Sequence

from .models import Action, Config, Decision, Packet, PolicyRule
from .object_resolver import ObjectResolver
from .schedule_evaluator import ScheduleEvaluator
from .zone_map import ZoneMap


class PolicyEngine:
    """Walks the policy matrix in order and returns the first-match verdict."""

    def __init__(
        self,
        config: Config,
        resolver: ObjectResolver | None = None,
        zone_map: ZoneMap | None = None,
        schedule_evaluator: ScheduleEvaluator | None = None,
    ):
        self.config = config
        self.resolver = resolver or ObjectResolver(config.addresses, config.services)
        self.zone_map = zone_map or ZoneMap(
            config.zones, config.interface_to_zone, config.defaults,
        )
        self.schedules = schedule_evaluator or ScheduleEvaluator(config.schedules)
        self._rules: Sequence[PolicyRule] = config.policies

    def evaluate(self, packet: Packet, now: datetime) -> Decision:
        src_zone = self.zone_map.zone_for_interface(packet.ingress_iface)
        dst_zone = self.zone_map.zone_for_interface(packet.egress_iface)

        for rule in self._rules:
            if not self._zone_match(rule.src_zone, src_zone):
                continue
            if not self._zone_match(rule.dst_zone, dst_zone):
                continue
            if not self.resolver.ip_in_address(packet.src_ip, rule.src_addr):
                continue
            if not self.resolver.ip_in_address(packet.dst_ip, rule.dst_addr):
                continue
            if not self.resolver.service_matches(
                rule.service,
                protocol=packet.protocol,
                dst_port=packet.dst_port,
                src_port=packet.src_port,
                icmp_type=packet.icmp_type,
            ):
                continue
            if not self.schedules.matches(rule.schedule, now):
                continue

            return Decision(
                action=rule.action,
                rule_id=rule.id,
                log=rule.log,
                matched_default=False,
                reason=f"matched policy {rule.id}",
            )

        # No policy matched — fall through to defaults
        default_action = self.zone_map.default_action(src_zone, dst_zone)
        return Decision(
            action=default_action,
            rule_id=f"__default_{src_zone}_to_{dst_zone}__",
            log=True,  # defaults are always logged
            matched_default=True,
            reason=f"no policy matched; default for ({src_zone} -> {dst_zone})",
        )

    @staticmethod
    def _zone_match(rule_zone: str, packet_zone: str) -> bool:
        return rule_zone == "any" or rule_zone == packet_zone

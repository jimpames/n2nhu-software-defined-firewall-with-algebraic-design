"""
Policy-Based Routing data models.

Follows the same pattern as NAT: an INI-driven rule list, a pure-function
engine that takes a packet + now and returns an override decision.

Design notes:
- PBR rules are STATELESS. No session table, no port allocation. A match
  returns an override egress interface; the data plane uses it instead of
  the normal route-lookup result.
- PBR matches use the same vocabulary as policy/NAT (zones, address objects,
  services, schedules) plus one new criterion: DSCP. This lets operators
  write QoS-aware routing rules ("send EF/46 out wan2").
- PBR runs AFTER route lookup (so src_zone/dst_zone are known) and BEFORE
  both NAT and policy. Policy still evaluates on pre-NAT addresses.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Optional


class DSCPMatchMode(enum.Enum):
    """How to match the dscp field on a PBR rule."""

    ANY = "any"         # no DSCP constraint (default)
    EQUAL = "equal"     # packet.dscp == rule.dscp_value
    RANGE = "range"     # rule.dscp_min <= packet.dscp <= rule.dscp_max


@dataclass(frozen=True)
class PBRRule:
    """
    A single row in the PBR matrix.

    Matches on the usual zone/object/service/schedule tuple plus an optional
    DSCP criterion. If match succeeds, the packet is routed out `egress_iface`
    regardless of what the route table would have chosen.
    """

    id: str

    # Match criteria (reused from policy engine vocabulary)
    src_zone: str = "any"
    dst_zone: str = "any"
    src_addr: str = "addr_any"
    dst_addr: str = "addr_any"
    service: str = "svc_any"
    schedule: str = "sched_always"

    # DSCP match (new for PBR)
    dscp_mode: DSCPMatchMode = DSCPMatchMode.ANY
    dscp_value: int = 0      # used when mode = EQUAL
    dscp_min: int = 0        # used when mode = RANGE
    dscp_max: int = 63       # used when mode = RANGE

    # Action
    egress_iface: str = ""   # the interface to route to (required)

    log: bool = False
    comment: str = ""


@dataclass(frozen=True)
class PBRConfig:
    """Top-level PBR configuration."""

    rules: tuple[PBRRule, ...] = ()


@dataclass(frozen=True)
class PBRMatch:
    """PBR matched — use this egress instead of route lookup."""

    egress_iface: str
    rule_id: str


@dataclass(frozen=True)
class PBRPassThrough:
    """No PBR rule matched — use normal route lookup."""


# Return union
PBRResult = PBRMatch | PBRPassThrough

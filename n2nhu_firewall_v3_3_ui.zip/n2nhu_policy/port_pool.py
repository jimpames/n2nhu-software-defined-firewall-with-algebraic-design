"""
PortPool — thread-safe port allocator for SNAT.

Strategy: a set of free ports, pulled FIFO via deque. When exhausted,
raise PortPoolExhausted — the caller (NAT engine) decides whether to
try the overflow chain or deny.

This is classic COTS from the book's philosophy: deque + lock, nothing fancy.
Allocation is O(1); release is O(1); exhaustion check is O(1).
"""

from __future__ import annotations

from collections import deque
from threading import Lock
from typing import Deque

from .nat_models import PortPoolSpec


class PortPoolExhausted(Exception):
    """Raised when allocate() is called on an empty pool."""


class PortPool:
    """
    Thread-safe port allocator.

    Allocate: O(1). Release: O(1). Size/exhausted check: O(1).
    Ports are reused FIFO so a freshly-released port won't immediately
    collide with a still-draining TCP TIME_WAIT.
    """

    def __init__(self, spec: PortPoolSpec):
        self.spec = spec
        self._lock = Lock()
        self._free: Deque[int] = deque(range(spec.start, spec.end + 1))
        self._allocated: set[int] = set()

    def allocate(self) -> int:
        with self._lock:
            if not self._free:
                raise PortPoolExhausted(
                    f"no free ports in pool {self.spec.start}-{self.spec.end}"
                )
            port = self._free.popleft()
            self._allocated.add(port)
            return port

    def release(self, port: int) -> None:
        with self._lock:
            if port in self._allocated:
                self._allocated.remove(port)
                self._free.append(port)
            # Releasing an unknown port is a no-op — defensive against
            # double-release on session teardown.

    def available(self) -> int:
        with self._lock:
            return len(self._free)

    def in_use(self) -> int:
        with self._lock:
            return len(self._allocated)

    def is_exhausted(self) -> bool:
        with self._lock:
            return not self._free

    def utilization(self) -> float:
        with self._lock:
            total = self.spec.size
            return len(self._allocated) / total if total else 0.0

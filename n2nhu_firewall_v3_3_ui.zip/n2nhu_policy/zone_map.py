"""
ZoneMap — O(1) interface -> zone lookup and the inter-zone defaults matrix.
"""

from __future__ import annotations

from typing import Mapping

from .errors import ResolverError
from .models import Action, Zone


class ZoneMap:
    """Wraps the interface/zone mappings and the default action matrix."""

    def __init__(
        self,
        zones: Mapping[str, Zone],
        interface_to_zone: Mapping[str, str],
        defaults: Mapping[tuple[str, str], Action],
    ):
        self._zones = dict(zones)
        self._iface = dict(interface_to_zone)
        self._defaults = dict(defaults)

    def zone_for_interface(self, iface: str) -> str:
        if iface not in self._iface:
            raise ResolverError(f"interface {iface!r} not mapped to any zone")
        return self._iface[iface]

    def zone(self, name: str) -> Zone:
        if name not in self._zones:
            raise ResolverError(f"unknown zone: {name!r}")
        return self._zones[name]

    def default_action(self, src_zone: str, dst_zone: str) -> Action:
        """
        Return the default action for a (src, dst) zone pair.
        Falls back to 'any -> <dst>', then '<src> -> any', then 'any -> any',
        then finally DENY if nothing is defined.
        """
        for key in (
            (src_zone, dst_zone),
            ("any", dst_zone),
            (src_zone, "any"),
            ("any", "any"),
        ):
            if key in self._defaults:
                return self._defaults[key]
        return Action.DENY

    @property
    def zones(self) -> Mapping[str, Zone]:
        return self._zones

    @property
    def interfaces(self) -> Mapping[str, str]:
        return self._iface

"""
pcapng_writer — minimal but standards-compliant PcapNG file writer.

Reference: https://www.ietf.org/archive/id/draft-tuexen-opsawg-pcapng-02.html
            https://github.com/pcapng/pcapng

This writer produces three block types only, sufficient for representing
N2NHU captures:

  * Section Header Block (SHB)            — once per file, at the start
  * Interface Description Block (IDB)     — once per file (single iface)
  * Enhanced Packet Block (EPB)           — one per captured frame

Each EPB carries an opt_comment (option code 1) populated with the
capture annotations: capture_point, decision, rule_id, nat_rule_id,
pbr_rule_id. Wireshark renders these in the "Packet comments" tree
of the packet detail pane natively.

All multi-byte fields use the host byte order, signaled by the SHB's
byte-order magic (0x1A2B3C4D). We always emit little-endian on
little-endian hosts and big-endian on big-endian hosts; readers (incl.
Wireshark) handle both.

Block layout (every block):
  uint32 block_type
  uint32 block_total_length         # total bytes incl. trailer
  ... body, padded to 4-byte boundary ...
  uint32 block_total_length         # repeated, for backward iteration
"""

from __future__ import annotations

import os
import struct
import sys
import threading
import time
from pathlib import Path
from typing import Optional


BLOCK_TYPE_SHB = 0x0A0D0D0A
BLOCK_TYPE_IDB = 0x00000001
BLOCK_TYPE_EPB = 0x00000006

BYTE_ORDER_MAGIC = 0x1A2B3C4D
PCAPNG_VERSION = (1, 0)
LINKTYPE_ETHERNET = 1

OPT_END = 0
OPT_COMMENT = 1
OPT_IF_NAME = 2
OPT_IF_DESC = 3

# Native byte order for this host. Wireshark detects from the SHB.
_NATIVE = "<" if sys.byteorder == "little" else ">"


def _pad4(n: int) -> int:
    """Round up to next multiple of 4."""
    return (n + 3) & ~3


def _option(code: int, value: bytes) -> bytes:
    """Encode a single option: code(2) + length(2) + value(padded to 4)."""
    if not (0 <= code <= 0xFFFF):
        raise ValueError(f"option code out of range: {code}")
    if len(value) > 0xFFFF:
        raise ValueError(f"option value too long: {len(value)} bytes")
    header = struct.pack(_NATIVE + "HH", code, len(value))
    pad = b"\x00" * (_pad4(len(value)) - len(value))
    return header + value + pad


def _option_block_end() -> bytes:
    """The opt_endofopt option that terminates an options list."""
    return struct.pack(_NATIVE + "HH", OPT_END, 0)


def encode_shb() -> bytes:
    """Section Header Block — minimum-options form."""
    body = struct.pack(
        _NATIVE + "IHHQ",
        BYTE_ORDER_MAGIC,
        PCAPNG_VERSION[0], PCAPNG_VERSION[1],
        # Section length: -1 (unknown). PcapNG spec calls this an int64.
        # 0xFFFFFFFFFFFFFFFF is two's-complement -1 in 64 bits.
        (1 << 64) - 1,
    )
    total_len = 8 + len(body) + 4  # type + first_len + body + trailer_len
    return (
        struct.pack(_NATIVE + "II", BLOCK_TYPE_SHB, total_len)
        + body
        + struct.pack(_NATIVE + "I", total_len)
    )


def encode_idb(snap_len: int = 65535, name: Optional[str] = None) -> bytes:
    """Interface Description Block — Ethernet, single interface (id 0).

    The reader maps EPB.interface_id → this IDB by index. Since we only
    emit one IDB, every EPB uses interface_id=0.
    """
    body = struct.pack(
        _NATIVE + "HHI",
        LINKTYPE_ETHERNET, 0,    # linktype, reserved
        snap_len,
    )

    # Optional interface name option
    options = b""
    if name is not None:
        options += _option(OPT_IF_NAME, name.encode("utf-8"))
    if options:
        options += _option_block_end()

    total_len = 8 + len(body) + len(options) + 4
    return (
        struct.pack(_NATIVE + "II", BLOCK_TYPE_IDB, total_len)
        + body
        + options
        + struct.pack(_NATIVE + "I", total_len)
    )


def encode_epb(
    interface_id: int,
    timestamp_us: int,
    captured_data: bytes,
    original_length: int,
    comment: Optional[str] = None,
) -> bytes:
    """Enhanced Packet Block.

    Args:
        interface_id: index into the IDB list (always 0 for us).
        timestamp_us: microseconds since Unix epoch. Stored as a pair of
            uint32s — high then low — interpreted as a single uint64 in
            "resolution units"; default resolution is microseconds.
        captured_data: the bytes actually recorded (may be shorter than
            original_length if snap_len truncated).
        original_length: full size of the frame as it was on the wire.
        comment: optional UTF-8 comment recorded as an opt_comment option.
    """
    if interface_id < 0:
        raise ValueError(f"negative interface_id: {interface_id}")

    captured_len = len(captured_data)
    pad_len = _pad4(captured_len) - captured_len
    ts_high = (timestamp_us >> 32) & 0xFFFFFFFF
    ts_low = timestamp_us & 0xFFFFFFFF

    body = struct.pack(
        _NATIVE + "IIIII",
        interface_id,
        ts_high, ts_low,
        captured_len, original_length,
    ) + captured_data + (b"\x00" * pad_len)

    options = b""
    if comment is not None:
        options += _option(OPT_COMMENT, comment.encode("utf-8"))
    if options:
        options += _option_block_end()

    total_len = 8 + len(body) + len(options) + 4
    return (
        struct.pack(_NATIVE + "II", BLOCK_TYPE_EPB, total_len)
        + body
        + options
        + struct.pack(_NATIVE + "I", total_len)
    )


# ---------------------------------------------------------------------------
# File-level writer with rotation
# ---------------------------------------------------------------------------


class PcapngWriter:
    """Append-only PcapNG file writer with size-based rotation.

    Thread-safe: a single lock protects the file handle and rotation
    state. Callers should not assume any particular fsync semantics —
    use flush() between major write batches if durability matters.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        snap_len: int = 65535,
        rotate_size_bytes: int = 0,    # 0 = never rotate
        rotate_keep: int = 0,          # 0 = keep all rotated files
        interface_name: Optional[str] = None,
    ):
        self.path = Path(path)
        self.snap_len = snap_len
        self.rotate_size_bytes = rotate_size_bytes
        self.rotate_keep = rotate_keep
        self.interface_name = interface_name

        self._lock = threading.Lock()
        self._fp = None
        self._bytes_written = 0
        self._frames_written = 0
        self._open()

    def _open(self) -> None:
        """Open (or create) the file and emit SHB+IDB if it's empty."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        existed = self.path.exists() and self.path.stat().st_size > 0
        self._fp = open(self.path, "ab")
        if not existed:
            shb = encode_shb()
            idb = encode_idb(snap_len=self.snap_len, name=self.interface_name)
            self._fp.write(shb)
            self._fp.write(idb)
            self._bytes_written = len(shb) + len(idb)
            self._fp.flush()
        else:
            self._bytes_written = self.path.stat().st_size

    def write_frame(
        self,
        frame: bytes,
        *,
        timestamp_us: Optional[int] = None,
        comment: Optional[str] = None,
    ) -> None:
        """Append one Enhanced Packet Block to the file.

        If snap_len is set and frame exceeds it, the frame is truncated
        and the original length is preserved in the EPB header — Wireshark
        displays this as a truncated capture, which is the standard
        convention.
        """
        if self._fp is None:
            return  # closed

        if timestamp_us is None:
            timestamp_us = int(time.time() * 1_000_000)

        original_length = len(frame)
        captured = frame
        if self.snap_len > 0 and len(captured) > self.snap_len:
            captured = captured[: self.snap_len]

        block = encode_epb(
            interface_id=0,
            timestamp_us=timestamp_us,
            captured_data=captured,
            original_length=original_length,
            comment=comment,
        )

        with self._lock:
            if self._fp is None:
                return
            self._fp.write(block)
            self._bytes_written += len(block)
            self._frames_written += 1

            if (self.rotate_size_bytes > 0 and
                    self._bytes_written >= self.rotate_size_bytes):
                self._rotate_locked()

    def flush(self) -> None:
        with self._lock:
            if self._fp is not None:
                self._fp.flush()

    def close(self) -> None:
        with self._lock:
            if self._fp is not None:
                try:
                    self._fp.flush()
                    self._fp.close()
                finally:
                    self._fp = None

    @property
    def bytes_written(self) -> int:
        return self._bytes_written

    @property
    def frames_written(self) -> int:
        return self._frames_written

    # ---- rotation ----

    def _rotate_locked(self) -> None:
        """Caller must hold self._lock. Closes current file, renames it
        with a timestamp suffix, opens a fresh primary file.
        """
        self._fp.flush()
        self._fp.close()
        self._fp = None

        ts = time.strftime("%Y%m%d-%H%M%S")
        rotated = self.path.with_name(f"{self.path.stem}.{ts}{self.path.suffix}")
        # Avoid collision if the same second produces multiple rotates
        n = 0
        candidate = rotated
        while candidate.exists():
            n += 1
            candidate = self.path.with_name(
                f"{self.path.stem}.{ts}.{n}{self.path.suffix}"
            )
        os.rename(self.path, candidate)

        if self.rotate_keep > 0:
            self._prune_locked()

        self._bytes_written = 0
        self._frames_written = 0
        self._open()

    def _prune_locked(self) -> None:
        """Caller must hold self._lock. Removes rotated files beyond the
        retention count, oldest first."""
        prefix = f"{self.path.stem}."
        suffix = self.path.suffix
        siblings = []
        for p in self.path.parent.iterdir():
            if (p.name.startswith(prefix)
                    and p.name.endswith(suffix)
                    and p.name != self.path.name):
                try:
                    siblings.append((p.stat().st_mtime, p))
                except OSError:
                    continue
        siblings.sort()  # oldest first
        excess = len(siblings) - self.rotate_keep
        for _mtime, p in siblings[: max(0, excess)]:
            try:
                p.unlink()
            except OSError:
                pass

    def __enter__(self) -> "PcapngWriter":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

"""
icmpv6 — IPv6 semantics support for the firewall.

Two responsibilities:

1. Classify ICMPv6 message types per RFC 4890 into three categories:
     - MUST_PERMIT: dropping these breaks IPv6 entirely (ND, PTB, etc.)
     - SHOULD_PERMIT: useful for diagnostics (echo), generally permitted
     - DISCRETIONARY: operator choice (experimental, mobility, etc.)

2. Classify IPv6 addresses into scopes:
     - LINK_LOCAL (fe80::/10): valid only within one link
     - SITE_LOCAL (fec0::/10, deprecated): historical; we reject
     - UNIQUE_LOCAL (fc00::/7): private, cross-link, non-routable globally
     - MULTICAST (ff00::/8): various scopes, ff02 = link-local mcast
     - LOOPBACK (::1/128)
     - UNSPECIFIED (::/128)
     - GLOBAL: everything else

The firewall uses classify_address() to enforce that link-local traffic
doesn't cross zone boundaries. A packet with src or dst in fe80::/10
can only traverse inside a single zone — routing it between zones is
a configuration error that we drop at the shim layer.

Reference: RFC 4443 (ICMPv6), RFC 4291 (addressing), RFC 4890 (firewall).
"""

from __future__ import annotations

import enum
from ipaddress import IPv6Address, IPv6Network


# ----------------------------------------------------------------------
# ICMPv6 type categorization per RFC 4890
# ----------------------------------------------------------------------


class ICMPv6Category(enum.Enum):
    MUST_PERMIT = "must_permit"       # breaks IPv6 if dropped
    SHOULD_PERMIT = "should_permit"   # strongly recommended
    DISCRETIONARY = "discretionary"   # operator choice
    UNKNOWN = "unknown"


# Per RFC 4890 §4.3 and §4.4. Error messages in 0-127 are MUST_PERMIT;
# informational messages in 128-255 are mostly SHOULD_PERMIT except for
# Neighbor Discovery which is MUST_PERMIT to keep the network alive.
_MUST_PERMIT_TYPES: frozenset[int] = frozenset({
    # Error messages — MUST be permitted for v6 to function (RFC 4890 §4.3.1)
    1,   # Destination Unreachable
    2,   # Packet Too Big — critical for PMTUD, dropping breaks everything
    3,   # Time Exceeded
    4,   # Parameter Problem
    # Neighbor Discovery — without these, hosts can't discover each other
    # on a link (RFC 4890 §4.4.1)
    133, # Router Solicitation
    134, # Router Advertisement
    135, # Neighbor Solicitation
    136, # Neighbor Advertisement
    141, # Inverse Neighbor Discovery Solicitation
    142, # Inverse Neighbor Discovery Advertisement
    # Multicast Listener Discovery v2 (RFC 4890 §4.4.2)
    130, # MLD Query
    131, # MLD Report (v1)
    132, # MLD Done
    143, # MLDv2 Report
})

_SHOULD_PERMIT_TYPES: frozenset[int] = frozenset({
    128, # Echo Request — diagnostics
    129, # Echo Reply
})

_DISCRETIONARY_TYPES: frozenset[int] = frozenset({
    # Mobility (RFC 6275) — discretionary per RFC 4890
    144, 145, 146, 147,
    # SEND (Secure Neighbor Discovery)
    148, 149,
    # Multicast Router Discovery
    151, 152, 153,
})


def classify_icmpv6_type(icmp_type: int) -> ICMPv6Category:
    """Return the RFC 4890 category for an ICMPv6 message type."""
    if icmp_type in _MUST_PERMIT_TYPES:
        return ICMPv6Category.MUST_PERMIT
    if icmp_type in _SHOULD_PERMIT_TYPES:
        return ICMPv6Category.SHOULD_PERMIT
    if icmp_type in _DISCRETIONARY_TYPES:
        return ICMPv6Category.DISCRETIONARY
    return ICMPv6Category.UNKNOWN


def is_essential_icmpv6(icmp_type: int) -> bool:
    """True if dropping this type breaks IPv6 operation.

    Used by the firewall's default deny rules — essential ICMPv6 is
    always permitted regardless of policy, before any deny rule applies.
    """
    return icmp_type in _MUST_PERMIT_TYPES


# Service-group defaults used by the UI's Restore-Defaults feature and
# documented in the operator manual. These are the ICMPv6 types the
# shipped security.ini default config permits unconditionally.
ESSENTIAL_ICMPV6_TYPES: tuple[int, ...] = tuple(sorted(_MUST_PERMIT_TYPES))
DIAGNOSTIC_ICMPV6_TYPES: tuple[int, ...] = tuple(sorted(_SHOULD_PERMIT_TYPES))


# ----------------------------------------------------------------------
# IPv6 address scope classification
# ----------------------------------------------------------------------


class AddressScope(enum.Enum):
    GLOBAL = "global"              # normal, globally-routable
    LINK_LOCAL = "link_local"      # fe80::/10 — one link only
    UNIQUE_LOCAL = "unique_local"  # fc00::/7 — private, org-wide
    SITE_LOCAL = "site_local"      # fec0::/10 — deprecated
    MULTICAST = "multicast"        # ff00::/8
    LOOPBACK = "loopback"          # ::1
    UNSPECIFIED = "unspecified"    # ::


# Predefined networks for scope classification — computed once at module load.
_LINK_LOCAL_NET = IPv6Network("fe80::/10")
_SITE_LOCAL_NET = IPv6Network("fec0::/10")
_UNIQUE_LOCAL_NET = IPv6Network("fc00::/7")
_MULTICAST_NET = IPv6Network("ff00::/8")
_LOOPBACK = IPv6Address("::1")
_UNSPECIFIED = IPv6Address("::")


def classify_address(addr: IPv6Address) -> AddressScope:
    """Return the scope of an IPv6 address.

    Order matters: loopback/unspecified are single addresses and checked
    first; multicast overlaps with nothing else; link/site/unique local
    are ordered by prefix length (most specific first).
    """
    if addr == _LOOPBACK:
        return AddressScope.LOOPBACK
    if addr == _UNSPECIFIED:
        return AddressScope.UNSPECIFIED
    if addr in _MULTICAST_NET:
        return AddressScope.MULTICAST
    if addr in _LINK_LOCAL_NET:
        return AddressScope.LINK_LOCAL
    if addr in _SITE_LOCAL_NET:
        return AddressScope.SITE_LOCAL
    if addr in _UNIQUE_LOCAL_NET:
        return AddressScope.UNIQUE_LOCAL
    return AddressScope.GLOBAL


def is_link_local(addr: IPv6Address) -> bool:
    """Link-local addresses (fe80::/10) are scoped to one link.

    These must never traverse a zone boundary. The shim drops link-local
    traffic whose ingress and egress interfaces are in different zones.
    """
    return addr in _LINK_LOCAL_NET


def is_multicast(addr: IPv6Address) -> bool:
    return addr in _MULTICAST_NET


# Solicited-node multicast prefix — used by Neighbor Discovery.
# NS messages are sent to ff02::1:ff00:0/104 addresses.
_SOLICITED_NODE_PREFIX = IPv6Network("ff02::1:ff00:0/104")


def is_solicited_node_multicast(addr: IPv6Address) -> bool:
    """True if addr is a solicited-node multicast address per RFC 4291.

    ND hosts subscribe to these to answer Neighbor Solicitations.
    """
    return addr in _SOLICITED_NODE_PREFIX

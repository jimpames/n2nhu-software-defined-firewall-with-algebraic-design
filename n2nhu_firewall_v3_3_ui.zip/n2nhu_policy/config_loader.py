"""
ConfigLoader — reads the INI tree and emits a validated Config.

Philosophy:
- Parse everything in a side-buffer. Only return on full success.
- Unknown keys raise — typos should not silently become "default behavior".
- Every error carries a source file + section name.
"""

from __future__ import annotations

import configparser
from ipaddress import IPv4Address, IPv4Network, ip_address, ip_network
from pathlib import Path
from typing import Iterable

from .errors import ConfigError
from .models import (
    Action,
    AddressObject,
    AddressType,
    Config,
    PolicyRule,
    PortRange,
    Protocol,
    Schedule,
    ScheduleType,
    ServiceObject,
    Zone,
)


# ---------------------------------------------------------------------------
# Allowed keys per section type (unknown keys raise)
# ---------------------------------------------------------------------------

_ZONE_KEYS = {"security_level", "description", "mgt_plane"}
_ADDR_LEAF_KEYS = {"type", "value", "ttl"}
_ADDR_GROUP_KEYS = {"type", "members"}
_SVC_LEAF_KEYS = {"protocol", "dst_port", "src_port", "icmp_type"}
_SVC_GROUP_KEYS = {"type", "members"}
_SCHED_KEYS = {"type", "days", "start", "end", "timezone"}
_POLICY_KEYS = {
    "src_zone",
    "dst_zone",
    "src_addr",
    "dst_addr",
    "service",
    "schedule",
    "action",
    "log",
    "comment",
}

_WEEKDAYS = {
    "mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6,
}


def _parse_bool(raw: str, *, source: str, section: str, key: str) -> bool:
    val = raw.strip().lower()
    if val in ("true", "yes", "1", "on"):
        return True
    if val in ("false", "no", "0", "off"):
        return False
    raise ConfigError(f"'{key}' must be true/false, got {raw!r}", source=source, section=section)


def _parse_int(raw: str, *, source: str, section: str, key: str) -> int:
    try:
        return int(raw.strip())
    except ValueError as exc:
        raise ConfigError(f"'{key}' must be integer, got {raw!r}", source=source, section=section) from exc


def _parse_csv(raw: str) -> tuple[str, ...]:
    """Parse a comma-separated string (possibly multi-line) into a tuple of trimmed strings."""
    if not raw:
        return ()
    parts = [p.strip() for p in raw.replace("\n", ",").split(",")]
    return tuple(p for p in parts if p)


def _check_keys(
    section_keys: Iterable[str],
    allowed: set[str],
    *,
    source: str,
    section: str,
) -> None:
    unknown = set(section_keys) - allowed
    if unknown:
        raise ConfigError(
            f"unknown keys: {sorted(unknown)}. Allowed: {sorted(allowed)}",
            source=source,
            section=section,
        )


def _read_ini(path: Path) -> configparser.ConfigParser:
    if not path.exists():
        raise ConfigError(f"missing file: {path}", source=str(path))
    cp = configparser.ConfigParser()
    # Strict mode catches duplicate sections/keys
    cp.optionxform = str  # preserve key case
    try:
        cp.read(path, encoding="utf-8")
    except configparser.Error as exc:
        raise ConfigError(f"INI parse error: {exc}", source=str(path)) from exc
    return cp


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


class ConfigLoader:
    """Loads the INI tree from a root directory and produces a validated Config."""

    def __init__(self, root: str | Path):
        self.root = Path(root)

    def load(self) -> Config:
        zones, iface_to_zone, defaults = self._load_zones()
        addresses = self._load_addresses()
        services = self._load_services()
        schedules = self._load_schedules()
        policies = self._load_policies(zones, addresses, services, schedules)

        # Sanity check: every interface maps to a declared zone
        for iface, zone_name in iface_to_zone.items():
            if zone_name not in zones:
                raise ConfigError(
                    f"interface {iface!r} assigned to undeclared zone {zone_name!r}",
                    source="zones.ini",
                )

        return Config(
            zones=zones,
            interface_to_zone=iface_to_zone,
            defaults=defaults,
            addresses=addresses,
            services=services,
            schedules=schedules,
            policies=policies,
        )

    # -----------------------------------------------------------------------
    # zones.ini
    # -----------------------------------------------------------------------

    def _load_zones(self) -> tuple[dict[str, Zone], dict[str, str], dict[tuple[str, str], Action]]:
        path = self.root / "zones.ini"
        cp = _read_ini(path)
        source = "zones.ini"

        if "zones" not in cp:
            raise ConfigError("[zones] section missing", source=source)

        # Interface -> zone mapping
        iface_to_zone: dict[str, str] = {}
        declared_zones: set[str] = set()
        for zone_name, raw_ifaces in cp["zones"].items():
            declared_zones.add(zone_name)
            for iface in _parse_csv(raw_ifaces):
                if iface in iface_to_zone:
                    raise ConfigError(
                        f"interface {iface!r} assigned to multiple zones: "
                        f"{iface_to_zone[iface]!r} and {zone_name!r}",
                        source=source,
                        section="zones",
                    )
                iface_to_zone[iface] = zone_name

        # Zone metadata
        zones: dict[str, Zone] = {}
        for zone_name in declared_zones:
            sect_name = f"zone_{zone_name}"
            if sect_name in cp:
                _check_keys(cp[sect_name].keys(), _ZONE_KEYS, source=source, section=sect_name)
                zones[zone_name] = Zone(
                    name=zone_name,
                    security_level=_parse_int(
                        cp[sect_name].get("security_level", "0"),
                        source=source, section=sect_name, key="security_level",
                    ),
                    description=cp[sect_name].get("description", ""),
                    mgt_plane=_parse_bool(
                        cp[sect_name].get("mgt_plane", "false"),
                        source=source, section=sect_name, key="mgt_plane",
                    ),
                )
            else:
                zones[zone_name] = Zone(name=zone_name)

        # Defaults matrix
        defaults: dict[tuple[str, str], Action] = {}
        if "defaults" in cp:
            for key, raw_action in cp["defaults"].items():
                if not key.startswith("default_") or "_to_" not in key:
                    raise ConfigError(
                        f"default key {key!r} must be 'default_<src>_to_<dst>'",
                        source=source, section="defaults",
                    )
                body = key[len("default_"):]
                src, _, dst = body.partition("_to_")
                if not src or not dst:
                    raise ConfigError(
                        f"cannot parse src/dst from default key {key!r}",
                        source=source, section="defaults",
                    )
                try:
                    defaults[(src, dst)] = Action.parse(raw_action)
                except ValueError as exc:
                    raise ConfigError(str(exc), source=source, section="defaults") from exc

        return zones, iface_to_zone, defaults

    # -----------------------------------------------------------------------
    # objects/addresses.ini
    # -----------------------------------------------------------------------

    def _load_addresses(self) -> dict[str, AddressObject]:
        path = self.root / "objects" / "addresses.ini"
        cp = _read_ini(path)
        source = "objects/addresses.ini"
        addresses: dict[str, AddressObject] = {}

        for section in cp.sections():
            if "type" not in cp[section]:
                raise ConfigError("missing 'type' key", source=source, section=section)
            try:
                addr_type = AddressType.parse(cp[section]["type"])
            except ValueError as exc:
                raise ConfigError(str(exc), source=source, section=section) from exc

            if addr_type == AddressType.GROUP:
                _check_keys(cp[section].keys(), _ADDR_GROUP_KEYS, source=source, section=section)
                if "members" not in cp[section]:
                    raise ConfigError("group missing 'members'", source=source, section=section)
                members = _parse_csv(cp[section]["members"])
                if not members:
                    raise ConfigError("group has empty 'members'", source=source, section=section)
                addresses[section] = AddressObject(id=section, type=addr_type, members=members)
                continue

            _check_keys(cp[section].keys(), _ADDR_LEAF_KEYS, source=source, section=section)
            if "value" not in cp[section]:
                raise ConfigError("leaf object missing 'value'", source=source, section=section)
            value = cp[section]["value"].strip()

            try:
                if addr_type == AddressType.HOST:
                    host = ip_address(value)
                    addresses[section] = AddressObject(id=section, type=addr_type, host=host)

                elif addr_type == AddressType.NETWORK:
                    net = ip_network(value, strict=False)
                    addresses[section] = AddressObject(id=section, type=addr_type, network=net)

                elif addr_type == AddressType.RANGE:
                    if "-" not in value:
                        raise ValueError(f"range must be 'start-end', got {value!r}")
                    lo, hi = (v.strip() for v in value.split("-", 1))
                    lo_ip = ip_address(lo)
                    hi_ip = ip_address(hi)
                    if lo_ip.version != hi_ip.version:
                        raise ValueError(
                            f"range start/end must be same IP version, got v{lo_ip.version}-v{hi_ip.version}"
                        )
                    if int(lo_ip) > int(hi_ip):
                        raise ValueError(f"range start > end: {value!r}")
                    addresses[section] = AddressObject(
                        id=section, type=addr_type, range_start=lo_ip, range_end=hi_ip,
                    )

                elif addr_type == AddressType.FQDN:
                    ttl = _parse_int(
                        cp[section].get("ttl", "3600"),
                        source=source, section=section, key="ttl",
                    )
                    addresses[section] = AddressObject(
                        id=section, type=addr_type, fqdn=value, fqdn_ttl=ttl,
                    )
            except ValueError as exc:
                raise ConfigError(str(exc), source=source, section=section) from exc

        return addresses

    # -----------------------------------------------------------------------
    # objects/services.ini
    # -----------------------------------------------------------------------

    def _parse_port(self, raw: str, *, source: str, section: str, key: str) -> PortRange:
        raw = raw.strip()
        if "-" in raw:
            lo, hi = (v.strip() for v in raw.split("-", 1))
            try:
                lo_i, hi_i = int(lo), int(hi)
            except ValueError as exc:
                raise ConfigError(
                    f"{key!r} range not integer: {raw!r}",
                    source=source, section=section,
                ) from exc
        else:
            try:
                lo_i = hi_i = int(raw)
            except ValueError as exc:
                raise ConfigError(
                    f"{key!r} not integer: {raw!r}",
                    source=source, section=section,
                ) from exc
        if not (0 <= lo_i <= 65535 and 0 <= hi_i <= 65535):
            raise ConfigError(
                f"{key!r} out of range 0-65535: {raw!r}",
                source=source, section=section,
            )
        if lo_i > hi_i:
            raise ConfigError(
                f"{key!r} range start > end: {raw!r}",
                source=source, section=section,
            )
        return PortRange(lo_i, hi_i)

    def _load_services(self) -> dict[str, ServiceObject]:
        path = self.root / "objects" / "services.ini"
        cp = _read_ini(path)
        source = "objects/services.ini"
        services: dict[str, ServiceObject] = {}

        for section in cp.sections():
            # Group detection: 'type = group'
            if cp[section].get("type", "").strip().lower() == "group":
                _check_keys(cp[section].keys(), _SVC_GROUP_KEYS, source=source, section=section)
                members = _parse_csv(cp[section].get("members", ""))
                if not members:
                    raise ConfigError("group has empty 'members'", source=source, section=section)
                services[section] = ServiceObject(id=section, is_group=True, members=members)
                continue

            _check_keys(cp[section].keys(), _SVC_LEAF_KEYS, source=source, section=section)
            if "protocol" not in cp[section]:
                raise ConfigError("missing 'protocol'", source=source, section=section)
            try:
                proto = Protocol.parse(cp[section]["protocol"])
            except ValueError as exc:
                raise ConfigError(str(exc), source=source, section=section) from exc

            dst_port = None
            src_port = None
            icmp_type = None

            if "dst_port" in cp[section]:
                if proto in (Protocol.ANY, Protocol.ICMP):
                    raise ConfigError(
                        f"'dst_port' not valid for protocol {proto.value}",
                        source=source, section=section,
                    )
                dst_port = self._parse_port(
                    cp[section]["dst_port"], source=source, section=section, key="dst_port",
                )
            if "src_port" in cp[section]:
                if proto in (Protocol.ANY, Protocol.ICMP):
                    raise ConfigError(
                        f"'src_port' not valid for protocol {proto.value}",
                        source=source, section=section,
                    )
                src_port = self._parse_port(
                    cp[section]["src_port"], source=source, section=section, key="src_port",
                )
            if "icmp_type" in cp[section]:
                if proto not in (Protocol.ICMP, Protocol.ICMPV6):
                    raise ConfigError(
                        "'icmp_type' only valid for protocol icmp or icmpv6",
                        source=source, section=section,
                    )
                icmp_type = _parse_int(
                    cp[section]["icmp_type"], source=source, section=section, key="icmp_type",
                )

            services[section] = ServiceObject(
                id=section,
                protocol=proto,
                dst_port=dst_port,
                src_port=src_port,
                icmp_type=icmp_type,
            )

        return services

    # -----------------------------------------------------------------------
    # objects/schedules.ini
    # -----------------------------------------------------------------------

    def _load_schedules(self) -> dict[str, Schedule]:
        path = self.root / "objects" / "schedules.ini"
        cp = _read_ini(path)
        source = "objects/schedules.ini"
        schedules: dict[str, Schedule] = {}

        for section in cp.sections():
            _check_keys(cp[section].keys(), _SCHED_KEYS, source=source, section=section)
            if "type" not in cp[section]:
                raise ConfigError("missing 'type'", source=source, section=section)
            try:
                sched_type = ScheduleType.parse(cp[section]["type"])
            except ValueError as exc:
                raise ConfigError(str(exc), source=source, section=section) from exc

            tz = cp[section].get("timezone", "UTC")

            if sched_type == ScheduleType.ALWAYS:
                schedules[section] = Schedule(id=section, type=sched_type, timezone=tz)

            elif sched_type == ScheduleType.RECURRING:
                for required in ("days", "start", "end"):
                    if required not in cp[section]:
                        raise ConfigError(
                            f"recurring schedule missing {required!r}",
                            source=source, section=section,
                        )
                day_names = _parse_csv(cp[section]["days"])
                days: list[int] = []
                for d in day_names:
                    key = d.strip().lower()[:3]
                    if key not in _WEEKDAYS:
                        raise ConfigError(
                            f"unknown day {d!r}. Use mon,tue,wed,thu,fri,sat,sun.",
                            source=source, section=section,
                        )
                    days.append(_WEEKDAYS[key])
                start = cp[section]["start"].strip()
                end = cp[section]["end"].strip()
                self._validate_hhmm(start, source=source, section=section, key="start")
                self._validate_hhmm(end, source=source, section=section, key="end")
                schedules[section] = Schedule(
                    id=section,
                    type=sched_type,
                    days=tuple(sorted(set(days))),
                    start_time=start,
                    end_time=end,
                    timezone=tz,
                )

            elif sched_type == ScheduleType.ONE_TIME:
                for required in ("start", "end"):
                    if required not in cp[section]:
                        raise ConfigError(
                            f"one_time schedule missing {required!r}",
                            source=source, section=section,
                        )
                start = cp[section]["start"].strip()
                end = cp[section]["end"].strip()
                schedules[section] = Schedule(
                    id=section,
                    type=sched_type,
                    start_datetime=start,
                    end_datetime=end,
                    timezone=tz,
                )

        return schedules

    def _validate_hhmm(self, raw: str, *, source: str, section: str, key: str) -> None:
        parts = raw.split(":")
        if len(parts) != 2:
            raise ConfigError(
                f"{key!r} must be HH:MM, got {raw!r}",
                source=source, section=section,
            )
        try:
            h, m = int(parts[0]), int(parts[1])
        except ValueError as exc:
            raise ConfigError(
                f"{key!r} must be HH:MM integers, got {raw!r}",
                source=source, section=section,
            ) from exc
        if not (0 <= h <= 23 and 0 <= m <= 59):
            raise ConfigError(
                f"{key!r} out of range 00:00-23:59, got {raw!r}",
                source=source, section=section,
            )

    # -----------------------------------------------------------------------
    # policies/security.ini
    # -----------------------------------------------------------------------

    def _load_policies(
        self,
        zones: dict[str, Zone],
        addresses: dict[str, AddressObject],
        services: dict[str, ServiceObject],
        schedules: dict[str, Schedule],
    ) -> tuple[PolicyRule, ...]:
        path = self.root / "policies" / "security.ini"
        cp = _read_ini(path)
        source = "policies/security.ini"

        if "policy_order" not in cp:
            raise ConfigError("[policy_order] section missing", source=source)
        if "rules" not in cp["policy_order"]:
            raise ConfigError("[policy_order] missing 'rules'", source=source, section="policy_order")
        order = _parse_csv(cp["policy_order"]["rules"])
        if not order:
            raise ConfigError("[policy_order] 'rules' is empty", source=source, section="policy_order")

        # Check all referenced rules exist
        missing = [r for r in order if r not in cp.sections() or r == "policy_order"]
        missing = [r for r in order if r not in cp.sections()]
        if missing:
            raise ConfigError(
                f"policy_order references undefined rules: {missing}",
                source=source, section="policy_order",
            )

        # Check no duplicates in ordering
        seen: set[str] = set()
        dupes = [r for r in order if r in seen or seen.add(r)]  # type: ignore[func-returns-value]
        if dupes:
            raise ConfigError(
                f"policy_order has duplicate rule IDs: {dupes}",
                source=source, section="policy_order",
            )

        # Parse each rule in declared order
        rules: list[PolicyRule] = []
        valid_zones = set(zones.keys()) | {"any"}
        valid_addrs = set(addresses.keys())
        valid_svcs = set(services.keys())
        valid_scheds = set(schedules.keys())

        for rule_id in order:
            sect = cp[rule_id]
            _check_keys(sect.keys(), _POLICY_KEYS, source=source, section=rule_id)
            for required in ("src_zone", "dst_zone", "src_addr", "dst_addr", "service", "schedule", "action"):
                if required not in sect:
                    raise ConfigError(
                        f"rule missing {required!r}",
                        source=source, section=rule_id,
                    )
            src_zone = sect["src_zone"].strip()
            dst_zone = sect["dst_zone"].strip()
            src_addr = sect["src_addr"].strip()
            dst_addr = sect["dst_addr"].strip()
            service = sect["service"].strip()
            schedule = sect["schedule"].strip()

            if src_zone not in valid_zones:
                raise ConfigError(
                    f"src_zone {src_zone!r} not declared in zones.ini",
                    source=source, section=rule_id,
                )
            if dst_zone not in valid_zones:
                raise ConfigError(
                    f"dst_zone {dst_zone!r} not declared in zones.ini",
                    source=source, section=rule_id,
                )
            if src_addr not in valid_addrs:
                raise ConfigError(
                    f"src_addr {src_addr!r} not defined",
                    source=source, section=rule_id,
                )
            if dst_addr not in valid_addrs:
                raise ConfigError(
                    f"dst_addr {dst_addr!r} not defined",
                    source=source, section=rule_id,
                )
            if service not in valid_svcs:
                raise ConfigError(
                    f"service {service!r} not defined",
                    source=source, section=rule_id,
                )
            if schedule not in valid_scheds:
                raise ConfigError(
                    f"schedule {schedule!r} not defined",
                    source=source, section=rule_id,
                )

            try:
                action = Action.parse(sect["action"])
            except ValueError as exc:
                raise ConfigError(str(exc), source=source, section=rule_id) from exc

            log_flag = _parse_bool(
                sect.get("log", "false"), source=source, section=rule_id, key="log",
            )
            comment = sect.get("comment", "")

            rules.append(PolicyRule(
                id=rule_id,
                src_zone=src_zone,
                dst_zone=dst_zone,
                src_addr=src_addr,
                dst_addr=dst_addr,
                service=service,
                schedule=schedule,
                action=action,
                log=log_flag,
                comment=comment,
            ))

        return tuple(rules)

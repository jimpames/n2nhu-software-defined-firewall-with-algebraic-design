"""
capture_manager — async write path with bounded queues + writer threads.

Architecture:
    - One PcapngWriter per unique pcap_file in the rule set
    - One bounded queue + one writer thread per writer
    - Engine match() result tells us which rules fire; we enqueue the
      frame onto each rule's writer's queue (bounded — drop on overflow)
    - Writer threads drain their queues and call PcapngWriter.write_frame

Why a queue + thread per writer rather than a single thread:
    Writer threads block on file I/O. A single thread serializing all
    writers would let one slow file (rotated, fsync'd, network-mounted)
    starve every other capture. One thread per file isolates the
    blocking domain. The cost is ~1 OS thread per active capture file —
    acceptable for the scale (typically <10 captures simultaneously).

Comment format produced for every frame:
    capture_point=<ingress|post_policy|post_nat>
    decision=<allow|deny|none>
    rule_id=<policy_rule_id_or_empty>
    nat_rule_id=<nat_rule_id_or_empty>
    pbr_rule_id=<pbr_rule_id_or_empty>
    cap_rule=<capture_rule_id>

Wireshark renders this in the Packet Comments tree natively. tcpdump
ignores comments. The format is stable and documented; downstream
tooling (n2nhu_pcap_tool) parses it back into structured fields.
"""

from __future__ import annotations

import logging
import queue
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .capture_models import CaptureConfig, CapturePoint, CaptureRule
from .models import Action
from .pcapng_writer import PcapngWriter


_log = logging.getLogger(__name__)


@dataclass
class _CaptureFrame:
    """Item placed on a writer's queue: the frame plus its annotations."""

    frame: bytes
    timestamp_us: int
    comment: str


@dataclass
class CaptureStats:
    """Per-rule stats. Read with manager.stats()."""

    rule_id: str = ""
    pcap_file: str = ""
    frames_written: int = 0
    frames_dropped_queue_full: int = 0
    bytes_written: int = 0


def format_capture_comment(
    *,
    capture_rule_id: str,
    capture_point: CapturePoint,
    decision_action: Optional[Action],
    policy_rule_id: str = "",
    nat_rule_id: str = "",
    pbr_rule_id: str = "",
) -> str:
    """Build the comment string embedded in each EPB."""
    decision_str = (
        "none" if decision_action is None else decision_action.value.lower()
    )
    return (
        f"capture_point={capture_point.value} "
        f"decision={decision_str} "
        f"rule_id={policy_rule_id} "
        f"nat_rule_id={nat_rule_id} "
        f"pbr_rule_id={pbr_rule_id} "
        f"cap_rule={capture_rule_id}"
    )


class _WriterWorker:
    """Owns one PcapngWriter, one queue, one thread."""

    def __init__(
        self,
        pcap_file: str,
        snap_len: int,
        rotate_size_bytes: int,
        rotate_keep: int,
        queue_depth: int,
    ):
        self.pcap_file = pcap_file
        self.queue: queue.Queue[Optional[_CaptureFrame]] = queue.Queue(
            maxsize=queue_depth
        )
        self.writer = PcapngWriter(
            pcap_file,
            snap_len=snap_len if snap_len > 0 else 65535,
            rotate_size_bytes=rotate_size_bytes,
            rotate_keep=rotate_keep,
        )
        self._stop = threading.Event()
        self.thread = threading.Thread(
            target=self._run,
            name=f"n2nhu-pcap-{Path(pcap_file).name}",
            daemon=True,
        )
        self.frames_written = 0
        self.frames_dropped = 0
        self.bytes_in = 0  # frame bytes received from dataplane
        self.thread.start()

    def submit(self, item: _CaptureFrame) -> bool:
        """Non-blocking enqueue. Returns True if accepted, False if dropped."""
        try:
            self.queue.put_nowait(item)
            return True
        except queue.Full:
            self.frames_dropped += 1
            return False

    def stop(self, *, timeout: float = 2.0) -> None:
        """Drain the queue, signal the thread, and close the writer."""
        self._stop.set()
        # Sentinel wakes the thread if it's blocked on get()
        try:
            self.queue.put(None, timeout=0.1)
        except queue.Full:
            pass
        self.thread.join(timeout=timeout)
        self.writer.close()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                item = self.queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if item is None:
                # Sentinel — flush remaining items then exit
                self._drain_remaining()
                return
            self._write_one(item)

        # Stop was set externally — drain whatever's left
        self._drain_remaining()

    def _drain_remaining(self) -> None:
        while True:
            try:
                item = self.queue.get_nowait()
            except queue.Empty:
                return
            if item is None:
                continue
            self._write_one(item)

    def _write_one(self, item: _CaptureFrame) -> None:
        try:
            self.writer.write_frame(
                item.frame,
                timestamp_us=item.timestamp_us,
                comment=item.comment,
            )
            self.frames_written += 1
            self.bytes_in += len(item.frame)
        except Exception:  # noqa: BLE001 — broad: protect dataplane
            _log.exception(
                "capture writer error for %s; further frames may be lost",
                self.pcap_file,
            )


class CaptureManager:
    """Owns the writer pool keyed by pcap_file. Hand it a list of rules
    + frame and it routes the frame to the right writers asynchronously.

    Lifecycle:
        cm = CaptureManager(capture_config)
        cm.submit(rules, frame, ts_us, comment)
        ...
        cm.stop()              # waits for queues to drain, closes files
    """

    def __init__(self, capture_config: CaptureConfig):
        self.capture_config = capture_config
        self._workers: dict[str, _WriterWorker] = {}
        self._final_stats: dict[str, tuple[int, int, int]] = {}
        self._stopped = False
        self._init_workers()

    def _init_workers(self) -> None:
        """Build one worker per unique pcap_file across enabled rules.

        Two rules sharing the same pcap_file share a writer. The
        most-permissive rotate/snap settings win on conflict, with a
        warning logged. (In practice operators are unlikely to point
        two rules at the same file with different settings; if they
        do, the resulting capture is at least functional.)
        """
        per_file: dict[str, dict] = {}
        for rule in self.capture_config.enabled_rules():
            f = rule.pcap_file
            if f not in per_file:
                per_file[f] = {
                    "snap_len": rule.snap_len,
                    "rotate_size_bytes": rule.rotate_size_mb * 1024 * 1024,
                    "rotate_keep": rule.rotate_keep,
                    "queue_depth": rule.queue_depth,
                }
            else:
                cur = per_file[f]
                # Take the bigger snap_len (0 = full, treat as max)
                if rule.snap_len == 0:
                    cur["snap_len"] = 0
                elif cur["snap_len"] != 0:
                    cur["snap_len"] = max(cur["snap_len"], rule.snap_len)
                cur["queue_depth"] = max(cur["queue_depth"], rule.queue_depth)
                # Conservative on rotate — pick smaller threshold,
                # bigger keep
                if rule.rotate_size_mb > 0:
                    new_bytes = rule.rotate_size_mb * 1024 * 1024
                    if cur["rotate_size_bytes"] == 0:
                        cur["rotate_size_bytes"] = new_bytes
                    else:
                        cur["rotate_size_bytes"] = min(
                            cur["rotate_size_bytes"], new_bytes,
                        )
                cur["rotate_keep"] = max(cur["rotate_keep"], rule.rotate_keep)

        for pcap_file, cfg in per_file.items():
            self._workers[pcap_file] = _WriterWorker(
                pcap_file=pcap_file,
                snap_len=cfg["snap_len"],
                rotate_size_bytes=cfg["rotate_size_bytes"],
                rotate_keep=cfg["rotate_keep"],
                queue_depth=cfg["queue_depth"],
            )

    def submit(
        self,
        matching_rules: tuple[CaptureRule, ...],
        frame: bytes,
        *,
        timestamp_us: int,
        capture_point: CapturePoint,
        decision_action: Optional[Action] = None,
        policy_rule_id: str = "",
        nat_rule_id: str = "",
        pbr_rule_id: str = "",
    ) -> int:
        """Route the frame to every matching rule's writer. Returns the
        number of writers that accepted (vs queue-full drops)."""
        if self._stopped or not matching_rules:
            return 0

        accepted = 0
        for rule in matching_rules:
            worker = self._workers.get(rule.pcap_file)
            if worker is None:
                continue
            comment = format_capture_comment(
                capture_rule_id=rule.id,
                capture_point=capture_point,
                decision_action=decision_action,
                policy_rule_id=policy_rule_id,
                nat_rule_id=nat_rule_id,
                pbr_rule_id=pbr_rule_id,
            )
            item = _CaptureFrame(
                frame=frame,
                timestamp_us=timestamp_us,
                comment=comment,
            )
            if worker.submit(item):
                accepted += 1
        return accepted

    def stop(self, *, timeout_per_writer: float = 2.0) -> None:
        """Drain queues, signal workers, close files. Idempotent."""
        if self._stopped:
            return
        self._stopped = True
        for pcap_file, worker in self._workers.items():
            worker.stop(timeout=timeout_per_writer)
            self._final_stats[pcap_file] = (
                worker.frames_written,
                worker.frames_dropped,
                worker.bytes_in,
            )
        self._workers.clear()

    def stats(self) -> dict[str, CaptureStats]:
        """Return per-rule stats. The mapping is keyed by rule_id, not
        pcap_file, so two rules sharing a file each get their own row
        (with shared frames_written counts only on the writer)."""
        # Aggregate writer-level stats and project to per-rule stats.
        # Use live workers if running, else the snapshot taken at stop().
        out: dict[str, CaptureStats] = {}
        writer_view: dict[str, tuple[int, int, int]] = {}
        if self._workers:
            for pcap_file, w in self._workers.items():
                writer_view[pcap_file] = (
                    w.frames_written, w.frames_dropped, w.bytes_in,
                )
        else:
            writer_view = dict(self._final_stats)
        for rule in self.capture_config.enabled_rules():
            fw, fd, bi = writer_view.get(rule.pcap_file, (0, 0, 0))
            out[rule.id] = CaptureStats(
                rule_id=rule.id,
                pcap_file=rule.pcap_file,
                frames_written=fw,
                frames_dropped_queue_full=fd,
                bytes_written=bi,
            )
        return out

    @property
    def active_files(self) -> tuple[str, ...]:
        return tuple(self._workers.keys())

    def __enter__(self) -> "CaptureManager":
        return self

    def __exit__(self, *exc) -> None:
        self.stop()

"""
capture_models — declarative data model for packet capture.

A capture rule is matched against (packet, decision, capture_point) using
the same vocabulary the policy and PBR engines speak: zones, address
objects, service objects. Rules are evaluated in order; first match wins
per capture_point. A frame may be captured by multiple rules at different
capture points.

Capture points are fixed:
  INGRESS      — frame as it arrived from the wire (pre-policy, pre-NAT)
  POST_POLICY  — frame after policy decision (action visible)
  POST_NAT     — frame after NAT rewrite (output bytes as forwarded)

A rule with capture_point=POST_NAT on a frame that gets dropped at
policy will never trigger — the decision-point ordering is structural.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Optional


class CapturePoint(enum.Enum):
    """Where in the pipeline a frame is observed."""

    INGRESS = "ingress"
    POST_POLICY = "post_policy"
    POST_NAT = "post_nat"


class CaptureMatchAction(enum.Enum):
    """What policy outcome a capture rule wants to see.

    A capture can be restricted to allowed traffic (the common case for
    troubleshooting connectivity), denied traffic (the common case for
    investigating policy enforcement), or any.
    """

    ANY = "any"
    ALLOW = "allow"
    DENY = "deny"


@dataclass(frozen=True)
class CaptureRule:
    """A single capture rule. Matched against the same vocabulary as
    policy: zones, address objects, service objects. ID is the section
    name from capture.ini."""

    id: str
    enabled: bool

    # Which decision point should be observed
    capture_point: CapturePoint

    # Match criteria — all "any" / "addr_any" / "svc_any" by default
    src_zone: str           # zone name or "any"
    dst_zone: str           # zone name or "any"
    src_addr: str           # address object id or "addr_any" / "addr_any_v6"
    dst_addr: str           # address object id
    service: str            # service object id

    # Whether to record allows, denies, or both
    match_action: CaptureMatchAction

    # Output sink configuration
    pcap_file: str          # absolute or relative path
    rotate_size_mb: int     # rotate when this size is reached (0 = never)
    rotate_keep: int        # how many rotated files to retain (0 = keep all)

    # Snap length: max bytes recorded per frame (0 = full frame)
    snap_len: int

    # Bounded queue depth for async writes — frames beyond this are
    # dropped with a counter (rather than blocking the dataplane).
    queue_depth: int


@dataclass(frozen=True)
class CaptureConfig:
    """Top-level capture config. Empty rules tuple = capture disabled."""

    rules: tuple[CaptureRule, ...]

    def enabled_rules(self) -> tuple[CaptureRule, ...]:
        return tuple(r for r in self.rules if r.enabled)

    def rules_for_point(self, point: CapturePoint) -> tuple[CaptureRule, ...]:
        return tuple(
            r for r in self.rules
            if r.enabled and r.capture_point == point
        )

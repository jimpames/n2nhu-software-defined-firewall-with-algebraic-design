"""
Frame codec — parse and rewrite real Ethernet/IPv4/TCP/UDP frames.

This is the byte-level interface between the TAP adapter and our NAT engine.
TAP reads hand us raw frames (Ethernet + IP + L4); we parse to extract the
5-tuple, hand that to NATEngine as a Packet, and if a TranslatedPacket comes
back, we rewrite the frame in place with correct checksums.

No networking imports — just stdlib struct + our existing checksum module.
Pure, testable, byte-exact.

Frame layout:
  Bytes 0..13    — Ethernet header (dst_mac, src_mac, ethertype)
  Bytes 14..33+  — IPv4 header (variable IHL; minimum 20 bytes)
  Bytes 14+ihl.. — TCP/UDP/ICMP/etc payload
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from ipaddress import IPv4Address
from typing import Optional

from .checksum import (
    calculate_ip_checksum,
    update_ip_checksum_for_dst_change,
    update_ip_checksum_for_src_change,
    update_l4_checksum_for_dnat,
    update_l4_checksum_for_snat,
)
from .models import Protocol


# Ethertype for IPv4
ETH_P_IP = 0x0800

# IP protocol numbers
IP_PROTO_ICMP = 1
IP_PROTO_TCP = 6
IP_PROTO_UDP = 17


class FrameParseError(Exception):
    """Raised when a frame is too short or malformed to parse."""


@dataclass(frozen=True)
class ParsedFrame:
    """
    A parsed IPv4 frame. Enough structure to hand to the NAT engine and
    to perform byte-exact rewrites.
    """

    # Raw frame bytes (so we can rewrite against a known baseline)
    raw: bytes

    # Ethernet
    eth_dst: bytes      # 6 bytes
    eth_src: bytes      # 6 bytes
    ethertype: int

    # IPv4
    ip_header_start: int      # index into raw (always 14 for untagged Ethernet)
    ip_header_length: int     # bytes
    ip_version: int
    ip_protocol: int          # 1/6/17/etc.
    ip_total_length: int
    ip_checksum: int
    ip_tos: int               # full TOS byte (DSCP in top 6 bits, ECN in low 2)
    src_ip: IPv4Address
    dst_ip: IPv4Address

    # L4 (TCP/UDP; None for ICMP and unknown)
    l4_header_start: int      # index into raw
    l4_protocol: Protocol     # maps from ip_protocol
    src_port: int             # 0 for non-TCP/UDP
    dst_port: int             # 0 for non-TCP/UDP
    l4_checksum: int          # 0 if not TCP/UDP
    icmp_type: Optional[int]  # only populated for ICMP


def parse_frame(frame: bytes) -> ParsedFrame:
    """
    Parse an Ethernet+IPv4 frame. Raises FrameParseError if the frame is
    too short or not IPv4.
    """
    if len(frame) < 34:  # minimum: 14 Ethernet + 20 IPv4
        raise FrameParseError(f"frame too short: {len(frame)} bytes")

    eth_dst = frame[0:6]
    eth_src = frame[6:12]
    ethertype = struct.unpack("!H", frame[12:14])[0]
    if ethertype != ETH_P_IP:
        raise FrameParseError(f"not IPv4 (ethertype 0x{ethertype:04x})")

    ip_start = 14
    version_ihl = frame[ip_start]
    version = version_ihl >> 4
    if version != 4:
        raise FrameParseError(f"not IPv4 (version {version})")
    ihl = (version_ihl & 0x0F) * 4
    if ihl < 20:
        raise FrameParseError(f"IHL too small: {ihl}")
    if len(frame) < ip_start + ihl:
        raise FrameParseError("frame truncated within IP header")

    total_length = struct.unpack("!H", frame[ip_start + 2:ip_start + 4])[0]
    ip_tos = frame[ip_start + 1]
    ip_protocol = frame[ip_start + 9]
    ip_checksum = struct.unpack("!H", frame[ip_start + 10:ip_start + 12])[0]
    src_ip = IPv4Address(frame[ip_start + 12:ip_start + 16])
    dst_ip = IPv4Address(frame[ip_start + 16:ip_start + 20])

    l4_start = ip_start + ihl
    src_port = 0
    dst_port = 0
    l4_checksum = 0
    icmp_type: Optional[int] = None
    l4_protocol = Protocol.ANY

    if ip_protocol == IP_PROTO_TCP:
        if len(frame) < l4_start + 20:
            raise FrameParseError("frame truncated within TCP header")
        l4_protocol = Protocol.TCP
        src_port = struct.unpack("!H", frame[l4_start:l4_start + 2])[0]
        dst_port = struct.unpack("!H", frame[l4_start + 2:l4_start + 4])[0]
        l4_checksum = struct.unpack("!H", frame[l4_start + 16:l4_start + 18])[0]
    elif ip_protocol == IP_PROTO_UDP:
        if len(frame) < l4_start + 8:
            raise FrameParseError("frame truncated within UDP header")
        l4_protocol = Protocol.UDP
        src_port = struct.unpack("!H", frame[l4_start:l4_start + 2])[0]
        dst_port = struct.unpack("!H", frame[l4_start + 2:l4_start + 4])[0]
        l4_checksum = struct.unpack("!H", frame[l4_start + 6:l4_start + 8])[0]
    elif ip_protocol == IP_PROTO_ICMP:
        if len(frame) < l4_start + 1:
            raise FrameParseError("frame truncated within ICMP header")
        l4_protocol = Protocol.ICMP
        icmp_type = frame[l4_start]

    return ParsedFrame(
        raw=frame,
        eth_dst=eth_dst, eth_src=eth_src, ethertype=ethertype,
        ip_header_start=ip_start,
        ip_header_length=ihl,
        ip_version=version,
        ip_protocol=ip_protocol,
        ip_total_length=total_length,
        ip_checksum=ip_checksum,
        ip_tos=ip_tos,
        src_ip=src_ip, dst_ip=dst_ip,
        l4_header_start=l4_start,
        l4_protocol=l4_protocol,
        src_port=src_port, dst_port=dst_port,
        l4_checksum=l4_checksum,
        icmp_type=icmp_type,
    )


def rewrite_frame_snat(
    parsed: ParsedFrame,
    new_src_ip: IPv4Address,
    new_src_port: int,
) -> bytes:
    """
    Rewrite a frame for source-NAT: change src_ip (+ src_port if TCP/UDP)
    and update IP + L4 checksums incrementally.

    Returns a new bytes object — the original frame is untouched.
    """
    out = bytearray(parsed.raw)
    ip_start = parsed.ip_header_start

    # Update src IP in IP header
    out[ip_start + 12:ip_start + 16] = new_src_ip.packed

    # Incremental IP checksum update (src changed)
    new_ip_cs = update_ip_checksum_for_src_change(
        parsed.ip_checksum, parsed.src_ip, new_src_ip,
    )
    out[ip_start + 10:ip_start + 12] = struct.pack("!H", new_ip_cs)

    # L4 rewrite
    l4_start = parsed.l4_header_start
    if parsed.l4_protocol == Protocol.TCP:
        # Src port
        out[l4_start:l4_start + 2] = struct.pack("!H", new_src_port)
        # Incremental TCP checksum update
        new_l4_cs = update_l4_checksum_for_snat(
            parsed.l4_checksum,
            parsed.src_ip, new_src_ip,
            parsed.src_port, new_src_port,
        )
        out[l4_start + 16:l4_start + 18] = struct.pack("!H", new_l4_cs)
    elif parsed.l4_protocol == Protocol.UDP:
        out[l4_start:l4_start + 2] = struct.pack("!H", new_src_port)
        new_l4_cs = update_l4_checksum_for_snat(
            parsed.l4_checksum,
            parsed.src_ip, new_src_ip,
            parsed.src_port, new_src_port,
        )
        # UDP checksum of 0 means "no checksum"; real stacks accept this.
        # But per RFC 768, if the *computed* checksum is 0 it's transmitted
        # as 0xFFFF. Our incremental update preserves that convention correctly.
        out[l4_start + 6:l4_start + 8] = struct.pack("!H", new_l4_cs)
    # ICMP: no ports, checksum covers only ICMP data which didn't change.

    return bytes(out)


def rewrite_frame_dnat(
    parsed: ParsedFrame,
    new_dst_ip: IPv4Address,
    new_dst_port: int,
) -> bytes:
    """Rewrite a frame for destination NAT."""
    out = bytearray(parsed.raw)
    ip_start = parsed.ip_header_start

    out[ip_start + 16:ip_start + 20] = new_dst_ip.packed

    new_ip_cs = update_ip_checksum_for_dst_change(
        parsed.ip_checksum, parsed.dst_ip, new_dst_ip,
    )
    out[ip_start + 10:ip_start + 12] = struct.pack("!H", new_ip_cs)

    l4_start = parsed.l4_header_start
    if parsed.l4_protocol == Protocol.TCP:
        out[l4_start + 2:l4_start + 4] = struct.pack("!H", new_dst_port)
        new_l4_cs = update_l4_checksum_for_dnat(
            parsed.l4_checksum,
            parsed.dst_ip, new_dst_ip,
            parsed.dst_port, new_dst_port,
        )
        out[l4_start + 16:l4_start + 18] = struct.pack("!H", new_l4_cs)
    elif parsed.l4_protocol == Protocol.UDP:
        out[l4_start + 2:l4_start + 4] = struct.pack("!H", new_dst_port)
        new_l4_cs = update_l4_checksum_for_dnat(
            parsed.l4_checksum,
            parsed.dst_ip, new_dst_ip,
            parsed.dst_port, new_dst_port,
        )
        out[l4_start + 6:l4_start + 8] = struct.pack("!H", new_l4_cs)

    return bytes(out)


def rewrite_frame_full(
    parsed: ParsedFrame,
    new_src_ip: IPv4Address,
    new_src_port: int,
    new_dst_ip: IPv4Address,
    new_dst_port: int,
) -> bytes:
    """
    Rewrite BOTH src and dst. Used when an incoming SNAT-reverse packet
    needs both its src (unchanged) and its dst (reversed to original LAN
    client) adjusted — actually in the reverse-SNAT case src is unchanged,
    so this helper is mainly for completeness.

    When ip/port changes touch both source and destination, we compute
    checksums from scratch (rather than incremental) because the savings
    of incremental are negligible vs the correctness risk.
    """
    out = bytearray(parsed.raw)
    ip_start = parsed.ip_header_start
    ihl = parsed.ip_header_length

    out[ip_start + 12:ip_start + 16] = new_src_ip.packed
    out[ip_start + 16:ip_start + 20] = new_dst_ip.packed
    # Zero IP checksum, recompute
    out[ip_start + 10:ip_start + 12] = b"\x00\x00"
    new_ip_cs = calculate_ip_checksum(bytes(out[ip_start:ip_start + ihl]))
    out[ip_start + 10:ip_start + 12] = struct.pack("!H", new_ip_cs)

    l4_start = parsed.l4_header_start

    if parsed.l4_protocol in (Protocol.TCP, Protocol.UDP):
        if parsed.l4_protocol == Protocol.TCP:
            out[l4_start:l4_start + 2] = struct.pack("!H", new_src_port)
            out[l4_start + 2:l4_start + 4] = struct.pack("!H", new_dst_port)
            out[l4_start + 16:l4_start + 18] = b"\x00\x00"
            # Recompute TCP checksum from scratch using the already-updated buffer
            from .checksum import calculate_tcp_checksum
            l4_end = ip_start + parsed.ip_total_length
            tcp_segment = bytes(out[l4_start:l4_end])
            new_l4_cs = calculate_tcp_checksum(new_src_ip, new_dst_ip, tcp_segment)
            out[l4_start + 16:l4_start + 18] = struct.pack("!H", new_l4_cs)
        else:  # UDP
            out[l4_start:l4_start + 2] = struct.pack("!H", new_src_port)
            out[l4_start + 2:l4_start + 4] = struct.pack("!H", new_dst_port)
            out[l4_start + 6:l4_start + 8] = b"\x00\x00"
            from .checksum import calculate_udp_checksum
            l4_end = ip_start + parsed.ip_total_length
            udp_segment = bytes(out[l4_start:l4_end])
            new_l4_cs = calculate_udp_checksum(new_src_ip, new_dst_ip, udp_segment)
            out[l4_start + 6:l4_start + 8] = struct.pack("!H", new_l4_cs)

    return bytes(out)


# ---------------------------------------------------------------------------
# Frame builders (useful for tests)
# ---------------------------------------------------------------------------


def build_tcp_frame(
    *,
    eth_dst: bytes = b"\x00\x11\x22\x33\x44\x55",
    eth_src: bytes = b"\x00\xaa\xbb\xcc\xdd\xee",
    src_ip: IPv4Address,
    dst_ip: IPv4Address,
    src_port: int,
    dst_port: int,
    payload: bytes = b"",
    flags: int = 0x18,  # PSH|ACK
    ttl: int = 64,
    seq: int = 0x12345678,
    ack: int = 0,
    dscp: int = 0,     # 6-bit DSCP (0-63); left-shifted into TOS byte
) -> bytes:
    """Build a minimal TCP/IP/Ethernet frame with correct checksums."""
    from .checksum import calculate_ip_checksum, calculate_tcp_checksum

    if not (0 <= dscp <= 63):
        raise ValueError(f"dscp out of range 0-63: {dscp}")
    tos_byte = (dscp << 2)  # DSCP in top 6 bits, ECN low 2 bits = 0

    # TCP header (20 bytes, no options)
    tcp = bytearray(struct.pack(
        "!HHIIBBHHH",
        src_port, dst_port,
        seq, ack,
        (5 << 4),   # data offset = 5 × 4 = 20 bytes, reserved = 0
        flags,
        8192,       # window
        0,          # checksum (zero before computation)
        0,          # urgent pointer
    )) + payload

    # IP header (20 bytes, no options)
    total_length = 20 + len(tcp)
    ip = bytearray(struct.pack(
        "!BBHHHBBH4s4s",
        (4 << 4) | 5,  # version=4, IHL=5
        tos_byte,      # TOS (DSCP + ECN)
        total_length,
        0x1234,        # ID
        0x4000,        # flags=DF, fragment offset=0
        ttl,
        IP_PROTO_TCP,
        0,             # checksum (zero before computation)
        src_ip.packed, dst_ip.packed,
    ))

    # Compute checksums
    ip_cs = calculate_ip_checksum(bytes(ip))
    ip[10:12] = struct.pack("!H", ip_cs)

    tcp_cs = calculate_tcp_checksum(src_ip, dst_ip, bytes(tcp))
    tcp[16:18] = struct.pack("!H", tcp_cs)

    # Ethernet header
    eth = eth_dst + eth_src + struct.pack("!H", ETH_P_IP)

    return eth + bytes(ip) + bytes(tcp)


def build_udp_frame(
    *,
    eth_dst: bytes = b"\x00\x11\x22\x33\x44\x55",
    eth_src: bytes = b"\x00\xaa\xbb\xcc\xdd\xee",
    src_ip: IPv4Address,
    dst_ip: IPv4Address,
    src_port: int,
    dst_port: int,
    payload: bytes = b"",
    ttl: int = 64,
    dscp: int = 0,
) -> bytes:
    """Build a minimal UDP/IP/Ethernet frame with correct checksums."""
    from .checksum import calculate_ip_checksum, calculate_udp_checksum

    if not (0 <= dscp <= 63):
        raise ValueError(f"dscp out of range 0-63: {dscp}")
    tos_byte = (dscp << 2)

    udp_length = 8 + len(payload)
    udp = bytearray(struct.pack(
        "!HHHH",
        src_port, dst_port, udp_length, 0,
    )) + payload

    total_length = 20 + len(udp)
    ip = bytearray(struct.pack(
        "!BBHHHBBH4s4s",
        (4 << 4) | 5, tos_byte,
        total_length,
        0x1234, 0x4000,
        ttl, IP_PROTO_UDP,
        0,
        src_ip.packed, dst_ip.packed,
    ))
    ip_cs = calculate_ip_checksum(bytes(ip))
    ip[10:12] = struct.pack("!H", ip_cs)

    udp_cs = calculate_udp_checksum(src_ip, dst_ip, bytes(udp))
    udp[6:8] = struct.pack("!H", udp_cs)

    eth = eth_dst + eth_src + struct.pack("!H", ETH_P_IP)
    return eth + bytes(ip) + bytes(udp)


def verify_frame_checksums(frame: bytes) -> tuple[bool, bool]:
    """
    Verify that a frame has correct IP and L4 checksums.
    Returns (ip_ok, l4_ok). l4_ok is True for non-TCP/UDP protocols
    (nothing to check).
    """
    parsed = parse_frame(frame)
    ip_start = parsed.ip_header_start

    # IP: sum over entire header (including checksum field) should be 0xFFFF
    from .checksum import ones_complement_sum
    ip_sum = ones_complement_sum(
        frame[ip_start:ip_start + parsed.ip_header_length],
    )
    ip_ok = (ip_sum == 0xFFFF)

    # L4
    if parsed.l4_protocol == Protocol.TCP:
        from .checksum import calculate_tcp_checksum
        l4_start = parsed.l4_header_start
        l4_end = ip_start + parsed.ip_total_length
        segment = frame[l4_start:l4_end]
        expected = calculate_tcp_checksum(parsed.src_ip, parsed.dst_ip, segment)
        l4_ok = (expected == 0)  # verifying an existing checksum yields 0
        if not l4_ok:
            # Alternative: zero the checksum field and recompute, compare
            seg_zero = bytearray(segment)
            seg_zero[16:18] = b"\x00\x00"
            fresh = calculate_tcp_checksum(parsed.src_ip, parsed.dst_ip, bytes(seg_zero))
            l4_ok = (fresh == parsed.l4_checksum)
    elif parsed.l4_protocol == Protocol.UDP:
        from .checksum import calculate_udp_checksum
        l4_start = parsed.l4_header_start
        l4_end = ip_start + parsed.ip_total_length
        segment = frame[l4_start:l4_end]
        seg_zero = bytearray(segment)
        seg_zero[6:8] = b"\x00\x00"
        fresh = calculate_udp_checksum(parsed.src_ip, parsed.dst_ip, bytes(seg_zero))
        l4_ok = (fresh == parsed.l4_checksum)
    else:
        l4_ok = True

    return (ip_ok, l4_ok)

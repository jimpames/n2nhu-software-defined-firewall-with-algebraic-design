"""
PBRConfigLoader — parses policies/pbr.ini.

Like NATConfigLoader, it takes the already-loaded policy Config so it can
cross-validate that every referenced object exists.
"""

from __future__ import annotations

import configparser
from pathlib import Path

from .config_loader import _check_keys, _parse_bool, _parse_csv, _parse_int, _read_ini
from .errors import ConfigError
from .models import Config
from .pbr_models import DSCPMatchMode, PBRConfig, PBRRule


_PBR_RULE_KEYS = {
    "src_zone", "dst_zone", "src_addr", "dst_addr", "service", "schedule",
    "dscp", "dscp_min", "dscp_max",
    "egress_iface",
    "log", "comment",
}


def _parse_dscp(
    raw: str, *, source: str, section: str, key: str,
) -> int:
    """
    Accept either a numeric DSCP (0-63) or a symbolic name.
    Returns the integer DSCP value.
    """
    raw = raw.strip().lower()
    # Common symbolic names (partial list — the most used markings)
    symbolic = {
        "cs0": 0, "cs1": 8, "cs2": 16, "cs3": 24,
        "cs4": 32, "cs5": 40, "cs6": 48, "cs7": 56,
        "af11": 10, "af12": 12, "af13": 14,
        "af21": 18, "af22": 20, "af23": 22,
        "af31": 26, "af32": 28, "af33": 30,
        "af41": 34, "af42": 36, "af43": 38,
        "ef": 46,
        "voice-admit": 44,
        "default": 0, "be": 0,
    }
    if raw in symbolic:
        return symbolic[raw]
    try:
        val = int(raw)
    except ValueError as exc:
        raise ConfigError(
            f"{key!r} must be 0-63 or symbolic (ef, af41, cs6, ...); got {raw!r}",
            source=source, section=section,
        ) from exc
    if not (0 <= val <= 63):
        raise ConfigError(
            f"{key!r} out of range 0-63: {val}",
            source=source, section=section,
        )
    return val


class PBRConfigLoader:
    """Loads PBR rules from `<root>/policies/pbr.ini`."""

    def __init__(self, root: str | Path, policy_config: Config):
        self.root = Path(root)
        self.policy_config = policy_config

    def load(self) -> PBRConfig:
        path = self.root / "policies" / "pbr.ini"
        if not path.exists():
            # PBR is optional — no pbr.ini means no override rules
            return PBRConfig(rules=())

        cp = _read_ini(path)
        source = "policies/pbr.ini"

        if "pbr_order" not in cp:
            raise ConfigError("[pbr_order] section missing", source=source)
        if "rules" not in cp["pbr_order"]:
            raise ConfigError(
                "[pbr_order] missing 'rules'",
                source=source, section="pbr_order",
            )
        order = _parse_csv(cp["pbr_order"]["rules"])
        if not order:
            raise ConfigError(
                "[pbr_order] 'rules' is empty",
                source=source, section="pbr_order",
            )

        missing = [r for r in order if r not in cp.sections()]
        if missing:
            raise ConfigError(
                f"pbr_order references undefined rules: {missing}",
                source=source, section="pbr_order",
            )

        seen = set()
        dupes = [r for r in order if r in seen or seen.add(r)]  # type: ignore[func-returns-value]
        if dupes:
            raise ConfigError(
                f"pbr_order has duplicate rule IDs: {dupes}",
                source=source, section="pbr_order",
            )

        valid_zones = set(self.policy_config.zones.keys()) | {"any"}
        valid_addrs = set(self.policy_config.addresses.keys())
        valid_svcs = set(self.policy_config.services.keys())
        valid_scheds = set(self.policy_config.schedules.keys())
        valid_ifaces = set(self.policy_config.interface_to_zone.keys())

        rules: list[PBRRule] = []
        for rule_id in order:
            sect = cp[rule_id]
            _check_keys(sect.keys(), _PBR_RULE_KEYS, source=source, section=rule_id)

            if "egress_iface" not in sect:
                raise ConfigError(
                    "PBR rule missing 'egress_iface'",
                    source=source, section=rule_id,
                )
            egress = sect["egress_iface"].strip()
            if egress not in valid_ifaces:
                raise ConfigError(
                    f"egress_iface {egress!r} not declared in zones.ini",
                    source=source, section=rule_id,
                )

            src_zone = sect.get("src_zone", "any").strip()
            dst_zone = sect.get("dst_zone", "any").strip()
            src_addr = sect.get("src_addr", "addr_any").strip()
            dst_addr = sect.get("dst_addr", "addr_any").strip()
            service = sect.get("service", "svc_any").strip()
            schedule = sect.get("schedule", "sched_always").strip()

            if src_zone not in valid_zones:
                raise ConfigError(
                    f"src_zone {src_zone!r} not declared", source=source, section=rule_id,
                )
            if dst_zone not in valid_zones:
                raise ConfigError(
                    f"dst_zone {dst_zone!r} not declared", source=source, section=rule_id,
                )
            if src_addr not in valid_addrs:
                raise ConfigError(
                    f"src_addr {src_addr!r} not defined", source=source, section=rule_id,
                )
            if dst_addr not in valid_addrs:
                raise ConfigError(
                    f"dst_addr {dst_addr!r} not defined", source=source, section=rule_id,
                )
            if service not in valid_svcs:
                raise ConfigError(
                    f"service {service!r} not defined", source=source, section=rule_id,
                )
            if schedule not in valid_scheds:
                raise ConfigError(
                    f"schedule {schedule!r} not defined", source=source, section=rule_id,
                )

            # DSCP parsing — three forms: absent, equal, range
            has_dscp = "dscp" in sect
            has_min = "dscp_min" in sect
            has_max = "dscp_max" in sect

            if has_dscp and (has_min or has_max):
                raise ConfigError(
                    "can't mix 'dscp' with 'dscp_min'/'dscp_max'",
                    source=source, section=rule_id,
                )
            if has_min != has_max:
                raise ConfigError(
                    "'dscp_min' and 'dscp_max' must both be set together",
                    source=source, section=rule_id,
                )

            if has_dscp:
                dscp_mode = DSCPMatchMode.EQUAL
                dscp_value = _parse_dscp(
                    sect["dscp"], source=source, section=rule_id, key="dscp",
                )
                dscp_min = 0
                dscp_max = 63
            elif has_min:
                dscp_mode = DSCPMatchMode.RANGE
                dscp_value = 0
                dscp_min = _parse_dscp(
                    sect["dscp_min"], source=source, section=rule_id, key="dscp_min",
                )
                dscp_max = _parse_dscp(
                    sect["dscp_max"], source=source, section=rule_id, key="dscp_max",
                )
                if dscp_min > dscp_max:
                    raise ConfigError(
                        f"dscp_min ({dscp_min}) > dscp_max ({dscp_max})",
                        source=source, section=rule_id,
                    )
            else:
                dscp_mode = DSCPMatchMode.ANY
                dscp_value = 0
                dscp_min = 0
                dscp_max = 63

            log_flag = _parse_bool(
                sect.get("log", "false"), source=source, section=rule_id, key="log",
            )
            comment = sect.get("comment", "")

            rules.append(PBRRule(
                id=rule_id,
                src_zone=src_zone, dst_zone=dst_zone,
                src_addr=src_addr, dst_addr=dst_addr,
                service=service, schedule=schedule,
                dscp_mode=dscp_mode,
                dscp_value=dscp_value,
                dscp_min=dscp_min,
                dscp_max=dscp_max,
                egress_iface=egress,
                log=log_flag,
                comment=comment,
            ))

        return PBRConfig(rules=tuple(rules))

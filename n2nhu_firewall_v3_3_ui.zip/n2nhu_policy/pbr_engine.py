"""
PBREngine — the pure-function policy-based routing plane.

    route_override(packet, now) -> PBRMatch | PBRPassThrough

No state. No I/O. First-match wins.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from .models import Config, Packet
from .object_resolver import ObjectResolver
from .pbr_models import DSCPMatchMode, PBRConfig, PBRMatch, PBRPassThrough, PBRResult
from .schedule_evaluator import ScheduleEvaluator
from .zone_map import ZoneMap


class PBREngine:
    """
    Walks the PBR matrix in declared order. First match returns an override
    egress interface. No match returns PBRPassThrough (caller uses normal
    route lookup).
    """

    def __init__(
        self,
        policy_config: Config,
        pbr_config: PBRConfig,
        resolver: Optional[ObjectResolver] = None,
        zone_map: Optional[ZoneMap] = None,
        schedule_evaluator: Optional[ScheduleEvaluator] = None,
    ):
        self.policy_config = policy_config
        self.pbr_config = pbr_config
        self.resolver = resolver or ObjectResolver(
            policy_config.addresses, policy_config.services,
        )
        self.zone_map = zone_map or ZoneMap(
            policy_config.zones,
            policy_config.interface_to_zone,
            policy_config.defaults,
        )
        self.schedules = schedule_evaluator or ScheduleEvaluator(policy_config.schedules)

    def route_override(self, packet: Packet, now: datetime) -> PBRResult:
        """
        Return a PBRMatch if any rule matches this packet, else PBRPassThrough.
        """
        for rule in self.pbr_config.rules:
            if not self._rule_matches(rule, packet, now):
                continue
            return PBRMatch(
                egress_iface=rule.egress_iface,
                rule_id=rule.id,
            )
        return PBRPassThrough()

    def _rule_matches(self, rule, packet: Packet, now: datetime) -> bool:
        # Zone match (explicit or "any")
        try:
            src_zone = self.zone_map.zone_for_interface(packet.ingress_iface)
        except Exception:
            return False
        # For egress zone, we use packet.egress_iface which may be the
        # route-lookup-provided default. If it's not mapped, fall back to "any".
        try:
            dst_zone = self.zone_map.zone_for_interface(packet.egress_iface)
        except Exception:
            dst_zone = ""

        if rule.src_zone != "any" and rule.src_zone != src_zone:
            return False
        if rule.dst_zone != "any" and rule.dst_zone != dst_zone:
            return False

        # Address match
        if not self.resolver.ip_in_address(packet.src_ip, rule.src_addr):
            return False
        if not self.resolver.ip_in_address(packet.dst_ip, rule.dst_addr):
            return False

        # Service match
        if not self.resolver.service_matches(
            rule.service,
            protocol=packet.protocol,
            dst_port=packet.dst_port,
            src_port=packet.src_port,
            icmp_type=packet.icmp_type,
        ):
            return False

        # Schedule match
        if not self.schedules.matches(rule.schedule, now):
            return False

        # DSCP match
        if rule.dscp_mode == DSCPMatchMode.EQUAL:
            if packet.dscp != rule.dscp_value:
                return False
        elif rule.dscp_mode == DSCPMatchMode.RANGE:
            if not (rule.dscp_min <= packet.dscp <= rule.dscp_max):
                return False
        # DSCPMatchMode.ANY: no DSCP filtering

        return True

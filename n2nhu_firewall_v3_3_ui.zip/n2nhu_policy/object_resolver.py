"""
ObjectResolver — expands groups and provides O(log n) membership tests.

Groups are resolved via DFS with a visited set (cycle detection).
Address groups flatten to a union of IP networks.
Service groups flatten to a list of (protocol, dst_port, icmp_type) matchers.
"""

from __future__ import annotations

from ipaddress import (
    IPv4Address, IPv4Network, IPv6Address, IPv6Network,
    ip_address, ip_network,
)
from typing import Iterable, Mapping

from .errors import CycleError, ResolverError
from .models import (
    AddressObject,
    AddressType,
    IPAddress,
    IPNetwork,
    PortRange,
    Protocol,
    ServiceObject,
)


class _ServiceMatcher:
    """A flattened service-leaf matcher. Compiled once, queried many times."""

    __slots__ = ("protocol", "dst_port", "src_port", "icmp_type")

    def __init__(
        self,
        protocol: Protocol,
        dst_port: PortRange | None,
        src_port: PortRange | None,
        icmp_type: int | None,
    ):
        self.protocol = protocol
        self.dst_port = dst_port
        self.src_port = src_port
        self.icmp_type = icmp_type

    def matches(
        self,
        protocol: Protocol,
        dst_port: int,
        src_port: int,
        icmp_type: int | None,
    ) -> bool:
        if self.protocol != Protocol.ANY and self.protocol != protocol:
            return False
        if self.dst_port is not None and not self.dst_port.contains(dst_port):
            return False
        if self.src_port is not None and not self.src_port.contains(src_port):
            return False
        if self.icmp_type is not None:
            if icmp_type is None or icmp_type != self.icmp_type:
                return False
        return True


class ObjectResolver:
    """
    Resolves object references into concrete membership tests.

    Address groups are flattened into a list of (network, range_start, range_end)
    tuples. Service groups are flattened into a list of _ServiceMatcher.
    Flattening happens once, at construction time. Cycles raise CycleError.
    """

    def __init__(
        self,
        addresses: Mapping[str, AddressObject],
        services: Mapping[str, ServiceObject],
        *,
        fqdn_resolver=None,
    ):
        self._addresses = dict(addresses)
        self._services = dict(services)
        # Optional DNS hook; default raises if an FQDN is encountered without one
        self._fqdn_resolver = fqdn_resolver

        # Compile flattened membership for every address object
        self._addr_networks: dict[str, tuple[IPNetwork, ...]] = {}
        self._addr_ranges: dict[str, tuple[tuple[IPAddress, IPAddress], ...]] = {}
        for addr_id in self._addresses:
            nets, ranges = self._resolve_addr(addr_id, [])
            self._addr_networks[addr_id] = nets
            self._addr_ranges[addr_id] = ranges

        # Compile flattened matchers for every service object
        self._svc_matchers: dict[str, tuple[_ServiceMatcher, ...]] = {}
        for svc_id in self._services:
            self._svc_matchers[svc_id] = self._resolve_svc(svc_id, [])

    # -----------------------------------------------------------------------
    # Address resolution
    # -----------------------------------------------------------------------

    def _resolve_addr(
        self,
        addr_id: str,
        path: list[str],
    ) -> tuple[tuple[IPNetwork, ...], tuple[tuple[IPAddress, IPAddress], ...]]:
        if addr_id in path:
            raise CycleError(path + [addr_id])
        if addr_id not in self._addresses:
            raise ResolverError(f"undefined address object: {addr_id!r}")

        obj = self._addresses[addr_id]

        if obj.type == AddressType.HOST:
            assert obj.host is not None
            # Wrap single host as /32 (v4) or /128 (v6)
            prefix = 32 if obj.host.version == 4 else 128
            net = ip_network(f"{obj.host}/{prefix}")
            return ((net,), ())

        if obj.type == AddressType.NETWORK:
            assert obj.network is not None
            return ((obj.network,), ())

        if obj.type == AddressType.RANGE:
            assert obj.range_start is not None and obj.range_end is not None
            return ((), ((obj.range_start, obj.range_end),))

        if obj.type == AddressType.FQDN:
            if self._fqdn_resolver is None:
                return ((), ())
            ips = self._fqdn_resolver(obj.fqdn)
            nets = []
            for ip in ips:
                ip_obj = ip_address(ip) if not isinstance(ip, (IPv4Address, IPv6Address)) else ip
                prefix = 32 if ip_obj.version == 4 else 128
                nets.append(ip_network(f"{ip_obj}/{prefix}"))
            return (tuple(nets), ())

        if obj.type == AddressType.GROUP:
            all_nets: list[IPNetwork] = []
            all_ranges: list[tuple[IPAddress, IPAddress]] = []
            for member in obj.members:
                nets, ranges = self._resolve_addr(member, path + [addr_id])
                all_nets.extend(nets)
                all_ranges.extend(ranges)
            return (tuple(all_nets), tuple(all_ranges))

        raise ResolverError(f"unhandled address type: {obj.type}")

    def ip_in_address(self, ip: IPAddress, addr_id: str) -> bool:
        """Return True if `ip` is a member of the named address object.

        Strict family matching: a v4 IP never matches a v6 network and
        vice versa. Mixed-family address groups are fine; only the members
        of matching family are tested.
        """
        if addr_id not in self._addr_networks:
            raise ResolverError(f"unknown address object: {addr_id!r}")
        for net in self._addr_networks[addr_id]:
            # Python's `in` on ip_address vs ip_network is family-strict
            # and returns False if versions differ — exactly what we want.
            if net.version == ip.version and ip in net:
                return True
        int_ip = int(ip)
        for lo, hi in self._addr_ranges[addr_id]:
            if lo.version == ip.version and int(lo) <= int_ip <= int(hi):
                return True
        return False

    # -----------------------------------------------------------------------
    # Service resolution
    # -----------------------------------------------------------------------

    def _resolve_svc(self, svc_id: str, path: list[str]) -> tuple[_ServiceMatcher, ...]:
        if svc_id in path:
            raise CycleError(path + [svc_id])
        if svc_id not in self._services:
            raise ResolverError(f"undefined service object: {svc_id!r}")

        obj = self._services[svc_id]

        if not obj.is_group:
            return (_ServiceMatcher(
                protocol=obj.protocol,
                dst_port=obj.dst_port,
                src_port=obj.src_port,
                icmp_type=obj.icmp_type,
            ),)

        out: list[_ServiceMatcher] = []
        for member in obj.members:
            out.extend(self._resolve_svc(member, path + [svc_id]))
        return tuple(out)

    def service_matches(
        self,
        svc_id: str,
        *,
        protocol: Protocol,
        dst_port: int,
        src_port: int,
        icmp_type: int | None,
    ) -> bool:
        if svc_id not in self._svc_matchers:
            raise ResolverError(f"unknown service object: {svc_id!r}")
        for m in self._svc_matchers[svc_id]:
            if m.matches(protocol, dst_port, src_port, icmp_type):
                return True
        return False

    # -----------------------------------------------------------------------
    # Introspection (useful for tests and UIs)
    # -----------------------------------------------------------------------

    def flatten_address(self, addr_id: str) -> dict:
        return {
            "networks": [str(n) for n in self._addr_networks.get(addr_id, ())],
            "ranges": [
                f"{lo}-{hi}" for lo, hi in self._addr_ranges.get(addr_id, ())
            ],
        }

    def flatten_service(self, svc_id: str) -> list[dict]:
        matchers = self._svc_matchers.get(svc_id, ())
        return [
            {
                "protocol": m.protocol.value,
                "dst_port": (
                    f"{m.dst_port.start}-{m.dst_port.end}"
                    if m.dst_port and m.dst_port.start != m.dst_port.end
                    else str(m.dst_port.start) if m.dst_port else None
                ),
                "icmp_type": m.icmp_type,
            }
            for m in matchers
        ]

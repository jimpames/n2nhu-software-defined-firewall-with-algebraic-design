"""Custom exceptions for n2nhu_policy."""


class N2NHUPolicyError(Exception):
    """Base exception for all policy-engine errors."""


class ConfigError(N2NHUPolicyError):
    """Raised when INI config is malformed, missing, or semantically invalid."""

    def __init__(self, message: str, source: str | None = None, section: str | None = None):
        parts = []
        if source:
            parts.append(f"[{source}]")
        if section:
            parts.append(f"section '{section}'")
        parts.append(message)
        super().__init__(" ".join(parts))
        self.source = source
        self.section = section


class ResolverError(N2NHUPolicyError):
    """Raised when object resolution fails (missing reference, bad members)."""


class CycleError(ResolverError):
    """Raised when an object-group cycle is detected."""

    def __init__(self, cycle_path: list[str]):
        self.cycle_path = cycle_path
        super().__init__(f"Group cycle detected: {' -> '.join(cycle_path)}")

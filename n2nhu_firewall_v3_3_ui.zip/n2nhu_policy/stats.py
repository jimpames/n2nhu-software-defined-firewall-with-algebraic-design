"""
Stats — in-memory counters for rule hits, actions taken, zone pairs.

Kept intentionally simple. Dump with `.as_dict()`. Reset with `.reset()`.
"""

from __future__ import annotations

from collections import defaultdict
from threading import Lock

from .models import Action, Decision


class Stats:
    def __init__(self):
        self._lock = Lock()
        self._rule_hits: dict[str, int] = defaultdict(int)
        self._action_counts: dict[str, int] = defaultdict(int)
        self._default_hits: int = 0
        self._total: int = 0

    def record(self, decision: Decision) -> None:
        with self._lock:
            self._total += 1
            self._rule_hits[decision.rule_id] += 1
            self._action_counts[decision.action.value] += 1
            if decision.matched_default:
                self._default_hits += 1

    def as_dict(self) -> dict:
        with self._lock:
            return {
                "total_decisions": self._total,
                "default_hits": self._default_hits,
                "by_rule": dict(self._rule_hits),
                "by_action": dict(self._action_counts),
            }

    def reset(self) -> None:
        with self._lock:
            self._rule_hits.clear()
            self._action_counts.clear()
            self._default_hits = 0
            self._total = 0

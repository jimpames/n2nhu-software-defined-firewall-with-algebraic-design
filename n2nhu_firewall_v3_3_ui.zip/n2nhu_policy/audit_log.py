"""
Audit log — one JSON object per logged decision, one line at a time.

Called only when `decision.log` is True OR `decision.matched_default` is True.
The data plane is responsible for calling `.log()` explicitly — keeps the
engine a pure function.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import IO

from .models import Decision, Packet


class AuditLog:
    def __init__(self, sink: IO[str] | None = None, path: str | Path | None = None):
        if sink is not None and path is not None:
            raise ValueError("supply `sink` OR `path`, not both")
        self._lock = Lock()
        if path is not None:
            self._sink = open(path, "a", encoding="utf-8", buffering=1)
            self._owns_sink = True
        else:
            import sys
            self._sink = sink if sink is not None else sys.stdout
            self._owns_sink = False

    def log(self, packet: Packet, decision: Decision, now: datetime) -> None:
        if not (decision.log or decision.matched_default):
            return
        entry = {
            "ts": now.isoformat(),
            "action": decision.action.value,
            "rule_id": decision.rule_id,
            "matched_default": decision.matched_default,
            "ingress": packet.ingress_iface,
            "egress": packet.egress_iface,
            "src_ip": str(packet.src_ip),
            "dst_ip": str(packet.dst_ip),
            "protocol": packet.protocol.value,
            "src_port": packet.src_port,
            "dst_port": packet.dst_port,
            "icmp_type": packet.icmp_type,
            "reason": decision.reason,
        }
        with self._lock:
            self._sink.write(json.dumps(entry, separators=(",", ":")) + "\n")

    def close(self) -> None:
        if self._owns_sink:
            self._sink.close()

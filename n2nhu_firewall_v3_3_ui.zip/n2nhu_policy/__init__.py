"""
n2nhu_policy — Declarative firewall policy engine.

Pure matrix lookup. No hardcoded product behavior.
All policy lives in INI files. The engine never changes.
"""

from .errors import ConfigError, ResolverError, CycleError
from .models import (
    Action,
    AddressObject,
    AddressType,
    Config,
    Decision,
    Packet,
    PolicyRule,
    Protocol,
    Schedule,
    ScheduleType,
    ServiceObject,
    Zone,
)
from .config_loader import ConfigLoader
from .object_resolver import ObjectResolver
from .zone_map import ZoneMap
from .schedule_evaluator import ScheduleEvaluator
from .policy_engine import PolicyEngine
from .stats import Stats
from .audit_log import AuditLog

# NAT plane
from .nat_models import (
    Direction,
    NATConfig,
    NATDenied,
    NATRule,
    NATSession,
    NATType,
    PassThrough,
    PortPoolSpec,
    TranslatedPacket,
)
from .nat_config_loader import NATConfigLoader
from .nat_engine import NATEngine
from .port_pool import PortPool, PortPoolExhausted
from .session_table import SessionTable
from .frame_codec import (
    ETH_P_IP,
    FrameParseError,
    ParsedFrame,
    build_tcp_frame,
    build_udp_frame,
    parse_frame,
    rewrite_frame_dnat,
    rewrite_frame_full,
    rewrite_frame_snat,
    verify_frame_checksums,
)
from .router_shim import ForwardAction, ForwardDecision, RouterShim, RouterStats

# PBR plane
from .pbr_models import (
    DSCPMatchMode,
    PBRConfig,
    PBRMatch,
    PBRPassThrough,
    PBRResult,
    PBRRule,
)
from .pbr_config_loader import PBRConfigLoader
from .pbr_engine import PBREngine

__all__ = [
    "Action",
    "AddressObject",
    "AddressType",
    "AuditLog",
    "Config",
    "ConfigError",
    "ConfigLoader",
    "CycleError",
    "Decision",
    "ObjectResolver",
    "Packet",
    "PolicyEngine",
    "PolicyRule",
    "Protocol",
    "ResolverError",
    "Schedule",
    "ScheduleEvaluator",
    "ScheduleType",
    "ServiceObject",
    "Stats",
    "Zone",
    "ZoneMap",
]

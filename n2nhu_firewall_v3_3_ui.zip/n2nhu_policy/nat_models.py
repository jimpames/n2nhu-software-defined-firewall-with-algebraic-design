"""
NAT data models. Mirrors the structure of n2nhu_policy.models but for
address/port translation.

Design notes:
- NATRule is a frozen dataclass. Reload swaps the pointer, never mutates.
- NATType is an enum; new types are data, not code changes.
- NATSession is NOT frozen — it mutates last_seen on every packet. Instances
  live in SessionTable, which handles concurrency.
- TranslatedPacket and PassThrough are return values from nat_engine.translate().
  PassThrough means "no translation needed"; TranslatedPacket carries both
  the post-translation packet AND the session reference so the data plane
  can record stats + renew timeouts.
"""

from __future__ import annotations

import enum
import time
from dataclasses import dataclass, field
from ipaddress import IPv4Address
from typing import Optional

from n2nhu_policy.models import IPAddress, Protocol


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class NATType(enum.Enum):
    """The NAT types we support."""

    SOURCE_NAT = "source_nat"           # PAT/masquerade — many-to-one with port remap
    DESTINATION_NAT = "destination_nat" # Port forward — external:port -> internal:port
    STATIC_NAT = "static_nat"           # Bidirectional 1:1 IP mapping
    NO_NAT = "no_nat"                   # Explicit bypass — leave packet unchanged
    NAT64 = "nat64"                     # Stateful IPv6 → IPv4 translation (RFC 6146)

    @classmethod
    def parse(cls, raw: str) -> "NATType":
        key = raw.strip().lower()
        for member in cls:
            if member.value == key:
                return member
        raise ValueError(
            f"Unknown NAT type: {raw!r}. "
            f"Expected: {', '.join(m.value for m in cls)}"
        )


class Direction(enum.Enum):
    """A session's original direction (which side initiated)."""

    FORWARD = "forward"   # The original flow direction (LAN->WAN for SNAT)
    REVERSE = "reverse"   # Return traffic


# ---------------------------------------------------------------------------
# Port pool
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PortPoolSpec:
    """Declarative port pool — start/end inclusive."""

    start: int
    end: int

    def __post_init__(self):
        if not (1 <= self.start <= self.end <= 65535):
            raise ValueError(
                f"port pool out of range: {self.start}-{self.end} (must be 1-65535)"
            )

    @property
    def size(self) -> int:
        return self.end - self.start + 1


# ---------------------------------------------------------------------------
# NAT rules
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NATRule:
    """
    A single row in the NAT matrix.

    Field semantics by type:
      SOURCE_NAT      — rewrites src_ip/src_port on FORWARD packets;
                        reverse-matches use the session table.
      DESTINATION_NAT — rewrites dst_ip/dst_port on FORWARD packets.
      STATIC_NAT      — bidirectional: forward rewrites src (internal->external)
                        OR reverse rewrites dst (external->internal). Both sides
                        always apply, no session state needed for the mapping.
      NO_NAT          — matches, records nothing, signals bypass.
    """

    id: str
    type: NATType

    # Match criteria (reused from policy engine object model)
    src_zone: str = "any"
    dst_zone: str = "any"
    src_addr: str = "addr_any"
    dst_addr: str = "addr_any"
    service: str = "svc_any"
    schedule: str = "sched_always"

    # SOURCE_NAT translation targets
    # Either "interface" (use egress iface IP) or an address object name
    translate_src_to: str = ""
    port_pool: Optional[PortPoolSpec] = None

    # DESTINATION_NAT translation targets
    translate_dst_to: str = ""       # address object name (typically a host)
    translate_dst_port: int = 0      # 0 means "keep original dst_port"

    # STATIC_NAT
    internal_addr: str = ""          # host address object
    external_addr: str = ""          # host address object
    bidirectional: bool = True

    # NAT64 — stateful v6 → v4 translation (RFC 6146)
    # The "well-known" prefix 64:ff9b::/96 per RFC 6052 is the default;
    # operators may override with a /96 out of their own assignment.
    # `nat64_prefix` matches the destination of v6 packets that trigger
    # translation; its length is hardcoded to /96 in v1 (other prefix
    # lengths per RFC 6052 §2.2 are deferred to v1.1).
    # `translate_src_to_v4` is the v4 pool address to source-NAT onto
    # (typically the firewall's external v4 address).
    nat64_prefix: str = ""           # e.g. "64:ff9b::/96"
    translate_src_to_v4: str = ""    # v4 address object

    # Per-rule timeout overrides (0 = use defaults from NATConfig)
    tcp_established_timeout: int = 0
    tcp_half_open_timeout: int = 0
    udp_timeout: int = 0
    icmp_timeout: int = 0

    log: bool = False
    comment: str = ""


# ---------------------------------------------------------------------------
# NAT configuration (timeouts, defaults)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NATConfig:
    """
    Top-level NAT configuration — timeouts, reaper interval, rules.

    Defaults here match industry norms:
      TCP established: 3600s (1 hour of inactivity)
      TCP half-open  :   30s (SYN sent, no SYN-ACK yet)
      UDP            :  180s (3 minutes — covers DNS, NTP, VoIP hold)
      ICMP           :   60s
      Reaper sweeps  :   10s

    These are data. Override in the INI or per-rule.
    """

    rules: tuple[NATRule, ...] = ()
    tcp_established_timeout: int = 3600
    tcp_half_open_timeout: int = 30
    udp_timeout: int = 180
    icmp_timeout: int = 60
    reaper_interval: int = 10
    # If SNAT exhausts its primary pool, try these pools in order (by rule id).
    # Empty list = deny + log on exhaustion.
    overflow_chain: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------


@dataclass
class NATSession:
    """
    A live NAT session. Mutable: `last_seen` and `bytes_*` update on every packet.

    Keyed in the session table two ways:
      forward_key = (orig_src_ip, orig_src_port, orig_dst_ip, orig_dst_port, protocol)
      reverse_key = (xlated_src_ip, xlated_src_port, orig_dst_ip, orig_dst_port, protocol)
                   (for SNAT; DNAT reverses differently)
    """

    session_id: str
    rule_id: str
    nat_type: NATType
    protocol: Protocol

    # Original tuple (pre-NAT). For NAT64, orig_* is the v6 side,
    # xlated_* is the v4 side.
    orig_src_ip: "IPAddress"
    orig_src_port: int
    orig_dst_ip: "IPAddress"
    orig_dst_port: int

    # Translated tuple (post-NAT)
    xlated_src_ip: "IPAddress"
    xlated_src_port: int
    xlated_dst_ip: "IPAddress"
    xlated_dst_port: int

    # Lifecycle
    created_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    # TCP state tracking (simplified — full TCP state machine is overkill for v1)
    tcp_established: bool = False

    # Counters
    packets_forward: int = 0
    packets_reverse: int = 0
    bytes_forward: int = 0
    bytes_reverse: int = 0

    # Origin interface — set for NAT64 sessions so the reply path
    # (v4→v6) knows which iface to emit the translated v6 frame on.
    # For v4-only NAT (SNAT/DNAT) this is unused and stays None.
    client_ingress_iface: "str | None" = None

    def touch(self, now: float, direction: Direction, byte_count: int = 0) -> None:
        self.last_seen = now
        if direction == Direction.FORWARD:
            self.packets_forward += 1
            self.bytes_forward += byte_count
        else:
            self.packets_reverse += 1
            self.bytes_reverse += byte_count

    def age(self, now: float) -> float:
        return now - self.last_seen

    def timeout_for(self, cfg: NATConfig, rule: NATRule) -> int:
        """Compute effective timeout for this session given the owning rule."""
        if self.protocol == Protocol.TCP:
            if self.tcp_established:
                return rule.tcp_established_timeout or cfg.tcp_established_timeout
            return rule.tcp_half_open_timeout or cfg.tcp_half_open_timeout
        if self.protocol == Protocol.UDP:
            return rule.udp_timeout or cfg.udp_timeout
        if self.protocol == Protocol.ICMP:
            return rule.icmp_timeout or cfg.icmp_timeout
        return cfg.tcp_established_timeout  # fallback


# ---------------------------------------------------------------------------
# Engine return values
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TranslatedPacket:
    """
    The result of a successful NAT translation. Contains the post-translation
    5-tuple plus a reference to the session (if any) for data-plane tracking.

    The data plane is responsible for:
      - applying these new src/dst fields to the packet bytes
      - recomputing IP + L4 checksums
      - calling session.touch() on each packet
    """

    src_ip: IPv4Address
    src_port: int
    dst_ip: IPv4Address
    dst_port: int
    session_id: Optional[str] = None
    rule_id: Optional[str] = None


@dataclass(frozen=True)
class PassThrough:
    """Signal that no NAT translation should be applied to this packet."""

    rule_id: Optional[str] = None  # the no_nat rule that matched, or None


@dataclass(frozen=True)
class NATDenied:
    """Signal that NAT failed (e.g., port pool exhausted). Data plane drops."""

    reason: str
    rule_id: Optional[str] = None

"""
CaptureConfigLoader — parses policies/capture.ini.

Like the NAT and PBR loaders, this takes the already-loaded policy
Config so it can cross-validate that every referenced address, service,
and zone exists.

Schema:
    [capture_order]
    rules = cap_lan_egress, cap_dmz_denies

    [cap_lan_egress]
    enabled = true
    capture_point = post_nat        ; ingress | post_policy | post_nat
    src_zone = trusted
    dst_zone = any
    src_addr = addr_lan
    dst_addr = addr_any
    service = svc_any
    match_action = allow            ; any | allow | deny
    pcap_file = /var/log/n2nhu/lan_egress.pcapng
    rotate_size_mb = 100            ; 0 = never rotate
    rotate_keep = 5                 ; 0 = retain all rotated files
    snap_len = 0                    ; 0 = capture full frame
    queue_depth = 4096              ; bounded async queue

If capture.ini is absent the loader returns an empty config, mirroring
the NAT/PBR convention: capture is opt-in, not required.
"""

from __future__ import annotations

import configparser
from pathlib import Path

from .capture_models import (
    CaptureConfig, CaptureMatchAction, CapturePoint, CaptureRule,
)
from .config_loader import _check_keys, _parse_bool, _parse_csv, _parse_int, _read_ini
from .errors import ConfigError
from .models import Config


_CAPTURE_RULE_KEYS = {
    "enabled",
    "capture_point",
    "src_zone", "dst_zone",
    "src_addr", "dst_addr", "service",
    "match_action",
    "pcap_file",
    "rotate_size_mb", "rotate_keep",
    "snap_len",
    "queue_depth",
    "comment",
}


def _parse_capture_point(raw: str, *, source: str, section: str) -> CapturePoint:
    raw = raw.strip().lower()
    try:
        return CapturePoint(raw)
    except ValueError:
        valid = ", ".join(p.value for p in CapturePoint)
        raise ConfigError(
            f"capture_point must be one of: {valid} (got {raw!r})",
            source=source, section=section,
        ) from None


def _parse_match_action(raw: str, *, source: str, section: str) -> CaptureMatchAction:
    raw = raw.strip().lower()
    try:
        return CaptureMatchAction(raw)
    except ValueError:
        valid = ", ".join(a.value for a in CaptureMatchAction)
        raise ConfigError(
            f"match_action must be one of: {valid} (got {raw!r})",
            source=source, section=section,
        ) from None


class CaptureConfigLoader:
    def __init__(self, root: str | Path, policy_config: Config):
        self.root = Path(root)
        self.policy_config = policy_config

    def load(self) -> CaptureConfig:
        path = self.root / "policies" / "capture.ini"
        if not path.exists():
            return CaptureConfig(rules=())

        cp = _read_ini(path)
        source = "policies/capture.ini"

        if "capture_order" not in cp:
            raise ConfigError("[capture_order] section missing", source=source)
        if "rules" not in cp["capture_order"]:
            raise ConfigError(
                "[capture_order] missing 'rules'",
                source=source, section="capture_order",
            )

        order = _parse_csv(cp["capture_order"]["rules"])
        # An empty order is valid for capture — operator may have all
        # rules disabled while keeping the file structure.
        if not order:
            return CaptureConfig(rules=())

        # Verify every order entry has a section
        missing = [r for r in order if r not in cp.sections()]
        if missing:
            raise ConfigError(
                f"capture_order references undefined rules: {missing}",
                source=source, section="capture_order",
            )

        rules: list[CaptureRule] = []
        for rule_id in order:
            rules.append(self._parse_rule(rule_id, cp[rule_id], source))

        return CaptureConfig(rules=tuple(rules))

    def _parse_rule(
        self,
        rule_id: str,
        section: configparser.SectionProxy,
        source: str,
    ) -> CaptureRule:
        _check_keys(
            section.keys(), _CAPTURE_RULE_KEYS,
            source=source, section=rule_id,
        )

        # Required keys
        for required in ("capture_point", "pcap_file"):
            if required not in section:
                raise ConfigError(
                    f"missing required key '{required}'",
                    source=source, section=rule_id,
                )

        capture_point = _parse_capture_point(
            section["capture_point"], source=source, section=rule_id,
        )

        match_action = _parse_match_action(
            section.get("match_action", "any"),
            source=source, section=rule_id,
        )

        # Vocabulary cross-validation
        src_zone = section.get("src_zone", "any")
        dst_zone = section.get("dst_zone", "any")
        src_addr = section.get("src_addr", "addr_any")
        dst_addr = section.get("dst_addr", "addr_any")
        service = section.get("service", "svc_any")

        zone_names = set(self.policy_config.zones.keys())
        if src_zone != "any" and src_zone not in zone_names:
            raise ConfigError(
                f"src_zone {src_zone!r} not defined in zones.ini",
                source=source, section=rule_id,
            )
        if dst_zone != "any" and dst_zone not in zone_names:
            raise ConfigError(
                f"dst_zone {dst_zone!r} not defined in zones.ini",
                source=source, section=rule_id,
            )
        if src_addr not in self.policy_config.addresses:
            raise ConfigError(
                f"src_addr {src_addr!r} not in addresses.ini",
                source=source, section=rule_id,
            )
        if dst_addr not in self.policy_config.addresses:
            raise ConfigError(
                f"dst_addr {dst_addr!r} not in addresses.ini",
                source=source, section=rule_id,
            )
        if service not in self.policy_config.services:
            raise ConfigError(
                f"service {service!r} not in services.ini",
                source=source, section=rule_id,
            )

        rotate_size_mb = _parse_int(
            section.get("rotate_size_mb", "0"),
            source=source, section=rule_id, key="rotate_size_mb",
        )
        if rotate_size_mb < 0:
            raise ConfigError(
                f"rotate_size_mb must be >= 0, got {rotate_size_mb}",
                source=source, section=rule_id,
            )
        rotate_keep = _parse_int(
            section.get("rotate_keep", "0"),
            source=source, section=rule_id, key="rotate_keep",
        )
        if rotate_keep < 0:
            raise ConfigError(
                f"rotate_keep must be >= 0, got {rotate_keep}",
                source=source, section=rule_id,
            )
        snap_len = _parse_int(
            section.get("snap_len", "0"),
            source=source, section=rule_id, key="snap_len",
        )
        if snap_len < 0:
            raise ConfigError(
                f"snap_len must be >= 0, got {snap_len}",
                source=source, section=rule_id,
            )
        queue_depth = _parse_int(
            section.get("queue_depth", "4096"),
            source=source, section=rule_id, key="queue_depth",
        )
        if queue_depth < 1:
            raise ConfigError(
                f"queue_depth must be >= 1, got {queue_depth}",
                source=source, section=rule_id,
            )

        return CaptureRule(
            id=rule_id,
            enabled=_parse_bool(
                section.get("enabled", "true"),
                source=source, section=rule_id, key="enabled",
            ),
            capture_point=capture_point,
            src_zone=src_zone,
            dst_zone=dst_zone,
            src_addr=src_addr,
            dst_addr=dst_addr,
            service=service,
            match_action=match_action,
            pcap_file=section["pcap_file"].strip(),
            rotate_size_mb=rotate_size_mb,
            rotate_keep=rotate_keep,
            snap_len=snap_len,
            queue_depth=queue_depth,
        )

"""
NATConfigLoader — parses policies/nat.ini and validates against the policy Config.

Reuses address/service/schedule/zone definitions from the main policy Config,
so NAT rules reference the same object vocabulary as security rules.
Zero duplication.

Validation mirrors config_loader.py: unknown keys raise, undefined references
raise, every error carries source + section.
"""

from __future__ import annotations

import configparser
from pathlib import Path
from typing import Optional

from .config_loader import _check_keys, _parse_bool, _parse_csv, _parse_int, _read_ini
from .errors import ConfigError
from .models import Config
from .nat_models import NATConfig, NATRule, NATType, PortPoolSpec


# Allowed keys per NAT-rule type (unknown keys raise)
_NAT_COMMON_KEYS = {
    "type",
    "src_zone", "dst_zone", "src_addr", "dst_addr", "service", "schedule",
    "log", "comment",
    "tcp_established_timeout", "tcp_half_open_timeout",
    "udp_timeout", "icmp_timeout",
}

_NAT_SNAT_KEYS = _NAT_COMMON_KEYS | {"translate_src_to", "port_pool"}
_NAT_DNAT_KEYS = _NAT_COMMON_KEYS | {"translate_dst_to", "translate_dst_port"}
_NAT_STATIC_KEYS = _NAT_COMMON_KEYS | {
    "internal_addr", "external_addr", "bidirectional",
}
_NAT_NO_NAT_KEYS = _NAT_COMMON_KEYS  # no translation params
_NAT_NAT64_KEYS = _NAT_COMMON_KEYS | {
    "nat64_prefix",          # optional, defaults to 64:ff9b::/96
    "translate_src_to_v4",   # required: v4 address object
    "port_pool",             # optional; reuses SNAT port pool semantics
}

_NAT_DEFAULTS_KEYS = {
    "tcp_established_timeout", "tcp_half_open_timeout",
    "udp_timeout", "icmp_timeout",
    "reaper_interval", "overflow_chain",
}


def _parse_port_pool(raw: str, *, source: str, section: str) -> PortPoolSpec:
    raw = raw.strip()
    if "-" not in raw:
        raise ConfigError(
            f"port_pool must be 'start-end', got {raw!r}",
            source=source, section=section,
        )
    lo, hi = (v.strip() for v in raw.split("-", 1))
    try:
        lo_i, hi_i = int(lo), int(hi)
    except ValueError as exc:
        raise ConfigError(
            f"port_pool values must be integers, got {raw!r}",
            source=source, section=section,
        ) from exc
    try:
        return PortPoolSpec(start=lo_i, end=hi_i)
    except ValueError as exc:
        raise ConfigError(str(exc), source=source, section=section) from exc


class NATConfigLoader:
    """Loads NAT rules from `<root>/policies/nat.ini`. Requires the policy
    Config so references can be validated."""

    def __init__(self, root: str | Path, policy_config: Config):
        self.root = Path(root)
        self.policy_config = policy_config

    def load(self) -> NATConfig:
        path = self.root / "policies" / "nat.ini"
        if not path.exists():
            # NAT is optional — no nat.ini means no translation rules.
            return NATConfig(rules=())

        cp = _read_ini(path)
        source = "policies/nat.ini"

        # Parse [nat_order]
        if "nat_order" not in cp:
            raise ConfigError("[nat_order] section missing", source=source)
        if "rules" not in cp["nat_order"]:
            raise ConfigError(
                "[nat_order] missing 'rules'",
                source=source, section="nat_order",
            )
        order = _parse_csv(cp["nat_order"]["rules"])
        if not order:
            raise ConfigError(
                "[nat_order] 'rules' is empty",
                source=source, section="nat_order",
            )

        # Check all referenced rules exist as sections
        missing = [r for r in order if r not in cp.sections()]
        if missing:
            raise ConfigError(
                f"nat_order references undefined rules: {missing}",
                source=source, section="nat_order",
            )

        # No duplicates
        seen = set()
        dupes = [r for r in order if r in seen or seen.add(r)]  # type: ignore[func-returns-value]
        if dupes:
            raise ConfigError(
                f"nat_order has duplicate rule IDs: {dupes}",
                source=source, section="nat_order",
            )

        # Parse [nat_defaults]
        tcp_est = 3600
        tcp_half = 30
        udp_to = 180
        icmp_to = 60
        reaper_int = 10
        overflow: tuple[str, ...] = ()

        if "nat_defaults" in cp:
            _check_keys(
                cp["nat_defaults"].keys(), _NAT_DEFAULTS_KEYS,
                source=source, section="nat_defaults",
            )
            if "tcp_established_timeout" in cp["nat_defaults"]:
                tcp_est = _parse_int(
                    cp["nat_defaults"]["tcp_established_timeout"],
                    source=source, section="nat_defaults", key="tcp_established_timeout",
                )
            if "tcp_half_open_timeout" in cp["nat_defaults"]:
                tcp_half = _parse_int(
                    cp["nat_defaults"]["tcp_half_open_timeout"],
                    source=source, section="nat_defaults", key="tcp_half_open_timeout",
                )
            if "udp_timeout" in cp["nat_defaults"]:
                udp_to = _parse_int(
                    cp["nat_defaults"]["udp_timeout"],
                    source=source, section="nat_defaults", key="udp_timeout",
                )
            if "icmp_timeout" in cp["nat_defaults"]:
                icmp_to = _parse_int(
                    cp["nat_defaults"]["icmp_timeout"],
                    source=source, section="nat_defaults", key="icmp_timeout",
                )
            if "reaper_interval" in cp["nat_defaults"]:
                reaper_int = _parse_int(
                    cp["nat_defaults"]["reaper_interval"],
                    source=source, section="nat_defaults", key="reaper_interval",
                )
            if "overflow_chain" in cp["nat_defaults"]:
                overflow = _parse_csv(cp["nat_defaults"]["overflow_chain"])

        # Parse individual rules
        rules: list[NATRule] = []
        valid_zones = set(self.policy_config.zones.keys()) | {"any"}
        valid_addrs = set(self.policy_config.addresses.keys())
        valid_svcs = set(self.policy_config.services.keys())
        valid_scheds = set(self.policy_config.schedules.keys())

        for rule_id in order:
            rule = self._parse_rule(
                rule_id, cp[rule_id], source,
                valid_zones, valid_addrs, valid_svcs, valid_scheds,
            )
            rules.append(rule)

        # Cross-validate overflow_chain references
        rule_ids = {r.id for r in rules}
        bad_overflow = [r for r in overflow if r not in rule_ids]
        if bad_overflow:
            raise ConfigError(
                f"overflow_chain references undefined rules: {bad_overflow}",
                source=source, section="nat_defaults",
            )

        return NATConfig(
            rules=tuple(rules),
            tcp_established_timeout=tcp_est,
            tcp_half_open_timeout=tcp_half,
            udp_timeout=udp_to,
            icmp_timeout=icmp_to,
            reaper_interval=reaper_int,
            overflow_chain=overflow,
        )

    def _parse_rule(
        self,
        rule_id: str,
        sect: configparser.SectionProxy,
        source: str,
        valid_zones: set[str],
        valid_addrs: set[str],
        valid_svcs: set[str],
        valid_scheds: set[str],
    ) -> NATRule:
        if "type" not in sect:
            raise ConfigError("rule missing 'type'", source=source, section=rule_id)
        try:
            nat_type = NATType.parse(sect["type"])
        except ValueError as exc:
            raise ConfigError(str(exc), source=source, section=rule_id) from exc

        # Choose allowed-keys set based on type
        allowed = {
            NATType.SOURCE_NAT: _NAT_SNAT_KEYS,
            NATType.DESTINATION_NAT: _NAT_DNAT_KEYS,
            NATType.STATIC_NAT: _NAT_STATIC_KEYS,
            NATType.NO_NAT: _NAT_NO_NAT_KEYS,
            NATType.NAT64: _NAT_NAT64_KEYS,
        }[nat_type]
        _check_keys(sect.keys(), allowed, source=source, section=rule_id)

        # Common match criteria — all optional, default "any"
        src_zone = sect.get("src_zone", "any").strip()
        dst_zone = sect.get("dst_zone", "any").strip()
        src_addr = sect.get("src_addr", "addr_any").strip()
        dst_addr = sect.get("dst_addr", "addr_any").strip()
        service = sect.get("service", "svc_any").strip()
        schedule = sect.get("schedule", "sched_always").strip()

        if src_zone not in valid_zones:
            raise ConfigError(
                f"src_zone {src_zone!r} not declared in zones.ini",
                source=source, section=rule_id,
            )
        if dst_zone not in valid_zones:
            raise ConfigError(
                f"dst_zone {dst_zone!r} not declared in zones.ini",
                source=source, section=rule_id,
            )
        if src_addr not in valid_addrs:
            raise ConfigError(
                f"src_addr {src_addr!r} not defined", source=source, section=rule_id,
            )
        if dst_addr not in valid_addrs:
            raise ConfigError(
                f"dst_addr {dst_addr!r} not defined", source=source, section=rule_id,
            )
        if service not in valid_svcs:
            raise ConfigError(
                f"service {service!r} not defined", source=source, section=rule_id,
            )
        if schedule not in valid_scheds:
            raise ConfigError(
                f"schedule {schedule!r} not defined", source=source, section=rule_id,
            )

        log_flag = _parse_bool(
            sect.get("log", "false"), source=source, section=rule_id, key="log",
        )
        comment = sect.get("comment", "")

        # Per-rule timeouts
        def _timeout(key: str) -> int:
            if key not in sect:
                return 0
            return _parse_int(sect[key], source=source, section=rule_id, key=key)

        tcp_est_to = _timeout("tcp_established_timeout")
        tcp_half_to = _timeout("tcp_half_open_timeout")
        udp_to_override = _timeout("udp_timeout")
        icmp_to_override = _timeout("icmp_timeout")

        # Type-specific fields
        translate_src_to = ""
        port_pool: Optional[PortPoolSpec] = None
        translate_dst_to = ""
        translate_dst_port = 0
        internal_addr = ""
        external_addr = ""
        bidirectional = True
        nat64_prefix = ""
        translate_src_to_v4 = ""

        if nat_type == NATType.SOURCE_NAT:
            if "translate_src_to" not in sect:
                raise ConfigError(
                    "source_nat requires 'translate_src_to'",
                    source=source, section=rule_id,
                )
            translate_src_to = sect["translate_src_to"].strip()
            if translate_src_to != "interface" and translate_src_to not in valid_addrs:
                raise ConfigError(
                    f"translate_src_to {translate_src_to!r} must be 'interface' "
                    f"or a defined address object",
                    source=source, section=rule_id,
                )
            if "port_pool" not in sect:
                raise ConfigError(
                    "source_nat requires 'port_pool'",
                    source=source, section=rule_id,
                )
            port_pool = _parse_port_pool(
                sect["port_pool"], source=source, section=rule_id,
            )

        elif nat_type == NATType.DESTINATION_NAT:
            if "translate_dst_to" not in sect:
                raise ConfigError(
                    "destination_nat requires 'translate_dst_to'",
                    source=source, section=rule_id,
                )
            translate_dst_to = sect["translate_dst_to"].strip()
            if translate_dst_to not in valid_addrs:
                raise ConfigError(
                    f"translate_dst_to {translate_dst_to!r} not defined",
                    source=source, section=rule_id,
                )
            if "translate_dst_port" in sect:
                translate_dst_port = _parse_int(
                    sect["translate_dst_port"],
                    source=source, section=rule_id, key="translate_dst_port",
                )
                if not (0 <= translate_dst_port <= 65535):
                    raise ConfigError(
                        f"translate_dst_port out of range: {translate_dst_port}",
                        source=source, section=rule_id,
                    )

        elif nat_type == NATType.STATIC_NAT:
            for required in ("internal_addr", "external_addr"):
                if required not in sect:
                    raise ConfigError(
                        f"static_nat requires {required!r}",
                        source=source, section=rule_id,
                    )
            internal_addr = sect["internal_addr"].strip()
            external_addr = sect["external_addr"].strip()
            if internal_addr not in valid_addrs:
                raise ConfigError(
                    f"internal_addr {internal_addr!r} not defined",
                    source=source, section=rule_id,
                )
            if external_addr not in valid_addrs:
                raise ConfigError(
                    f"external_addr {external_addr!r} not defined",
                    source=source, section=rule_id,
                )
            bidirectional = _parse_bool(
                sect.get("bidirectional", "true"),
                source=source, section=rule_id, key="bidirectional",
            )

        elif nat_type == NATType.NAT64:
            # `translate_src_to_v4` is required — a v4 address object the
            # translator will masquerade the v6 client behind. Without it
            # the v4 reply packets have nowhere to go.
            if "translate_src_to_v4" not in sect:
                raise ConfigError(
                    "nat64 requires 'translate_src_to_v4' (a v4 address object)",
                    source=source, section=rule_id,
                )
            translate_src_to_v4 = sect["translate_src_to_v4"].strip()
            if translate_src_to_v4 not in valid_addrs:
                raise ConfigError(
                    f"translate_src_to_v4 {translate_src_to_v4!r} not defined",
                    source=source, section=rule_id,
                )
            # Default prefix is the well-known 64:ff9b::/96; operator may
            # override with their own /96. We validate by parsing — parse
            # also enforces /96 for v1.
            from .nat64_addr import parse_nat64_prefix, NAT64AddressError
            raw_prefix = sect.get("nat64_prefix", "64:ff9b::/96").strip()
            try:
                parse_nat64_prefix(raw_prefix)
            except NAT64AddressError as e:
                raise ConfigError(
                    f"invalid nat64_prefix: {e}",
                    source=source, section=rule_id,
                ) from e
            nat64_prefix = raw_prefix
            # Optional port pool (same semantics as SNAT)
            if "port_pool" in sect:
                port_pool = _parse_port_pool(
                    sect["port_pool"], source=source, section=rule_id,
                )

        # NO_NAT has no extra fields

        return NATRule(
            id=rule_id,
            type=nat_type,
            src_zone=src_zone, dst_zone=dst_zone,
            src_addr=src_addr, dst_addr=dst_addr,
            service=service, schedule=schedule,
            translate_src_to=translate_src_to,
            port_pool=port_pool,
            translate_dst_to=translate_dst_to,
            translate_dst_port=translate_dst_port,
            internal_addr=internal_addr,
            external_addr=external_addr,
            bidirectional=bidirectional,
            nat64_prefix=nat64_prefix,
            translate_src_to_v4=translate_src_to_v4,
            tcp_established_timeout=tcp_est_to,
            tcp_half_open_timeout=tcp_half_to,
            udp_timeout=udp_to_override,
            icmp_timeout=icmp_to_override,
            log=log_flag,
            comment=comment,
        )

"""
nat64_icmp — ICMP/ICMPv6 cross-translation per RFC 7915 §5.

This is the subtle part of NAT64. When a v6-only client receives an
error from a v4 path (e.g., TTL expired at some router), the ICMP
message arrives at the firewall as IPv4 ICMP. The firewall must:

  1. Translate the ICMP type and code (different numbering in v6).
  2. Rebuild the outer packet as v6.
  3. Recursively translate the embedded offending packet (the first
     bytes of what the router was reporting on) so the client sees
     its own addressing, not the firewall's.

Type/code mappings we implement for v1 (RFC 7915 §5.1 and §5.2):

  v6 → v4 outer (Echo and errors):
    128 Echo Request          -> 8
    129 Echo Reply            -> 0
      1 Destination Unreachable codes:
         0 No Route           -> 3 Net Unreachable       (1)
         1 Administratively   -> 3 Host Admin Prohib.   (10)
         2 Beyond Scope       -> 3 Net Unreachable       (1)
         3 Address Unreachable-> 3 Host Unreachable      (1)
         4 Port Unreachable   -> 3 Port Unreachable      (3)
      2 Packet Too Big        -> 3 Frag Needed/DF set    (4)  (adjust MTU)
      3 Time Exceeded         -> 11 (code preserved)
      4 Parameter Problem     -> 12 (with Pointer translate)

  v4 → v6 outer:
      0 Echo Reply            -> 129
      8 Echo Request          -> 128
      3 Destination Unreachable codes:
         0 Net Unreachable    -> 1 No Route              (0)
         1 Host Unreachable   -> 1 Address Unreachable   (3)
         2 Protocol Unreach.  -> 4 Parameter Problem     (1)  (pointer=6)
         3 Port Unreachable   -> 1 Port Unreachable      (4)
         4 Frag Needed/DF set -> 2 Packet Too Big        (MTU adj)
      4 Source Quench          -> SILENTLY DROPPED (RFC 7915 §4.2)
     11 Time Exceeded         -> 3  (code preserved)
     12 Parameter Problem     -> 4  (Pointer translate)

Unsupported messages are dropped. The caller is expected to log this
event but continue operation.

Embedded payload translation: most error messages carry the "as much
of the original packet as will fit without exceeding the minimum MTU."
For ICMPv4 that's typically the IP header + 8 bytes of the original L4.
For ICMPv6 it can be up to 1232 bytes (IPv6 minimum MTU 1280 minus
headers). When translating, we translate ONLY the outer addresses and
the IP header of the embedded packet; we do not recurse into multiply-
nested errors.

Reference: RFC 7915 §5 (obsoletes RFC 6145).
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from ipaddress import IPv4Address, IPv6Address, IPv6Network

from .checksum import calculate_ip_checksum
from .frame_codec_v6 import (
    ETH_P_IPV6, IP_PROTO_ICMPV6, IP_PROTO_TCP, IP_PROTO_UDP,
    compute_l4_checksum_v6,
)
from .frame_codec import ETH_P_IP
from .nat64_addr import embed_v4_in_v6, extract_v4_from_v6


class ICMPTranslationError(Exception):
    """Raised when an ICMP message cannot be translated (unsupported
    type, malformed, etc.). Callers should drop and log."""


# ---------------------------------------------------------------------------
# Type/code mapping tables
# ---------------------------------------------------------------------------


# v4 → v6: given (type, code), return (new_type, new_code) or None if drop.
# MTU translation is handled specially for PTB — the caller passes the MTU.
_V4_TO_V6_MAP: dict[tuple[int, int], tuple[int, int]] = {
    # Echo
    (0, 0): (129, 0),
    (8, 0): (128, 0),
    # Destination Unreachable
    (3, 0): (1, 0),   # Net Unreachable -> No Route
    (3, 1): (1, 3),   # Host Unreachable -> Address Unreachable
    (3, 3): (1, 4),   # Port Unreachable -> Port Unreachable
    (3, 4): (2, 0),   # Frag Needed -> Packet Too Big (MTU handled separately)
    # Time Exceeded
    (11, 0): (3, 0),
    (11, 1): (3, 1),
    # Parameter Problem
    (12, 0): (4, 0),  # Pointer indicates error — pointer field translated
    (12, 1): (4, 0),
}


# v6 → v4: reverse mapping.
_V6_TO_V4_MAP: dict[tuple[int, int], tuple[int, int]] = {
    (129, 0): (0, 0),
    (128, 0): (8, 0),
    (1, 0): (3, 1),   # No Route -> Host Unreachable (RFC 7915 Table 3)
    (1, 1): (3, 10),  # Admin Prohib -> Host Admin Prohibited
    (1, 2): (3, 1),   # Beyond Scope -> Host Unreachable
    (1, 3): (3, 1),   # Address Unreachable -> Host Unreachable
    (1, 4): (3, 3),   # Port Unreachable -> Port Unreachable
    (2, 0): (3, 4),   # Packet Too Big -> Frag Needed/DF set (MTU adjusted)
    (3, 0): (11, 0),  # Hop limit exceeded -> Time Exceeded
    (3, 1): (11, 1),
    (4, 0): (12, 0),  # Erroneous header -> Parameter Problem
}


# Messages that MUST be dropped (never translated)
_V4_DROP_TYPES = frozenset({4})    # Source Quench (deprecated)


def map_v4_to_v6_type_code(v4_type: int, v4_code: int) -> tuple[int, int] | None:
    """Return the (type, code) to use in the translated ICMPv6 message,
    or None if this v4 message should be silently dropped."""
    if v4_type in _V4_DROP_TYPES:
        return None
    return _V4_TO_V6_MAP.get((v4_type, v4_code))


def map_v6_to_v4_type_code(v6_type: int, v6_code: int) -> tuple[int, int] | None:
    """Return the (type, code) to use in the translated ICMPv4 message,
    or None if this v6 message should be silently dropped."""
    return _V6_TO_V4_MAP.get((v6_type, v6_code))


# ---------------------------------------------------------------------------
# ICMPv6 Echo translation (128 → 8, 129 → 0)
# ---------------------------------------------------------------------------


def translate_icmpv6_echo_to_v4(
    icmpv6_payload: bytes,
    v4_src: IPv4Address, v4_dst: IPv4Address,
    *,
    ttl: int = 64,
    packet_id: int = 0,
) -> bytes:
    """Translate an ICMPv6 Echo Request (128) or Echo Reply (129) to
    the v4 equivalent.

    `icmpv6_payload` is the ICMPv6 message (starting with type byte),
    NOT the outer IPv6 header. Returns a full IPv4 packet (20-byte header
    + ICMP payload) — caller prepends Ethernet.

    The Echo Identifier and Sequence Number fields are at the same offsets
    in both versions, so only type/code/checksum change.
    """
    if len(icmpv6_payload) < 8:
        raise ICMPTranslationError("ICMPv6 Echo too short")

    v6_type = icmpv6_payload[0]
    v6_code = icmpv6_payload[1]
    mapping = map_v6_to_v4_type_code(v6_type, v6_code)
    if mapping is None:
        raise ICMPTranslationError(
            f"unsupported ICMPv6 type/code for Echo: {v6_type}/{v6_code}"
        )
    v4_type, v4_code = mapping

    # Build the new ICMPv4 message
    new_icmp = bytearray(icmpv6_payload)
    new_icmp[0] = v4_type
    new_icmp[1] = v4_code
    # Zero the checksum for recomputation
    new_icmp[2] = 0
    new_icmp[3] = 0

    # ICMPv4 checksum is just one's complement over the ICMP payload,
    # no pseudo-header (unlike ICMPv6).
    cksum = _icmp_v4_checksum(bytes(new_icmp))
    struct.pack_into("!H", new_icmp, 2, cksum)

    # Build the IPv4 header
    total_length = 20 + len(new_icmp)
    v4_header = bytearray(20)
    v4_header[0] = 0x45
    v4_header[1] = 0  # TOS
    struct.pack_into("!H", v4_header, 2, total_length)
    struct.pack_into("!H", v4_header, 4, packet_id)
    v4_header[6] = 0x40  # Don't Fragment
    v4_header[8] = ttl
    v4_header[9] = 1  # ICMP
    v4_header[12:16] = v4_src.packed
    v4_header[16:20] = v4_dst.packed
    ip_cksum = calculate_ip_checksum(bytes(v4_header))
    struct.pack_into("!H", v4_header, 10, ip_cksum)

    return bytes(v4_header) + bytes(new_icmp)


def translate_icmp_echo_to_v6(
    icmp_payload: bytes,
    v6_src: IPv6Address, v6_dst: IPv6Address,
    *,
    hop_limit: int = 64,
) -> bytes:
    """Translate an ICMPv4 Echo (8 → 128, 0 → 129) to ICMPv6.

    Returns the full IPv6 packet (40-byte header + ICMPv6 payload).
    """
    if len(icmp_payload) < 8:
        raise ICMPTranslationError("ICMP Echo too short")

    v4_type = icmp_payload[0]
    v4_code = icmp_payload[1]
    mapping = map_v4_to_v6_type_code(v4_type, v4_code)
    if mapping is None:
        raise ICMPTranslationError(
            f"ICMPv4 type/code drop for Echo: {v4_type}/{v4_code}"
        )
    v6_type, v6_code = mapping

    new_icmp = bytearray(icmp_payload)
    new_icmp[0] = v6_type
    new_icmp[1] = v6_code
    # Zero checksum — will be recomputed with v6 pseudo-header
    new_icmp[2] = 0
    new_icmp[3] = 0
    cksum = compute_l4_checksum_v6(
        v6_src, v6_dst, IP_PROTO_ICMPV6, bytes(new_icmp),
    )
    struct.pack_into("!H", new_icmp, 2, cksum)

    # Build IPv6 header
    payload_length = len(new_icmp)
    vtcfl = (6 << 28)
    v6_header = (
        struct.pack("!I", vtcfl) +
        struct.pack("!H", payload_length) +
        struct.pack("!B", IP_PROTO_ICMPV6) +
        struct.pack("!B", hop_limit) +
        v6_src.packed + v6_dst.packed
    )
    return bytes(v6_header) + bytes(new_icmp)


# ---------------------------------------------------------------------------
# ICMP Error messages — the recursive part (RFC 7915 §5.2)
# ---------------------------------------------------------------------------


def translate_embedded_header_v4_to_v6(
    embedded_v4_hdr: bytes,
    nat64_prefix: IPv6Network,
    # The original session's original v6 addresses (if known from session table).
    # If None, we construct a best-effort v6 header by embedding v4 addrs into
    # the NAT64 prefix. This is what an unmapped-address fallback looks like.
    orig_v6_src: IPv6Address | None = None,
    orig_v6_dst: IPv6Address | None = None,
) -> bytes:
    """Translate the IPv4 header embedded inside an ICMP error message
    into an IPv6 header.

    Per RFC 7915 §5.2 we produce a synthetic v6 header that mirrors the
    v4 addressing viewed from the v6 client's perspective. The caller
    has presumably looked up the session matching (v4 src, v4 dst, etc.)
    to recover the original v6 tuple.
    """
    if len(embedded_v4_hdr) < 20:
        raise ICMPTranslationError("embedded v4 header too short")
    ihl = (embedded_v4_hdr[0] & 0x0F) * 4
    if ihl < 20:
        raise ICMPTranslationError(f"embedded IHL too small: {ihl}")

    src_v4 = IPv4Address(embedded_v4_hdr[12:16])
    dst_v4 = IPv4Address(embedded_v4_hdr[16:20])
    protocol = embedded_v4_hdr[9]
    total_length = struct.unpack("!H", embedded_v4_hdr[2:4])[0]

    # Determine v6 addresses. If the caller gave us explicit mappings
    # (from session lookup), use them. Otherwise embed via prefix.
    if orig_v6_src is None:
        orig_v6_src = embed_v4_in_v6(src_v4, nat64_prefix)
    if orig_v6_dst is None:
        orig_v6_dst = embed_v4_in_v6(dst_v4, nat64_prefix)

    # Protocol stays the same for TCP/UDP; ICMP→ICMPv6 is 1→58.
    if protocol == 1:  # ICMP
        v6_next = IP_PROTO_ICMPV6
    elif protocol == 6:
        v6_next = IP_PROTO_TCP
    elif protocol == 17:
        v6_next = IP_PROTO_UDP
    else:
        raise ICMPTranslationError(
            f"embedded protocol {protocol} not supported for translation"
        )

    # Payload length in v6 refers to what comes AFTER the fixed 40-byte
    # header, which is the embedded L4 snippet. In v4, the error carries
    # typically 8 bytes of the original L4, so the "synthetic payload
    # length" is that amount.
    embedded_l4_len = total_length - ihl
    # Build synthetic v6 header
    vtcfl = (6 << 28)
    v6_header = (
        struct.pack("!I", vtcfl) +
        struct.pack("!H", embedded_l4_len) +
        struct.pack("!B", v6_next) +
        struct.pack("!B", 64) +  # hop limit — synthetic
        orig_v6_src.packed + orig_v6_dst.packed
    )
    return bytes(v6_header)


def translate_embedded_header_v6_to_v4(
    embedded_v6_hdr: bytes,
    nat64_prefix: IPv6Network,
    orig_v4_src: IPv4Address | None = None,
    orig_v4_dst: IPv4Address | None = None,
) -> bytes:
    """Translate an IPv6 header embedded in an ICMPv6 error to an IPv4
    header for the outer ICMP error message (which will be delivered
    over v4 to a v4 party — rare, but RFC 7915 defines it)."""
    if len(embedded_v6_hdr) < 40:
        raise ICMPTranslationError("embedded v6 header too short")

    src_v6 = IPv6Address(embedded_v6_hdr[8:24])
    dst_v6 = IPv6Address(embedded_v6_hdr[24:40])
    next_hdr = embedded_v6_hdr[6]
    payload_length = struct.unpack("!H", embedded_v6_hdr[4:6])[0]

    # Recover v4 addresses
    if orig_v4_src is None:
        try:
            orig_v4_src = extract_v4_from_v6(src_v6, nat64_prefix)
        except Exception:
            raise ICMPTranslationError(
                f"cannot extract v4 src from {src_v6}"
            )
    if orig_v4_dst is None:
        try:
            orig_v4_dst = extract_v4_from_v6(dst_v6, nat64_prefix)
        except Exception:
            raise ICMPTranslationError(
                f"cannot extract v4 dst from {dst_v6}"
            )

    if next_hdr == IP_PROTO_ICMPV6:
        v4_proto = 1
    elif next_hdr == IP_PROTO_TCP:
        v4_proto = 6
    elif next_hdr == IP_PROTO_UDP:
        v4_proto = 17
    else:
        raise ICMPTranslationError(
            f"embedded next header {next_hdr} not supported for translation"
        )

    # Build synthetic v4 header (20 bytes, no options)
    total_length = 20 + payload_length
    v4_header = bytearray(20)
    v4_header[0] = 0x45
    struct.pack_into("!H", v4_header, 2, total_length)
    v4_header[8] = 64  # TTL
    v4_header[9] = v4_proto
    v4_header[12:16] = orig_v4_src.packed
    v4_header[16:20] = orig_v4_dst.packed
    ip_cksum = calculate_ip_checksum(bytes(v4_header))
    struct.pack_into("!H", v4_header, 10, ip_cksum)
    return bytes(v4_header)


# ---------------------------------------------------------------------------
# ICMPv4 checksum helper (no pseudo-header)
# ---------------------------------------------------------------------------


def _icmp_v4_checksum(data: bytes) -> int:
    """One's complement sum over the ICMPv4 message. No pseudo-header."""
    # Pad to even length
    if len(data) % 2:
        data = data + b"\x00"
    total = 0
    for i in range(0, len(data), 2):
        total += (data[i] << 8) | data[i + 1]
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF

"""
ScheduleEvaluator — pure function of (schedule_id, now) -> bool.

Handles ALWAYS / RECURRING / ONE_TIME schedule types with tz awareness.
Takes `now` as an argument — no hidden calls to datetime.now() — so tests
can inject any timestamp.
"""

from __future__ import annotations

from datetime import datetime, time
from typing import Mapping
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .errors import ResolverError
from .models import Schedule, ScheduleType


class ScheduleEvaluator:
    def __init__(self, schedules: Mapping[str, Schedule]):
        self._schedules = dict(schedules)

        # Pre-parse times and datetimes to validate config up-front
        self._parsed: dict[str, dict] = {}
        for sid, sched in self._schedules.items():
            try:
                tz = ZoneInfo(sched.timezone)
            except ZoneInfoNotFoundError as exc:
                raise ResolverError(
                    f"schedule {sid!r}: unknown timezone {sched.timezone!r}"
                ) from exc

            entry: dict = {"tz": tz}
            if sched.type == ScheduleType.RECURRING:
                entry["start"] = _parse_hhmm(sched.start_time)
                entry["end"] = _parse_hhmm(sched.end_time)
                entry["days"] = set(sched.days)
            elif sched.type == ScheduleType.ONE_TIME:
                entry["start_dt"] = _parse_iso(sched.start_datetime, tz)
                entry["end_dt"] = _parse_iso(sched.end_datetime, tz)
                if entry["end_dt"] < entry["start_dt"]:
                    raise ResolverError(
                        f"schedule {sid!r}: end < start"
                    )
            self._parsed[sid] = entry

    def matches(self, schedule_id: str, now: datetime) -> bool:
        """
        Return True if `now` falls within the named schedule window.

        `now` must be timezone-aware. Evaluation converts to the schedule's
        timezone before comparing (for recurring schedules in particular).
        """
        if schedule_id not in self._schedules:
            raise ResolverError(f"unknown schedule: {schedule_id!r}")
        if now.tzinfo is None:
            raise ResolverError(
                "ScheduleEvaluator.matches() requires tz-aware datetime; got naive"
            )

        sched = self._schedules[schedule_id]
        entry = self._parsed[schedule_id]
        tz = entry["tz"]

        if sched.type == ScheduleType.ALWAYS:
            return True

        local = now.astimezone(tz)

        if sched.type == ScheduleType.RECURRING:
            if local.weekday() not in entry["days"]:
                return False
            # Inclusive start, exclusive end to avoid the 18:00 overlap ambiguity
            local_t = local.time()
            return entry["start"] <= local_t < entry["end"]

        if sched.type == ScheduleType.ONE_TIME:
            return entry["start_dt"] <= local <= entry["end_dt"]

        return False


def _parse_hhmm(raw: str) -> time:
    h, m = raw.split(":")
    return time(int(h), int(m))


def _parse_iso(raw: str, tz: ZoneInfo) -> datetime:
    # Accept "YYYY-MM-DD HH:MM" or "YYYY-MM-DDTHH:MM[:SS]"
    raw = raw.strip().replace("T", " ")
    fmts = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M")
    for fmt in fmts:
        try:
            naive = datetime.strptime(raw, fmt)
            return naive.replace(tzinfo=tz)
        except ValueError:
            continue
    raise ResolverError(f"cannot parse one_time datetime: {raw!r}")

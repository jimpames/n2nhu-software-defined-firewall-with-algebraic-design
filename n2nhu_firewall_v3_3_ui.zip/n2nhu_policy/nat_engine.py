"""
NAT engine — translate(packet, now) -> TranslatedPacket | PassThrough | NATDenied.

Two phases per packet:
  1. Session lookup — existing session? reuse its translation.
  2. Rule walk     — no session? match rules, create session if needed.

Execution model matches the policy engine: first-match wins. Rules are walked
in `nat_order` declared in nat.ini.

Integration contract with the data plane:
  - Called AFTER zone classification, BEFORE security policy evaluation.
  - Security policy evaluates on pre-NAT (original) addresses.
  - If security says ALLOW, data plane applies the translation returned here.
  - Session.touch() is the data-plane's responsibility on each packet.
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime
from ipaddress import IPv4Address
from typing import Callable, Optional, Union

from .models import Config, Packet, Protocol
from .nat_models import (
    Direction,
    NATConfig,
    NATDenied,
    NATRule,
    NATSession,
    NATType,
    PassThrough,
    TranslatedPacket,
)
from .object_resolver import ObjectResolver
from .port_pool import PortPool, PortPoolExhausted
from .schedule_evaluator import ScheduleEvaluator
from .session_table import SessionTable
from .zone_map import ZoneMap


# Type alias: either a translation result, a bypass, or a denial
NATResult = Union[TranslatedPacket, PassThrough, NATDenied]


class NATEngine:
    """
    The NAT translation plane. Mirrors PolicyEngine's API:
        translate(packet, now) -> NATResult

    Stateful: holds session table and port pools. Reload replaces the engine
    entirely (old sessions drop — same pattern as policy config reload).
    """

    def __init__(
        self,
        policy_config: Config,
        nat_config: NATConfig,
        resolver: Optional[ObjectResolver] = None,
        zone_map: Optional[ZoneMap] = None,
        schedule_evaluator: Optional[ScheduleEvaluator] = None,
        interface_ips: Optional[dict[str, IPv4Address]] = None,
        *,
        clock: Callable[[], float] = time.time,
    ):
        self.policy_config = policy_config
        self.nat_config = nat_config
        self.resolver = resolver or ObjectResolver(
            policy_config.addresses, policy_config.services,
        )
        self.zone_map = zone_map or ZoneMap(
            policy_config.zones, policy_config.interface_to_zone, policy_config.defaults,
        )
        self.schedules = schedule_evaluator or ScheduleEvaluator(policy_config.schedules)
        self._interface_ips = interface_ips or {}
        self._clock = clock

        # Build port pools for SNAT and NAT64 rules (both masquerade onto
        # a v4 address and need unique source ports per flow)
        self._port_pools: dict[str, PortPool] = {}
        for rule in nat_config.rules:
            if rule.type in (NATType.SOURCE_NAT, NATType.NAT64) and rule.port_pool is not None:
                self._port_pools[rule.id] = PortPool(rule.port_pool)

        self._rules_by_id: dict[str, NATRule] = {r.id: r for r in nat_config.rules}

        # Session table with rule-lookup callback for reaper
        self.session_table = SessionTable(
            nat_config,
            rule_lookup=self._rule_lookup,
            port_pools=self._port_pools,
            clock=clock,
        )

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def translate(self, packet: Packet, now: datetime) -> NATResult:
        """
        Decide how to translate this packet.

        Returns one of:
          TranslatedPacket — apply new src/dst, recompute checksums
          PassThrough      — leave the packet alone (no-NAT match, or no rule)
          NATDenied        — data plane must drop (port pool exhausted, etc.)
        """
        # Phase 1: Check for existing session (forward direction)
        fwd_session = self.session_table.lookup_forward(
            packet.src_ip, packet.src_port,
            packet.dst_ip, packet.dst_port,
            packet.protocol,
        )
        if fwd_session is not None:
            fwd_session.touch(self._clock(), Direction.FORWARD)
            return TranslatedPacket(
                src_ip=fwd_session.xlated_src_ip,
                src_port=fwd_session.xlated_src_port,
                dst_ip=fwd_session.xlated_dst_ip,
                dst_port=fwd_session.xlated_dst_port,
                session_id=fwd_session.session_id,
                rule_id=fwd_session.rule_id,
            )

        # Phase 2: Check for reverse-traffic session
        rev_session = self.session_table.lookup_reverse(
            packet.src_ip, packet.src_port,
            packet.dst_ip, packet.dst_port,
            packet.protocol,
        )
        if rev_session is not None:
            rev_session.touch(self._clock(), Direction.REVERSE)
            # Reverse-direction translation inverts the session's mapping:
            if rev_session.nat_type == NATType.SOURCE_NAT:
                # Return SNAT: packet is (their_ip:their_port -> xlated_src:xlated_port),
                # rewrite dst to (orig_src:orig_src_port).
                return TranslatedPacket(
                    src_ip=packet.src_ip,
                    src_port=packet.src_port,
                    dst_ip=rev_session.orig_src_ip,
                    dst_port=rev_session.orig_src_port,
                    session_id=rev_session.session_id,
                    rule_id=rev_session.rule_id,
                )
            if rev_session.nat_type == NATType.DESTINATION_NAT:
                # Return DNAT: packet is (internal_host:internal_port -> their_ip:their_port),
                # rewrite src to (orig_dst:orig_dst_port) — the external-facing identity.
                return TranslatedPacket(
                    src_ip=rev_session.orig_dst_ip,
                    src_port=rev_session.orig_dst_port,
                    dst_ip=packet.dst_ip,
                    dst_port=packet.dst_port,
                    session_id=rev_session.session_id,
                    rule_id=rev_session.rule_id,
                )

        # Phase 3: Walk the rule matrix for a new match
        try:
            src_zone = self.zone_map.zone_for_interface(packet.ingress_iface)
            dst_zone = self.zone_map.zone_for_interface(packet.egress_iface)
        except Exception:
            # Interface unknown → no NAT
            return PassThrough()

        for rule in self.nat_config.rules:
            if not self._rule_matches(rule, packet, src_zone, dst_zone, now):
                continue
            return self._apply_new_rule(rule, packet)

        # Phase 4: No rule matched → pass through unmodified
        return PassThrough()

    # -----------------------------------------------------------------------
    # Rule match helpers
    # -----------------------------------------------------------------------

    def _rule_matches(
        self,
        rule: NATRule,
        packet: Packet,
        src_zone: str,
        dst_zone: str,
        now: datetime,
    ) -> bool:
        # Zone match (explicit or "any")
        if rule.src_zone != "any" and rule.src_zone != src_zone:
            return False
        if rule.dst_zone != "any" and rule.dst_zone != dst_zone:
            return False

        # Static NAT is special: it matches on internal_addr (forward) OR
        # external_addr (reverse for bidirectional).
        if rule.type == NATType.STATIC_NAT:
            return self._static_rule_matches(rule, packet)

        # Address match
        if not self.resolver.ip_in_address(packet.src_ip, rule.src_addr):
            return False
        if not self.resolver.ip_in_address(packet.dst_ip, rule.dst_addr):
            return False

        # Service match
        if not self.resolver.service_matches(
            rule.service,
            protocol=packet.protocol,
            dst_port=packet.dst_port,
            src_port=packet.src_port,
            icmp_type=packet.icmp_type,
        ):
            return False

        # Schedule match
        if not self.schedules.matches(rule.schedule, now):
            return False

        return True

    def _static_rule_matches(self, rule: NATRule, packet: Packet) -> bool:
        # Forward: src is internal
        if self.resolver.ip_in_address(packet.src_ip, rule.internal_addr):
            return True
        # Reverse: dst is external (only if bidirectional)
        if rule.bidirectional and self.resolver.ip_in_address(
            packet.dst_ip, rule.external_addr,
        ):
            return True
        return False

    # -----------------------------------------------------------------------
    # Translation application
    # -----------------------------------------------------------------------

    def _apply_new_rule(self, rule: NATRule, packet: Packet) -> NATResult:
        if rule.type == NATType.NO_NAT:
            return PassThrough(rule_id=rule.id)

        if rule.type == NATType.SOURCE_NAT:
            return self._apply_snat(rule, packet)

        if rule.type == NATType.DESTINATION_NAT:
            return self._apply_dnat(rule, packet)

        if rule.type == NATType.STATIC_NAT:
            return self._apply_static(rule, packet)

        return PassThrough()

    def _apply_snat(self, rule: NATRule, packet: Packet) -> NATResult:
        # Resolve translated source IP
        if rule.translate_src_to == "interface":
            iface_ip = self._interface_ips.get(packet.egress_iface)
            if iface_ip is None:
                return NATDenied(
                    reason=f"egress interface {packet.egress_iface!r} has no IP configured",
                    rule_id=rule.id,
                )
            new_src_ip = iface_ip
        else:
            # Use the first network's first address from the address object
            flat = self.resolver.flatten_address(rule.translate_src_to)
            if not flat["networks"]:
                return NATDenied(
                    reason=f"translate_src_to {rule.translate_src_to!r} resolves to empty set",
                    rule_id=rule.id,
                )
            # For a /32 host object, network_address is the host itself.
            from ipaddress import IPv4Network
            net = IPv4Network(flat["networks"][0], strict=False)
            new_src_ip = net.network_address

        # Allocate a port from the pool, trying overflow chain on exhaustion
        new_src_port, chosen_rule = self._allocate_snat_port(rule)
        if new_src_port is None:
            return NATDenied(
                reason="port pool exhausted (including overflow chain)",
                rule_id=rule.id,
            )

        session = self.session_table.create_session(
            rule_id=chosen_rule.id,
            nat_type=NATType.SOURCE_NAT,
            protocol=packet.protocol,
            orig_src_ip=packet.src_ip, orig_src_port=packet.src_port,
            orig_dst_ip=packet.dst_ip, orig_dst_port=packet.dst_port,
            xlated_src_ip=new_src_ip, xlated_src_port=new_src_port,
            xlated_dst_ip=packet.dst_ip, xlated_dst_port=packet.dst_port,
        )
        # Count the creating packet itself — the data plane would call touch()
        # on every subsequent packet, but the initiating packet goes through
        # this create path not the session-reuse path.
        session.touch(self._clock(), Direction.FORWARD)

        return TranslatedPacket(
            src_ip=new_src_ip,
            src_port=new_src_port,
            dst_ip=packet.dst_ip,
            dst_port=packet.dst_port,
            session_id=session.session_id,
            rule_id=chosen_rule.id,
        )

    def _allocate_snat_port(
        self, rule: NATRule,
    ) -> tuple[Optional[int], NATRule]:
        """
        Try to allocate a port from rule.port_pool; on exhaustion, walk the
        overflow chain. Returns (port, rule_that_allocated) or (None, rule).
        """
        candidates = [rule.id]
        candidates.extend(
            rid for rid in self.nat_config.overflow_chain if rid != rule.id
        )
        for rid in candidates:
            pool = self._port_pools.get(rid)
            candidate_rule = self._rules_by_id.get(rid)
            if pool is None or candidate_rule is None:
                continue
            try:
                return pool.allocate(), candidate_rule
            except PortPoolExhausted:
                continue
        return None, rule

    def _apply_dnat(self, rule: NATRule, packet: Packet) -> NATResult:
        flat = self.resolver.flatten_address(rule.translate_dst_to)
        if not flat["networks"]:
            return NATDenied(
                reason=f"translate_dst_to {rule.translate_dst_to!r} resolves to empty set",
                rule_id=rule.id,
            )
        from ipaddress import IPv4Network
        net = IPv4Network(flat["networks"][0], strict=False)
        new_dst_ip = net.network_address
        new_dst_port = rule.translate_dst_port or packet.dst_port

        session = self.session_table.create_session(
            rule_id=rule.id,
            nat_type=NATType.DESTINATION_NAT,
            protocol=packet.protocol,
            orig_src_ip=packet.src_ip, orig_src_port=packet.src_port,
            orig_dst_ip=packet.dst_ip, orig_dst_port=packet.dst_port,
            xlated_src_ip=packet.src_ip, xlated_src_port=packet.src_port,
            xlated_dst_ip=new_dst_ip, xlated_dst_port=new_dst_port,
        )
        session.touch(self._clock(), Direction.FORWARD)

        return TranslatedPacket(
            src_ip=packet.src_ip,
            src_port=packet.src_port,
            dst_ip=new_dst_ip,
            dst_port=new_dst_port,
            session_id=session.session_id,
            rule_id=rule.id,
        )

    def _apply_static(self, rule: NATRule, packet: Packet) -> NATResult:
        """
        Static NAT is stateless — no session needed. Forward direction: rewrite
        src from internal to external. Reverse: rewrite dst from external to internal.
        """
        from ipaddress import IPv4Network

        internal_flat = self.resolver.flatten_address(rule.internal_addr)
        external_flat = self.resolver.flatten_address(rule.external_addr)
        if not internal_flat["networks"] or not external_flat["networks"]:
            return NATDenied(
                reason="static_nat refers to empty address object",
                rule_id=rule.id,
            )
        internal_ip = IPv4Network(internal_flat["networks"][0], strict=False).network_address
        external_ip = IPv4Network(external_flat["networks"][0], strict=False).network_address

        if self.resolver.ip_in_address(packet.src_ip, rule.internal_addr):
            # Forward: rewrite src
            return TranslatedPacket(
                src_ip=external_ip,
                src_port=packet.src_port,
                dst_ip=packet.dst_ip,
                dst_port=packet.dst_port,
                session_id=None,  # static NAT is stateless
                rule_id=rule.id,
            )
        if rule.bidirectional and self.resolver.ip_in_address(
            packet.dst_ip, rule.external_addr,
        ):
            # Reverse: rewrite dst
            return TranslatedPacket(
                src_ip=packet.src_ip,
                src_port=packet.src_port,
                dst_ip=internal_ip,
                dst_port=packet.dst_port,
                session_id=None,
                rule_id=rule.id,
            )

        # Shouldn't reach here if _static_rule_matches was correct
        return PassThrough()

    def _rule_lookup(self, rule_id: str) -> NATRule:
        if rule_id not in self._rules_by_id:
            raise KeyError(rule_id)
        return self._rules_by_id[rule_id]

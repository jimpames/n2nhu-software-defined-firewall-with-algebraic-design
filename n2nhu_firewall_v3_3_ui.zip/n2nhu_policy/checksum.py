"""
Checksum math for IP / TCP / UDP header rewriting after NAT.

References:
  RFC 791 — IP header checksum
  RFC 793 — TCP checksum (uses pseudo-header)
  RFC 768 — UDP checksum (uses pseudo-header; optional for IPv4 but we always compute)

All functions operate on bytes. The caller is responsible for producing the
pseudo-header in the right form. We expose both "compute fresh" and
"incremental update" variants — incremental update (RFC 1624) is ~20x faster
because it avoids re-summing the whole segment on every NAT rewrite.

Design note: byte-exact tests in test_checksum.py pin these against known-good
values so that any future speedup doesn't silently break correctness.
"""

from __future__ import annotations

import struct
from ipaddress import IPv4Address


# ---------------------------------------------------------------------------
# Raw one's-complement sum (internet checksum core, RFC 1071)
# ---------------------------------------------------------------------------


def ones_complement_sum(data: bytes) -> int:
    """
    Compute the one's complement sum of 16-bit words in `data`.

    If `data` has an odd length, the last byte is padded with a zero byte
    on the right. Returns a 16-bit integer.
    """
    if len(data) % 2:
        data = data + b"\x00"
    total = 0
    for i in range(0, len(data), 2):
        total += (data[i] << 8) | data[i + 1]
    # Fold 32-bit sum into 16 bits
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return total & 0xFFFF


def internet_checksum(data: bytes) -> int:
    """RFC 1071 internet checksum of `data`. Result is the 16-bit one's complement."""
    return (~ones_complement_sum(data)) & 0xFFFF


# ---------------------------------------------------------------------------
# IP header checksum
# ---------------------------------------------------------------------------


def calculate_ip_checksum(header: bytes) -> int:
    """
    Compute IP header checksum per RFC 791.

    `header` is the 20+ byte IPv4 header with the existing checksum field
    (bytes 10-11) zeroed. Returns the 16-bit checksum.
    """
    if len(header) < 20:
        raise ValueError(f"IP header too short: {len(header)} bytes")
    # Ensure the checksum field is zero before computation
    if header[10] != 0 or header[11] != 0:
        header = header[:10] + b"\x00\x00" + header[12:]
    return internet_checksum(header)


# ---------------------------------------------------------------------------
# TCP / UDP pseudo-header
# ---------------------------------------------------------------------------


def _pseudo_header(
    src_ip: IPv4Address,
    dst_ip: IPv4Address,
    protocol: int,    # 6 for TCP, 17 for UDP
    length: int,      # L4 segment length in bytes (header + payload)
) -> bytes:
    return struct.pack(
        "!4s4sBBH",
        src_ip.packed,
        dst_ip.packed,
        0,                # zero byte
        protocol,         # TCP=6, UDP=17
        length,
    )


def calculate_tcp_checksum(
    src_ip: IPv4Address,
    dst_ip: IPv4Address,
    tcp_segment: bytes,
) -> int:
    """
    Compute TCP checksum per RFC 793.

    `tcp_segment` is the TCP header + payload, with the existing checksum
    field (bytes 16-17) zeroed. Returns the 16-bit checksum.
    """
    if len(tcp_segment) < 20:
        raise ValueError(f"TCP segment too short: {len(tcp_segment)} bytes")
    if tcp_segment[16] != 0 or tcp_segment[17] != 0:
        tcp_segment = tcp_segment[:16] + b"\x00\x00" + tcp_segment[18:]
    pseudo = _pseudo_header(src_ip, dst_ip, 6, len(tcp_segment))
    return internet_checksum(pseudo + tcp_segment)


def calculate_udp_checksum(
    src_ip: IPv4Address,
    dst_ip: IPv4Address,
    udp_segment: bytes,
) -> int:
    """
    Compute UDP checksum per RFC 768.

    `udp_segment` is the UDP header + payload, with the existing checksum
    field (bytes 6-7) zeroed. Returns the 16-bit checksum.

    UDP checksum of 0 means "no checksum provided"; if the computed value
    is 0, callers should substitute 0xFFFF per RFC 768.
    """
    if len(udp_segment) < 8:
        raise ValueError(f"UDP segment too short: {len(udp_segment)} bytes")
    if udp_segment[6] != 0 or udp_segment[7] != 0:
        udp_segment = udp_segment[:6] + b"\x00\x00" + udp_segment[8:]
    pseudo = _pseudo_header(src_ip, dst_ip, 17, len(udp_segment))
    cksum = internet_checksum(pseudo + udp_segment)
    return cksum if cksum != 0 else 0xFFFF


# ---------------------------------------------------------------------------
# Incremental checksum update (RFC 1624) — the fast path for NAT
# ---------------------------------------------------------------------------


def incremental_update(
    old_checksum: int,
    old_words: list[int],
    new_words: list[int],
) -> int:
    """
    Update a checksum incrementally per RFC 1624 equation 3:

        HC' = ~(~HC + ~m + m')

    Where HC is the old checksum, m is the old 16-bit word being replaced,
    m' is the new 16-bit word. Accepts lists of equal-length word pairs to
    batch multiple simultaneous changes (e.g., IP + port rewrites at once).

    Returns the new 16-bit checksum.
    """
    if len(old_words) != len(new_words):
        raise ValueError("old/new word lists must have equal length")

    # Start from the complement of the existing checksum
    total = (~old_checksum) & 0xFFFF
    for old_w, new_w in zip(old_words, new_words):
        total += (~old_w) & 0xFFFF
        total += new_w & 0xFFFF

    # Fold
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def _ip_to_words(ip: IPv4Address) -> list[int]:
    """Split an IPv4 address into two 16-bit words (big-endian)."""
    packed = ip.packed
    return [
        (packed[0] << 8) | packed[1],
        (packed[2] << 8) | packed[3],
    ]


def update_ip_checksum_for_src_change(
    old_checksum: int,
    old_src: IPv4Address,
    new_src: IPv4Address,
) -> int:
    """IP header checksum update when only the source IP changed."""
    return incremental_update(
        old_checksum,
        _ip_to_words(old_src),
        _ip_to_words(new_src),
    )


def update_ip_checksum_for_dst_change(
    old_checksum: int,
    old_dst: IPv4Address,
    new_dst: IPv4Address,
) -> int:
    """IP header checksum update when only the destination IP changed."""
    return incremental_update(
        old_checksum,
        _ip_to_words(old_dst),
        _ip_to_words(new_dst),
    )


def update_l4_checksum_for_snat(
    old_checksum: int,
    old_src_ip: IPv4Address, new_src_ip: IPv4Address,
    old_src_port: int, new_src_port: int,
) -> int:
    """
    TCP/UDP checksum update for SNAT: src IP and src port both change.
    Both IP changes and port change are batched in a single incremental update.
    """
    return incremental_update(
        old_checksum,
        _ip_to_words(old_src_ip) + [old_src_port],
        _ip_to_words(new_src_ip) + [new_src_port],
    )


def update_l4_checksum_for_dnat(
    old_checksum: int,
    old_dst_ip: IPv4Address, new_dst_ip: IPv4Address,
    old_dst_port: int, new_dst_port: int,
) -> int:
    """TCP/UDP checksum update for DNAT."""
    return incremental_update(
        old_checksum,
        _ip_to_words(old_dst_ip) + [old_dst_port],
        _ip_to_words(new_dst_ip) + [new_dst_port],
    )

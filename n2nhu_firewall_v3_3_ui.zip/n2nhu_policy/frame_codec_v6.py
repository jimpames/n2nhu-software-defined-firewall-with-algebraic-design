"""
frame_codec_v6 — IPv6 frame parsing, building, and rewriting.

IPv6 differs from IPv4 in several important ways that required a separate
codec module rather than a branch inside frame_codec.py:

  1. Fixed 40-byte header (vs. variable 20-60 bytes in IPv4). All fields
     at fixed offsets: version/class/flow in [0:4], payload_length at [4:6],
     next_header at [6], hop_limit at [7], src at [8:24], dst at [24:40].

  2. NO header checksum. IPv6 dropped it entirely, relying on L2 FCS and
     L4 checksums. This means rewriting addresses does NOT require updating
     an IP header checksum — only the TCP/UDP checksum needs recomputation.

  3. Extension header chain. The 'Next Header' field chains zero or more
     extension headers (Hop-by-Hop, Routing, Fragment, Destination Options,
     ESP, AH) before the transport (TCP/UDP/ICMPv6). We walk this chain to
     find where the L4 header actually starts.

  4. TCP/UDP checksum uses a DIFFERENT pseudo-header than IPv4:
       v4: src(4) + dst(4) + zero(1) + proto(1) + length(2) = 12 bytes
       v6: src(16) + dst(16) + length(4) + zero(3) + next_hdr(1) = 40 bytes
     So we have a new pseudo-header checksum function.

  5. ICMPv6 is protocol 58 (not 1 like ICMP), uses the same checksum
     algorithm as TCP/UDP (covers the pseudo-header, unlike ICMPv4).

Reference: RFC 8200 (IPv6 spec), RFC 2460 (older but still cited),
RFC 4443 (ICMPv6).
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from ipaddress import IPv6Address
from typing import Optional

from .models import Protocol


# Ethertype for IPv6
ETH_P_IPV6 = 0x86DD

# IPv6 Next-Header values. The ones that terminate the chain (point to L4)
# are TCP, UDP, ICMPv6, and a few transport protocols. The extension
# headers (to keep walking) are listed in _EXTENSION_HEADERS.
IP_PROTO_HOPOPT = 0       # Hop-by-Hop Options (must be first if present)
IP_PROTO_ICMP = 1         # legacy ICMPv4 — should NOT appear in IPv6 stream
IP_PROTO_TCP = 6
IP_PROTO_UDP = 17
IP_PROTO_ROUTING = 43     # Routing header
IP_PROTO_FRAGMENT = 44    # Fragment header
IP_PROTO_ESP = 50         # IPsec ESP (terminates parsing for us — encrypted)
IP_PROTO_AH = 51          # IPsec Authentication Header
IP_PROTO_ICMPV6 = 58
IP_PROTO_NONE = 59        # No Next Header
IP_PROTO_DSTOPTS = 60     # Destination Options

# Extension headers we know how to skip over
_EXTENSION_HEADERS = frozenset({
    IP_PROTO_HOPOPT,
    IP_PROTO_ROUTING,
    IP_PROTO_FRAGMENT,
    IP_PROTO_DSTOPTS,
    IP_PROTO_AH,
})

# Hard limit on extension-header chain walks — paranoia against malicious
# crafted frames that loop or explode.
_MAX_EXT_HEADERS = 8


class FrameParseErrorV6(Exception):
    """Raised when an IPv6 frame cannot be parsed."""


@dataclass(frozen=True)
class ParsedFrameV6:
    """Parsed IPv6 frame. Structurally analogous to ParsedFrame (v4)."""

    raw: bytes

    # Ethernet
    eth_dst: bytes
    eth_src: bytes
    ethertype: int

    # IPv6 fixed header
    ip_header_start: int      # always 14 (after Ethernet)
    ip_version: int           # always 6
    traffic_class: int        # full 8-bit TC byte; DSCP is top 6 bits
    flow_label: int           # 20 bits
    payload_length: int
    hop_limit: int
    src_ip: IPv6Address
    dst_ip: IPv6Address

    # Extension header walking
    first_next_header: int    # value from fixed header's "next header" byte
    final_next_header: int    # L4 protocol after all extensions stripped
    extension_header_length: int  # total bytes consumed by extensions

    # L4
    l4_header_start: int
    l4_protocol: Protocol     # mapped from final_next_header
    src_port: int             # 0 for ICMPv6 / unknown
    dst_port: int             # 0 for ICMPv6 / unknown
    l4_checksum: int
    icmpv6_type: Optional[int]  # only for ICMPv6


# ----------------------------------------------------------------------
# Parsing
# ----------------------------------------------------------------------


def parse_frame_v6(frame: bytes) -> ParsedFrameV6:
    """Parse an Ethernet+IPv6 frame. Raise FrameParseErrorV6 on failure."""
    if len(frame) < 14 + 40:
        raise FrameParseErrorV6(f"frame too short: {len(frame)} bytes")

    eth_dst = frame[0:6]
    eth_src = frame[6:12]
    ethertype = struct.unpack("!H", frame[12:14])[0]
    if ethertype != ETH_P_IPV6:
        raise FrameParseErrorV6(f"not IPv6 (ethertype 0x{ethertype:04x})")

    ip_start = 14

    # First 4 bytes: version (4) + traffic class (8) + flow label (20) packed big-endian
    vtcfl = struct.unpack("!I", frame[ip_start:ip_start + 4])[0]
    version = (vtcfl >> 28) & 0xF
    if version != 6:
        raise FrameParseErrorV6(f"not IPv6 (version {version})")
    traffic_class = (vtcfl >> 20) & 0xFF
    flow_label = vtcfl & 0x000FFFFF

    payload_length = struct.unpack("!H", frame[ip_start + 4:ip_start + 6])[0]
    first_next_header = frame[ip_start + 6]
    hop_limit = frame[ip_start + 7]
    src_ip = IPv6Address(frame[ip_start + 8:ip_start + 24])
    dst_ip = IPv6Address(frame[ip_start + 24:ip_start + 40])

    if len(frame) < ip_start + 40 + payload_length:
        raise FrameParseErrorV6(
            f"frame truncated: header+payload {ip_start + 40 + payload_length} "
            f"but frame is {len(frame)} bytes"
        )

    # Walk the extension-header chain. Each extension header is at minimum
    # 8 bytes, with its length in the 2nd byte as (n+1)*8 bytes for most
    # types but the fragment header is fixed at 8.
    next_header = first_next_header
    cursor = ip_start + 40
    steps = 0
    while next_header in _EXTENSION_HEADERS and steps < _MAX_EXT_HEADERS:
        if cursor + 8 > len(frame):
            raise FrameParseErrorV6("truncated within extension header")
        if next_header == IP_PROTO_FRAGMENT:
            # Fragment header is always 8 bytes; layout:
            #   next_header(1), reserved(1), frag_offset+flags(2), id(4)
            hdr_len = 8
        else:
            # Generic ext header layout: next_header(1), hdr_ext_len(1, in 8-byte
            # units, not counting first 8 bytes), data...
            hdr_ext_len = frame[cursor + 1]
            hdr_len = (hdr_ext_len + 1) * 8
        if cursor + hdr_len > len(frame):
            raise FrameParseErrorV6("extension header extends beyond frame")
        next_header = frame[cursor]
        cursor += hdr_len
        steps += 1

    if steps >= _MAX_EXT_HEADERS and next_header in _EXTENSION_HEADERS:
        raise FrameParseErrorV6("extension header chain too long")

    final_next_header = next_header
    extension_header_length = cursor - (ip_start + 40)

    # Parse L4
    l4_start = cursor
    src_port = 0
    dst_port = 0
    l4_checksum = 0
    icmpv6_type: Optional[int] = None

    if final_next_header == IP_PROTO_TCP:
        if l4_start + 20 > len(frame):
            raise FrameParseErrorV6("frame truncated within TCP header")
        src_port, dst_port = struct.unpack("!HH", frame[l4_start:l4_start + 4])
        l4_checksum = struct.unpack("!H", frame[l4_start + 16:l4_start + 18])[0]
        l4_protocol = Protocol.TCP
    elif final_next_header == IP_PROTO_UDP:
        if l4_start + 8 > len(frame):
            raise FrameParseErrorV6("frame truncated within UDP header")
        src_port, dst_port = struct.unpack("!HH", frame[l4_start:l4_start + 4])
        l4_checksum = struct.unpack("!H", frame[l4_start + 6:l4_start + 8])[0]
        l4_protocol = Protocol.UDP
    elif final_next_header == IP_PROTO_ICMPV6:
        if l4_start + 4 > len(frame):
            raise FrameParseErrorV6("frame truncated within ICMPv6 header")
        icmpv6_type = frame[l4_start]
        l4_checksum = struct.unpack("!H", frame[l4_start + 2:l4_start + 4])[0]
        l4_protocol = Protocol.ICMPV6
    else:
        l4_protocol = Protocol.ANY

    return ParsedFrameV6(
        raw=frame,
        eth_dst=eth_dst,
        eth_src=eth_src,
        ethertype=ethertype,
        ip_header_start=ip_start,
        ip_version=6,
        traffic_class=traffic_class,
        flow_label=flow_label,
        payload_length=payload_length,
        hop_limit=hop_limit,
        src_ip=src_ip,
        dst_ip=dst_ip,
        first_next_header=first_next_header,
        final_next_header=final_next_header,
        extension_header_length=extension_header_length,
        l4_header_start=l4_start,
        l4_protocol=l4_protocol,
        src_port=src_port,
        dst_port=dst_port,
        l4_checksum=l4_checksum,
        icmpv6_type=icmpv6_type,
    )


# ----------------------------------------------------------------------
# IPv6 pseudo-header checksum (for TCP/UDP/ICMPv6)
# ----------------------------------------------------------------------


def _ones_complement_sum(data: bytes) -> int:
    """Standard internet one's-complement sum."""
    total = 0
    # Pad to even length
    if len(data) % 2:
        data = data + b"\x00"
    for i in range(0, len(data), 2):
        total += (data[i] << 8) | data[i + 1]
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return total


def ipv6_pseudo_header(
    src: IPv6Address, dst: IPv6Address,
    upper_layer_length: int, next_header: int,
) -> bytes:
    """Build the 40-byte IPv6 pseudo-header for TCP/UDP/ICMPv6 checksum."""
    return (
        src.packed + dst.packed +
        struct.pack("!I", upper_layer_length) +
        b"\x00\x00\x00" + struct.pack("!B", next_header)
    )


def compute_l4_checksum_v6(
    src: IPv6Address, dst: IPv6Address,
    next_header: int, l4_payload: bytes,
) -> int:
    """Compute the TCP/UDP/ICMPv6 checksum with IPv6 pseudo-header.

    `l4_payload` must have its checksum field zeroed out before calling.
    Returns the 16-bit checksum to write into the header.
    """
    pseudo = ipv6_pseudo_header(src, dst, len(l4_payload), next_header)
    total = _ones_complement_sum(pseudo) + _ones_complement_sum(l4_payload)
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    cksum = (~total) & 0xFFFF
    # For UDP, a computed 0 is transmitted as 0xFFFF (RFC 768 / RFC 8200 §8.1).
    # We leave that to callers since the rule differs per-protocol.
    return cksum


# ----------------------------------------------------------------------
# Building test frames
# ----------------------------------------------------------------------


def build_tcp_frame_v6(
    src_ip: IPv6Address, dst_ip: IPv6Address,
    src_port: int, dst_port: int,
    seq: int = 0, ack: int = 0,
    flags: int = 0x02,  # SYN
    payload: bytes = b"",
    eth_src: bytes = b"\x02\x00\x00\x00\x00\x01",
    eth_dst: bytes = b"\x02\x00\x00\x00\x00\x02",
    traffic_class: int = 0,
    hop_limit: int = 64,
) -> bytes:
    """Construct a minimal IPv6+TCP frame with a valid checksum."""
    # TCP header (20 bytes + payload, no options)
    tcp = (
        struct.pack("!HH", src_port, dst_port) +
        struct.pack("!I", seq) +
        struct.pack("!I", ack) +
        struct.pack("!B", 0x50) +  # data offset 5 (20 bytes), reserved 0
        struct.pack("!B", flags) +
        struct.pack("!H", 65535) +  # window
        b"\x00\x00" +               # checksum placeholder
        b"\x00\x00"                 # urg ptr
    )
    tcp_and_payload = tcp + payload
    cksum = compute_l4_checksum_v6(src_ip, dst_ip, IP_PROTO_TCP, tcp_and_payload)
    # Splice checksum in at offset 16
    tcp_and_payload = tcp_and_payload[:16] + struct.pack("!H", cksum) + tcp_and_payload[18:]

    payload_length = len(tcp_and_payload)
    # IPv6 header: version=6, TC, FL, payload_len, next_hdr=TCP, hop_limit, src, dst
    vtcfl = (6 << 28) | (traffic_class << 20) | 0
    ipv6_header = (
        struct.pack("!I", vtcfl) +
        struct.pack("!H", payload_length) +
        struct.pack("!B", IP_PROTO_TCP) +
        struct.pack("!B", hop_limit) +
        src_ip.packed + dst_ip.packed
    )
    eth = eth_dst + eth_src + struct.pack("!H", ETH_P_IPV6)
    return eth + ipv6_header + tcp_and_payload


def build_udp_frame_v6(
    src_ip: IPv6Address, dst_ip: IPv6Address,
    src_port: int, dst_port: int,
    payload: bytes = b"",
    eth_src: bytes = b"\x02\x00\x00\x00\x00\x01",
    eth_dst: bytes = b"\x02\x00\x00\x00\x00\x02",
    traffic_class: int = 0,
    hop_limit: int = 64,
) -> bytes:
    """Construct a minimal IPv6+UDP frame with a valid checksum."""
    udp_length = 8 + len(payload)
    udp = (
        struct.pack("!HH", src_port, dst_port) +
        struct.pack("!H", udp_length) +
        b"\x00\x00" +  # checksum placeholder
        payload
    )
    cksum = compute_l4_checksum_v6(src_ip, dst_ip, IP_PROTO_UDP, udp)
    # UDP: a computed 0 is sent as 0xFFFF
    if cksum == 0:
        cksum = 0xFFFF
    udp = udp[:6] + struct.pack("!H", cksum) + udp[8:]

    vtcfl = (6 << 28) | (traffic_class << 20) | 0
    ipv6_header = (
        struct.pack("!I", vtcfl) +
        struct.pack("!H", udp_length) +
        struct.pack("!B", IP_PROTO_UDP) +
        struct.pack("!B", hop_limit) +
        src_ip.packed + dst_ip.packed
    )
    eth = eth_dst + eth_src + struct.pack("!H", ETH_P_IPV6)
    return eth + ipv6_header + udp


def build_icmpv6_frame(
    src_ip: IPv6Address, dst_ip: IPv6Address,
    icmp_type: int, icmp_code: int = 0,
    payload: bytes = b"",
    eth_src: bytes = b"\x02\x00\x00\x00\x00\x01",
    eth_dst: bytes = b"\x02\x00\x00\x00\x00\x02",
    hop_limit: int = 255,  # ICMPv6 typically uses 255
) -> bytes:
    """Construct a minimal IPv6+ICMPv6 frame with a valid checksum."""
    icmp = (
        struct.pack("!BB", icmp_type, icmp_code) +
        b"\x00\x00" +  # checksum placeholder
        payload
    )
    cksum = compute_l4_checksum_v6(src_ip, dst_ip, IP_PROTO_ICMPV6, icmp)
    icmp = icmp[:2] + struct.pack("!H", cksum) + icmp[4:]

    payload_length = len(icmp)
    vtcfl = (6 << 28)
    ipv6_header = (
        struct.pack("!I", vtcfl) +
        struct.pack("!H", payload_length) +
        struct.pack("!B", IP_PROTO_ICMPV6) +
        struct.pack("!B", hop_limit) +
        src_ip.packed + dst_ip.packed
    )
    eth = eth_dst + eth_src + struct.pack("!H", ETH_P_IPV6)
    return eth + ipv6_header + icmp


# ----------------------------------------------------------------------
# Rewriting (DNAT66 / SNAT66 — for v1 we're only implementing DNAT66
# since Jim's direction is "no NAT66 in general, just DNAT for port-
# forwarding to internal servers; NAT64 for v6-to-v4 translation"
# Actually: we're skipping NAT66 entirely per spec, so these rewrites
# are only used internally by the NAT64 path. But we keep the v6
# rewrite function available for future use.)
# ----------------------------------------------------------------------


def rewrite_frame_dnat_v6(
    parsed: ParsedFrameV6,
    new_dst_ip: IPv6Address,
    new_dst_port: int,
) -> bytes:
    """Rewrite a v6 frame's destination IP and port, recompute L4 checksum.

    There's no IP header checksum in IPv6, so we only touch:
      - dst_ip field in the IPv6 header (bytes 24..40 of IP header)
      - dst_port in TCP/UDP header (bytes 2..4 of L4 header)
      - L4 checksum (recomputed, not incrementally updated — pseudo-header
        changes too much for incremental to save meaningful work)
    """
    frame = bytearray(parsed.raw)
    ip_start = parsed.ip_header_start
    l4_start = parsed.l4_header_start

    # Overwrite dst IP
    frame[ip_start + 24:ip_start + 40] = new_dst_ip.packed

    if parsed.l4_protocol == Protocol.TCP or parsed.l4_protocol == Protocol.UDP:
        # Overwrite dst port
        frame[l4_start + 2:l4_start + 4] = struct.pack("!H", new_dst_port)
        # Zero the checksum
        cksum_offset = l4_start + 16 if parsed.l4_protocol == Protocol.TCP else l4_start + 6
        frame[cksum_offset:cksum_offset + 2] = b"\x00\x00"
        # Recompute over the L4 payload
        l4_end = ip_start + 40 + parsed.payload_length
        l4_payload = bytes(frame[l4_start:l4_end])
        proto_num = IP_PROTO_TCP if parsed.l4_protocol == Protocol.TCP else IP_PROTO_UDP
        cksum = compute_l4_checksum_v6(
            parsed.src_ip, new_dst_ip, proto_num, l4_payload,
        )
        if parsed.l4_protocol == Protocol.UDP and cksum == 0:
            cksum = 0xFFFF
        frame[cksum_offset:cksum_offset + 2] = struct.pack("!H", cksum)

    return bytes(frame)

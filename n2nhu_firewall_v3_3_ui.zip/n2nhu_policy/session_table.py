"""
SessionTable — thread-safe NAT session store with forward+reverse lookups
and a background reaper.

Two indexes:
  _forward_index: (orig_src_ip, orig_src_port, orig_dst_ip, orig_dst_port, proto)
                  -> session_id
  _reverse_index: (xlated_src_ip, xlated_src_port, xlated_dst_ip, xlated_dst_port, proto)
                  -> session_id
  _sessions     : session_id -> NATSession

Reaper runs on its own thread, wakes every `reaper_interval` seconds, and
evicts sessions whose (now - last_seen) > timeout_for(session).

The reaper is optional — tests inject time and call reap_once() directly.
"""

from __future__ import annotations

import threading
import time
import uuid
from ipaddress import IPv4Address, IPv6Address
from typing import Callable, Iterator, Optional

from n2nhu_policy.models import IPAddress, Protocol

from .nat_models import Direction, NATConfig, NATRule, NATSession, NATType
from .port_pool import PortPool


SessionKey = tuple[str, int, str, int, str]  # ip, port, ip, port, proto.value


def _make_key(
    src_ip: IPAddress, src_port: int,
    dst_ip: IPAddress, dst_port: int,
    protocol: Protocol,
) -> SessionKey:
    return (str(src_ip), src_port, str(dst_ip), dst_port, protocol.value)


class SessionTable:
    def __init__(
        self,
        config: NATConfig,
        rule_lookup: Callable[[str], NATRule],
        *,
        port_pools: Optional[dict[str, PortPool]] = None,
        clock: Callable[[], float] = time.time,
    ):
        self._config = config
        self._rule_lookup = rule_lookup
        self._port_pools = port_pools or {}
        self._clock = clock

        self._lock = threading.RLock()
        self._sessions: dict[str, NATSession] = {}
        self._forward_index: dict[SessionKey, str] = {}
        self._reverse_index: dict[SessionKey, str] = {}

        # Reaper thread control
        self._reaper_stop = threading.Event()
        self._reaper_thread: Optional[threading.Thread] = None

    # -----------------------------------------------------------------------
    # Session lifecycle
    # -----------------------------------------------------------------------

    def create_session(
        self,
        *,
        rule_id: str,
        nat_type: NATType,
        protocol: Protocol,
        orig_src_ip: IPAddress, orig_src_port: int,
        orig_dst_ip: IPAddress, orig_dst_port: int,
        xlated_src_ip: IPAddress, xlated_src_port: int,
        xlated_dst_ip: IPAddress, xlated_dst_port: int,
        client_ingress_iface: str | None = None,
    ) -> NATSession:
        session_id = uuid.uuid4().hex
        session = NATSession(
            session_id=session_id,
            rule_id=rule_id,
            nat_type=nat_type,
            protocol=protocol,
            orig_src_ip=orig_src_ip,
            orig_src_port=orig_src_port,
            orig_dst_ip=orig_dst_ip,
            orig_dst_port=orig_dst_port,
            xlated_src_ip=xlated_src_ip,
            xlated_src_port=xlated_src_port,
            xlated_dst_ip=xlated_dst_ip,
            xlated_dst_port=xlated_dst_port,
            created_at=self._clock(),
            last_seen=self._clock(),
            client_ingress_iface=client_ingress_iface,
        )

        fwd = _make_key(orig_src_ip, orig_src_port, orig_dst_ip, orig_dst_port, protocol)

        # Reverse key depends on NAT type:
        # - SNAT: return packet has (orig_dst as src, xlated_src as dst).
        #         So reverse key = (orig_dst, orig_dst_port, xlated_src, xlated_src_port)
        # - DNAT: return packet has (xlated_dst as src, orig_src as dst).
        #         So reverse key = (xlated_dst, xlated_dst_port, orig_src, orig_src_port)
        # - STATIC: both sides independent — we only register the forward mapping here;
        #           the engine handles static reverse via rule match, not session lookup.
        if nat_type == NATType.SOURCE_NAT:
            rev = _make_key(
                orig_dst_ip, orig_dst_port,
                xlated_src_ip, xlated_src_port,
                protocol,
            )
        elif nat_type == NATType.DESTINATION_NAT:
            rev = _make_key(
                xlated_dst_ip, xlated_dst_port,
                orig_src_ip, orig_src_port,
                protocol,
            )
        elif nat_type == NATType.NAT64:
            # Reply from v4 server: src=xlated_dst (v4 server), port=80,
            # dst=xlated_src (firewall v4), port=pool-allocated.
            # Reverse key is the v4 5-tuple of the reply, which the engine
            # will look up when a v4 packet arrives at the firewall.
            rev = _make_key(
                xlated_dst_ip, xlated_dst_port,
                xlated_src_ip, xlated_src_port,
                protocol,
            )
        else:
            rev = None

        with self._lock:
            self._sessions[session_id] = session
            self._forward_index[fwd] = session_id
            if rev is not None:
                self._reverse_index[rev] = session_id

        return session

    def lookup_forward(
        self,
        src_ip: IPv4Address, src_port: int,
        dst_ip: IPv4Address, dst_port: int,
        protocol: Protocol,
    ) -> Optional[NATSession]:
        key = _make_key(src_ip, src_port, dst_ip, dst_port, protocol)
        with self._lock:
            sid = self._forward_index.get(key)
            if sid is None:
                return None
            return self._sessions.get(sid)

    def lookup_reverse(
        self,
        src_ip: IPv4Address, src_port: int,
        dst_ip: IPv4Address, dst_port: int,
        protocol: Protocol,
    ) -> Optional[NATSession]:
        key = _make_key(src_ip, src_port, dst_ip, dst_port, protocol)
        with self._lock:
            sid = self._reverse_index.get(key)
            if sid is None:
                return None
            return self._sessions.get(sid)

    def evict(self, session: NATSession) -> None:
        """Remove a session and release its port back to the pool (if any)."""
        fwd = _make_key(
            session.orig_src_ip, session.orig_src_port,
            session.orig_dst_ip, session.orig_dst_port,
            session.protocol,
        )
        if session.nat_type == NATType.SOURCE_NAT:
            rev = _make_key(
                session.orig_dst_ip, session.orig_dst_port,
                session.xlated_src_ip, session.xlated_src_port,
                session.protocol,
            )
        elif session.nat_type == NATType.DESTINATION_NAT:
            rev = _make_key(
                session.xlated_dst_ip, session.xlated_dst_port,
                session.orig_src_ip, session.orig_src_port,
                session.protocol,
            )
        elif session.nat_type == NATType.NAT64:
            rev = _make_key(
                session.xlated_dst_ip, session.xlated_dst_port,
                session.xlated_src_ip, session.xlated_src_port,
                session.protocol,
            )
        else:
            rev = None

        with self._lock:
            self._sessions.pop(session.session_id, None)
            self._forward_index.pop(fwd, None)
            if rev is not None:
                self._reverse_index.pop(rev, None)

        # Return port to pool for NAT types that allocate from pools
        if (session.nat_type in (NATType.SOURCE_NAT, NATType.NAT64)
                and session.rule_id in self._port_pools):
            self._port_pools[session.rule_id].release(session.xlated_src_port)

    # -----------------------------------------------------------------------
    # Reaper
    # -----------------------------------------------------------------------

    def reap_once(self, now: Optional[float] = None) -> int:
        """
        Single reaper sweep. Evicts expired sessions. Returns count evicted.
        Safe to call from any thread.
        """
        if now is None:
            now = self._clock()

        with self._lock:
            snapshot = list(self._sessions.values())

        evicted = 0
        for session in snapshot:
            try:
                rule = self._rule_lookup(session.rule_id)
            except KeyError:
                # Rule was reloaded away — evict orphan session
                self.evict(session)
                evicted += 1
                continue
            timeout = session.timeout_for(self._config, rule)
            if session.age(now) > timeout:
                self.evict(session)
                evicted += 1
        return evicted

    def start_reaper(self) -> None:
        """Start the background reaper thread. Idempotent."""
        if self._reaper_thread is not None and self._reaper_thread.is_alive():
            return
        self._reaper_stop.clear()

        def _loop():
            while not self._reaper_stop.wait(self._config.reaper_interval):
                try:
                    self.reap_once()
                except Exception:
                    # Never let a reaper exception kill the thread.
                    # In production, this would go to the audit log.
                    pass

        self._reaper_thread = threading.Thread(
            target=_loop, name="nat-reaper", daemon=True,
        )
        self._reaper_thread.start()

    def stop_reaper(self) -> None:
        """Stop the reaper thread. Blocks until the thread exits."""
        self._reaper_stop.set()
        if self._reaper_thread is not None:
            self._reaper_thread.join(timeout=self._config.reaper_interval + 2)
            self._reaper_thread = None

    # -----------------------------------------------------------------------
    # Introspection
    # -----------------------------------------------------------------------

    def __len__(self) -> int:
        with self._lock:
            return len(self._sessions)

    def all_sessions(self) -> list[NATSession]:
        with self._lock:
            return list(self._sessions.values())

    def iter_sessions(self) -> Iterator[NATSession]:
        # Snapshot to avoid holding the lock during iteration
        yield from self.all_sessions()

"""
capture_engine — pure function over (packet, decision, capture_point) → matching rules.

Like PolicyEngine and PBREngine, the CaptureEngine is stateless and
side-effect-free. It walks the configured rules and returns those whose
criteria match the packet at the given capture point. The actual file
I/O is done by CaptureManager (which holds the writers); the engine
only decides which rules apply.

Match semantics (per rule):
  - capture_point must equal the supplied point (or rule is skipped)
  - src_zone matches if rule.src_zone == "any" or matches the packet's
    ingress zone
  - dst_zone matches if rule.dst_zone == "any" or matches the packet's
    egress zone
  - src_addr matches via the same ip_in_address resolver used by policy
  - dst_addr matches likewise
  - service matches via the same service resolver
  - match_action filters on the policy decision:
      ANY   — record regardless of policy outcome
      ALLOW — record only if decision.action == ALLOW
      DENY  — record only if decision.action != ALLOW
  - INGRESS captures bypass policy filtering entirely (decision is None)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .capture_models import (
    CaptureConfig, CaptureMatchAction, CapturePoint, CaptureRule,
)
from .models import Action, Config, Packet
from .object_resolver import ObjectResolver
from .zone_map import ZoneMap


@dataclass(frozen=True)
class _DecisionLike:
    """A decision-shaped duck for cases where we have only an action.
    The capture engine reads decision.action only."""
    action: Action


class CaptureEngine:
    """Stateless matcher. Construct once per capture-config + policy-config
    pair; call match() to find the rules applicable to a frame."""

    def __init__(self, capture_config: CaptureConfig, policy_config: Config):
        self.capture_config = capture_config
        self.policy_config = policy_config
        self.resolver = ObjectResolver(
            policy_config.addresses, policy_config.services,
        )
        self.zone_map = ZoneMap(
            policy_config.zones,
            policy_config.interface_to_zone,
            policy_config.defaults,
        )

    def match(
        self,
        packet: Packet,
        decision_action: Optional[Action],
        capture_point: CapturePoint,
    ) -> tuple[CaptureRule, ...]:
        """Return the capture rules whose criteria match.

        Args:
            packet: the packet under evaluation. ingress_iface and
                egress_iface must be set (egress may be the same as
                ingress for INGRESS-point captures).
            decision_action: the policy decision's action, or None for
                INGRESS captures (where policy hasn't run yet).
            capture_point: which decision point is firing.

        Returns:
            Tuple of matching rules. Empty if none match.
        """
        if not self.capture_config.rules:
            return ()

        src_zone = self.zone_map.zone_for_interface(packet.ingress_iface)
        dst_zone = self.zone_map.zone_for_interface(packet.egress_iface)

        out: list[CaptureRule] = []
        for rule in self.capture_config.rules:
            if not rule.enabled:
                continue
            if rule.capture_point != capture_point:
                continue
            if not self._zone_match(rule.src_zone, src_zone):
                continue
            if not self._zone_match(rule.dst_zone, dst_zone):
                continue
            if not self._action_match(rule.match_action, decision_action):
                continue
            try:
                if not self.resolver.ip_in_address(packet.src_ip, rule.src_addr):
                    continue
                if not self.resolver.ip_in_address(packet.dst_ip, rule.dst_addr):
                    continue
                if not self.resolver.service_matches(
                    rule.service,
                    protocol=packet.protocol,
                    dst_port=packet.dst_port,
                    src_port=packet.src_port,
                    icmp_type=packet.icmp_type,
                ):
                    continue
            except Exception:
                # Resolver errors should be loud at config-load time;
                # at runtime, on the off chance one slips through, we
                # skip the rule rather than crash the dataplane.
                continue
            out.append(rule)
        return tuple(out)

    @staticmethod
    def _zone_match(rule_zone: str, packet_zone: str) -> bool:
        return rule_zone == "any" or rule_zone == packet_zone

    @staticmethod
    def _action_match(
        rule_match: CaptureMatchAction,
        decision_action: Optional[Action],
    ) -> bool:
        # INGRESS captures pass decision_action=None: policy hasn't run.
        # We honor any/allow/deny by treating None as "not yet decided" —
        # ANY matches; ALLOW and DENY do not (record only at points
        # where policy has decided).
        if decision_action is None:
            return rule_match == CaptureMatchAction.ANY
        if rule_match == CaptureMatchAction.ANY:
            return True
        if rule_match == CaptureMatchAction.ALLOW:
            return decision_action == Action.ALLOW
        if rule_match == CaptureMatchAction.DENY:
            return decision_action != Action.ALLOW
        return False

"""
ipsec_models — declarative data model for IPSec/IKE configuration.

Three object types compose into a working IPSec configuration, mirroring
the object-vocabulary pattern used everywhere else in N2NHU:

  IPSecProposal — crypto suite (encryption + integrity + DH group). Reusable.
  IKEPolicy     — Phase 1: peer identity, auth method, IKE proposal refs, DPD.
  IPSecTunnel   — Phase 2: references an IKE policy + IPSec proposals,
                  defines traffic selectors (via address objects),
                  picks tunnel-mode topology.

The structural separation matches strongSwan's own model: a `conn` block
in ipsec.conf binds together a Phase-1 IKE half and a Phase-2 ESP half.
That mapping is intentional — it makes the emitter a near-trivial
projection rather than a translation.

Crypto choices are deliberately conservative:

  ENC : aes256, aes192, aes128
  INT : sha256, sha384, sha512, sha1 (legacy)
  DH  : modp2048, modp3072, modp4096, ecp256, ecp384, ecp521,
        curve25519, modp1024 (legacy)

3DES, MD5, modp768, and modp1536 are not supported. Operators with
legacy peer requirements should pin a peer-specific proposal containing
the minimum necessary downgrade and rotate the peer.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Crypto enumerations
# ---------------------------------------------------------------------------


class IKEVersion(enum.Enum):
    IKEV1 = "ikev1"
    IKEV2 = "ikev2"


class IPSecMode(enum.Enum):
    TUNNEL = "tunnel"
    TRANSPORT = "transport"


class IPSecAuth(enum.Enum):
    PSK = "psk"
    PUBKEY = "pubkey"   # certificate / RSA / ECDSA


class IPSecEncryption(enum.Enum):
    AES128 = "aes128"
    AES192 = "aes192"
    AES256 = "aes256"
    AES128GCM16 = "aes128gcm16"
    AES256GCM16 = "aes256gcm16"


class IPSecIntegrity(enum.Enum):
    SHA1 = "sha1"        # legacy; permitted but discouraged
    SHA256 = "sha256"
    SHA384 = "sha384"
    SHA512 = "sha512"


class IPSecDHGroup(enum.Enum):
    MODP1024 = "modp1024"   # group 2; legacy
    MODP2048 = "modp2048"   # group 14
    MODP3072 = "modp3072"   # group 15
    MODP4096 = "modp4096"   # group 16
    ECP256 = "ecp256"       # group 19
    ECP384 = "ecp384"       # group 20
    ECP521 = "ecp521"       # group 21
    CURVE25519 = "curve25519"


# ---------------------------------------------------------------------------
# Object types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class IPSecProposal:
    """A crypto suite. References from IKEPolicy or IPSecTunnel."""

    id: str
    encryption: IPSecEncryption
    integrity: IPSecIntegrity
    dh_group: IPSecDHGroup

    def to_strongswan_string(self) -> str:
        """Render as a single proposal token consumable by strongSwan,
        e.g. 'aes256-sha256-modp2048'. AEAD suites omit the integrity
        component (gcm builds hash into the cipher)."""
        # AEAD ciphers don't pair with a separate integrity algorithm
        if self.encryption in (
            IPSecEncryption.AES128GCM16, IPSecEncryption.AES256GCM16,
        ):
            return f"{self.encryption.value}-{self.dh_group.value}"
        return (
            f"{self.encryption.value}-"
            f"{self.integrity.value}-"
            f"{self.dh_group.value}"
        )


@dataclass(frozen=True)
class IKEPolicy:
    """Phase 1 (IKE_SA) parameters. Authentication, identity, proposals.

    PSK material is referenced by `psk_file` (a path on disk with 0600
    perms expected) rather than inlined. This keeps the INI file safe
    to check into version control. Certificate auth uses `local_cert`
    and `remote_cert` paths; the strongSwan emitter will project these
    onto strongSwan's `leftcert` / `rightca` fields.
    """

    id: str

    # IKE version — defaults to v2 (opt-in for v1 if the peer requires it)
    ike_version: IKEVersion

    # Local / peer identities — typically FQDNs or @user@example.com
    local_id: str
    remote_id: str

    # Where the peer is reachable. Hostname or IP. May be "%any" for
    # roadwarrior/responder deployments.
    remote_addr: str

    # Authentication
    auth_method: IPSecAuth
    psk_file: str | None         # path to file with PSK; mode 0600
    local_cert: str | None       # path to local cert (auth = pubkey)
    remote_cert: str | None      # path to peer cert / CA

    # IKE proposal references — order matters; first negotiated wins
    proposal_ids: tuple[str, ...]

    # Dead-peer detection
    dpd_action: str              # "clear" | "hold" | "restart" | "none"
    dpd_delay_seconds: int       # 0 = disabled

    # Lifetimes
    ike_lifetime_seconds: int

    # Optional NAT-T mobility extension
    mobike: bool


@dataclass(frozen=True)
class IPSecTunnel:
    """Phase 2 (CHILD_SA / ESP) parameters. Binds an IKE policy with
    traffic selectors and ESP proposals.

    Traffic selectors reference address objects from the policy
    config — not inline subnets. This keeps the IPSec config in the
    same vocabulary as policy/NAT and means renaming a subnet object
    flows through every IPSec rule that references it.
    """

    id: str

    # Which Phase-1 negotiation this tunnel uses
    ike_policy_id: str

    # Traffic selectors — address objects from policy config
    local_subnet: str            # address-object id (e.g. addr_lan_net)
    remote_subnet: str           # address-object id (e.g. addr_branch_net)

    # ESP proposal references; same shape and discipline as IKE proposals
    proposal_ids: tuple[str, ...]

    # Tunnel-mode (default) or transport-mode
    mode: IPSecMode

    # If true, attach to a route-based VTI interface named `vti_<id>`
    # rather than a policy-based selector. Recommended for v1.
    use_vti: bool

    # Perfect-forward-secrecy — re-key each phase-2 with new DH
    pfs: bool

    # Lifetimes
    ipsec_lifetime_seconds: int

    # Auto-start: "start" | "route" | "add" — strongSwan terminology
    # start  = initiate immediately and keep up
    # route  = install kernel trap, initiate on first matching packet
    # add    = load config but do not initiate (responder-only)
    auto: str

    # Auto-discovery / opportunistic encryption — disabled by default
    enabled: bool


# ---------------------------------------------------------------------------
# Composite IPSec config
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class IPSecConfig:
    """Fully-parsed IPSec config. Consumed by IPSecConfigLoader and
    handed to StrongSwanEmitter and IPSecShim."""

    proposals: dict[str, IPSecProposal]
    ike_policies: dict[str, IKEPolicy]
    tunnels: tuple[IPSecTunnel, ...]

    def enabled_tunnels(self) -> tuple[IPSecTunnel, ...]:
        return tuple(t for t in self.tunnels if t.enabled)

    def is_empty(self) -> bool:
        return not self.tunnels

    def proposal(self, pid: str) -> IPSecProposal:
        return self.proposals[pid]

    def ike_policy(self, pid: str) -> IKEPolicy:
        return self.ike_policies[pid]

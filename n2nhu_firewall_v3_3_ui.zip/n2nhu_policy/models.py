"""
Data models for n2nhu_policy.

Everything the engine operates on is a typed, frozen dataclass.
Nothing mutates after load-time. Reload = build a new Config, swap pointer.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from ipaddress import IPv4Address, IPv4Network, IPv6Address, IPv6Network

# Type aliases for cross-family addressing. Engines treat addresses
# uniformly — both families are hashable, comparable, and have `.version`
# for family-specific branching when needed.
IPAddress = IPv4Address | IPv6Address
IPNetwork = IPv4Network | IPv6Network
from typing import Mapping, Sequence


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class Action(enum.Enum):
    """Verdict returned by the policy engine for a packet."""

    ALLOW = "ALLOW"
    DENY = "DENY"
    REJECT = "REJECT"

    @classmethod
    def parse(cls, raw: str) -> "Action":
        key = raw.strip().upper()
        if key not in cls.__members__:
            raise ValueError(f"Unknown action: {raw!r}. Expected ALLOW, DENY, or REJECT.")
        return cls[key]


class AddressType(enum.Enum):
    HOST = "host"
    NETWORK = "network"
    RANGE = "range"
    FQDN = "fqdn"
    GROUP = "group"

    @classmethod
    def parse(cls, raw: str) -> "AddressType":
        key = raw.strip().lower()
        for member in cls:
            if member.value == key:
                return member
        raise ValueError(f"Unknown address type: {raw!r}")


class ScheduleType(enum.Enum):
    ALWAYS = "always"
    RECURRING = "recurring"
    ONE_TIME = "one_time"

    @classmethod
    def parse(cls, raw: str) -> "ScheduleType":
        key = raw.strip().lower()
        for member in cls:
            if member.value == key:
                return member
        raise ValueError(f"Unknown schedule type: {raw!r}")


class Protocol(enum.Enum):
    ANY = "any"
    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"        # IPv4 ICMP (protocol 1)
    ICMPV6 = "icmpv6"    # IPv6 ICMPv6 (protocol 58)

    @classmethod
    def parse(cls, raw: str) -> "Protocol":
        key = raw.strip().lower()
        for member in cls:
            if member.value == key:
                return member
        raise ValueError(f"Unknown protocol: {raw!r}. Expected any, tcp, udp, icmp, icmpv6.")


# ---------------------------------------------------------------------------
# Zones
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Zone:
    name: str
    security_level: int = 0
    description: str = ""
    mgt_plane: bool = False


# ---------------------------------------------------------------------------
# Address objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AddressObject:
    """
    A single address object.

    For leaf types (host/network/range/fqdn) the `networks` field carries the
    resolved IP set. For group types, `members` carries the child object
    names; the resolver flattens these into `networks` downstream.
    """

    id: str
    type: AddressType
    # Leaf values — one of these is populated based on type
    host: IPAddress | None = None
    network: IPNetwork | None = None
    range_start: IPAddress | None = None
    range_end: IPAddress | None = None
    fqdn: str | None = None
    fqdn_ttl: int = 3600
    # Group members (names of other address objects)
    members: tuple[str, ...] = ()
    # Raw source line for error messages
    source_line: int = 0

    @property
    def version(self) -> int | None:
        """The IP version (4 or 6) of this address object's content.
        None for groups (which may be mixed), FQDNs (resolved later),
        and address objects with no concrete value yet."""
        if self.host is not None:
            return self.host.version
        if self.network is not None:
            return self.network.version
        if self.range_start is not None:
            return self.range_start.version
        return None


# ---------------------------------------------------------------------------
# Service objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PortRange:
    """A port range, inclusive on both ends. start == end means single port."""

    start: int
    end: int

    def contains(self, port: int) -> bool:
        return self.start <= port <= self.end


@dataclass(frozen=True)
class ServiceObject:
    """
    A service object. Leaf services specify a protocol and optional ports.
    Groups specify members.
    """

    id: str
    protocol: Protocol = Protocol.ANY
    dst_port: PortRange | None = None
    src_port: PortRange | None = None
    icmp_type: int | None = None
    # Group members
    is_group: bool = False
    members: tuple[str, ...] = ()
    source_line: int = 0


# ---------------------------------------------------------------------------
# Schedules
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Schedule:
    """A time-window object."""

    id: str
    type: ScheduleType
    # For RECURRING
    days: tuple[int, ...] = ()  # 0=Monday .. 6=Sunday
    start_time: str = ""  # "HH:MM"
    end_time: str = ""
    # For ONE_TIME
    start_datetime: str = ""  # ISO 8601 (no tz in string; tz separate)
    end_datetime: str = ""
    # Shared
    timezone: str = "UTC"


# ---------------------------------------------------------------------------
# Policy rules
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PolicyRule:
    """A single row in the security policy matrix."""

    id: str
    src_zone: str
    dst_zone: str
    src_addr: str
    dst_addr: str
    service: str
    schedule: str
    action: Action
    log: bool = False
    comment: str = ""


# ---------------------------------------------------------------------------
# Runtime types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Packet:
    """
    A packet to evaluate. Ingress/egress interface names are assumed to have
    been determined upstream by the data plane (routing + interface classify).
    """

    ingress_iface: str
    egress_iface: str
    src_ip: IPAddress
    dst_ip: IPAddress
    protocol: Protocol
    src_port: int = 0
    dst_port: int = 0
    icmp_type: int | None = None
    dscp: int = 0   # 6-bit DSCP value from the IP TOS/TC field (0-63)

    @property
    def version(self) -> int:
        """IP version of the packet (4 or 6)."""
        return self.src_ip.version


@dataclass(frozen=True)
class Decision:
    """The verdict from the policy engine for a single packet."""

    action: Action
    rule_id: str
    log: bool
    matched_default: bool = False
    reason: str = ""


# ---------------------------------------------------------------------------
# Top-level config bundle
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Config:
    """
    Fully-parsed config. This is the output of ConfigLoader and the
    input to ObjectResolver + PolicyEngine. Pointer-swap-to-reload unit.
    """

    zones: Mapping[str, Zone]
    interface_to_zone: Mapping[str, str]
    defaults: Mapping[tuple[str, str], Action]
    addresses: Mapping[str, AddressObject]
    services: Mapping[str, ServiceObject]
    schedules: Mapping[str, Schedule]
    policies: Sequence[PolicyRule]  # in evaluation order

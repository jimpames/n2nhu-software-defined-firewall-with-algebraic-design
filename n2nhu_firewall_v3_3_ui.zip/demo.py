#!/usr/bin/env python3
"""
demo.py — Walk a handful of packets through the policy engine.

Run:
    python3 demo.py

Output is the raw matrix lookup in action: every packet produces exactly one
Decision, every Decision names the rule that fired (or the default that did).
"""

from __future__ import annotations

import sys
from datetime import datetime
from ipaddress import IPv4Address
from pathlib import Path
from zoneinfo import ZoneInfo

# Allow running from the project root without install
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from n2nhu_policy import (
    Action,
    AuditLog,
    ConfigLoader,
    Packet,
    PolicyEngine,
    Protocol,
    Stats,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

NY = ZoneInfo("America/New_York")

# Pretty-print colors (disabled if not a TTY)
def _supports_color() -> bool:
    return sys.stdout.isatty()


def _colored(text: str, code: str) -> str:
    if not _supports_color():
        return text
    return f"\033[{code}m{text}\033[0m"


def _action_color(action: Action) -> str:
    return {
        Action.ALLOW: "32",   # green
        Action.DENY: "31",    # red
        Action.REJECT: "33",  # yellow
    }[action]


def _pkt(
    ingress: str,
    egress: str,
    src: str,
    dst: str,
    *,
    proto: Protocol = Protocol.TCP,
    sport: int = 54321,
    dport: int = 0,
    icmp: int | None = None,
) -> Packet:
    return Packet(
        ingress_iface=ingress,
        egress_iface=egress,
        src_ip=IPv4Address(src),
        dst_ip=IPv4Address(dst),
        protocol=proto,
        src_port=sport,
        dst_port=dport,
        icmp_type=icmp,
    )


def _describe(p: Packet) -> str:
    proto = p.protocol.value.upper()
    if p.protocol == Protocol.ICMP:
        svc = f"ICMP type {p.icmp_type}"
    else:
        svc = f"{proto}/{p.dst_port}"
    return (
        f"{p.ingress_iface:>10s} -> {p.egress_iface:<10s} "
        f"{str(p.src_ip):<15s} -> {str(p.dst_ip):<15s} {svc}"
    )


# ---------------------------------------------------------------------------
# Scenarios
# ---------------------------------------------------------------------------

# Tuesday, Feb 24, 2026 at 10am NY — inside business hours
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)
# Sunday, Feb 22, 2026 at 10am NY — outside business hours (weekend)
SUN = datetime(2026, 2, 22, 10, 0, tzinfo=NY)


SCENARIOS = [
    # (label, packet, timestamp)
    (
        "LAN workstation -> Internet on HTTP (Tue 10am)",
        _pkt("lan", "wan1", "192.168.1.10", "198.51.100.1", dport=80),
        BIZ,
    ),
    (
        "Admin workstation -> DMZ webserver SSH (Tue 10am, business hours)",
        _pkt("lan", "dmz", "192.168.1.50", "172.16.0.10", dport=22),
        BIZ,
    ),
    (
        "Admin workstation -> DMZ webserver SSH (Sun 10am, weekend)",
        _pkt("lan", "dmz", "192.168.1.50", "172.16.0.10", dport=22),
        SUN,
    ),
    (
        "Non-admin LAN host -> DMZ webserver SSH (Tue 10am)",
        _pkt("lan", "dmz", "192.168.1.51", "172.16.0.10", dport=22),
        BIZ,
    ),
    (
        "Internet -> DMZ webserver HTTPS (Tue 10am)",
        _pkt("wan1", "dmz", "198.51.100.77", "172.16.0.10", dport=443),
        BIZ,
    ),
    (
        "Internet -> DMZ webserver SSH (Tue 10am) -- implicit deny",
        _pkt("wan1", "dmz", "198.51.100.77", "172.16.0.10", dport=22),
        BIZ,
    ),
    (
        "Guest WiFi -> Internet HTTPS (Tue 10am)",
        _pkt("wifi_guest", "wan1", "192.168.99.10", "1.1.1.1", dport=443),
        BIZ,
    ),
    (
        "Guest WiFi -> Internal LAN host (Tue 10am) -- blocked by p060",
        _pkt("wifi_guest", "lan", "192.168.99.10", "192.168.1.50", dport=445),
        BIZ,
    ),
    (
        "LAN -> blocklisted IP on HTTP (Tue 10am) -- p010 beats p030",
        _pkt("lan", "wan1", "192.168.1.10", "203.0.113.66", dport=80),
        BIZ,
    ),
    (
        "LAN -> management plane (Tue 10am) -- data-plane->mgt denied",
        _pkt("lan", "mgt", "192.168.1.10", "10.255.0.1", dport=22),
        BIZ,
    ),
]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    print("=" * 96)
    print("N2NHU Policy Engine — demo walkthrough")
    print("=" * 96)
    print()

    config = ConfigLoader(ROOT / "fixtures").load()
    engine = PolicyEngine(config)
    stats = Stats()

    # Header
    print(f"Loaded config:")
    print(f"  zones      : {len(config.zones)}")
    print(f"  interfaces : {len(config.interface_to_zone)}")
    print(f"  addresses  : {len(config.addresses)}")
    print(f"  services   : {len(config.services)}")
    print(f"  schedules  : {len(config.schedules)}")
    print(f"  policies   : {len(config.policies)} (evaluation order: "
          f"{', '.join(r.id for r in config.policies)})")
    print()
    print("-" * 96)
    print()

    # Per-scenario evaluation
    for i, (label, packet, now) in enumerate(SCENARIOS, 1):
        decision = engine.evaluate(packet, now)
        stats.record(decision)

        action_str = _colored(
            f"{decision.action.value:<6s}", _action_color(decision.action),
        )
        default_marker = " [default matrix]" if decision.matched_default else ""
        log_marker = " [logged]" if decision.log else ""

        print(f"[{i:>2d}] {label}")
        print(f"     {_describe(packet)}")
        print(f"     @ {now.isoformat()}")
        print(f"  -> {action_str} via {decision.rule_id}{default_marker}{log_marker}")
        if decision.reason:
            print(f"     ({decision.reason})")
        print()

    # Stats summary
    print("-" * 96)
    print("Summary")
    print("-" * 96)
    summary = stats.as_dict()
    print(f"  Total decisions : {summary['total_decisions']}")
    print(f"  Default hits    : {summary['default_hits']}")
    print(f"  By action       : {summary['by_action']}")
    print(f"  By rule         :")
    for rule_id, hits in sorted(summary["by_rule"].items()):
        print(f"      {rule_id:<40s} {hits}")
    print()

    # Audit log sample
    print("-" * 96)
    print("Audit log (only logged or default decisions)")
    print("-" * 96)
    import io
    buf = io.StringIO()
    audit = AuditLog(sink=buf)
    for label, packet, now in SCENARIOS:
        decision = engine.evaluate(packet, now)
        audit.log(packet, decision, now)
    for line in buf.getvalue().strip().split("\n"):
        if line:
            print(f"  {line}")
    print()

    return 0


if __name__ == "__main__":
    sys.exit(main())

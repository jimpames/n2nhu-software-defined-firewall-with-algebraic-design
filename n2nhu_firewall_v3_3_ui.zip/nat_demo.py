#!/usr/bin/env python3
"""
nat_demo.py — Walk representative packets through the NAT plane.

Run:
    python3 nat_demo.py

Output shows the translation matrix in action: every packet produces a
TranslatedPacket, PassThrough, or NATDenied, with session tracking stats.
"""

from __future__ import annotations

import sys
from datetime import datetime
from ipaddress import IPv4Address
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from n2nhu_policy import (
    ConfigLoader,
    NATConfigLoader,
    NATDenied,
    NATEngine,
    Packet,
    PassThrough,
    Protocol,
    TranslatedPacket,
)


NY = ZoneInfo("America/New_York")
BIZ = datetime(2026, 2, 24, 10, 0, tzinfo=NY)


def _supports_color() -> bool:
    return sys.stdout.isatty()


def _c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _supports_color() else text


def _pkt(**kw):
    return Packet(
        ingress_iface=kw["ingress"], egress_iface=kw["egress"],
        src_ip=IPv4Address(kw["src"]), dst_ip=IPv4Address(kw["dst"]),
        protocol=kw.get("proto", Protocol.TCP),
        src_port=kw.get("sport", 54321), dst_port=kw.get("dport", 443),
        icmp_type=kw.get("icmp"),
    )


def _describe(p: Packet) -> str:
    return (
        f"{p.ingress_iface:>10s} -> {p.egress_iface:<10s} "
        f"{str(p.src_ip):<15s}:{p.src_port:<5d} -> "
        f"{str(p.dst_ip):<15s}:{p.dst_port}"
    )


def _describe_result(r) -> str:
    if isinstance(r, TranslatedPacket):
        head = _c("XLATE ", "32")
        body = (
            f"-> {str(r.src_ip):<15s}:{r.src_port:<5d} -> "
            f"{str(r.dst_ip):<15s}:{r.dst_port}  via {r.rule_id}"
        )
        if r.session_id:
            body += f"  [session {r.session_id[:8]}]"
        return head + body
    if isinstance(r, PassThrough):
        return _c("PASS  ", "33") + (
            f"(no-nat rule: {r.rule_id})" if r.rule_id else "(no match)"
        )
    if isinstance(r, NATDenied):
        return _c("DENY  ", "31") + f"{r.reason}"
    return str(r)


SCENARIOS = [
    (
        "LAN workstation -> internet HTTPS (SNAT)",
        _pkt(ingress="lan", egress="wan1",
             src="192.168.1.10", dst="8.8.8.8", sport=54321, dport=443),
    ),
    (
        "Same LAN flow, second packet (session reuse)",
        _pkt(ingress="lan", egress="wan1",
             src="192.168.1.10", dst="8.8.8.8", sport=54321, dport=443),
    ),
    (
        "Different LAN workstation -> internet DNS (SNAT, different port)",
        _pkt(ingress="lan", egress="wan1",
             src="192.168.1.20", dst="1.1.1.1",
             proto=Protocol.UDP, sport=33333, dport=53),
    ),
    (
        "Internet user -> public WAN IP on HTTPS (DNAT port forward)",
        _pkt(ingress="wan1", egress="wan1",
             src="198.51.100.77", dst="203.0.113.1", sport=55555, dport=443),
    ),
    (
        "DMZ mailserver -> internet on SMTP (static NAT forward)",
        _pkt(ingress="dmz", egress="wan1",
             src="172.16.0.20", dst="8.8.8.8", sport=33333, dport=25),
    ),
    (
        "Internet user -> mailserver public IP (static NAT reverse)",
        _pkt(ingress="wan1", egress="dmz",
             src="198.51.100.99", dst="203.0.113.25", sport=44444, dport=25),
    ),
    (
        "Intra-LAN traffic (no-NAT bypass)",
        _pkt(ingress="lan", egress="lan",
             src="192.168.1.10", dst="192.168.1.50", sport=22222, dport=80),
    ),
    (
        "DMZ webserver -> some random host (no matching rule, pass-through)",
        _pkt(ingress="dmz", egress="wan1",
             src="172.16.0.99", dst="8.8.8.8", sport=11111, dport=80),
    ),
]


def main() -> int:
    print("=" * 96)
    print("N2NHU NAT Engine — demo walkthrough")
    print("=" * 96)
    print()

    policy_cfg = ConfigLoader(ROOT / "fixtures").load()
    nat_cfg = NATConfigLoader(ROOT / "fixtures", policy_cfg).load()
    engine = NATEngine(
        policy_cfg, nat_cfg,
        interface_ips={
            "lan": IPv4Address("192.168.1.1"),
            "wan1": IPv4Address("203.0.113.1"),
            "wan2": IPv4Address("203.0.113.2"),
            "dmz": IPv4Address("172.16.0.1"),
            "wifi_guest": IPv4Address("192.168.99.1"),
            "wifi_corp": IPv4Address("192.168.1.2"),
            "mgt": IPv4Address("10.255.0.1"),
        },
    )

    print(f"Loaded NAT config:")
    print(f"  rules    : {len(nat_cfg.rules)} ({', '.join(r.id for r in nat_cfg.rules)})")
    print(f"  timeouts : tcp_established={nat_cfg.tcp_established_timeout}s "
          f"tcp_half_open={nat_cfg.tcp_half_open_timeout}s "
          f"udp={nat_cfg.udp_timeout}s icmp={nat_cfg.icmp_timeout}s")
    print()
    print("-" * 96)
    print()

    # Run scenarios
    for i, (label, pkt) in enumerate(SCENARIOS, 1):
        result = engine.translate(pkt, BIZ)
        print(f"[{i:>2d}] {label}")
        print(f"     IN : {_describe(pkt)}")
        print(f"     OUT: {_describe_result(result)}")
        print()

    # SNAT return-traffic demonstration
    print("-" * 96)
    print("Return traffic demonstration")
    print("-" * 96)
    print()
    # Replay scenario 1 to get the session
    first = SCENARIOS[0][1]
    xlation = engine.translate(first, BIZ)
    if isinstance(xlation, TranslatedPacket):
        # Craft the return packet
        return_pkt = Packet(
            ingress_iface="wan1", egress_iface="lan",
            src_ip=first.dst_ip, dst_ip=xlation.src_ip,
            protocol=first.protocol,
            src_port=first.dst_port, dst_port=xlation.src_port,
        )
        return_result = engine.translate(return_pkt, BIZ)
        print(f"     Reply from {first.dst_ip} arrives at the router:")
        print(f"     IN : {_describe(return_pkt)}")
        print(f"     OUT: {_describe_result(return_result)}")
        print()

    # Session table summary
    print("-" * 96)
    print("Session table")
    print("-" * 96)
    sessions = engine.session_table.all_sessions()
    print(f"  Active sessions: {len(sessions)}")
    for s in sessions:
        print(
            f"    {s.session_id[:8]}  {s.nat_type.value:<16s} "
            f"{s.orig_src_ip}:{s.orig_src_port} <-> "
            f"{s.xlated_src_ip}:{s.xlated_src_port}  "
            f"fwd={s.packets_forward} rev={s.packets_reverse}"
        )
    print()

    return 0


if __name__ == "__main__":
    sys.exit(main())

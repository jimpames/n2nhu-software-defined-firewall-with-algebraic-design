#!/usr/bin/env python3
"""
N2NHU Multi-Interface Firewall Router v3.0
POWERED BY n2nhu_policy (declarative INI-driven policy + NAT engines)

WHAT CHANGED FROM v2:
- The ~300-line procedural NAT/firewall brain has been replaced by a single
  call into n2nhu_policy.RouterShim.process_frame().
- All checksum math, port pool allocation, session tracking, and policy
  evaluation are now done by the engines in n2nhu_policy/, which have 245
  unit and integration tests with byte-exact NAT frame verification.
- The policy and NAT rules are now INI files in `etc/n2nhu/` instead of
  being hardcoded or scattered across firewall_router_v2.ini's port-forward
  strings.

WHAT STAYED THE SAME:
- TAP adapter setup (still uses TapDevice from vpn_server_v3_debug).
- The async read loop per interface — frame comes in, shim processes it,
  shim returns the egress interface + rewritten bytes, we forward.
- PCAP capture via DebugCapture / DebugSettings.
- Stats loop (enhanced with shim stats).
- Command-line interface (still --config firewall_router_v2.ini).

REQUIRED FILES:
- n2nhu_policy/ package directory (from the foundation zip)
- etc/n2nhu/zones.ini, objects/*.ini, policies/*.ini

Author: N2NHU Team + Claude (Apr 2026)
"""

import asyncio
import configparser
import ipaddress
import logging
import os
import signal
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, field
from ipaddress import IPv4Address, IPv4Network
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Add project paths
sys.path.insert(0, str(Path(__file__).parent))

# Existing TAP + debug imports (unchanged from v2)
try:
    from vpn_server_v3_debug import TapDevice
    from vpn_debug import DebugCapture, DebugSettings
except ImportError as e:
    print(f"[ERROR] Missing v2 dependencies: {e}")
    print("[INFO] Make sure vpn_server_v3_debug.py and vpn_debug.py are present")
    sys.exit(1)

# NEW: n2nhu_policy engine
try:
    from n2nhu_policy import (
        ForwardAction,
        RouterShim,
    )
except ImportError as e:
    print(f"[ERROR] Missing n2nhu_policy package: {e}")
    print("[INFO] Unzip n2nhu_firewall_router_v3.zip and place n2nhu_policy/ here")
    sys.exit(1)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


# ============================================================================
# Interface config (retained from v2, trimmed — NAT stuff no longer lives here)
# ============================================================================


@dataclass
class InterfaceConfig:
    """
    Interface binding for the TAP adapter layer. NAT behavior is now
    expressed in n2nhu_policy's nat.ini, not here.
    """

    name: str
    tap_name: str
    type: str                  # LAN, WAN, DMZ, VLAN (informational; zones.ini drives policy)
    network: str               # CIDR for routing table
    ip_address: str
    enabled: bool = True
    mtu: int = 1500


@dataclass
class RouterConfig:
    """Trimmed router configuration. Policy/NAT rules now live in etc/n2nhu/."""

    interfaces: Dict[str, InterfaceConfig]
    default_route: str
    policy_root: str           # path to etc/n2nhu (or similar)
    debug_enabled: bool
    pcap_enabled: bool
    pcap_file: str
    frame_trace: bool
    stats_interval: int


@dataclass
class RouterStats:
    """TAP-layer stats. Shim stats are in self.shim.get_stats()."""

    frames_rx: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    frames_tx: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    bytes_rx: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    bytes_tx: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    drops: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    start_time: float = field(default_factory=time.time)


# ============================================================================
# MULTI-INTERFACE FIREWALL v3
# ============================================================================


class MultiInterfaceFirewallV3:
    """
    v3 router: TAP I/O + async loops, with n2nhu_policy.RouterShim as the brain.

    Compare to v2: the class is ~40% smaller. All the removed code is either
    now in n2nhu_policy (tested) or unnecessary (replaced by INI rules).
    """

    def __init__(self, config_file: str):
        logger.info("=" * 70)
        logger.info("N2NHU Multi-Interface Firewall Router v3.0")
        logger.info("Declarative policy + NAT via n2nhu_policy engines")
        logger.info("=" * 70)

        # 1. Load interface/TAP config (same INI as v2, trimmed fields)
        self.config = self._load_config(config_file)
        logger.info(f"Loaded interface config from {config_file}")
        logger.info(f"Policy config root: {self.config.policy_root}")

        # 2. Initialize TAP devices (unchanged from v2)
        self.taps: Dict[str, TapDevice] = {}
        self._init_tap_devices()

        # 3. Build interface_ips and interface_networks maps for the shim
        interface_ips: Dict[str, IPv4Address] = {}
        interface_networks: Dict[str, IPv4Network] = {}
        for name, iface in self.config.interfaces.items():
            if not iface.enabled:
                continue
            try:
                interface_ips[name] = IPv4Address(iface.ip_address)
                interface_networks[name] = IPv4Network(iface.network, strict=False)
            except (ValueError, TypeError) as e:
                logger.warning(f"Skipping interface {name} in shim map: {e}")

        # If a default_route interface was named, promote it to 0.0.0.0/0
        if self.config.default_route in interface_networks:
            interface_networks[self.config.default_route] = IPv4Network("0.0.0.0/0")

        # 4. Construct the shim — loads policy + NAT INIs, validates everything
        try:
            self.shim = RouterShim(
                config_root=self.config.policy_root,
                interface_ips=interface_ips,
                interface_networks=interface_networks,
            )
        except Exception as e:
            logger.error(f"Failed to load policy config from {self.config.policy_root}")
            logger.error(f"  {e}")
            raise

        logger.info(
            "Shim loaded: %d policy rules, %d NAT rules, %d interfaces",
            len(self.shim.policy_config.policies),
            len(self.shim.nat_config.rules),
            len(interface_ips),
        )

        # 5. PCAP (unchanged from v2)
        if self.config.pcap_enabled:
            debug_settings = DebugSettings(
                enabled=self.config.debug_enabled,
                frame_trace=self.config.frame_trace,
                pcap_enable=self.config.pcap_enabled,
                pcap_file=self.config.pcap_file,
            )
            self.debug = DebugCapture(debug_settings)
            logger.info(f"PCAP capture enabled: {self.config.pcap_file}")
        else:
            self.debug = None

        # 6. Stats + async state
        self.stats = RouterStats()
        self.running = False
        self.tasks: List[asyncio.Task] = []

        logger.info("✅ Initialization complete")
        self._show_config()

        # 7. Start the NAT session reaper thread
        self.shim.nat_engine.session_table.start_reaper()
        logger.info(
            "✅ Session reaper started (interval=%ds)",
            self.shim.nat_config.reaper_interval,
        )

        # 8. Install SIGHUP handler for config reload (Linux only)
        if hasattr(signal, "SIGHUP"):
            signal.signal(signal.SIGHUP, self._sighup_handler)
            logger.info("✅ SIGHUP handler installed for reload")

    # ------------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------------

    def _load_config(self, config_file: str) -> RouterConfig:
        if not os.path.exists(config_file):
            raise FileNotFoundError(f"Config file not found: {config_file}")

        cp = configparser.ConfigParser()
        cp.read(config_file)

        # Parse interfaces (NAT/port-forward fields are no longer read here —
        # they live in n2nhu_policy's nat.ini now)
        interfaces: Dict[str, InterfaceConfig] = {}
        if "interfaces" in cp:
            for name in cp["interfaces"]:
                tap_name = cp["interfaces"][name]
                section = f"interface_{name}"
                if section not in cp:
                    logger.warning(f"No section for interface {name}, skipping")
                    continue
                interfaces[name] = InterfaceConfig(
                    name=name,
                    tap_name=tap_name,
                    type=cp.get(section, "type", fallback="LAN"),
                    network=cp.get(section, "network", fallback="0.0.0.0/0"),
                    ip_address=cp.get(section, "ip_address", fallback="0.0.0.0"),
                    enabled=cp.getboolean(section, "enabled", fallback=True),
                    mtu=cp.getint(section, "mtu", fallback=1500),
                )

        default_route = cp.get("routing", "default_interface", fallback="wan1")
        policy_root = cp.get(
            "firewall", "policy_config_root",
            fallback=cp.get("firewall", "config_path", fallback="etc/n2nhu"),
        )
        debug_enabled = cp.getboolean("debug", "enabled", fallback=True)
        pcap_enabled = cp.getboolean("debug", "pcap_enable", fallback=True)
        pcap_file = cp.get("debug", "pcap_file", fallback="router_capture.pcap")
        frame_trace = cp.getboolean("debug", "frame_trace", fallback=False)
        stats_interval = cp.getint("debug", "stats_interval_sec", fallback=10)

        return RouterConfig(
            interfaces=interfaces,
            default_route=default_route,
            policy_root=policy_root,
            debug_enabled=debug_enabled,
            pcap_enabled=pcap_enabled,
            pcap_file=pcap_file,
            frame_trace=frame_trace,
            stats_interval=stats_interval,
        )

    def _init_tap_devices(self):
        for name, iface in self.config.interfaces.items():
            if not iface.enabled:
                continue
            logger.info(f"Opening TAP: {name} ({iface.type}) → {iface.tap_name}")
            try:
                tap = TapDevice(iface.tap_name)
                tap.open()
                self.taps[name] = tap
                logger.info(f"✅ {name}: {iface.tap_name} opened")
            except Exception as e:
                logger.error(f"❌ Failed to open {name}: {e}")
                raise

    def _show_config(self):
        logger.info("=" * 70)
        logger.info("ROUTER CONFIGURATION")
        logger.info("=" * 70)
        logger.info(f"Interfaces: {', '.join(self.taps.keys())}")
        logger.info(f"Default route: {self.config.default_route}")
        logger.info(
            "Policy rules (order): %s",
            ", ".join(r.id for r in self.shim.policy_config.policies),
        )
        logger.info(
            "NAT rules (order): %s",
            ", ".join(r.id for r in self.shim.nat_config.rules) or "(none)",
        )
        logger.info("=" * 70)

    # ------------------------------------------------------------------------
    # SIGHUP reload
    # ------------------------------------------------------------------------

    def _sighup_handler(self, signum, frame):
        logger.info("SIGHUP received — attempting config reload")
        try:
            new_shim = self.shim.reload()
        except Exception as e:
            logger.error(f"Reload failed, keeping old config: {e}")
            return
        # Swap shim atomically; old engine's reaper thread will exit on stop.
        old_shim = self.shim
        self.shim = new_shim
        self.shim.nat_engine.session_table.start_reaper()
        old_shim.nat_engine.session_table.stop_reaper()
        logger.info(
            "✅ Reload OK: %d policy rules, %d NAT rules",
            len(self.shim.policy_config.policies),
            len(self.shim.nat_config.rules),
        )

    # ------------------------------------------------------------------------
    # Frame pipeline — the heart. This is now 10 lines instead of ~300.
    # ------------------------------------------------------------------------

    async def process_frame(self, src_interface: str, frame: bytes):
        """
        The brain. Hand the frame to the shim, forward or drop based on
        its decision. All NAT, policy, checksum, session logic is inside
        the shim.
        """
        try:
            self.stats.frames_rx[src_interface] += 1
            self.stats.bytes_rx[src_interface] += len(frame)

            if self.debug:
                self.debug.on_frame(f"{src_interface}_RX", frame)

            decision = self.shim.process_frame(src_interface, frame)

            if decision.action == ForwardAction.FORWARD:
                await self.forward_frame(decision.egress_iface, decision.frame)
            else:
                self.stats.drops[decision.action.value] += 1
                if self.debug:
                    reason = (
                        decision.policy_rule_id
                        or decision.nat_rule_id
                        or decision.drop_reason
                    )
                    self.debug.drop(f"{decision.action.value}_{reason}")

        except Exception as e:
            logger.error(f"Error processing frame from {src_interface}: {e}")
            self.stats.drops["error"] += 1

    async def forward_frame(self, dst_interface: str, frame: bytes):
        """Write frame to destination TAP. Unchanged from v2."""
        if dst_interface not in self.taps:
            self.stats.drops["unknown_interface"] += 1
            return
        try:
            if self.debug:
                self.debug.on_frame(f"{dst_interface}_TX", frame)
            tap = self.taps[dst_interface]
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, tap.write_frame, frame, 100)
            self.stats.frames_tx[dst_interface] += 1
            self.stats.bytes_tx[dst_interface] += len(frame)
        except Exception as e:
            logger.error(f"Error forwarding to {dst_interface}: {e}")
            self.stats.drops["forward_error"] += 1

    async def read_loop(self, interface_name: str):
        """
        Per-interface async read loop. Unchanged from v2.

        NOTE on "event-driven": this is the one place in the whole stack
        that still polls — Windows TAP adapters use overlapped ReadFile
        which we poll with a 100ms timeout + 1ms back-off. Upgrading to
        WaitForMultipleObjects is possible but not yet done. See README
        "Execution model" section.
        """
        tap = self.taps[interface_name]
        loop = asyncio.get_event_loop()
        logger.info(f"Started read loop for {interface_name}")

        while self.running:
            try:
                frame = await loop.run_in_executor(None, tap.read_frame, 100)
                if frame:
                    await self.process_frame(interface_name, frame)
                else:
                    await asyncio.sleep(0.001)
            except Exception as e:
                logger.error(f"Error in read loop for {interface_name}: {e}")
                await asyncio.sleep(0.1)

        logger.info(f"Stopped read loop for {interface_name}")

    # ------------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------------

    async def stats_loop(self):
        """Enhanced stats loop — includes shim counters."""
        while self.running:
            await asyncio.sleep(self.config.stats_interval)
            if not self.config.debug_enabled:
                continue

            shim_stats = self.shim.get_stats()
            logger.info("=" * 70)
            logger.info("ROUTER STATISTICS")
            logger.info(
                "TAP: rx=%d tx=%d drops=%d",
                sum(self.stats.frames_rx.values()),
                sum(self.stats.frames_tx.values()),
                sum(self.stats.drops.values()),
            )
            logger.info(
                "Shim: in=%d fwd=%d drop=%d (parse_err=%d, policy_deny=%d, nat_deny=%d)",
                shim_stats.frames_in,
                shim_stats.frames_forwarded,
                shim_stats.frames_dropped,
                shim_stats.parse_errors,
                shim_stats.policy_denies,
                shim_stats.nat_denies,
            )
            logger.info(
                "NAT: translations=%d active_sessions=%d",
                shim_stats.nat_translations,
                self.shim.session_count(),
            )
            logger.info("=" * 70)

    # ------------------------------------------------------------------------
    # Run / stop
    # ------------------------------------------------------------------------

    async def run(self):
        logger.info("=" * 70)
        logger.info("STARTING MULTI-INTERFACE FIREWALL ROUTER V3.0")
        logger.info("=" * 70)
        self.running = True

        try:
            for name in self.taps.keys():
                task = asyncio.create_task(self.read_loop(name))
                self.tasks.append(task)
                logger.info(f"✅ Started reader for {name}")

            if self.config.stats_interval > 0:
                self.tasks.append(asyncio.create_task(self.stats_loop()))

            logger.info("✅ All tasks started")
            logger.info(f"✅ Routing {len(self.taps)} interfaces")
            logger.info("=" * 70)

            await asyncio.gather(*self.tasks)

        except asyncio.CancelledError:
            logger.info("Router tasks cancelled")
        except Exception as e:
            logger.error(f"Router error: {e}")
            raise

    def stop(self):
        logger.info("Stopping router...")
        self.running = False

        # Stop the reaper
        try:
            self.shim.nat_engine.session_table.stop_reaper()
        except Exception as e:
            logger.warning(f"Reaper stop error: {e}")

        for task in self.tasks:
            task.cancel()

        for name, tap in self.taps.items():
            logger.info(f"Closing {name}")
            try:
                tap.close()
            except Exception:
                pass

        if self.debug:
            self.debug.close()

        logger.info("✅ Router stopped")

    def get_statistics(self) -> Dict:
        """Combined TAP + shim stats."""
        elapsed = time.time() - self.stats.start_time
        shim_stats = self.shim.get_stats()
        return {
            "elapsed_seconds": elapsed,
            "tap": {
                "frames_rx": dict(self.stats.frames_rx),
                "frames_tx": dict(self.stats.frames_tx),
                "bytes_rx": dict(self.stats.bytes_rx),
                "bytes_tx": dict(self.stats.bytes_tx),
                "drops": dict(self.stats.drops),
            },
            "shim": {
                "frames_in": shim_stats.frames_in,
                "frames_forwarded": shim_stats.frames_forwarded,
                "frames_dropped": shim_stats.frames_dropped,
                "parse_errors": shim_stats.parse_errors,
                "policy_denies": shim_stats.policy_denies,
                "nat_translations": shim_stats.nat_translations,
                "nat_denies": shim_stats.nat_denies,
                "passthroughs": shim_stats.passthroughs,
                "active_sessions": self.shim.session_count(),
            },
            "policy_hits": self.shim.policy_stats.as_dict(),
        }


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="N2NHU Multi-Interface Firewall Router v3.0 (shim-powered)",
    )
    parser.add_argument(
        "--config", default="firewall_router_v2.ini",
        help="Interface/TAP config file (same as v2)",
    )
    args = parser.parse_args()

    router: Optional[MultiInterfaceFirewallV3] = None
    try:
        router = MultiInterfaceFirewallV3(args.config)
        asyncio.run(router.run())
    except KeyboardInterrupt:
        print("\n\n🛑 Interrupted by user")
        if router is not None:
            router.stop()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        if router is not None:
            try:
                router.stop()
            except Exception:
                pass
        sys.exit(1)


if __name__ == "__main__":
    main()

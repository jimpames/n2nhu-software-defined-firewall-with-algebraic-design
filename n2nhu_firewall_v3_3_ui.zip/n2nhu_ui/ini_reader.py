"""
ini_reader — read a live INI file from disk and structure it against its schema.

The UI layer receives a list of "rendered sections" where each section has
its schema spec, its actual data, and any schema-vs-data warnings.
"""

from __future__ import annotations

import configparser
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .schema_models import FieldSpec, IniSchema, SectionKind, SectionSpec


@dataclass
class RenderedField:
    """One field ready to render in the UI."""

    spec: FieldSpec
    value: Any          # raw string or None if absent
    is_default: bool    # true if using schema default (value was absent)


@dataclass
class RenderedSection:
    """One section + its data, ready to render."""

    real_name: str               # the actual section name in the INI
    spec: SectionSpec            # the schema spec it matched
    template_instance: str = ""  # e.g. "trusted" for [zone_trusted] under [zone_*]
    # For FIXED/TEMPLATE sections: field name -> RenderedField
    fields: dict[str, RenderedField] = None
    # For MAP sections: list of (key, value) tuples preserving order
    map_entries: list[tuple[str, str]] = None

    def __post_init__(self):
        if self.fields is None:
            self.fields = {}
        if self.map_entries is None:
            self.map_entries = []


@dataclass
class RenderedIni:
    """A whole INI file ready for the UI."""

    schema: IniSchema
    file_exists: bool
    file_path: Path
    raw_text: str = ""
    sections: list[RenderedSection] = None
    warnings: list[str] = None

    def __post_init__(self):
        if self.sections is None:
            self.sections = []
        if self.warnings is None:
            self.warnings = []


def read_ini(schema: IniSchema, config_root: Path) -> RenderedIni:
    """
    Read an INI file from `config_root / schema.filename` and structure it
    against the schema. If the file doesn't exist, returns a RenderedIni
    with file_exists=False and empty sections — the UI can offer
    "Restore Defaults" to create it.
    """
    file_path = config_root / schema.filename
    rendered = RenderedIni(
        schema=schema,
        file_exists=file_path.exists(),
        file_path=file_path,
    )

    if not rendered.file_exists:
        return rendered

    rendered.raw_text = file_path.read_text(encoding="utf-8")

    cp = configparser.ConfigParser()
    cp.optionxform = str
    try:
        cp.read_string(rendered.raw_text)
    except configparser.Error as e:
        rendered.warnings.append(f"Failed to parse INI: {e}")
        return rendered

    for real_name in cp.sections():
        spec = schema.section_matching(real_name)
        if spec is None:
            rendered.warnings.append(
                f"Section [{real_name}] has no matching schema entry — "
                f"will be shown as raw text but not editable.",
            )
            continue

        rendered_section = RenderedSection(
            real_name=real_name,
            spec=spec,
        )
        if spec.kind == SectionKind.TEMPLATE:
            rendered_section.template_instance = schema.template_instance_label(
                spec.name, real_name,
            )

        section_data = cp[real_name]

        if spec.kind == SectionKind.MAP:
            for k in section_data:
                rendered_section.map_entries.append((k, section_data[k]))
        else:
            # FIXED or TEMPLATE — walk schema fields and look up values
            for f in spec.fields:
                if f.name in section_data:
                    rendered_section.fields[f.name] = RenderedField(
                        spec=f,
                        value=section_data[f.name],
                        is_default=False,
                    )
                else:
                    rendered_section.fields[f.name] = RenderedField(
                        spec=f,
                        value=f.default,
                        is_default=True,
                    )
            # Note: actual data keys not in the schema are ignored silently.
            # A CI test will pin schema-vs-loader drift separately.

        rendered.sections.append(rendered_section)

    return rendered

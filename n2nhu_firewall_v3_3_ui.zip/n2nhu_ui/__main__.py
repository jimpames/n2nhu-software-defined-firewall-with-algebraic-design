"""
Launcher: `python -m n2nhu_ui`

Default binding: 127.0.0.1:8800 (local-only, no auth).
To bind externally, pass --host and --password.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .app import create_app


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m n2nhu_ui",
        description=(
            "N2NHU Config Manager — schema-driven web UI for viewing "
            "(and soon editing) the firewall INI files."
        ),
    )
    parser.add_argument(
        "--config-root", "-c", type=str, default=None,
        help=(
            "Path to the INI tree (contains zones.ini, objects/, policies/). "
            "Default: $N2NHU_CONFIG_ROOT, then ./etc/n2nhu, then ./fixtures"
        ),
    )
    parser.add_argument(
        "--host", type=str, default="127.0.0.1",
        help="Bind address (default: 127.0.0.1 — local only)",
    )
    parser.add_argument(
        "--port", "-p", type=int, default=8800,
        help="Port (default: 8800)",
    )
    parser.add_argument(
        "--debug", action="store_true",
        help="Run Flask in debug mode (reloads on file changes)",
    )
    parser.add_argument(
        "--author", type=str, default="n2nhu-ui",
        help="Git commit author for UI-driven changes (default: n2nhu-ui)",
    )
    parser.add_argument(
        "--no-edit", action="store_true",
        help="Disable editing (read-only mode); only view and raw pages available",
    )
    args = parser.parse_args(argv)

    if args.host != "127.0.0.1" and args.host != "localhost":
        print(
            "\n⚠  WARNING: binding to a non-local address without auth. "
            "Anyone on the network can read (and restore) your config.\n"
            "Consider using SSH port-forwarding instead:\n"
            "   ssh -L 8800:127.0.0.1:8800 user@host\n",
            file=sys.stderr,
        )

    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )

    app = create_app(
        config_root=args.config_root,
        author=args.author,
        allow_edit=not args.no_edit,
    )

    mode = "READ-ONLY" if args.no_edit else f"EDIT (as {args.author})"
    banner = f"""
╔════════════════════════════════════════════════════════════════╗
║  N2NHU Config Manager v2.0 — http://{args.host}:{args.port}{' ' * max(0, 25 - len(args.host) - len(str(args.port)))}║
║  Config root: {str(app.config['CONFIG_ROOT'])[:48]:<48s}║
║  Schemas: {len(app.config['REGISTRY'].schemas):<53d}║
║  Mode: {mode:<56s}║
╚════════════════════════════════════════════════════════════════╝
"""
    print(banner)

    app.run(host=args.host, port=args.port, debug=args.debug)
    return 0


if __name__ == "__main__":
    sys.exit(main())

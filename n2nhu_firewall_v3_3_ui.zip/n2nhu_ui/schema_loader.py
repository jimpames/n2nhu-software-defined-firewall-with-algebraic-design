"""
SchemaLoader — reads .schema.ini files into typed IniSchema objects.

Schema file format:

    [__schema__]
    name = zones
    filename = zones.ini
    title = Zones & Interface Assignments
    description = ...
    icon = shield
    order = 10

    [__default_content__]
    content =
        ; -- N2NHU zones.ini --
        [zones]
        lan = lan_iface
        ...

    [section:zones]
    kind = map
    key_label = Zone name
    value_label = Member interfaces
    value_type = csv_string

    [section:zone_*]
    kind = template
    template_label = Zone name (without prefix)
    title = Per-zone settings

    [field:zone_*.security_level]
    type = integer
    default = 50
    min = 0
    max = 100
    help = Higher means more trusted

Registry file format (schemas/registry.ini):

    [zones]
    schema = zones.schema.ini

    [addresses]
    schema = addresses.schema.ini
    ...
"""

from __future__ import annotations

import configparser
from pathlib import Path
from typing import Any

from .schema_models import (
    FieldSpec,
    FieldType,
    IniSchema,
    Registry,
    SectionKind,
    SectionSpec,
)


class SchemaError(Exception):
    """Raised when a schema file is malformed."""

    def __init__(self, message: str, source: str | None = None, section: str | None = None):
        parts = []
        if source:
            parts.append(f"[{source}]")
        if section:
            parts.append(f"section '{section}'")
        parts.append(message)
        super().__init__(" ".join(parts))


def _parse_int(raw: str, default: int | None = None) -> int | None:
    raw = raw.strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise SchemaError(f"not an integer: {raw!r}") from exc


def _parse_bool(raw: str) -> bool:
    v = raw.strip().lower()
    if v in ("true", "yes", "on", "1"):
        return True
    if v in ("false", "no", "off", "0"):
        return False
    raise SchemaError(f"not a boolean: {raw!r}")


def _parse_csv(raw: str) -> tuple[str, ...]:
    if not raw:
        return ()
    parts = [p.strip() for p in raw.replace("\n", ",").split(",")]
    return tuple(p for p in parts if p)


def _cast_default(raw: str, field_type: FieldType) -> Any:
    """Coerce a raw default string into the appropriate typed value."""
    if raw == "":
        return None
    if field_type == FieldType.INTEGER or field_type == FieldType.PORT or field_type == FieldType.DSCP:
        try:
            return int(raw)
        except ValueError:
            # Symbolic DSCP defaults allowed
            return raw
    if field_type == FieldType.BOOLEAN:
        return _parse_bool(raw)
    if field_type == FieldType.CSV_STRING:
        return list(_parse_csv(raw))
    return raw


class SchemaLoader:
    """Loads schema files from a directory."""

    def __init__(self, schema_dir: str | Path):
        self.schema_dir = Path(schema_dir)

    def load_registry(self) -> Registry:
        """Load registry.ini and every schema it references."""
        registry_path = self.schema_dir / "registry.ini"
        if not registry_path.exists():
            raise SchemaError(f"missing registry file: {registry_path}")
        cp = configparser.ConfigParser()
        cp.optionxform = str
        cp.read(registry_path, encoding="utf-8")

        schemas: list[IniSchema] = []
        for section in cp.sections():
            if "schema" not in cp[section]:
                raise SchemaError(
                    f"registry entry missing 'schema' key",
                    source=str(registry_path), section=section,
                )
            schema_file = cp[section]["schema"].strip()
            schema_path = self.schema_dir / schema_file
            schema = self.load_schema(schema_path, registry_name=section)
            schemas.append(schema)
        return Registry(schemas=tuple(schemas))

    def load_schema(self, path: Path | str, registry_name: str | None = None) -> IniSchema:
        path = Path(path)
        if not path.exists():
            raise SchemaError(f"missing schema file: {path}")
        cp = configparser.ConfigParser()
        cp.optionxform = str
        cp.read(path, encoding="utf-8")
        source = str(path.name)

        # Parse [__schema__]
        if "__schema__" not in cp:
            raise SchemaError("missing [__schema__] section", source=source)
        meta = cp["__schema__"]
        for required in ("name", "filename", "title"):
            if required not in meta:
                raise SchemaError(
                    f"[__schema__] missing {required!r}",
                    source=source, section="__schema__",
                )

        name = meta["name"].strip()
        if registry_name is not None and name != registry_name:
            raise SchemaError(
                f"schema name {name!r} does not match registry entry {registry_name!r}",
                source=source,
            )
        filename = meta["filename"].strip()
        title = meta["title"].strip()
        description = meta.get("description", "").strip()
        icon = meta.get("icon", "file").strip()
        order = _parse_int(meta.get("order", "100")) or 100

        # Parse [__default_content__] — two forms supported:
        # 1. External file: [__schema__] default_file = defaults/zones.ini
        #    (preferred — avoids INI-in-INI parsing issues)
        # 2. Inline:        [__default_content__] content = ...
        #    (legacy, fragile with multi-line values)
        default_content = ""
        if "default_file" in meta:
            default_path = self.schema_dir / meta["default_file"].strip()
            if not default_path.exists():
                raise SchemaError(
                    f"default_file not found: {default_path}",
                    source=source, section="__schema__",
                )
            default_content = default_path.read_text(encoding="utf-8")
        elif "__default_content__" in cp:
            if "content" in cp["__default_content__"]:
                default_content = cp["__default_content__"]["content"]
                # Strip a leading blank line if present
                if default_content.startswith("\n"):
                    default_content = default_content[1:]

        # Parse all section: and field: entries
        # First pass: sections
        section_specs: dict[str, dict] = {}
        for sect in cp.sections():
            if sect.startswith("section:"):
                sect_name = sect[len("section:"):].strip()
                s = cp[sect]
                if "kind" not in s:
                    raise SchemaError(
                        f"section spec missing 'kind'",
                        source=source, section=sect,
                    )
                section_specs[sect_name] = {
                    "kind": SectionKind.parse(s["kind"]),
                    "title": s.get("title", "").strip(),
                    "description": s.get("description", "").strip(),
                    "key_label": s.get("key_label", "Key").strip(),
                    "value_label": s.get("value_label", "Value").strip(),
                    "value_help": s.get("value_help", "").strip(),
                    "value_type": FieldType.parse(s.get("value_type", "string")),
                    "template_label": s.get("template_label", "").strip(),
                }

        # Second pass: fields, grouped by section
        fields_by_section: dict[str, list[FieldSpec]] = {
            sname: [] for sname in section_specs
        }
        for sect in cp.sections():
            if not sect.startswith("field:"):
                continue
            qualified = sect[len("field:"):].strip()
            if "." not in qualified:
                raise SchemaError(
                    f"field name must be 'section.field', got {qualified!r}",
                    source=source, section=sect,
                )
            sect_name, _, field_name = qualified.partition(".")
            if sect_name not in section_specs:
                raise SchemaError(
                    f"field references unknown section {sect_name!r}",
                    source=source, section=sect,
                )
            f = cp[sect]
            if "type" not in f:
                raise SchemaError(
                    f"field missing 'type'", source=source, section=sect,
                )
            field_type = FieldType.parse(f["type"])
            min_v = _parse_int(f.get("min", ""))
            max_v = _parse_int(f.get("max", ""))
            default_raw = f.get("default", "")
            default_val = _cast_default(default_raw, field_type)
            fields_by_section[sect_name].append(FieldSpec(
                name=field_name,
                type=field_type,
                label=f.get("label", field_name).strip(),
                help_text=f.get("help", "").strip(),
                default=default_val,
                required=_parse_bool(f.get("required", "false")),
                min_value=min_v,
                max_value=max_v,
                choices=_parse_csv(f.get("choices", "")),
                ref_to=f.get("ref_to", "").strip(),
                section=sect_name,
            ))

        # Build ordered section list (schemas/registry.ini order within a file
        # follows declaration order in the INI)
        sections: list[SectionSpec] = []
        for sect_name, meta_dict in section_specs.items():
            sections.append(SectionSpec(
                name=sect_name,
                kind=meta_dict["kind"],
                title=meta_dict["title"] or sect_name,
                description=meta_dict["description"],
                fields=tuple(fields_by_section[sect_name]),
                key_label=meta_dict["key_label"],
                value_label=meta_dict["value_label"],
                value_type=meta_dict["value_type"],
                value_help=meta_dict["value_help"],
                template_label=meta_dict["template_label"],
            ))

        return IniSchema(
            name=name,
            filename=filename,
            title=title,
            description=description,
            icon=icon,
            order=order,
            sections=tuple(sections),
            default_content=default_content,
        )

"""
commit_manager — diff generation and atomic file writes with optional git
audit trail.

Every save is one commit. The commit message is the filename + a short
summary, the author is configurable (default "n2nhu-ui"). If the config
root is not a git repo yet, the manager initializes one on first write.

This is the audit trail for compliance / rollback / blame. Every change
operators make through the UI is captured forever.
"""

from __future__ import annotations

import difflib
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CommitResult:
    ok: bool
    commit_hash: str = ""
    error_message: str = ""


def generate_unified_diff(
    old_text: str,
    new_text: str,
    filename: str,
) -> str:
    """
    Produce a unified diff suitable for rendering in the UI. Empty string
    if no changes.
    """
    old_lines = old_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    diff = difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
        lineterm="",
    )
    return "".join(diff)


def count_changes(diff_text: str) -> tuple[int, int]:
    """Count +added / -removed lines from a unified diff."""
    added = 0
    removed = 0
    for line in diff_text.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("+"):
            added += 1
        elif line.startswith("-"):
            removed += 1
    return added, removed


def _git(args: list[str], cwd: Path) -> tuple[int, str, str]:
    """Run a git command; return (returncode, stdout, stderr)."""
    try:
        proc = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=15,
        )
        return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
    except FileNotFoundError:
        return 127, "", "git not installed"
    except subprocess.TimeoutExpired:
        return 124, "", "git command timed out"


def is_git_available() -> bool:
    rc, _, _ = _git(["--version"], cwd=Path.cwd())
    return rc == 0


def ensure_git_repo(config_root: Path, author: str = "n2nhu-ui") -> bool:
    """
    If config_root is not a git repo, initialize one and make an initial
    commit of the current state. Returns True on success, False on failure
    (including if git itself isn't installed).
    """
    git_dir = config_root / ".git"
    if git_dir.exists():
        return True
    if not is_git_available():
        return False

    rc, _, err = _git(["init", "-b", "main"], cwd=config_root)
    if rc != 0:
        return False

    # Configure commit author for this repo
    _git(["config", "user.email", f"{author}@n2nhu.local"], cwd=config_root)
    _git(["config", "user.name", author], cwd=config_root)

    rc, _, _ = _git(["add", "-A"], cwd=config_root)
    if rc != 0:
        return False

    # Initial commit (allow empty in case there are no files yet)
    rc, _, _ = _git(
        ["commit", "--allow-empty", "-m", "Initial commit — existing config captured by N2NHU UI"],
        cwd=config_root,
    )
    return rc == 0


def commit_change(
    config_root: Path,
    filename: str,
    new_text: str,
    commit_message: str,
    author: str = "n2nhu-ui",
    use_git: bool = True,
) -> CommitResult:
    """
    Write `new_text` to `config_root / filename` and optionally git-commit.

    Writes are atomic via temp-file + rename to avoid partial writes if
    the process is killed mid-save.

    IMPORTANT: git repo initialization happens BEFORE the file write, so
    the initial commit captures the pre-change state — which is what makes
    the subsequent commit a "diff" of the operator's change.
    """
    target = config_root / filename

    # Step 1: ensure git repo exists and captures the pre-change state
    if use_git and not ensure_git_repo(config_root, author=author):
        # Non-fatal — we'll still try to write, just without git backing
        use_git = False

    target.parent.mkdir(parents=True, exist_ok=True)

    # Step 2: atomic write
    tmp = target.with_suffix(target.suffix + ".tmp")
    try:
        tmp.write_text(new_text, encoding="utf-8")
        os.replace(tmp, target)
    except OSError as e:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        return CommitResult(ok=False, error_message=f"write failed: {e}")

    if not use_git:
        return CommitResult(ok=True, commit_hash="")

    # Step 3: stage + commit
    rc, _, err = _git(["add", filename], cwd=config_root)
    if rc != 0:
        return CommitResult(ok=True, commit_hash="", error_message=f"git add failed: {err}")

    # Only commit if there's actually a change
    rc, _, _ = _git(["diff", "--cached", "--quiet"], cwd=config_root)
    if rc == 0:
        return CommitResult(ok=True, commit_hash="", error_message="")  # no change

    rc, _, err = _git(
        ["commit", "-m", commit_message, f"--author={author} <{author}@n2nhu.local>"],
        cwd=config_root,
    )
    if rc != 0:
        return CommitResult(ok=True, commit_hash="", error_message=f"git commit failed: {err}")

    rc, sha, _ = _git(["rev-parse", "--short", "HEAD"], cwd=config_root)
    if rc != 0:
        return CommitResult(ok=True, commit_hash="")
    return CommitResult(ok=True, commit_hash=sha)


def list_history(config_root: Path, filename: str | None = None, limit: int = 20) -> list[dict]:
    """
    Return the last N commits touching `filename` (or all files if None).
    Each entry: {hash, short, author, date, subject}.
    """
    if not (config_root / ".git").exists():
        return []

    args = ["log", f"-n{limit}", "--pretty=format:%H\t%h\t%an\t%aI\t%s"]
    if filename:
        args.append("--")
        args.append(filename)
    rc, out, _ = _git(args, cwd=config_root)
    if rc != 0:
        return []

    result = []
    for line in out.splitlines():
        parts = line.split("\t", 4)
        if len(parts) != 5:
            continue
        result.append({
            "hash": parts[0],
            "short": parts[1],
            "author": parts[2],
            "date": parts[3],
            "subject": parts[4],
        })
    return result


def get_file_at_commit(config_root: Path, filename: str, commit_hash: str) -> str | None:
    """Retrieve a file's contents at a specific commit. Returns None on error."""
    if not (config_root / ".git").exists():
        return None
    rc, out, _ = _git(["show", f"{commit_hash}:{filename}"], cwd=config_root)
    if rc != 0:
        return None
    return out

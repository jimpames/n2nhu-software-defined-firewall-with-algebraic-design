# N2NHU Config Manager (UI)

Schema-driven web UI for viewing the N2NHU firewall configuration. The
schema itself describes every INI file the engine accepts — field types,
defaults, ranges, help text, and how each section should render. The UI
walks the schema and produces professional forms automatically, so when
new fields get added to the engine, the UI gains controls for them by
adding a schema line.

**v1 is read-only.** "Restore defaults" is the one write path, and it's
backed by a CI test (`test_schema_drift.py`) that proves the schema's
default content produces an engine-valid config tree.

**Status: 349 tests green** (292 engine + 57 UI) in ~6 seconds.

---

## Running

```bash
pip install flask
cd n2nhu_firewall_ui_v1
python -m n2nhu_ui --config-root fixtures
# open http://127.0.0.1:8800
```

CLI options:

```
python -m n2nhu_ui --help
  --config-root PATH   Where the INI tree lives (default: auto-detect)
  --host ADDR          Bind address (default: 127.0.0.1 — local only)
  --port PORT          Port (default: 8800)
  --debug              Flask debug mode with auto-reload
```

By default binds to localhost only. Binding externally prints a warning
— for remote access, use SSH port forwarding:

```bash
ssh -L 8800:127.0.0.1:8800 user@firewall-box
```

## What's in the UI

- **Dashboard** — which INI files exist, their size, last-modified time.
- **Zones / Addresses / Services / Schedules / Security / NAT / PBR** —
  one page per INI, every section rendered as a card, every field shown
  with appropriate visual treatment:
  - ALLOW / DENY / REJECT in colored pills.
  - Booleans as filled/empty checkboxes.
  - CSV values as tag chips.
  - References (`src_addr = addr_lan_net`) annotated with the target type.
  - Fields missing from the INI marked "(default)" showing what value the
    schema would provide.
- **Raw view** — syntax-highlighted INI plaintext with a back-to-fields button.
- **Restore defaults** — on each page, with confirmation dialog. Writes the
  schema's canonical default content to disk. Parent directories are
  auto-created.

## Architecture

The UI is a thin layer over the engine's existing validation code. It
reuses `ConfigLoader`, `NATConfigLoader`, and `PBRConfigLoader` from
`n2nhu_policy` — which means the UI cannot accept a config the engine
would reject (and vice versa). This invariant is pinned by the test
suite.

```
n2nhu_ui/
├── schemas/
│   ├── registry.ini            Master list of all INI types
│   ├── zones.schema.ini        Metadata: section kinds, field types, ...
│   ├── addresses.schema.ini
│   ├── services.schema.ini
│   ├── schedules.schema.ini
│   ├── security.schema.ini
│   ├── nat.schema.ini
│   ├── pbr.schema.ini
│   └── defaults/               Canonical default INIs (one per schema)
│       ├── zones.ini
│       └── ... etc
├── schema_models.py            Typed dataclasses (FieldType, SectionSpec, ...)
├── schema_loader.py            Parse .schema.ini files → IniSchema
├── ini_reader.py               Read live INIs + match against schema
├── app.py                      Flask application factory
├── __main__.py                 python -m n2nhu_ui launcher
├── templates/
│   ├── base.html               Sidebar + layout
│   ├── dashboard.html
│   ├── ini_view.html           Structured field-by-field view
│   ├── ini_raw.html            Raw INI with syntax highlighting
│   └── _macros.html            Field type renderers (13 field types)
└── static/
    ├── css/tailwind.min.css    12 KB, compiled for our actual templates
    └── js/htmx.min.js          48 KB vendored
```

## The schema language

Each INI file has a `.schema.ini` that describes it. Three section kinds:

- **`fixed`** — single known section with a fixed set of fields
  (e.g., `[policy_order]` which has one `rules` field).
- **`map`** — section whose keys are user-chosen names
  (e.g., `[zones]` where each key is a zone name and each value is
  a list of interfaces).
- **`template`** — repeating sections matching a pattern
  (e.g., `[zone_*]` — one section per zone, each with the same fields).

Field types (each renders differently in the UI):

| Type | Widget (future edit mode) |
| --- | --- |
| `integer` | number spinner with min/max |
| `string` | text input |
| `boolean` | checkbox |
| `enum` | dropdown |
| `csv_string` | tag-input widget |
| `ref` | typeahead dropdown populated from another schema |
| `ip_address`, `ip_network`, `ip_range` | text with live validation |
| `port`, `port_range` | numeric with validation |
| `hhmm` | time picker |
| `dscp` | numeric or symbolic (ef, af41, cs6, ...) |

`ref` fields declare `ref_to = <schema_name>` — e.g., a policy rule's
`src_addr` has `ref_to = addresses`, which means the UI populates its
dropdown from `addresses.ini`. No typos, no stale choices.

## The drift-detection invariant

The core safety test (`tests/test_schema_drift.py`) writes every schema's
canonical defaults to a temp directory and asks the real engine's
`ConfigLoader`/`NATConfigLoader`/`PBRConfigLoader` to parse them. If any
schema drifts from what the engine expects, CI fails.

This is what makes "Restore Defaults" foolproof — operators literally
cannot produce a broken config by clicking that button.

During development of this v1, the drift test caught three real bugs
before the UI ever shipped:
1. Schema used `tz` where engine wanted `timezone`.
2. Default security.ini referenced `addrgrp_blocklist` but the slim
   default addresses.ini didn't declare it.
3. INI-in-INI continuation lines were being normalized by `configparser`
   on read, breaking multi-line values in defaults.

## Next phases (not in v1)

- **Edit mode** — form widgets for all 13 field types, with live
  validation via `ConfigLoader`, diff preview, confirm dialog.
- **Git integration** — auto-commit every save with user + timestamp;
  "Rollback to previous" button.
- **Router integration** — "Apply now" button that POSTs to
  `RouterShim`'s reload endpoint (or signals SIGHUP).
- **Auth** — HTTP basic auth when binding non-local; LDAP/SAML for
  larger deployments.

## License

Same as the parent N2NHU project.

— J P Ames & Claude, April 2026

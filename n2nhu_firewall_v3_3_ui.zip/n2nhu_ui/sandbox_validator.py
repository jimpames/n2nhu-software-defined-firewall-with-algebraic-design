"""
sandbox_validator — run the real engine's config loaders against a candidate
INI file in a throwaway directory.

This is the backbone of the foolproof guarantee: the UI cannot accept a config
the engine would reject, because the UI literally asks the engine. We do this
by:

  1. Copying the live INI tree into a temp directory.
  2. Overwriting ONE file with the candidate bytes.
  3. Running ConfigLoader / NATConfigLoader / PBRConfigLoader against the tmp
     tree.
  4. If any raises ConfigError, propagate the error with its source/section/key.

This is the same exact code path the running firewall uses. No duplicate
validation logic.
"""

from __future__ import annotations

import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

from n2nhu_policy.config_loader import ConfigLoader
from n2nhu_policy.errors import ConfigError
from n2nhu_policy.nat_config_loader import NATConfigLoader
from n2nhu_policy.pbr_config_loader import PBRConfigLoader


@dataclass(frozen=True)
class ValidationResult:
    ok: bool
    error_message: str = ""
    error_source: str = ""
    error_section: str = ""
    error_key: str = ""

    @property
    def display_error(self) -> str:
        parts = []
        if self.error_source:
            parts.append(f"[{self.error_source}]")
        if self.error_section:
            parts.append(f"section '{self.error_section}'")
        parts.append(self.error_message)
        return " ".join(parts)


# Schema names that, when edited, require different loader subsets to run.
# Security / zones / addresses / services / schedules → run ConfigLoader.
# NAT → run ConfigLoader then NATConfigLoader.
# PBR → run ConfigLoader then PBRConfigLoader.
# In all cases we run ConfigLoader first because NAT/PBR loaders consume its output.


def validate_candidate(
    schema_name: str,
    candidate_text: str,
    live_config_root: Path,
    candidate_filename: str,
) -> ValidationResult:
    """
    Write `candidate_text` to a tmp copy of the live tree, then invoke the
    real engine loaders. Returns a ValidationResult.

    Args:
        schema_name: the registry name ("zones", "security", "nat", "pbr", ...).
        candidate_text: the proposed full INI file text.
        live_config_root: path to the live configuration root.
        candidate_filename: relative path of the file being edited (e.g.,
                            "zones.ini" or "policies/security.ini").
    """
    with tempfile.TemporaryDirectory(prefix="n2nhu_validate_") as tmp:
        tmp_path = Path(tmp)

        # Copy live tree into tmp. Use ignore to skip any OS cruft.
        if live_config_root.exists():
            for item in live_config_root.iterdir():
                dest = tmp_path / item.name
                if item.is_dir():
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)

        # Overwrite the candidate file
        target = tmp_path / candidate_filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(candidate_text, encoding="utf-8")

        # Run the loaders in order. ConfigLoader always runs first.
        try:
            policy_cfg = ConfigLoader(tmp_path).load()
        except ConfigError as e:
            return _error_from_config_error(e)

        # If the schema touches NAT or PBR (either directly or transitively
        # via object changes), run those too. Cheap to run even when not
        # strictly needed — catches downstream breakage.
        try:
            NATConfigLoader(tmp_path, policy_cfg).load()
        except ConfigError as e:
            return _error_from_config_error(e)
        except FileNotFoundError:
            # NAT file is optional
            pass

        try:
            PBRConfigLoader(tmp_path, policy_cfg).load()
        except ConfigError as e:
            return _error_from_config_error(e)
        except FileNotFoundError:
            pass

    return ValidationResult(ok=True)


def _error_from_config_error(e: ConfigError) -> ValidationResult:
    """Extract source/section from a ConfigError's attributes."""
    # ConfigError.__init__ stores source/section on the instance and the
    # composed string is in str(e). Provide the composed string as the
    # display message so prefix formatting (which is in the composed string)
    # is shown.
    return ValidationResult(
        ok=False,
        error_message=str(e),
        error_source=getattr(e, "source", "") or "",
        error_section=getattr(e, "section", "") or "",
        error_key="",
    )

"""
ini_writer — emit formatted INI text from schema + data.

Design invariants:
  1. Round-trip correctness: reading a file with configparser, passing
     through write_ini(), and re-reading with configparser produces the
     same logical data.
  2. Field alignment: when a section has fixed fields, pad the keys so
     the '=' signs line up (matches the hand-written fixture style).
  3. Section ordering: respect schema declaration order for FIXED and
     MAP sections; TEMPLATE instances follow their declared order in
     the source INI (we preserve whatever ordering was read in).
  4. Comments at top of file: preserved if provided via `preamble`.
  5. Multi-line list values: CSV fields are emitted with commas and
     continuation-indented lines, matching fixture style.

This writer is INTENTIONALLY opinionated about formatting. It does NOT
try to preserve every whitespace quirk of hand-edited files — that way
lies madness. Instead it produces a canonical, consistent output that
the engine loads identically to the hand-written fixtures.
"""

from __future__ import annotations

from typing import Any

from .schema_models import FieldType, IniSchema, SectionKind, SectionSpec


def _format_value(value: Any, field_type: FieldType) -> str:
    """Turn a Python value into the INI string representation."""
    if value is None:
        return ""
    if field_type == FieldType.BOOLEAN:
        if isinstance(value, bool):
            return "true" if value else "false"
        v = str(value).strip().lower()
        if v in ("true", "yes", "on", "1"):
            return "true"
        if v in ("false", "no", "off", "0"):
            return "false"
        # Pass through unchanged if ambiguous
        return str(value)
    if field_type == FieldType.CSV_STRING:
        if isinstance(value, (list, tuple)):
            return ", ".join(str(v) for v in value if str(v).strip())
        return str(value)
    return str(value)


def _align_pad(key: str, max_key_len: int) -> str:
    """Right-pad key with spaces for '=' alignment."""
    return key + (" " * (max_key_len - len(key)))


def write_section_fixed_or_template(
    section_name: str,
    section_spec: SectionSpec,
    fields: dict[str, Any],
) -> list[str]:
    """
    Emit a FIXED or TEMPLATE section. `fields` is a dict mapping field
    name -> value (raw Python, not yet stringified).
    """
    lines = [f"[{section_name}]"]

    # Gather ordered (name, value, type) tuples — follow schema order,
    # skip unset fields unless they're marked required.
    entries: list[tuple[str, str, FieldType]] = []
    for fspec in section_spec.fields:
        raw = fields.get(fspec.name)
        if raw is None or (isinstance(raw, str) and raw == ""):
            if fspec.required:
                # Required field missing — emit empty so validation catches it
                entries.append((fspec.name, "", fspec.type))
            # else skip unset optional fields
            continue
        formatted = _format_value(raw, fspec.type)
        entries.append((fspec.name, formatted, fspec.type))

    if not entries:
        return lines

    # Align '=' signs
    max_key_len = max(len(name) for name, _, _ in entries)
    for name, val, ft in entries:
        key_padded = _align_pad(name, max_key_len)
        if ft == FieldType.CSV_STRING and "," in val and len(val) > 60:
            # Long CSV — break across lines at commas with continuation indent
            parts = [p.strip() for p in val.split(",")]
            indent = " " * (max_key_len + 3)  # align with value column
            first, *rest = parts
            lines.append(f"{key_padded} = {first},")
            for i, p in enumerate(rest):
                sep = "," if i < len(rest) - 1 else ""
                lines.append(f"{indent}{p}{sep}")
        else:
            lines.append(f"{key_padded} = {val}")
    return lines


def write_section_map(
    section_name: str,
    section_spec: SectionSpec,
    entries: list[tuple[str, Any]],
) -> list[str]:
    """
    Emit a MAP section. `entries` is a list of (key, value) tuples preserving
    the operator's ordering.
    """
    lines = [f"[{section_name}]"]
    if not entries:
        return lines

    # Align '=' signs across all keys
    max_key_len = max(len(str(k)) for k, _ in entries)
    for key, value in entries:
        key_padded = _align_pad(str(key), max_key_len)
        formatted = _format_value(value, section_spec.value_type)
        lines.append(f"{key_padded} = {formatted}")
    return lines


def write_ini(
    schema: IniSchema,
    sections: list[tuple[str, SectionSpec, Any]],
    preamble: str = "",
) -> str:
    """
    Compose a full INI file.

    Args:
        schema: the IniSchema for this file.
        sections: ordered list of (real_name, section_spec, data).
                  For FIXED/TEMPLATE sections, data is a dict[str, Any].
                  For MAP sections, data is a list[tuple[str, Any]].
        preamble: optional comment block to emit at the top.

    Returns:
        The full INI file text, ending with a newline.
    """
    out: list[str] = []
    if preamble:
        for line in preamble.rstrip().splitlines():
            stripped = line.strip()
            if not stripped:
                out.append("")
            elif stripped.startswith(";") or stripped.startswith("#"):
                out.append(line)
            else:
                out.append(f"; {line}")
        out.append("")

    for i, (real_name, spec, data) in enumerate(sections):
        if i > 0:
            out.append("")  # blank line between sections
        if spec.kind == SectionKind.MAP:
            out.extend(write_section_map(real_name, spec, data))
        else:
            out.extend(write_section_fixed_or_template(real_name, spec, data))

    return "\n".join(out) + "\n"


def parse_form_value(raw: str, field_type: FieldType) -> Any:
    """
    Take a string from an HTML form and return a Python value of the right
    type. Raises ValueError with a helpful message on bad input.

    The writer accepts the returned values; the engine's loader does the
    deep validation. We only reject here things that would break INI
    serialization (e.g., newlines in a string field).
    """
    # HTML forms give us strings. Booleans are special — checkboxes send
    # nothing when unchecked, or "on"/"true" when checked.
    if field_type == FieldType.BOOLEAN:
        if raw is None:
            return False
        v = str(raw).strip().lower()
        return v in ("true", "yes", "on", "1", "checked")

    if raw is None:
        return None

    if field_type == FieldType.INTEGER or field_type == FieldType.PORT or field_type == FieldType.DSCP:
        stripped = str(raw).strip()
        if stripped == "":
            return None
        # Allow DSCP symbolic names to pass through
        if field_type == FieldType.DSCP:
            try:
                return int(stripped)
            except ValueError:
                return stripped  # symbolic; loader will parse
        try:
            return int(stripped)
        except ValueError as exc:
            raise ValueError(f"not a valid integer: {raw!r}") from exc

    if field_type == FieldType.CSV_STRING:
        # Accept either a comma-separated string or a list
        if isinstance(raw, (list, tuple)):
            return [str(x).strip() for x in raw if str(x).strip()]
        return [p.strip() for p in str(raw).split(",") if p.strip()]

    # Everything else is a string; reject embedded newlines
    text = str(raw)
    if "\n" in text or "\r" in text:
        raise ValueError("value may not contain line breaks")
    return text.strip()

"""
N2NHU UI — Flask application.

Routes:
  /                         — dashboard
  /ini/<name>               — view an INI file (schema-driven form)
  /ini/<name>/raw           — raw INI text with syntax highlighting
  /ini/<name>/restore       — POST: write default content to disk
  /health                   — simple liveness check
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from flask import Flask, abort, flash, redirect, render_template, request, url_for

from .commit_manager import (
    CommitResult, commit_change, count_changes, generate_unified_diff,
    get_file_at_commit, is_git_available, list_history,
)
from .form_helpers import (
    InstanceError,
    _collect_ref_options, _form_to_ini,
    add_template_instance, delete_template_instance,
    reorder_template_instances,
)
from .ini_reader import RenderedIni, read_ini
from .ini_writer import parse_form_value, write_ini
from .sandbox_validator import validate_candidate
from .schema_loader import SchemaError, SchemaLoader
from .schema_models import FieldType, IniSchema, Registry, SectionKind


def _detect_config_root(cli_root: str | None) -> Path:
    """
    Pick the config root. Priority:
      1. Explicit --config-root from CLI (if cli_root is given)
      2. $N2NHU_CONFIG_ROOT environment variable
      3. ./etc/n2nhu
      4. ./fixtures (fallback for development)
    """
    import os
    if cli_root:
        return Path(cli_root).resolve()
    if "N2NHU_CONFIG_ROOT" in os.environ:
        return Path(os.environ["N2NHU_CONFIG_ROOT"]).resolve()
    for candidate in ("etc/n2nhu", "fixtures"):
        p = Path(candidate).resolve()
        if p.exists():
            return p
    return Path("etc/n2nhu").resolve()


def create_app(
    config_root: str | None = None,
    schema_dir: str | None = None,
    author: str = "n2nhu-ui",
    allow_edit: bool = True,
) -> Flask:
    pkg_dir = Path(__file__).resolve().parent
    app = Flask(
        __name__,
        template_folder=str(pkg_dir / "templates"),
        static_folder=str(pkg_dir / "static"),
    )
    app.secret_key = "n2nhu-ui-local-only"  # local-only, no auth

    app.config["CONFIG_ROOT"] = _detect_config_root(config_root)
    app.config["SCHEMA_DIR"] = (
        Path(schema_dir) if schema_dir else pkg_dir / "schemas"
    )
    app.config["AUTHOR"] = author
    app.config["ALLOW_EDIT"] = allow_edit

    registry = SchemaLoader(app.config["SCHEMA_DIR"]).load_registry()
    app.config["REGISTRY"] = registry

    # ---- Helpers available to all templates ----
    @app.context_processor
    def inject_globals():
        return {
            "registry": registry,
            "config_root": str(app.config["CONFIG_ROOT"]),
            "now": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": "2.0.0",
            "allow_edit": app.config["ALLOW_EDIT"],
            "git_available": is_git_available(),
        }

    @app.template_filter("highlight_ini")
    def highlight_ini(text: str) -> str:
        """Simple syntax highlight: wrap sections, keys, values in spans."""
        from markupsafe import Markup, escape
        out_lines = []
        for line in text.splitlines():
            s = escape(line)
            stripped = line.strip()
            if not stripped:
                out_lines.append("")
                continue
            if stripped.startswith(";") or stripped.startswith("#"):
                out_lines.append(
                    f'<span class="text-slate-500 italic">{s}</span>'
                )
                continue
            if stripped.startswith("[") and stripped.endswith("]"):
                out_lines.append(
                    f'<span class="text-indigo-400 font-semibold">{s}</span>'
                )
                continue
            if "=" in line:
                # Preserve leading whitespace
                leading_len = len(line) - len(line.lstrip())
                leading = escape(line[:leading_len])
                rest = line[leading_len:]
                key, _, val = rest.partition("=")
                key_esc = escape(key.rstrip())
                val_esc = escape(val)
                trailing_key_ws = escape(" " * (len(key) - len(key.rstrip())))
                out_lines.append(
                    f'{leading}<span class="text-emerald-400">{key_esc}</span>'
                    f'{trailing_key_ws}<span class="text-slate-500">=</span>'
                    f'<span class="text-slate-200">{val_esc}</span>'
                )
                continue
            out_lines.append(str(s))
        return Markup("\n".join(out_lines))

    # ---- Routes ----
    @app.route("/")
    def dashboard():
        config_root_path: Path = app.config["CONFIG_ROOT"]
        entries = []
        for schema in registry.ordered():
            file_path = config_root_path / schema.filename
            entries.append({
                "schema": schema,
                "exists": file_path.exists(),
                "mtime": (
                    datetime.fromtimestamp(file_path.stat().st_mtime)
                    if file_path.exists() else None
                ),
                "size_bytes": (
                    file_path.stat().st_size if file_path.exists() else 0
                ),
            })
        total = len(registry.schemas)
        existing = sum(1 for e in entries if e["exists"])
        return render_template(
            "dashboard.html",
            entries=entries,
            total=total,
            existing=existing,
            missing=total - existing,
        )

    @app.route("/ini/<name>")
    def view_ini(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        rendered = read_ini(schema, app.config["CONFIG_ROOT"])
        return render_template("ini_view.html", rendered=rendered, active=name)

    @app.route("/ini/<name>/raw")
    def view_raw(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        rendered = read_ini(schema, app.config["CONFIG_ROOT"])
        return render_template("ini_raw.html", rendered=rendered, active=name)

    @app.route("/ini/<name>/restore", methods=["POST"])
    def restore_defaults(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            flash("Editing is disabled on this instance.", "warning")
            return redirect(url_for("view_ini", name=name))

        content = schema.default_content
        if not content.endswith("\n"):
            content += "\n"
        result = commit_change(
            app.config["CONFIG_ROOT"],
            schema.filename,
            content,
            f"UI: restored defaults for {schema.filename}",
            author=app.config["AUTHOR"],
        )
        if result.ok:
            msg = f"Restored defaults → {schema.filename}"
            if result.commit_hash:
                msg += f" (commit {result.commit_hash})"
            flash(msg, "success")
        else:
            flash(f"Restore failed: {result.error_message}", "warning")
        return redirect(url_for("view_ini", name=name))

    # ----- Editing routes -----

    @app.route("/ini/<name>/edit")
    def edit_ini(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            return redirect(url_for("view_ini", name=name))
        rendered = read_ini(schema, app.config["CONFIG_ROOT"])
        ref_options = _collect_ref_options(registry, app.config["CONFIG_ROOT"])
        return render_template(
            "ini_edit.html",
            rendered=rendered, active=name, ref_options=ref_options,
        )

    @app.route("/ini/<name>/preview", methods=["POST"])
    def preview_changes(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            abort(403)

        try:
            new_text = _form_to_ini(schema, request.form, app.config["CONFIG_ROOT"])
        except ValueError as e:
            rendered = read_ini(schema, app.config["CONFIG_ROOT"])
            ref_options = _collect_ref_options(registry, app.config["CONFIG_ROOT"])
            return render_template(
                "ini_edit.html", rendered=rendered, active=name,
                ref_options=ref_options, form_error=str(e),
            )

        result = validate_candidate(
            schema_name=name,
            candidate_text=new_text,
            live_config_root=app.config["CONFIG_ROOT"],
            candidate_filename=schema.filename,
        )

        live_path = app.config["CONFIG_ROOT"] / schema.filename
        old_text = live_path.read_text(encoding="utf-8") if live_path.exists() else ""
        diff = generate_unified_diff(old_text, new_text, schema.filename)
        added, removed = count_changes(diff)

        return render_template(
            "ini_preview.html",
            schema=schema, active=name,
            new_text=new_text, old_text=old_text,
            diff=diff, added=added, removed=removed,
            validation=result,
        )

    @app.route("/ini/<name>/commit", methods=["POST"])
    def commit_edit(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            abort(403)

        new_text = request.form.get("new_text", "")
        msg = request.form.get("commit_message", "").strip() or \
              f"UI: edited {schema.filename}"

        result = validate_candidate(
            schema_name=name,
            candidate_text=new_text,
            live_config_root=app.config["CONFIG_ROOT"],
            candidate_filename=schema.filename,
        )
        if not result.ok:
            flash(f"Validation failed on commit: {result.display_error}", "warning")
            return redirect(url_for("edit_ini", name=name))

        commit = commit_change(
            app.config["CONFIG_ROOT"],
            schema.filename,
            new_text,
            msg,
            author=app.config["AUTHOR"],
        )
        if commit.ok:
            flash_msg = f"Saved → {schema.filename}"
            if commit.commit_hash:
                flash_msg += f" (commit {commit.commit_hash})"
            flash(flash_msg, "success")
        else:
            flash(f"Save failed: {commit.error_message}", "warning")

        return redirect(url_for("view_ini", name=name))

    # ----- Template instance management (v2.1) -----

    @app.route("/ini/<name>/instance/add", methods=["POST"])
    def add_instance(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            abort(403)

        pattern = (request.form.get("pattern") or "").strip()
        instance_id = (request.form.get("instance_id") or "").strip()
        if not pattern or not instance_id:
            flash("Both pattern and instance ID are required.", "warning")
            return redirect(url_for("edit_ini", name=name))

        try:
            new_text = add_template_instance(
                schema, pattern, instance_id,
                config_root=app.config["CONFIG_ROOT"],
            )
        except InstanceError as e:
            flash(f"Cannot add instance: {e}", "warning")
            return redirect(url_for("edit_ini", name=name))

        result = commit_change(
            app.config["CONFIG_ROOT"],
            schema.filename,
            new_text,
            f"UI: added instance {instance_id} to {schema.filename}",
            author=app.config["AUTHOR"],
        )
        if result.ok:
            msg = f"Added instance to {schema.filename}"
            if result.commit_hash:
                msg += f" (commit {result.commit_hash})"
            flash(msg, "success")
        else:
            flash(f"Save failed: {result.error_message}", "warning")
        return redirect(url_for("edit_ini", name=name))

    @app.route("/ini/<name>/instance/delete", methods=["POST"])
    def delete_instance(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            abort(403)

        target = (request.form.get("instance") or "").strip()
        if not target:
            flash("No instance specified.", "warning")
            return redirect(url_for("edit_ini", name=name))

        try:
            new_text = delete_template_instance(
                schema, target, config_root=app.config["CONFIG_ROOT"],
            )
        except InstanceError as e:
            flash(f"Cannot delete: {e}", "warning")
            return redirect(url_for("edit_ini", name=name))

        result = commit_change(
            app.config["CONFIG_ROOT"],
            schema.filename,
            new_text,
            f"UI: deleted instance {target} from {schema.filename}",
            author=app.config["AUTHOR"],
        )
        if result.ok:
            msg = f"Deleted [{target}]"
            if result.commit_hash:
                msg += f" (commit {result.commit_hash})"
            flash(msg, "success")
        else:
            flash(f"Save failed: {result.error_message}", "warning")
        return redirect(url_for("edit_ini", name=name))

    @app.route("/ini/<name>/instance/reorder", methods=["POST"])
    def reorder_instances(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            abort(403)

        pattern = (request.form.get("pattern") or "").strip()
        order_csv = (request.form.get("order") or "").strip()
        new_order = [x.strip() for x in order_csv.split(",") if x.strip()]
        if not pattern or not new_order:
            flash("Both pattern and a non-empty order are required.", "warning")
            return redirect(url_for("edit_ini", name=name))

        try:
            new_text = reorder_template_instances(
                schema, pattern, new_order,
                config_root=app.config["CONFIG_ROOT"],
            )
        except InstanceError as e:
            flash(f"Cannot reorder: {e}", "warning")
            return redirect(url_for("edit_ini", name=name))

        result = commit_change(
            app.config["CONFIG_ROOT"],
            schema.filename,
            new_text,
            f"UI: reordered {pattern} in {schema.filename}",
            author=app.config["AUTHOR"],
        )
        if result.ok:
            msg = f"Reordered {pattern}"
            if result.commit_hash:
                msg += f" (commit {result.commit_hash})"
            flash(msg, "success")
        else:
            flash(f"Save failed: {result.error_message}", "warning")
        return redirect(url_for("edit_ini", name=name))

    @app.route("/ini/<name>/history")
    def view_history(name: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        commits = list_history(app.config["CONFIG_ROOT"], schema.filename)
        return render_template(
            "ini_history.html",
            schema=schema, active=name, commits=commits,
        )

    @app.route("/ini/<name>/history/<commit_hash>")
    def view_commit(name: str, commit_hash: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not re.match(r"^[0-9a-f]{7,40}$", commit_hash):
            abort(400)
        content = get_file_at_commit(
            app.config["CONFIG_ROOT"], schema.filename, commit_hash,
        )
        if content is None:
            abort(404)
        current_path = app.config["CONFIG_ROOT"] / schema.filename
        current = current_path.read_text(encoding="utf-8") if current_path.exists() else ""
        diff = generate_unified_diff(current, content, schema.filename)
        added, removed = count_changes(diff)
        return render_template(
            "ini_commit_view.html",
            schema=schema, active=name,
            commit_hash=commit_hash, content=content,
            diff=diff, added=added, removed=removed,
        )

    @app.route("/ini/<name>/rollback/<commit_hash>", methods=["POST"])
    def rollback(name: str, commit_hash: str):
        schema = registry.by_name(name)
        if schema is None:
            abort(404)
        if not app.config["ALLOW_EDIT"]:
            abort(403)
        if not re.match(r"^[0-9a-f]{7,40}$", commit_hash):
            abort(400)
        content = get_file_at_commit(
            app.config["CONFIG_ROOT"], schema.filename, commit_hash,
        )
        if content is None:
            flash(f"Could not read file at commit {commit_hash}", "warning")
            return redirect(url_for("view_history", name=name))
        result = validate_candidate(
            name, content, app.config["CONFIG_ROOT"], schema.filename,
        )
        if not result.ok:
            flash(
                f"Rollback to {commit_hash} would fail validation: {result.display_error}",
                "warning",
            )
            return redirect(url_for("view_history", name=name))
        commit = commit_change(
            app.config["CONFIG_ROOT"],
            schema.filename,
            content,
            f"UI: rollback {schema.filename} to {commit_hash}",
            author=app.config["AUTHOR"],
        )
        flash(
            f"Rolled back → {schema.filename} (commit {commit.commit_hash})",
            "success" if commit.ok else "warning",
        )
        return redirect(url_for("view_ini", name=name))

    @app.route("/health")
    def health():
        return {"status": "ok", "schemas_loaded": len(registry.schemas)}

    return app

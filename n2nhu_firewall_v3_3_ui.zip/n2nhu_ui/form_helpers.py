"""
form_helpers — convert HTML form submissions back into INI text.

The editing UI posts fields named like:
  sec__<real_section_name>__field__<field_name>      for FIXED/TEMPLATE fields
  sec__<real_section_name>__mapkey__<index>          for MAP section keys
  sec__<real_section_name>__mapval__<index>          for MAP section values
  sec__<real_section_name>__present                  presence flag (if checkbox)
  ini__section_order                                 comma-separated real names
  ini__template_section_order__<pattern>             comma-separated real names
                                                     for a given template pattern

This module parses that form and reconstructs a list of
(real_name, section_spec, data) tuples suitable for write_ini().

Section ordering is driven by the submitted ini__section_order field when
present; otherwise we fall back to the schema's declared order.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .ini_reader import read_ini
from .ini_writer import parse_form_value, write_ini
from .schema_loader import SchemaLoader
from .schema_models import FieldType, IniSchema, Registry, SectionKind


def _form_to_ini(schema: IniSchema, form, config_root: Path) -> str:
    """
    Top-level: take a MultiDict form submission and produce the new INI text.

    For v2 we take a conservative approach: operators edit the existing
    sections (same real names, same map keys) and update values. Adding
    new sections / new map keys / new template instances is v2.1.

    We base the structure on the CURRENT file (read via read_ini) and
    overlay form values onto it.
    """
    rendered = read_ini(schema, config_root)

    sections_out: list[tuple[str, Any, Any]] = []

    for rs in rendered.sections:
        spec = rs.spec
        real_name = rs.real_name

        if spec.kind == SectionKind.MAP:
            # Keep each (key, new_value) pair
            map_entries = []
            for i, (k, _) in enumerate(rs.map_entries):
                form_key = f"sec__{real_name}__mapval__{i}"
                if form_key in form:
                    raw = form.get(form_key)
                    parsed = parse_form_value(raw, spec.value_type)
                    map_entries.append((k, parsed))
                else:
                    # Fall back to current value if form didn't include it
                    map_entries.append(rs.map_entries[i])
            sections_out.append((real_name, spec, map_entries))
        else:
            # FIXED or TEMPLATE — walk schema fields
            field_data: dict[str, Any] = {}
            for fspec in spec.fields:
                form_key = f"sec__{real_name}__field__{fspec.name}"
                if fspec.type == FieldType.BOOLEAN:
                    # Checkbox: presence = True, absence = False
                    field_data[fspec.name] = (form_key in form)
                elif form_key in form:
                    raw = form.get(form_key)
                    try:
                        field_data[fspec.name] = parse_form_value(raw, fspec.type)
                    except ValueError as e:
                        raise ValueError(
                            f"[{real_name}.{fspec.name}] {e}"
                        ) from e
                else:
                    # Not in form — preserve existing value if any
                    existing = rs.fields.get(fspec.name)
                    if existing is not None and not existing.is_default:
                        field_data[fspec.name] = existing.value
            sections_out.append((real_name, spec, field_data))

    return write_ini(schema, sections_out)


# ---------------------------------------------------------------------------
# v2.1: new-instance creation and deletion for template sections
# ---------------------------------------------------------------------------


class InstanceError(ValueError):
    """Raised when adding/deleting a template instance violates schema rules."""


def _validate_instance_id(pattern: str, instance_id: str) -> str:
    """Validate that instance_id is a legal name for a template pattern.

    Returns the full real-section name (e.g. 'pbr_voice' from pattern
    'pbr*' and instance_id 'voice'). Operator-supplied IDs are allowed
    to be either the trailing token alone ('voice') or the full real
    name ('pbr_voice'); we accept both and canonicalize.

    Raises InstanceError if the ID contains characters illegal in INI
    section names or if it's empty.
    """
    if not instance_id or not instance_id.strip():
        raise InstanceError("instance ID cannot be empty")
    instance_id = instance_id.strip()
    # Restrict to INI-safe characters: letters, digits, underscore, hyphen.
    # Brackets, equals, and whitespace would break the file.
    import re
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", instance_id):
        raise InstanceError(
            f"instance ID {instance_id!r} contains invalid characters; "
            f"use letters, digits, underscore, hyphen only",
        )

    if "*" not in pattern:
        raise InstanceError(f"section {pattern!r} is not a template")
    prefix, _, suffix = pattern.partition("*")

    # If operator already supplied the prefix, accept; otherwise prepend
    if instance_id.startswith(prefix) and (not suffix or instance_id.endswith(suffix)):
        full = instance_id
    else:
        full = f"{prefix}{instance_id}{suffix}"
    return full


def add_template_instance(
    schema: IniSchema,
    pattern: str,
    instance_id: str,
    config_root: Path,
) -> str:
    """Add a new template instance to the live INI file and return the
    new file text.

    Behavior:
      - Validates that pattern is a TEMPLATE section in the schema
      - Canonicalizes instance_id and ensures the new section name
        doesn't already exist in the file
      - Appends a section with schema defaults (only fields whose
        `default` is non-empty are written; required fields without a
        default are written as empty so the operator sees them)
      - If the schema has a `*_order` field for this template, appends
        the new ID to that field's CSV value
      - Returns the new INI text (does not write to disk; caller
        decides whether to overlay onto the form-submitted text or
        write directly)

    Raises InstanceError on schema or naming violations.
    """
    spec = schema.section_by_name(pattern)
    if spec is None:
        raise InstanceError(f"unknown section pattern {pattern!r}")
    if spec.kind != SectionKind.TEMPLATE:
        raise InstanceError(f"section {pattern!r} is not a template")

    full_name = _validate_instance_id(pattern, instance_id)

    rendered = read_ini(schema, config_root)
    existing = {rs.real_name for rs in rendered.sections}
    if full_name in existing:
        raise InstanceError(
            f"section [{full_name}] already exists; pick a different ID",
        )

    # Build new field_data using schema defaults
    field_data: dict[str, Any] = {}
    for fspec in spec.fields:
        if fspec.default is None or fspec.default == "":
            # Skip — write_ini will omit unless we set explicitly
            if fspec.type == FieldType.BOOLEAN:
                # Booleans always serialize, default to False
                field_data[fspec.name] = False
            continue
        field_data[fspec.name] = fspec.default

    # Reconstruct the section list, appending the new template instance
    sections_out: list[tuple[str, Any, Any]] = []
    new_appended = False
    last_template_index = -1

    for i, rs in enumerate(rendered.sections):
        if rs.spec.kind == SectionKind.MAP:
            sections_out.append((rs.real_name, rs.spec, rs.map_entries))
        else:
            existing_data: dict[str, Any] = {}
            for fname, rf in rs.fields.items():
                if not rf.is_default:
                    existing_data[fname] = rf.value
            sections_out.append((rs.real_name, rs.spec, existing_data))

        # Track the last instance of this same template so we can
        # insert the new one immediately after, keeping like with like
        if rs.spec.name == pattern:
            last_template_index = i

    # Insert at the position right after the last existing instance, or
    # at the end if there are none yet.
    insertion_point = (
        last_template_index + 1 if last_template_index >= 0
        else len(sections_out)
    )
    sections_out.insert(insertion_point, (full_name, spec, field_data))

    # If there's a *_order section/field that should be auto-updated,
    # find it (by convention: a fixed section whose name matches and
    # has a 'rules' or 'tunnels' field that's a CSV).
    sections_out = _maybe_append_to_order(
        schema, sections_out, pattern, full_name,
    )

    return write_ini(schema, sections_out)


def _maybe_append_to_order(
    schema: IniSchema,
    sections_out: list[tuple[str, Any, Any]],
    pattern: str,
    new_name: str,
) -> list[tuple[str, Any, Any]]:
    """If the schema has a fixed section that orders this template, add
    the new name to that section's CSV field.

    Convention: a fixed section is treated as an order list for a given
    template pattern only when the schema explicitly declares it so via
    naming. Specifically:

      - For the security/PBR/capture schemas: the order section is
        named "<schema>_order" (e.g. policy_order, pbr_order,
        capture_order) and contains a 'rules' csv_string field.
      - For ipsec: the order section [ipsec_order] orders TUNNELS only,
        via a 'tunnels' csv_string field. Proposals and IKE policies
        have no order list because they are referenced by other
        sections rather than evaluated in sequence.

    We encode that by matching pattern against an allow-list of
    template-prefixes-that-have-an-order-list. Templates not on the
    allow-list (proposals, IKE policies, addresses, services, etc.)
    skip the order update entirely.
    """
    # Pattern-prefix -> the order-section/field association.
    # Only templates that conceptually live in an evaluation queue
    # appear here. Reference-only templates (proposals, addresses,
    # services, schedules, etc.) are intentionally excluded.
    _ORDERED_PATTERNS = {
        "pbr*",
        "p*",          # security policy rules
        "n*",          # NAT rules — note the schema uses 'rules' too
        "cap*",        # capture rules
        "ipsec_tunnel_*",
    }
    if pattern not in _ORDERED_PATTERNS:
        return sections_out

    # Find the order-list candidate by walking the schema. We look for
    # the FIRST fixed section with a csv_string field named 'rules' or
    # 'tunnels'. (Each schema has at most one such field per file, so
    # this is unambiguous in practice.)
    order_section_name: str | None = None
    order_field_name: str | None = None
    for sec in schema.sections:
        if sec.kind != SectionKind.FIXED:
            continue
        for f in sec.fields:
            if f.type == FieldType.CSV_STRING and f.name in ("rules", "tunnels"):
                order_section_name = sec.name
                order_field_name = f.name
                break
        if order_section_name is not None:
            break

    if order_section_name is None or order_field_name is None:
        return sections_out

    # Update the existing entry in sections_out
    for i, (real_name, spec, data) in enumerate(sections_out):
        if real_name == order_section_name and isinstance(data, dict):
            current = data.get(order_field_name, ())
            if isinstance(current, str):
                items = tuple(x.strip() for x in current.split(",") if x.strip())
            elif isinstance(current, (list, tuple)):
                items = tuple(current)
            else:
                items = ()
            if new_name not in items:
                items = items + (new_name,)
            new_data = dict(data)
            new_data[order_field_name] = items
            sections_out[i] = (real_name, spec, new_data)
            break

    return sections_out


def delete_template_instance(
    schema: IniSchema,
    instance_real_name: str,
    config_root: Path,
) -> str:
    """Remove a template instance and return new INI text. Also removes
    the instance from any matching order field so the file stays
    self-consistent."""
    rendered = read_ini(schema, config_root)

    # Confirm the section exists and is a template instance
    matching = [rs for rs in rendered.sections if rs.real_name == instance_real_name]
    if not matching:
        raise InstanceError(f"section [{instance_real_name}] does not exist")
    rs = matching[0]
    if rs.spec.kind != SectionKind.TEMPLATE:
        raise InstanceError(
            f"section [{instance_real_name}] is not a template instance "
            f"and cannot be deleted via this path",
        )

    sections_out: list[tuple[str, Any, Any]] = []
    for rs in rendered.sections:
        if rs.real_name == instance_real_name:
            continue
        if rs.spec.kind == SectionKind.MAP:
            sections_out.append((rs.real_name, rs.spec, rs.map_entries))
        else:
            existing_data: dict[str, Any] = {}
            for fname, rf in rs.fields.items():
                if not rf.is_default:
                    existing_data[fname] = rf.value
            sections_out.append((rs.real_name, rs.spec, existing_data))

    # Remove from order list if present
    sections_out = _strip_from_order(schema, sections_out, instance_real_name)

    return write_ini(schema, sections_out)


def _strip_from_order(
    schema: IniSchema,
    sections_out: list[tuple[str, Any, Any]],
    target_name: str,
) -> list[tuple[str, Any, Any]]:
    """Remove target_name from any *_order field in sections_out."""
    order_section_name: str | None = None
    order_field_name: str | None = None
    for sec in schema.sections:
        if sec.kind != SectionKind.FIXED:
            continue
        for f in sec.fields:
            if f.type == FieldType.CSV_STRING and f.name in ("rules", "tunnels"):
                order_section_name = sec.name
                order_field_name = f.name
                break
        if order_section_name is not None:
            break

    if order_section_name is None:
        return sections_out

    for i, (real_name, spec, data) in enumerate(sections_out):
        if real_name == order_section_name and isinstance(data, dict):
            current = data.get(order_field_name, ())
            if isinstance(current, str):
                items = tuple(x.strip() for x in current.split(",") if x.strip())
            elif isinstance(current, (list, tuple)):
                items = tuple(current)
            else:
                items = ()
            if target_name in items:
                items = tuple(x for x in items if x != target_name)
                new_data = dict(data)
                new_data[order_field_name] = items
                sections_out[i] = (real_name, spec, new_data)
            break

    return sections_out


def reorder_template_instances(
    schema: IniSchema,
    pattern: str,
    new_order: list[str],
    config_root: Path,
) -> str:
    """Update the order field for a template pattern with the given list.

    Validates that each item in new_order is an existing section in
    the file and matches the template pattern. The actual section
    blocks are not moved within the file (operators read a logical
    order from the *_order CSV; physical ordering inside the INI is
    cosmetic). Returns the new INI text.
    """
    spec = schema.section_by_name(pattern)
    if spec is None or spec.kind != SectionKind.TEMPLATE:
        raise InstanceError(f"section {pattern!r} is not a template")

    rendered = read_ini(schema, config_root)
    existing_names = {rs.real_name for rs in rendered.sections}

    for n in new_order:
        if n not in existing_names:
            raise InstanceError(
                f"order references unknown section [{n}]",
            )
        if not schema._matches_template(pattern, n):
            raise InstanceError(
                f"order references [{n}] which does not match template "
                f"{pattern!r}",
            )

    # Find the order-section + field
    order_section_name: str | None = None
    order_field_name: str | None = None
    for sec in schema.sections:
        if sec.kind != SectionKind.FIXED:
            continue
        for f in sec.fields:
            if f.type == FieldType.CSV_STRING and f.name in ("rules", "tunnels"):
                order_section_name = sec.name
                order_field_name = f.name
                break
        if order_section_name is not None:
            break

    if order_section_name is None:
        raise InstanceError(
            f"schema {schema.name!r} has no order field — cannot reorder",
        )

    # Rebuild sections, replacing the order-list entry
    sections_out: list[tuple[str, Any, Any]] = []
    for rs in rendered.sections:
        if rs.real_name == order_section_name:
            new_data: dict[str, Any] = {}
            for fname, rf in rs.fields.items():
                if fname == order_field_name:
                    new_data[fname] = tuple(new_order)
                elif not rf.is_default:
                    new_data[fname] = rf.value
            sections_out.append((rs.real_name, rs.spec, new_data))
        elif rs.spec.kind == SectionKind.MAP:
            sections_out.append((rs.real_name, rs.spec, rs.map_entries))
        else:
            existing_data = {}
            for fname, rf in rs.fields.items():
                if not rf.is_default:
                    existing_data[fname] = rf.value
            sections_out.append((rs.real_name, rs.spec, existing_data))

    return write_ini(schema, sections_out)


def _collect_ref_options(registry: Registry, config_root: Path) -> dict[str, list[str]]:
    """
    Build the typeahead options for every REF field in the schema registry.

    Returns a dict mapping target schema name (e.g. "addresses") to a list
    of available item names read from the live INI tree (e.g.
    ["addr_any", "addr_lan_net", ...]).

    If the live file doesn't exist or can't be read, falls back to names
    extracted from the schema's default_content.
    """
    import configparser
    import re as _re

    result: dict[str, list[str]] = {}

    for schema in registry.schemas:
        file_path = config_root / schema.filename
        names: list[str] = []

        # Parse live file if present
        if file_path.exists():
            cp = configparser.ConfigParser()
            cp.optionxform = str
            try:
                cp.read(file_path, encoding="utf-8")
                names = [s for s in cp.sections()
                         if not s.startswith("_") and not s.startswith("policy_order")
                         and not s.startswith("nat_order") and not s.startswith("pbr_order")
                         and not s.startswith("nat_settings")]
            except configparser.Error:
                names = []
        # Fallback to default_content
        if not names:
            for line in schema.default_content.splitlines():
                m = _re.match(r"^\[([^\]_][^\]]*)\]\s*$", line.strip())
                if m:
                    sect = m.group(1)
                    if sect.startswith("_"):
                        continue
                    if sect in ("policy_order", "nat_order", "pbr_order",
                                "nat_settings", "zones", "defaults"):
                        continue
                    names.append(sect)

        # Special case: zones are map keys, not sections
        if schema.name == "zones":
            # Re-read zones.ini's [zones] section for its map keys
            if file_path.exists():
                cp2 = configparser.ConfigParser()
                cp2.optionxform = str
                try:
                    cp2.read(file_path, encoding="utf-8")
                    if "zones" in cp2:
                        names = list(cp2["zones"].keys())
                except configparser.Error:
                    pass

        # Add "any" as a universally available option for zones
        if schema.name == "zones" and "any" not in names:
            names.insert(0, "any")

        result[schema.name] = sorted(set(names)) if schema.name != "zones" else names

    return result

"""
Schema models — typed descriptions of INI files for the UI.

A Schema describes what sections/fields an INI file can have, what types
the fields are, what their defaults and ranges are, and how they should
render in the UI.

Schemas are the bridge between ConfigLoader's validation logic (Python)
and the UI's rendering logic (Jinja templates). Both read the same
schema files, so they can't drift.

Design: schemas are themselves INI files, stored in n2nhu_ui/schemas/.
A SchemaLoader parses them into these typed objects.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any


class FieldType(enum.Enum):
    """Supported field types for schema-driven UI rendering."""

    INTEGER = "integer"           # number spinner with min/max
    STRING = "string"             # text input
    BOOLEAN = "boolean"           # checkbox
    ENUM = "enum"                 # dropdown (choices from schema)
    CSV_STRING = "csv_string"     # comma-separated list, renders as tag input
    REF = "ref"                   # reference to another object (typeahead)
    IP_ADDRESS = "ip_address"     # single IPv4 address
    IP_NETWORK = "ip_network"     # CIDR (e.g., 192.168.1.0/24)
    IP_RANGE = "ip_range"         # start-end
    PORT = "port"                 # single port 0-65535
    PORT_RANGE = "port_range"     # N or N-M
    HHMM = "hhmm"                 # HH:MM time string
    DSCP = "dscp"                 # 0-63 or symbolic name

    @classmethod
    def parse(cls, raw: str) -> "FieldType":
        key = raw.strip().lower()
        for m in cls:
            if m.value == key:
                return m
        raise ValueError(f"Unknown field type: {raw!r}")


class SectionKind(enum.Enum):
    """
    How a section is structured.

    FIXED    — section with a known name and a fixed set of fields
               (e.g., [defaults] in zones.ini)
    MAP      — section whose keys are user-chosen names mapping to values
               (e.g., [zones] where key = zone name, value = iface list)
    TEMPLATE — repeating sections matching a pattern (e.g., [zone_*] —
               one section per zone, each with the same fields)
    """

    FIXED = "fixed"
    MAP = "map"
    TEMPLATE = "template"

    @classmethod
    def parse(cls, raw: str) -> "SectionKind":
        key = raw.strip().lower()
        for m in cls:
            if m.value == key:
                return m
        raise ValueError(f"Unknown section kind: {raw!r}")


@dataclass(frozen=True)
class FieldSpec:
    """Spec for one field within a section."""

    name: str
    type: FieldType
    label: str = ""
    help_text: str = ""
    default: Any = None
    required: bool = False
    # Numeric bounds (for integer / port / dscp)
    min_value: int | None = None
    max_value: int | None = None
    # Enum choices
    choices: tuple[str, ...] = ()
    # For REF fields: the object registry name whose items become the dropdown
    ref_to: str = ""
    # Section this field belongs to (filled in by loader for convenience)
    section: str = ""


@dataclass(frozen=True)
class SectionSpec:
    """Spec for one section (or section pattern) within an INI."""

    name: str                 # e.g., "zones" or "zone_*" or "defaults"
    kind: SectionKind
    title: str = ""
    description: str = ""
    # Fields (for FIXED or TEMPLATE)
    fields: tuple[FieldSpec, ...] = ()
    # Map-specific metadata (for MAP)
    key_label: str = "Key"
    value_label: str = "Value"
    value_type: FieldType = FieldType.STRING
    value_help: str = ""
    # TEMPLATE: what the named portion of the section name represents
    template_label: str = ""

    def field_by_name(self, name: str) -> FieldSpec | None:
        for f in self.fields:
            if f.name == name:
                return f
        return None


@dataclass(frozen=True)
class IniSchema:
    """Complete schema for one INI file."""

    name: str                 # registry key, e.g., "zones"
    filename: str             # path relative to config root, e.g., "zones.ini"
    title: str
    description: str
    icon: str = "file"
    order: int = 100          # sidebar ordering
    sections: tuple[SectionSpec, ...] = ()
    default_content: str = "" # literal text written by "Restore Defaults"

    def section_by_name(self, name: str) -> SectionSpec | None:
        for s in self.sections:
            if s.name == name:
                return s
        return None

    def section_matching(self, section_name: str) -> SectionSpec | None:
        """
        Find the section spec that matches a real section name in the INI.
        Handles TEMPLATE sections: a real name like 'zone_trusted' matches
        the pattern 'zone_*'.
        """
        # Exact match first
        exact = self.section_by_name(section_name)
        if exact is not None:
            return exact
        # Pattern match
        for s in self.sections:
            if s.kind == SectionKind.TEMPLATE and self._matches_template(s.name, section_name):
                return s
        return None

    @staticmethod
    def _matches_template(pattern: str, name: str) -> bool:
        if "*" not in pattern:
            return False
        prefix, _, suffix = pattern.partition("*")
        return name.startswith(prefix) and name.endswith(suffix) and len(name) > len(prefix) + len(suffix) - 1

    def template_instance_label(self, pattern: str, name: str) -> str:
        """For pattern 'zone_*' and name 'zone_trusted', return 'trusted'."""
        prefix, _, suffix = pattern.partition("*")
        inner = name[len(prefix):]
        if suffix and inner.endswith(suffix):
            inner = inner[:-len(suffix)]
        return inner


@dataclass(frozen=True)
class Registry:
    """Master list of all known INI types."""

    schemas: tuple[IniSchema, ...]

    def by_name(self, name: str) -> IniSchema | None:
        for s in self.schemas:
            if s.name == name:
                return s
        return None

    def ordered(self) -> list[IniSchema]:
        return sorted(self.schemas, key=lambda s: (s.order, s.title))
